import math

from helpers import CFG, flow, ground_vehicle
from drone_safety.core.config import SafetyConfig
from drone_safety.core.preflight import preflight_failures

ARMED_OUTPUT = (True, True)


def pf(v, fl=None, level=0, latched=False, fcu_output=ARMED_OUTPUT, cfg=CFG, age=0.1):
    return preflight_failures(cfg, v, age, fl or flow(), 0.1, level, latched, fcu_output)


def codes(fails):
    return sorted({f.split()[0] for f in fails})


def test_all_good_passes():
    assert pf(ground_vehicle()) == []


def test_no_state_or_link_stops_early():
    assert codes(pf(None)) == ['PF1']
    assert codes(pf(ground_vehicle(), age=2.0)) == ['PF1']
    assert codes(pf(ground_vehicle(connected=False))) == ['PF1']


def test_every_failure_is_listed():
    v = ground_vehicle(armed=True, fcu_prearm_ok=False, battery_voltage_v=0.03,
                       ekf_const_pos_mode=True, roll_rad=math.radians(10), mode='LAND',
                       rc_present=False)
    assert codes(pf(v, flow(healthy_takeoff=False, reason='flow stale'), level=2,
                    fcu_output=(False, False))) == \
        ['PF10', 'PF13', 'PF14', 'PF3', 'PF4', 'PF5', 'PF6', 'PF7', 'PF8', 'PF9']


def test_bench_mode_and_unreachable_command_node():
    assert any('bench mode' in f for f in pf(ground_vehicle(), fcu_output=(False, False)))
    assert any('not reachable' in f for f in pf(ground_vehicle(), fcu_output=None))


def test_battery_limit_unset_fails_on_purpose():
    fails = pf(ground_vehicle(), cfg=SafetyConfig())
    assert any('takeoff_min_voltage not configured' in f for f in fails)


def test_prearm_text_blocks_even_with_bit_set():
    fails = pf(ground_vehicle(last_prearm_text='PreArm: Compass not calibrated'))
    assert fails == ['PF4 FCU_PREARM: PreArm: Compass not calibrated']


def test_height_above_on_ground_limit():
    # e.g. sitting on a box: ArduPilot says on ground but the sensor sees 0.4 m
    assert codes(pf(ground_vehicle(height_above_ground_m=0.4))) == ['PF7']


def test_landed_undefined_uses_height():
    assert pf(ground_vehicle(landed_state=0)) == []
    assert 'PF3' in codes(pf(ground_vehicle(landed_state=0, height_valid=False)))


def test_rc_optional_by_config():
    cfg = SafetyConfig(takeoff_min_voltage=15.6, require_rc_present=False)
    assert pf(ground_vehicle(rc_present=False), cfg=cfg) == []
