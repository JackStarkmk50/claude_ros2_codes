"""safety_supervisor: the veto between the mission and the flight controller.

Phase 6 (bench):
  * health checks and safety level (drone_safety/core/supervisor.py), published on
    /drone/safety_status at 20 Hz (TRANSIENT_LOCAL, so late joiners get the current verdict)
  * pre-flight validation PF1-PF14 (core/preflight.py), also on /drone/safety/preflight_check
  * pilot / FCU override detection (core/override.py), latched
  * command gate (core/gate.py): /drone/control/command -> /drone/control/validated_command
  * /drone/safety/reset: clears latched faults, only disarmed on the ground

Not yet: the FlightOperation gate and "ABORT -> request LAND" (Phase 8). Until then an ABORT
in the air means HOLD is streamed and the pilot lands.
"""

import math
import time

import rclpy
from rcl_interfaces.srv import GetParameters
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from rclpy.time import Time
from std_srvs.srv import Trigger

from drone_interfaces.msg import ControlCommand, FlowStatus, SafetyStatus, VehicleState
from drone_safety.core.config import LEVEL_NAMES, LANDED_ON_GROUND, SafetyConfig
from drone_safety.core.gate import DROP, HOLD, PASS, CommandGate
from drone_safety.core.supervisor import Inputs, SafetyCore

# Parameter defaults. drone_bringup/config/drone.yaml overrides them. Read once at startup:
# the limits cannot be changed while the node runs.
PARAMETERS = {
    'rate_hz': 20.0,
    'telemetry_timeout_s': 1.0,
    'heartbeat_timeout_s': 2.0,
    'ekf_timeout_s': 2.0,
    'max_yaw_rate_deg_s': 30.0,
    'max_yaw_accel_deg_s2': 60.0,
    'max_horizontal_speed_mps': 0.0,
    'max_vertical_speed_mps': 0.0,
    'max_cmd_age_s': 0.3,
    'min_takeoff_alt_m': 0.8,
    'max_takeoff_alt_m': 1.5,
    'hard_ceiling_m': 2.2,
    'ceiling_margin_m': 0.5,
    'min_height_m': 0.5,
    'max_height_m': 2.0,
    'ground_height_max_m': 0.25,
    'max_tilt_deg': 25.0,
    'preflight_max_tilt_deg': 5.0,
    'takeoff_min_voltage': 0.0,
    'takeoff_min_remaining': 0.3,
    'battery_warn_v': 0.0,
    'battery_land_v': 0.0,
    'flow_bad_timeout_s': 1.0,
    'hold_to_land_s': 5.0,
    'require_rc_present': True,
    'allow_auto_land': True,
    'cpu_temp_warn_c': 75.0,
    'cpu_temp_fault_c': 82.0,
    'allowed_sources': ['mission_manager', 'operator'],
    'allowed_pretakeoff_modes': ['STABILIZE', 'ALT_HOLD', 'LOITER', 'GUIDED'],
}
CONFIG_FIELDS = set(SafetyConfig.__dataclass_fields__)
CPU_TEMP_FILE = '/sys/class/thermal/thermal_zone0/temp'

IN_QOS = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                    durability=DurabilityPolicy.VOLATILE)
CMD_QOS = QoSProfile(depth=10, reliability=ReliabilityPolicy.RELIABLE,
                     durability=DurabilityPolicy.VOLATILE)
STATUS_QOS = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                        durability=DurabilityPolicy.TRANSIENT_LOCAL)


class SafetySupervisor(Node):

    def __init__(self):
        super().__init__('safety_supervisor')
        for name, default in PARAMETERS.items():
            self.declare_parameter(name, default)
        p = {name: self.get_parameter(name).value for name in PARAMETERS}
        values = {k: (tuple(v) if isinstance(v, list) else v) for k, v in p.items()
                  if k in CONFIG_FIELDS}
        self.cfg = SafetyConfig(**values)
        self.core = SafetyCore(self.cfg)
        self.gate = CommandGate(self.cfg)

        self.vehicle = None
        self.vehicle_time = None
        self.flow = None
        self.flow_time = None
        self.last_cmd_time = None
        self.stream_active = False
        self.cpu_temp = math.nan
        self.fcu_output = None
        self.fcu_output_time = None
        self.rejected = 0
        self.clamped = 0
        self.verdict = None
        self._last_level = None
        self._land_logged = False

        self.create_subscription(VehicleState, '/drone/vehicle_state', self._on_vehicle, IN_QOS)
        self.create_subscription(FlowStatus, '/drone/flow_status', self._on_flow, IN_QOS)
        self.create_subscription(ControlCommand, '/drone/control/command', self._on_command,
                                 CMD_QOS)
        self.status_pub = self.create_publisher(SafetyStatus, '/drone/safety_status', STATUS_QOS)
        self.cmd_pub = self.create_publisher(ControlCommand, '/drone/control/validated_command',
                                             IN_QOS)
        self.create_service(Trigger, '/drone/safety/preflight_check', self._srv_preflight)
        self.create_service(Trigger, '/drone/safety/reset', self._srv_reset)
        self.param_client = self.create_client(GetParameters, '/fcu_command_node/get_parameters')

        self.create_timer(1.0 / p['rate_hz'], self._tick)
        self.create_timer(1.0, self._slow_tick)
        self.get_logger().info(
            f'up: yaw limit {self.cfg.max_yaw_rate_deg_s} deg/s, translation limits '
            f'{self.cfg.max_horizontal_speed_mps}/{self.cfg.max_vertical_speed_mps} m/s, '
            f'sources {list(self.cfg.allowed_sources)}')

    # ---------------------------------------------------------------- inputs

    def _on_vehicle(self, msg):
        self.vehicle, self.vehicle_time = msg, time.monotonic()

    def _on_flow(self, msg):
        self.flow, self.flow_time = msg, time.monotonic()

    def _inputs(self, now):
        def age(t):
            return now - t if t is not None else math.inf
        fcu_output = self.fcu_output if age(self.fcu_output_time) < 5.0 else None
        return Inputs(vehicle=self.vehicle, vehicle_age=age(self.vehicle_time),
                      flow=self.flow, flow_age=age(self.flow_time),
                      cmd_age=age(self.last_cmd_time), stream_active=self.stream_active,
                      cpu_temp_c=self.cpu_temp, fcu_output=fcu_output)

    def _slow_tick(self):
        try:
            with open(CPU_TEMP_FILE) as fh:
                self.cpu_temp = int(fh.read().strip()) / 1000.0
        except (OSError, ValueError):
            self.cpu_temp = math.nan
        if self.param_client.service_is_ready():
            req = GetParameters.Request(names=['output_enabled', 'allow_arming'])
            self.param_client.call_async(req).add_done_callback(self._on_fcu_params)

    def _on_fcu_params(self, future):
        try:
            values = future.result().values
            self.fcu_output = (values[0].bool_value, values[1].bool_value)
            self.fcu_output_time = time.monotonic()
        except Exception:  # noqa: BLE001  (node went away: PF13 reports it)
            self.fcu_output = None

    # ---------------------------------------------------------------- verdict

    def _tick(self):
        now = time.monotonic()
        v = self.vehicle
        if v is None or not v.armed:
            self.stream_active = False
        self.verdict = self.core.update(now, self._inputs(now))
        self._publish_status()

    def _publish_status(self):
        vd = self.verdict
        s = SafetyStatus()
        s.header.stamp = self.get_clock().now().to_msg()
        s.level = vd.level
        s.latched = vd.latched
        s.motion_allowed = vd.motion_allowed
        s.preflight_ok = vd.preflight_ok
        s.preflight_failures = vd.preflight_failures
        s.active_faults = vd.active_faults
        s.warnings = vd.warnings
        s.commands_rejected = self.rejected
        s.commands_clamped = self.clamped
        self.status_pub.publish(s)

        if vd.level != self._last_level:
            detail = '; '.join(vd.active_faults + vd.warnings) or 'no faults'
            # (rclpy forbids one log call site with two severities, hence two calls)
            if vd.level <= 1:
                self.get_logger().info(f'safety level {LEVEL_NAMES[vd.level]}: {detail}')
            else:
                self.get_logger().warn(f'safety level {LEVEL_NAMES[vd.level]}: {detail}')
            self._last_level = vd.level
        if vd.request_land and not self._land_logged:
            self.get_logger().error(
                'ABORT in the air: LAND must be requested. Automatic LAND arrives in Phase 8; '
                'until then HOLD is streamed and the PILOT must land.')
            self._land_logged = True
        elif not vd.request_land:
            self._land_logged = False

    # ---------------------------------------------------------------- command gate

    def _on_command(self, cmd):
        now = time.monotonic()
        if self.verdict is None:
            return
        age = (self.get_clock().now() - Time.from_msg(cmd.header.stamp)).nanoseconds * 1e-9
        vehicle_fresh = (self.vehicle_time is not None
                         and now - self.vehicle_time <= self.cfg.telemetry_timeout_s)
        result = self.gate.process(cmd, age, now, self.verdict.level, self.verdict.latched,
                                   self.vehicle, vehicle_fresh)
        if result.action == DROP:
            self.rejected += 1
            self.get_logger().warn(f'command rejected: {result.reason}',
                                   throttle_duration_sec=2.0)
            return
        # a valid command from an allowed source: the mission stream is alive
        self.last_cmd_time = now
        if self.vehicle is not None and self.vehicle.armed \
                and self.vehicle.landed_state != LANDED_ON_GROUND:
            self.stream_active = True

        out = ControlCommand()
        out.header.stamp = self.get_clock().now().to_msg()
        out.source = cmd.source
        out.seq = cmd.seq
        out.max_age_s = self.cfg.max_cmd_age_s
        if result.action == HOLD:
            out.mode = ControlCommand.MODE_HOLD
        else:
            assert result.action == PASS
            out.mode = ControlCommand.MODE_BODY_VELOCITY
            out.vx_mps, out.vy_mps, out.vz_mps = result.vx, result.vy, result.vz
            out.yaw_rate_rad_s = result.yaw_rate
            if result.clamped:
                self.clamped += 1
        self.cmd_pub.publish(out)

    # ---------------------------------------------------------------- services

    def _srv_preflight(self, request, response):
        vd = self.core.update(time.monotonic(), self._inputs(time.monotonic()))
        response.success = vd.preflight_ok
        response.message = 'PRE-FLIGHT OK' if vd.preflight_ok else \
            'PRE-FLIGHT FAILED: ' + ' | '.join(vd.preflight_failures)
        return response

    def _srv_reset(self, request, response):
        ok, message = self.core.reset(time.monotonic(), self._inputs(time.monotonic()))
        response.success = ok
        response.message = message
        if ok:
            self.get_logger().info(f'reset: {message}')
        else:
            self.get_logger().warn(f'reset refused: {message}')
        return response


def main(args=None):
    rclpy.init(args=args)
    node = SafetySupervisor()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        # A second Ctrl-C during cleanup (terminal + launch both send SIGINT) must not
        # print a traceback.
        try:
            node.destroy_node()
            rclpy.try_shutdown()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
