"""Command gate for the velocity / yaw stream (ARCHITECTURE §11.4)."""

import math
from dataclasses import dataclass

from drone_safety.core.config import LANDED_IN_AIR, LEVEL_DEGRADED, finite

MODE_HOLD = 0
MODE_BODY_VELOCITY = 1

PASS = 'PASS'      # forward the (possibly clamped) command
HOLD = 'HOLD'      # forward a zero-velocity HOLD instead
DROP = 'DROP'      # invalid: count and forward nothing (the command node times out to HOLD)


@dataclass
class GateResult:
    action: str
    reason: str = ''
    vx: float = 0.0
    vy: float = 0.0
    vz: float = 0.0
    yaw_rate: float = 0.0
    clamped: bool = False


def _clamp(x, limit):
    return max(-limit, min(limit, x))


class CommandGate:

    def __init__(self, cfg):
        self.cfg = cfg
        self._last_seq = {}
        self._last_yaw_rate = 0.0
        self._last_time = None

    def _hold(self, reason, now):
        self._last_yaw_rate = 0.0
        self._last_time = now
        return GateResult(HOLD, reason)

    def process(self, cmd, age_s, now, level, latched, vehicle, vehicle_fresh,
                op_in_progress=False):
        cfg = self.cfg
        # Validity first, so an invalid or foreign command is never counted as a live
        # mission stream, whatever the safety level.
        # 1. source
        if cmd.source not in cfg.allowed_sources:
            return GateResult(DROP, f'source "{cmd.source}" not allowed')
        # 2. sequence
        last = self._last_seq.get(cmd.source)
        if last is not None and cmd.seq <= last:
            return GateResult(DROP, f'seq {cmd.seq} not increasing (last {last})')
        self._last_seq[cmd.source] = cmd.seq
        # 3. age
        max_age = cfg.max_cmd_age_s
        if finite(cmd.max_age_s) and cmd.max_age_s > 0.0:
            max_age = min(max_age, cmd.max_age_s)
        if not finite(age_s) or age_s < -0.05 or age_s > max_age:
            return GateResult(DROP, f'command age {age_s:.2f} s > {max_age:.2f} s')
        # 4. numbers
        if not finite(cmd.vx_mps, cmd.vy_mps, cmd.vz_mps, cmd.yaw_rate_rad_s):
            return GateResult(DROP, 'non-finite value')
        # 5. mode
        if cmd.mode not in (MODE_HOLD, MODE_BODY_VELOCITY):
            return GateResult(DROP, f'unknown mode {cmd.mode}')
        # 6. safety level
        if level > LEVEL_DEGRADED or latched:
            return self._hold('safety level does not allow motion', now)
        # 7. vehicle state
        if not vehicle_fresh or vehicle is None:
            return self._hold('vehicle state stale', now)
        if vehicle.mode != 'GUIDED' or vehicle.landed_state != LANDED_IN_AIR:
            return self._hold(f'not flying in GUIDED (mode {vehicle.mode}, '
                              f'landed_state {vehicle.landed_state})', now)
        if op_in_progress:
            return self._hold('flight operation in progress', now)
        if cmd.mode == MODE_HOLD:
            return self._hold('HOLD requested', now)
        # 8. clamp
        vx = _clamp(cmd.vx_mps, cfg.max_horizontal_speed_mps)
        vy = _clamp(cmd.vy_mps, cfg.max_horizontal_speed_mps)
        vz = _clamp(cmd.vz_mps, cfg.max_vertical_speed_mps)
        yaw = _clamp(cmd.yaw_rate_rad_s, cfg.max_yaw_rate_rad_s)
        # 9. yaw acceleration
        dt = 0.1 if self._last_time is None else min(max(now - self._last_time, 0.0), 0.2)
        step = cfg.max_yaw_accel_rad_s2 * dt
        yaw = self._last_yaw_rate + _clamp(yaw - self._last_yaw_rate, step)
        clamped = any(not math.isclose(a, b, abs_tol=1e-6) for a, b in (
            (vx, cmd.vx_mps), (vy, cmd.vy_mps), (vz, cmd.vz_mps), (yaw, cmd.yaw_rate_rad_s)))
        self._last_yaw_rate = yaw
        self._last_time = now
        # 10. the node publishes it, stamped now
        return GateResult(PASS, 'clamped' if clamped else '', vx, vy, vz, yaw, clamped)
