#!/usr/bin/env python3
"""Check the approach distance estimate on the ground before flying it (sends nothing).

  python3 distance_check.py                     print the estimate once per second
  python3 distance_check.py --at 3.0            you stand at a tape-measured 3.0 m: also prints
                                                the camera_vfov_deg that would make it exact

Needs the camera, yolo_detector and target_tracker running (perception.launch.py). Hold or put
the drone at its flying height (about 1.2 m, camera level) and stand upright, whole body in the
picture. Uses the same formulas as the mission (drone_mission.core.mission), with
approach_person_height_m and camera_vfov_deg from drone.yaml unless you pass them.
"""

import argparse
import math
import os
import statistics
import sys
import time

import rclpy
import yaml
from rclpy.node import Node

from drone_interfaces.msg import TrackedTarget
from drone_mission.core.mission import estimate_distance_from_top_m, estimate_distance_m

CONFIG = os.path.expanduser('~/drone_ws/src/drone_bringup/config/drone.yaml')


def defaults():
    try:
        p = yaml.safe_load(open(CONFIG))['mission_manager']['ros__parameters']
        return p.get('approach_person_height_m', 1.7), p.get('camera_vfov_deg', 46.8)
    except (OSError, KeyError, TypeError):
        return 1.7, 46.8


def main():
    h0, v0 = defaults()
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--at', type=float, help='true distance (m) you are standing at')
    p.add_argument('--height', type=float, default=h0, help=f'person height m ({h0})')
    p.add_argument('--vfov', type=float, default=v0, help=f'camera vertical FOV deg ({v0})')
    p.add_argument('--camera-height', type=float, default=1.2,
                   help='camera height m, for the head estimate (1.2)')
    a = p.parse_args()
    rclpy.init()
    node = Node('distance_check')
    last = []
    node.create_subscription(TrackedTarget, '/drone/perception/target',
                             lambda m: last.__setitem__(slice(None), [m]), 10)
    sizes = []
    print(f'person height {a.height} m, vfov {a.vfov} deg, camera height {a.camera_height} m')
    try:
        while True:
            end = time.monotonic() + 1.0
            while time.monotonic() < end:
                rclpy.spin_once(node, timeout_sec=0.05)
            m = last[0] if last else None
            if m is None or m.state != 2 or m.image_height <= 0 or m.bbox.size_y <= 0:
                print('no person TRACKING' if m is not None else 'no target message yet')
                continue
            h = m.bbox.size_y / m.image_height
            top = (m.bbox.center.position.y - m.bbox.size_y / 2) / m.image_height
            bottom = (m.bbox.center.position.y + m.bbox.size_y / 2) / m.image_height
            d = estimate_distance_m(h, a.height, a.vfov)
            dh = estimate_distance_from_top_m(top, a.height, a.camera_height, a.vfov)
            cut = ' FEET CUT OFF (the mission uses the head)' if bottom >= 0.98 else ''
            cut += ' HEAD CUT OFF (too close)' if top <= 0.02 else ''
            line = f'by size ~{d:.2f} m, by head ~{dh:.2f} m, box {h:.2f} of the picture{cut}'
            if a.at and not cut:
                sizes.append(h)
                hm = statistics.median(sizes[-10:])
                vfov = math.degrees(2 * math.atan(a.height / (2 * a.at * hm)))
                line += f' | error {d - a.at:+.2f} m, exact with camera_vfov_deg {vfov:.1f}'
            print(line, flush=True)
    except KeyboardInterrupt:
        return 0
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == '__main__':
    sys.exit(main())
