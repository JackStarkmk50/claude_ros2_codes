"""Approach: fly closer to the tracked person and keep an estimated distance (sim first)."""

import math

from drone_mission.core import mission as m
from drone_mission.core.mission import (Goal, Mission, MissionConfig, approach_speed,
                                        estimate_distance_from_top_m, estimate_distance_m,
                                        validate_goal)
from test_mission import Sim

ON = MissionConfig(enable_approach=True)


class ApproachSim(Sim):
    """Sim + a person at a distance: forward speed closes it, the box grows as it closes."""

    def __init__(self, distance_m, person_height_m=1.7, **kw):
        super().__init__(**kw)
        self.distance = distance_m
        self.person_height = person_height_m
        self.vx_log = []

    def obs(self):
        o = super().obs()
        o.forward_speed_mps = self.last_vx if hasattr(self, 'last_vx') else 0.0
        if o.target_state == m.TGT_TRACKING:
            k = 2 * self.distance * math.tan(math.radians(46.8) / 2)   # metres per image
            cam = o.height_m if math.isfinite(o.height_m) else 1.2
            top = max(0.0, 0.5 - (self.person_height - cam) / k)
            bottom = min(1.0, 0.5 + cam / k)
            o.bbox_top_norm, o.bbox_bottom_norm = top, bottom
            o.bbox_height_norm = bottom - top
        return o

    def run(self, mission, seconds, handler=None, dt=0.1):
        end = self.t + seconds
        step = None
        while self.t < end and not mission.done:
            n = len(self.commands)
            step = Sim.run(self, mission, dt / 2, handler, dt)
            self.last_vx = 0.0
            if len(self.commands) > n:
                cmd = self.commands[-1][2]
                vx = cmd[2] if cmd[0] == m.MODE_BODY_VELOCITY else 0.0
                self.last_vx = vx
                self.vx_log.append((self.commands[-1][1], vx, self.distance))
                if self.person is not None:
                    off = math.radians(self.person - math.degrees(self.yaw))
                    self.distance = max(0.3, self.distance - vx * dt * math.cos(off))
        return step


def test_distance_estimate_matches_the_pinhole_model():
    # 1.7 m person at 3 m with a 46.8 deg vertical FOV fills about 52 % of the picture
    h = 1.7 / (2 * 3.0 * math.tan(math.radians(46.8) / 2))
    assert abs(estimate_distance_m(h, 1.7, 46.8) - 3.0) < 1e-9
    assert math.isnan(estimate_distance_m(0.0, 1.7, 46.8))
    assert math.isnan(estimate_distance_m(math.nan, 1.7, 46.8))


def test_distance_from_the_head_when_the_feet_are_cut_off():
    k = 2 * 2.5 * math.tan(math.radians(46.8) / 2)
    top = 0.5 - (1.7 - 1.2) / k
    assert abs(estimate_distance_from_top_m(top, 1.7, 1.2, 46.8) - 2.5) < 1e-9
    assert math.isnan(estimate_distance_from_top_m(0.48, 1.7, 1.2, 46.8))   # head at centre
    assert math.isnan(estimate_distance_from_top_m(0.2, 1.3, 1.2, 46.8))    # not taller
    assert math.isnan(estimate_distance_from_top_m(0.2, 1.7, math.nan, 46.8))


def test_approach_speed_is_forward_only_and_limited():
    assert approach_speed(6.0, 3.0, 0.3, 0.3, 0.3, False, 0.1) == 0.3
    assert 0 < approach_speed(3.5, 3.0, 0.3, 0.3, 0.3, False, 0.1) <= 0.15
    assert approach_speed(3.2, 3.0, 0.3, 0.3, 0.3, False, 0.1) == 0.0      # deadband
    assert approach_speed(2.0, 3.0, 0.3, 0.3, 0.3, False, 0.1) == 0.0      # too close: no reverse
    assert approach_speed(2.0, 3.0, 0.3, 0.3, 0.3, True, 0.1) == -0.1
    assert approach_speed(math.nan, 3.0, 0.3, 0.3, 0.3, True, 0.1) == 0.0


def test_goal_with_approach_is_refused_while_switched_off():
    sim = Sim()
    fails = validate_goal(MissionConfig(), Goal(approach=True), sim.obs())
    assert any('switched off' in f for f in fails)
    assert validate_goal(ON, Goal(approach=True), sim.obs()) == []
    assert validate_goal(ON, Goal(approach=True, approach_distance_m=1.0), sim.obs())
    assert validate_goal(ON, Goal(approach=True, approach_distance_m=9.0), sim.obs())
    # enable_approach alone changes nothing for a normal goal
    assert validate_goal(ON, Goal(), sim.obs()) == []


def test_without_approach_vx_is_always_zero():
    sim = ApproachSim(6.0, person_bearing=20.0, airborne=True)
    mis = Mission(ON, Goal(autonomous_takeoff=False, track_duration_s=5.0), 0.0)
    sim.run(mis, 60)
    assert mis.done and all(vx == 0.0 for _, vx, _ in sim.vx_log)
    assert abs(sim.distance - 6.0) < 1e-9


def test_approach_reaches_the_distance_then_holds_for_the_track_time():
    sim = ApproachSim(6.0, person_bearing=60.0)
    mis = Mission(ON, Goal(track_duration_s=10.0, approach=True), 0.0)
    sim.run(mis, 200)
    r = mis.result
    assert r.outcome == m.OUTCOME_COMPLETED and r.landed_and_disarmed, r.message
    assert abs(sim.distance - 3.0) <= ON.approach_deadband_m + 0.05, sim.distance
    assert 'travelled' in r.message and 'wanted 3.0 m' in r.message
    # forward speed only while tracking, never above the limit, never backwards
    for state, vx, _ in sim.vx_log:
        assert vx >= 0.0 and vx <= ON.approach_max_speed_mps + 1e-9
        if vx > 0.0:
            assert state == m.TRACKING
    # the 10 s were counted after arriving, so tracking lasted longer than 10 s
    tracking = [1 for s, _, _ in sim.vx_log if s == m.TRACKING]
    assert len(tracking) * 0.1 > 15.0


def test_turns_to_face_the_person_before_moving():
    sim = ApproachSim(6.0, person_bearing=25.0, airborne=True)
    mis = Mission(ON, Goal(autonomous_takeoff=False, track_duration_s=5.0, approach=True), 0.0)
    sim.run(mis, 1.0)
    # person near the edge of the picture: turning, not moving forward yet
    assert all(vx == 0.0 for _, vx, _ in sim.vx_log[:5])
    sim.run(mis, 120)
    assert mis.done and any(vx > 0 for _, vx, _ in sim.vx_log)


def test_travel_limit_stops_the_approach():
    cfg = MissionConfig(enable_approach=True, approach_max_travel_m=1.0, approach_timeout_s=20.0)
    sim = ApproachSim(6.0, person_bearing=0.0, airborne=True)
    mis = Mission(cfg, Goal(autonomous_takeoff=False, track_duration_s=5.0, approach=True), 0.0)
    sim.run(mis, 120)
    assert mis.result.outcome == m.OUTCOME_COMPLETED
    assert 5.0 - 0.1 <= sim.distance <= 5.0 + 0.05      # stopped after about 1 m
    assert 'travel limit' in mis.result.message and 'not reached' in mis.result.message


def test_person_filling_the_picture_means_no_forward_motion():
    sim = ApproachSim(0.8, person_bearing=0.0, airborne=True)     # head above the picture
    mis = Mission(ON, Goal(autonomous_takeoff=False, track_duration_s=3.0, approach=True), 0.0)
    sim.run(mis, 60)
    assert mis.result.outcome == m.OUTCOME_COMPLETED
    assert all(vx == 0.0 for _, vx, _ in sim.vx_log)


def test_person_walking_away_is_followed_up_to_the_travel_limit():
    sim = ApproachSim(3.0, person_bearing=0.0, airborne=True)
    mis = Mission(ON, Goal(autonomous_takeoff=False, track_duration_s=30.0, approach=True), 0.0)
    for _ in range(300):
        sim.distance += 0.02                         # walking away at 0.2 m/s
        sim.run(mis, 0.1)
    assert mis.travel_m > 3.0                        # it followed
    assert mis.travel_m <= ON.approach_max_travel_m + 0.05


def test_safety_hold_stops_forward_motion():
    sim = ApproachSim(6.0, person_bearing=0.0, airborne=True)
    mis = Mission(ON, Goal(autonomous_takeoff=False, track_duration_s=20.0, approach=True), 0.0)
    sim.run(mis, 3)
    sim.level = m.LEVEL_HOLD
    n = len(sim.vx_log)
    sim.run(mis, 2)
    assert all(vx == 0.0 for _, vx, _ in sim.vx_log[n:])


def test_approach_to_2_5_m_uses_the_head_once_the_feet_leave_the_picture():
    sim = ApproachSim(6.0, person_bearing=0.0, airborne=True)
    mis = Mission(ON, Goal(autonomous_takeoff=False, track_duration_s=5.0, approach=True,
                           approach_distance_m=2.5), 0.0)
    details = []
    while not mis.done and sim.t < 120:
        step = sim.run(mis, 0.1)
        details.append(step.detail if step else '')
    assert mis.result.outcome == m.OUTCOME_COMPLETED
    assert abs(sim.distance - 2.5) <= ON.approach_deadband_m + 0.05, sim.distance
    assert any('by size' in d for d in details) and any('by head' in d for d in details)


REV = MissionConfig(enable_approach=True, approach_allow_reverse=True)


def test_reverse_off_never_backs_away_when_the_person_comes_closer():
    sim = ApproachSim(3.0, person_bearing=0.0, airborne=True)
    mis = Mission(ON, Goal(autonomous_takeoff=False, track_duration_s=20.0, approach=True), 0.0)
    for _ in range(100):
        sim.distance = max(1.5, sim.distance - 0.02)      # walking closer at 0.2 m/s
        sim.run(mis, 0.1)
    assert all(vx >= 0.0 for _, vx, _ in sim.vx_log)
    assert mis.reverse_m == 0.0


def test_reverse_on_backs_away_to_keep_the_distance():
    sim = ApproachSim(3.0, person_bearing=0.0, airborne=True)
    mis = Mission(REV, Goal(autonomous_takeoff=False, track_duration_s=40.0, approach=True), 0.0)
    sim.run(mis, 3)
    for _ in range(40):                                   # 0.8 m closer over 4 s
        sim.distance -= 0.02
        sim.run(mis, 0.1)
    sim.run(mis, 10)
    back = [vx for _, vx, _ in sim.vx_log if vx < 0.0]
    assert back and min(back) >= -REV.approach_max_reverse_speed_mps - 1e-9
    assert abs(sim.distance - 3.0) <= REV.approach_deadband_m + 0.05, sim.distance
    assert 0.4 < mis.reverse_m <= REV.approach_max_reverse_travel_m


def test_reverse_travel_limit_stops_backing_away():
    sim = ApproachSim(3.0, person_bearing=0.0, airborne=True)
    mis = Mission(REV, Goal(autonomous_takeoff=False, track_duration_s=60.0, approach=True), 0.0)
    sim.run(mis, 2)
    for _ in range(300):                                  # keeps walking at the drone
        sim.distance = max(1.0, sim.distance - 0.03)
        sim.run(mis, 0.1)
    assert mis.reverse_m <= REV.approach_max_reverse_travel_m + 0.05
    assert mis.reverse_m >= REV.approach_max_reverse_travel_m - 0.05
    assert all(vx == 0.0 for _, vx, _ in sim.vx_log[-20:])          # holding now
    sim.run(mis, 60)
    assert 'reverse limit 1.5 m reached' in mis.result.message


def test_reverse_only_while_the_person_is_centred():
    sim = ApproachSim(1.8, person_bearing=25.0, airborne=True)      # close and off to the side
    mis = Mission(REV, Goal(autonomous_takeoff=False, track_duration_s=20.0, approach=True), 0.0)
    sim.run(mis, 0.5)
    assert all(vx == 0.0 for _, vx, _ in sim.vx_log)


def test_person_filling_the_picture_backs_away_with_reverse_on():
    sim = ApproachSim(0.8, person_bearing=0.0, airborne=True)      # head above the picture
    mis = Mission(REV, Goal(autonomous_takeoff=False, track_duration_s=30.0, approach=True), 0.0)
    sim.run(mis, 8)
    assert any(vx == -REV.approach_max_reverse_speed_mps for _, vx, _ in sim.vx_log)
    assert sim.distance > 1.2


def test_hover_drift_does_not_use_up_the_reverse_travel():
    sim = ApproachSim(3.0, person_bearing=0.0, airborne=True)
    mis = Mission(REV, Goal(autonomous_takeoff=False, track_duration_s=60.0, approach=True), 0.0)
    obs = sim.obs
    k = [0]

    def drifting():
        o = obs()
        k[0] += 1
        o.forward_speed_mps = 0.04 if k[0] % 2 else -0.04          # flow noise, holding still
        return o
    sim.obs = drifting
    sim.run(mis, 50)
    assert mis.reverse_m == 0.0
