"""SearchAndTrack mission state machine (ARCHITECTURE §9.4). Pure Python, no ROS.

The node calls step(now, obs) at 10 Hz. Each Step says:
  command   (mode, yaw_rate_rad_s, vx_mps) to stream on /drone/control/command, or None = send
            nothing
  request   (PREFLIGHT | TAKEOFF | LAND, arg) for the node to run once; answered with ack()
  state     the MissionStatus state
By default the mission only asks for yaw (turning on the spot) and vx is always zero: ArduPilot
holds position on optical flow. With a goal that asks for approach (and enable_approach true in
the config) TRACKING also sends a forward speed to reach and keep a distance to the person. That
distance is an ESTIMATE from the box height (assumed person height + camera field of view), not a
measurement: see approach_* in MissionConfig. The drone only moves forward, slowly, while the
person is centred and fully in the picture, and never further than approach_max_travel_m in
total. With approach_allow_reverse it also backs away (slower, approach_max_reverse_speed_mps)
when the person comes closer, at most approach_max_reverse_travel_m in total: there is no camera
behind, so backing up is blind. The safety gate clamps the speed again (max_horizontal_speed_mps,
and max_reverse_speed_mps for backwards; both 0 on the real drone).
Takeoff and landing are FlightOperations through safety_supervisor, never commands from here.

While airborne the mission streams something every tick (HOLD when it has nothing to do): the
safety supervisor treats a stream that stops in the air as a fault (HOLD, then LAND).

Terminal: MISSION_COMPLETE, MISSION_CANCELLED, SAFETY_STOP, MANUAL_OVERRIDE, ERROR, or IDLE with a
PREFLIGHT_FAILED / TAKEOFF_FAILED result. A mission that ends in the air leaves the drone in FCU
LAND mode, with the pilot, or hovering (land_on_finish false / on_cancel hover; the node keeps
streaming HOLD then).
"""

import math
from dataclasses import dataclass

# MissionStatus states
(IDLE, PREFLIGHT, TAKING_OFF, SEARCHING, PERSON_DETECTED, TARGET_SELECTED, TRACKING,
 TARGET_LOST, REACQUIRING, RETURNING, LANDING, MISSION_COMPLETE, MISSION_CANCELLED,
 SAFETY_STOP, MANUAL_OVERRIDE, ERROR) = range(16)
STATE_NAMES = ('IDLE', 'PREFLIGHT', 'TAKING_OFF', 'SEARCHING', 'PERSON_DETECTED',
               'TARGET_SELECTED', 'TRACKING', 'TARGET_LOST', 'REACQUIRING', 'RETURNING',
               'LANDING', 'MISSION_COMPLETE', 'MISSION_CANCELLED', 'SAFETY_STOP',
               'MANUAL_OVERRIDE', 'ERROR')
FLYING_STATES = (SEARCHING, PERSON_DETECTED, TARGET_SELECTED, TRACKING, TARGET_LOST,
                 REACQUIRING, RETURNING)
PERCEPTION_STATES = (SEARCHING, PERSON_DETECTED, TARGET_SELECTED, TRACKING, TARGET_LOST,
                     REACQUIRING)

# SearchAndTrack result outcomes
(OUTCOME_COMPLETED, OUTCOME_CANCELLED, OUTCOME_TARGET_NOT_FOUND, OUTCOME_TARGET_LOST,
 OUTCOME_SAFETY_STOP, OUTCOME_MANUAL_OVERRIDE, OUTCOME_PREFLIGHT_FAILED, OUTCOME_TAKEOFF_FAILED,
 OUTCOME_ERROR) = range(9)
OUTCOME_NAMES = ('COMPLETED', 'CANCELLED', 'TARGET_NOT_FOUND', 'TARGET_LOST', 'SAFETY_STOP',
                 'MANUAL_OVERRIDE', 'PREFLIGHT_FAILED', 'TAKEOFF_FAILED', 'ERROR')

MODE_HOLD, MODE_BODY_VELOCITY = 0, 1
HOLD_CMD = (MODE_HOLD, 0.0, 0.0)
PREFLIGHT_REQ, TAKEOFF_REQ, LAND_REQ = 'PREFLIGHT', 'TAKEOFF', 'LAND'

# mirrors of message constants
LEVEL_OK, LEVEL_DEGRADED, LEVEL_HOLD, LEVEL_ABORT, LEVEL_OVERRIDE = range(5)
TGT_NONE, TGT_CANDIDATE, TGT_TRACKING, TGT_LOST = range(4)
LANDED_ON_GROUND, LANDED_IN_AIR = 1, 2
SIDE_NAMES = {-1: 'left', 0: 'centre', 1: 'right'}


def wrap_rad(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def clamp(x, limit):
    return max(-limit, min(limit, x))


def track_yaw_rate(error_x_norm, kp, deadband, max_rate):
    """Person RIGHT of centre (error > 0) -> turn RIGHT = negative ROS yaw rate (FLU)."""
    if not math.isfinite(error_x_norm) or abs(error_x_norm) < deadband:
        return 0.0
    return clamp(-kp * error_x_norm, max_rate)


def estimate_distance_m(bbox_height_norm, person_height_m, vfov_deg):
    """Distance to a standing person from the box height (fraction of the image height).

    Pinhole camera, level, person fully in the picture: h_norm = H / (2 d tan(vfov/2)). An
    estimate only: a sitting or bending person, a child, a tilted camera all make it wrong. NaN
    if the box height is unusable.
    """
    if not math.isfinite(bbox_height_norm) or bbox_height_norm <= 0.0:
        return math.nan
    return person_height_m / (2.0 * math.tan(math.radians(vfov_deg) / 2.0) * bbox_height_norm)


def estimate_distance_from_top_m(bbox_top_norm, person_height_m, camera_height_m, vfov_deg):
    """Distance from where the top of the head is, for when the feet are below the picture.

    Level camera at camera_height_m: the head (person_height_m) appears above the image centre by
    (H - h_cam) / (2 d tan(vfov/2)) image heights. Less exact than the box height (the drone's
    pitch shifts it: pitching nose-down while moving forward makes it read SHORTER, which stops
    the approach early), so it is only the fallback. NaN if unusable.
    """
    rise = person_height_m - camera_height_m
    above = 0.5 - bbox_top_norm
    if not (math.isfinite(above) and math.isfinite(rise)) or rise < 0.2 or above < 0.05:
        return math.nan
    return rise / (2.0 * math.tan(math.radians(vfov_deg) / 2.0) * above)


def approach_speed(distance_m, target_m, kp, deadband_m, max_speed, allow_reverse,
                   max_reverse_speed):
    """Forward speed (m/s, + forward) to bring the estimated distance to target_m."""
    if not math.isfinite(distance_m):
        return 0.0
    err = distance_m - target_m                 # + = too far: go forward
    if abs(err) <= deadband_m:
        return 0.0
    v = kp * err                                # no offset: it stops inside the deadband
    if v < 0.0:
        return max(v, -max_reverse_speed) if allow_reverse else 0.0
    return min(v, max_speed)


@dataclass
class MissionConfig:
    default_takeoff_altitude_m: float = 1.2
    min_takeoff_alt_m: float = 0.8         # same as safety_supervisor (a test checks)
    max_takeoff_alt_m: float = 1.5
    search_yaw_rate_deg_s: float = 15.0
    search_direction: int = 1              # +1 = CCW (left)
    search_max_total_yaw_deg: float = 360.0
    search_timeout_s: float = 60.0
    max_search_timeout_s: float = 120.0
    track_kp: float = 0.5                  # rad/s per unit of error_x_norm
    track_deadband: float = 0.05
    max_track_yaw_rate_deg_s: float = 20.0
    lost_hold_s: float = 1.0
    reacquire_timeout_s: float = 5.0
    reacquire_max_yaw_deg: float = 45.0
    reacquire_yaw_rate_deg_s: float = 10.0
    max_reacquire_attempts: int = 2
    max_track_duration_s: float = 300.0
    return_mode: str = 'yaw_to_start_then_land'   # or 'land_in_place'
    return_yaw_tol_deg: float = 5.0
    return_yaw_rate_deg_s: float = 15.0
    return_timeout_s: float = 30.0
    on_cancel: str = 'land'                # or 'hover' (testing only)
    perception_timeout_s: float = 2.0      # tracker silent this long -> end the mission
    preflight_timeout_s: float = 5.0
    takeoff_timeout_s: float = 45.0
    land_timeout_s: float = 60.0
    enable_approach: bool = False
    # approach (only used with enable_approach true and a goal that asks for it)
    approach_default_distance_m: float = 3.0
    approach_min_distance_m: float = 2.0   # [TUNE] closer than this the person no longer fits
    approach_max_distance_m: float = 5.0
    approach_person_height_m: float = 1.7  # assumed: the distance estimate scales with it
    camera_vfov_deg: float = 46.8          # vertical field of view (60 deg horizontal, 4:3)
    approach_kp: float = 0.3               # m/s per m of distance error
    approach_deadband_m: float = 0.3
    approach_max_speed_mps: float = 0.3    # the safety gate clamps again
    approach_allow_reverse: bool = False   # no camera behind: backing up is blind
    approach_max_reverse_speed_mps: float = 0.2
    approach_max_reverse_travel_m: float = 1.5  # total backward travel per mission, then hold
    approach_travel_noise_mps: float = 0.05  # measured speed below this, not commanded: ignored
    approach_align_max_error: float = 0.15  # move only while |error_x| is below this
    approach_edge_margin: float = 0.02     # box this close to the top/bottom edge = cut off
    approach_max_travel_m: float = 4.0     # total forward travel per mission, then turn only
    approach_timeout_s: float = 30.0       # not at the distance by then: start the timer anyway


@dataclass
class Goal:
    target_class: str = 'person'
    autonomous_takeoff: bool = True
    takeoff_altitude_m: float = 0.0
    search_timeout_s: float = 0.0
    track_duration_s: float = 0.0
    land_on_finish: bool = True
    approach: bool = False                 # move forward to keep approach_distance_m
    approach_distance_m: float = 0.0       # 0 = config default


@dataclass
class Obs:
    vehicle_fresh: bool = True
    armed: bool = False
    mode: str = ''
    landed_state: int = LANDED_ON_GROUND
    yaw_rad: float = 0.0                   # ENU, CCW positive
    height_m: float = math.nan
    safety_fresh: bool = True
    safety_level: int = LEVEL_OK
    safety_latched: bool = False
    safety_faults: tuple = ()
    target_fresh: bool = True
    target_state: int = TGT_NONE
    target_id: int = 0
    error_x_norm: float = 0.0
    last_seen_side: int = 0
    bbox_height_norm: float = math.nan     # box height / image height
    bbox_top_norm: float = math.nan        # box top edge / image height (0 = top)
    bbox_bottom_norm: float = math.nan
    forward_speed_mps: float = math.nan    # body FLU x velocity from the FCU EKF

    @property
    def airborne(self):
        return self.armed and self.landed_state != LANDED_ON_GROUND

    @property
    def landed_and_disarmed(self):
        return not self.armed and self.landed_state == LANDED_ON_GROUND


@dataclass
class Step:
    state: int
    command: tuple = None
    request: tuple = None
    detail: str = ''


@dataclass
class Result:
    outcome: int
    landed_and_disarmed: bool
    message: str
    duration_s: float


def validate_goal(cfg, goal, o):
    """List of reasons to reject a new goal; empty = accept."""
    fails = []
    if goal.target_class != 'person':
        fails.append(f'target "{goal.target_class}" not supported (only "person")')
    if goal.approach:
        if not cfg.enable_approach:
            fails.append('approach is switched off (mission_manager enable_approach: false)')
        d = goal.approach_distance_m
        if d != 0.0 and not (cfg.approach_min_distance_m <= d <= cfg.approach_max_distance_m):
            fails.append(f'approach distance {d:.1f} m is outside '
                         f'{cfg.approach_min_distance_m:.1f} to '
                         f'{cfg.approach_max_distance_m:.1f} m')
    if not o.vehicle_fresh:
        fails.append('no fresh vehicle state')
    if not o.safety_fresh:
        fails.append('no fresh safety status')
    elif o.safety_level >= LEVEL_ABORT or o.safety_latched:
        fails.append('safety: ' + ('; '.join(o.safety_faults) or f'level {o.safety_level}')
                     + (' (latched: reset on the ground first)' if o.safety_latched else ''))
    if goal.autonomous_takeoff:
        if o.armed or o.landed_state != LANDED_ON_GROUND:
            fails.append('autonomous_takeoff needs the drone disarmed on the ground')
    elif not (o.armed and o.mode == 'GUIDED' and o.landed_state == LANDED_IN_AIR):
        fails.append('autonomous_takeoff false needs the drone flying in GUIDED '
                     f'(armed {o.armed}, mode "{o.mode}", landed_state {o.landed_state})')
    return fails


class Mission:

    def __init__(self, cfg, goal, now):
        self.cfg, self.goal = cfg, goal
        self.t_start = now
        alt = goal.takeoff_altitude_m if goal.takeoff_altitude_m > 0 \
            else cfg.default_takeoff_altitude_m
        self.altitude_m = min(max(alt, cfg.min_takeoff_alt_m), cfg.max_takeoff_alt_m)
        st = goal.search_timeout_s if goal.search_timeout_s > 0 else cfg.search_timeout_s
        self.search_timeout_s = min(st, cfg.max_search_timeout_s)
        td = goal.track_duration_s if goal.track_duration_s > 0 else cfg.max_track_duration_s
        self.track_duration_s = min(td, cfg.max_track_duration_s)
        self.approach = bool(goal.approach and cfg.enable_approach)
        ad = goal.approach_distance_m if goal.approach_distance_m > 0 \
            else cfg.approach_default_distance_m
        self.approach_distance_m = min(max(ad, cfg.approach_min_distance_m),
                                       cfg.approach_max_distance_m)
        self.approach_arrived = not self.approach   # the track timer runs once arrived
        self.approach_since = None                  # first TRACKING tick with approach
        self.travel_m = 0.0                         # forward travel so far
        self.reverse_m = 0.0                        # backward travel so far
        self.distance_m = math.nan                  # latest estimate
        self.last_vx = 0.0
        self.approach_note = ''                     # e.g. distance not reached in time
        self.travel_note = ''                       # travel limit reached
        self.reverse_note = ''                      # reverse travel limit reached

        self.result = None
        self.outcome = None            # why the mission is ending (kept through LANDING)
        self.reason = ''
        self.detail = ''
        self.start_yaw = None
        self.last_yaw = None
        self.search_yaw_deg = 0.0
        self.reacq_yaw_deg = 0.0
        self.reacq_side = 0
        self.reacquire_attempts = 0
        self.track_time_s = 0.0
        self.target_id = 0
        self.last_t = None
        self.cancel_requested = False
        self.perception_bad_since = None
        self.return_ok_since = None
        self.takeoff_failed = False
        self.pending = None            # request kind waiting for its ack
        self.pending_since = 0.0
        self.acks = {}                 # kind -> (ok, message) received
        self.requested = set()         # (kind, state entry time): each request sent once
        self.land_done_since = None
        self._enter(PREFLIGHT if goal.autonomous_takeoff else SEARCHING, now,
                    'checking pre-flight' if goal.autonomous_takeoff else 'searching')

    # ------------------------------------------------------------------ API

    @property
    def done(self):
        return self.result is not None

    @property
    def state_name(self):
        return STATE_NAMES[self.state]

    def cancel(self):
        self.cancel_requested = True

    def ack(self, kind, ok, message=''):
        if kind == self.pending:
            self.pending = None
        self.acks[kind] = (bool(ok), message)

    # ------------------------------------------------------------------ helpers

    def _enter(self, state, now, detail=''):
        self.state, self.t_state, self.detail = state, now, detail
        if state == SEARCHING:
            self.search_yaw_deg = 0.0
        elif state == REACQUIRING:
            self.reacq_yaw_deg = 0.0
            self.reacquire_attempts += 1
        elif state == RETURNING:
            self.return_ok_since = None

    def _finish(self, now, o, state, outcome, message):
        self.state, self.detail = state, message
        self.result = Result(outcome, o.landed_and_disarmed, message, now - self.t_start)
        return Step(state, None, None, message)

    def _request(self, now, o, kind, arg=None):
        """Ask the node for `kind` once per state entry; stream HOLD meanwhile if airborne."""
        cmd = HOLD_CMD if o.airborne else None
        key = (kind, self.t_state)
        if key in self.requested:
            return Step(self.state, cmd, None, self.detail)
        self.requested.add(key)
        self.pending, self.pending_since = kind, now
        self.acks.pop(kind, None)
        return Step(self.state, cmd, (kind, arg), self.detail)

    def _end_with(self, now, outcome, reason):
        """Stop searching/tracking: RETURNING (heading), then LANDING if land_on_finish."""
        if self.outcome is None:
            self.outcome, self.reason = outcome, reason
        self._enter(RETURNING, now, reason)

    def _yaw_step_deg(self, o):
        d = 0.0
        if math.isfinite(o.yaw_rad):
            if self.last_yaw is not None:
                d = math.degrees(wrap_rad(o.yaw_rad - self.last_yaw))
            self.last_yaw = o.yaw_rad
        return d

    # ------------------------------------------------------------------ step

    def step(self, now, o):
        if self.done:
            return Step(self.state, None, None, self.detail)
        dt = 0.0 if self.last_t is None else max(0.0, now - self.last_t)
        self.last_t = now
        yaw_step = abs(self._yaw_step_deg(o))

        # ---- from any state ----------------------------------------------------------
        if o.safety_fresh and o.safety_level == LEVEL_OVERRIDE:
            return self._finish(now, o, MANUAL_OVERRIDE, OUTCOME_MANUAL_OVERRIDE,
                                'the pilot took control: the Pi sends nothing more')
        if self.state in FLYING_STATES and o.vehicle_fresh and not o.airborne:
            return self._finish(now, o, ERROR, OUTCOME_ERROR,
                                'the drone is no longer flying (landed or disarmed)')
        if self.state == SAFETY_STOP or (
                o.safety_fresh and o.safety_level == LEVEL_ABORT and o.airborne
                and self.state not in (PREFLIGHT, TAKING_OFF)):
            return self._safety_stop(now, o)

        if self.state == PREFLIGHT:
            return self._preflight(now, o)
        if self.state == TAKING_OFF:
            step = self._taking_off(now, o)
            if step is not None:
                return step
        if self.state == LANDING:
            return self._landing(now, o)
        if self.cancel_requested:
            return self._cancel_in_air(now, o)
        return self._flying(now, o, dt, yaw_step)

    # ---- phases -----------------------------------------------------------------------

    def _safety_stop(self, now, o):
        if self.state != SAFETY_STOP:
            self.outcome = OUTCOME_SAFETY_STOP
            self.reason = 'safety ABORT: ' + ('; '.join(o.safety_faults) or 'unknown')
            self._enter(SAFETY_STOP, now, self.reason + ' (safety_supervisor is landing)')
        if o.landed_and_disarmed:
            return self._finish(now, o, SAFETY_STOP, OUTCOME_SAFETY_STOP,
                                self.reason + '; landed and disarmed')
        return Step(SAFETY_STOP, HOLD_CMD if o.airborne else None, None, self.detail)

    def _preflight(self, now, o):
        if self.cancel_requested:
            return self._finish(now, o, MISSION_CANCELLED, OUTCOME_CANCELLED,
                                'cancelled before takeoff')
        ack = self.acks.pop(PREFLIGHT_REQ, None)
        if ack is not None:
            if not ack[0]:
                return self._finish(now, o, IDLE, OUTCOME_PREFLIGHT_FAILED,
                                    f'pre-flight failed: {ack[1]}')
            self._enter(TAKING_OFF, now, f'taking off to {self.altitude_m:.2f} m')
            return self._request(now, o, TAKEOFF_REQ, self.altitude_m)
        if self.pending == PREFLIGHT_REQ and now - self.pending_since > \
                self.cfg.preflight_timeout_s:
            return self._finish(now, o, IDLE, OUTCOME_PREFLIGHT_FAILED,
                                'pre-flight check did not answer')
        return self._request(now, o, PREFLIGHT_REQ)

    def _taking_off(self, now, o):
        """Step while taking off, or None once airborne and handed to _flying."""
        if self.takeoff_failed:
            if not o.armed and o.vehicle_fresh:
                cancelled = self.cancel_requested
                return self._finish(now, o, MISSION_CANCELLED if cancelled else IDLE,
                                    OUTCOME_CANCELLED if cancelled else OUTCOME_TAKEOFF_FAILED,
                                    self.reason)
            if now - self.t_state > self.cfg.land_timeout_s:
                return self._finish(now, o, ERROR, OUTCOME_TAKEOFF_FAILED,
                                    self.reason + '; still armed: take manual control')
            return Step(TAKING_OFF, None, None, self.detail)
        ack = self.acks.pop(TAKEOFF_REQ, None)
        if ack is not None:
            if not ack[0]:
                self.takeoff_failed = True
                self.reason = ('cancelled during takeoff: ' if self.cancel_requested
                               else 'takeoff failed: ') + ack[1]
                self._enter(TAKING_OFF, now, self.reason)
                return Step(TAKING_OFF, None, None, self.detail)
            self.start_yaw = o.yaw_rad if math.isfinite(o.yaw_rad) else None
            self.last_yaw = self.start_yaw
            self._enter(SEARCHING, now, f'hovering at {o.height_m:.2f} m; searching')
            return None
        if self.pending == TAKEOFF_REQ and now - self.pending_since > self.cfg.takeoff_timeout_s:
            return self._finish(now, o, ERROR, OUTCOME_ERROR,
                                'takeoff did not finish in time: take manual control')
        # a cancel now is handled by the node: it cancels the TAKEOFF goal, which lands
        return self._request(now, o, TAKEOFF_REQ, self.altitude_m)

    def _cancel_in_air(self, now, o):
        if self.outcome is None:
            self.outcome, self.reason = OUTCOME_CANCELLED, 'cancelled'
        if self.cfg.on_cancel == 'hover':
            return self._finish(now, o, MISSION_CANCELLED, OUTCOME_CANCELLED,
                                'cancelled; hovering (on_cancel hover)')
        self._enter(LANDING, now, 'cancelled: landing')
        return self._landing(now, o)

    def _landing(self, now, o):
        final = {OUTCOME_CANCELLED: MISSION_CANCELLED, OUTCOME_ERROR: ERROR}.get(
            self.outcome, MISSION_COMPLETE)
        ack = self.acks.get(LAND_REQ)
        if ack is not None:
            if not ack[0]:
                return self._finish(now, o, ERROR, self.outcome,
                                    f'{self.reason}; LAND failed: {ack[1]} (take manual '
                                    'control)')
            if o.landed_and_disarmed:
                return self._finish(now, o, final, self.outcome,
                                    f'{self.reason}; landed and disarmed')
            if self.land_done_since is None:
                self.land_done_since = now
            if now - self.land_done_since > 5.0:
                return self._finish(now, o, final, self.outcome,
                                    f'{self.reason}; LAND reported done')
            return Step(LANDING, None, None, 'landed, waiting for the disarm to show')
        if self.pending == LAND_REQ and now - self.pending_since > self.cfg.land_timeout_s:
            return self._finish(now, o, ERROR, self.outcome,
                                f'{self.reason}; LAND did not finish: take manual control')
        return self._request(now, o, LAND_REQ)

    def _flying(self, now, o, dt, yaw_step):
        c = self.cfg
        if self.start_yaw is None and math.isfinite(o.yaw_rad):
            self.start_yaw = o.yaw_rad            # started in the air
        motion_ok = o.safety_fresh and o.safety_level <= LEVEL_DEGRADED
        paused = '' if motion_ok else ' (safety HOLD: paused)'
        if self.approach:
            # forward travel: the FCU's velocity if known, else what was asked last tick
            v = o.forward_speed_mps if math.isfinite(o.forward_speed_mps) else self.last_vx
            self.travel_m += max(0.0, v) * dt
            # backward: hover drift (flow) also reads as small negative speeds; only count it
            # beyond the noise floor unless backing up was asked for
            floor = 0.0 if self.last_vx < 0.0 else c.approach_travel_noise_mps
            self.reverse_m += max(0.0, -v - floor) * dt
            self.last_vx = 0.0

        if o.target_fresh:
            self.perception_bad_since = None
        elif self.perception_bad_since is None:
            self.perception_bad_since = now
        if (self.state in PERCEPTION_STATES and self.perception_bad_since is not None
                and now - self.perception_bad_since > c.perception_timeout_s):
            self._end_with(now, OUTCOME_ERROR, 'perception silent (no target messages)')
        seen = o.target_fresh and o.target_state == TGT_TRACKING

        def move(rate, detail, vx=0.0):
            return Step(self.state, (MODE_BODY_VELOCITY, rate, vx) if motion_ok else HOLD_CMD,
                        None, detail + paused)

        if self.state == SEARCHING:
            self.search_yaw_deg += yaw_step
            if seen:
                self.target_id = o.target_id
                self._enter(PERSON_DETECTED, now, f'person {o.target_id} seen')
                return Step(PERSON_DETECTED, HOLD_CMD, None, self.detail)
            # after a lost target, an empty new search means the target is lost for good
            none = OUTCOME_TARGET_LOST if self.target_id else OUTCOME_TARGET_NOT_FOUND
            again = 'target lost; ' if self.target_id else ''
            if self.search_yaw_deg >= c.search_max_total_yaw_deg:
                self._end_with(now, none, f'{again}nobody found in {self.search_yaw_deg:.0f} '
                                          'deg of turning')
            elif now - self.t_state >= self.search_timeout_s:
                self._end_with(now, none, f'{again}nobody found in '
                                          f'{self.search_timeout_s:.0f} s')
            else:
                rate = math.radians(c.search_yaw_rate_deg_s) * (1 if c.search_direction >= 0
                                                                 else -1)
                return move(rate, f'searching, turned {self.search_yaw_deg:.0f} deg')

        if self.state == PERSON_DETECTED:
            self._enter(TARGET_SELECTED, now, f'target {self.target_id} selected')
            return Step(TARGET_SELECTED, HOLD_CMD, None, self.detail)
        if self.state == TARGET_SELECTED:
            self._enter(TRACKING, now, f'tracking {self.target_id}')

        if self.state == TRACKING:
            if seen:
                self.target_id = o.target_id
                vx, note = self._approach(now, o) if self.approach else (0.0, '')
                if self.approach_arrived:
                    self.track_time_s += dt
                if self.track_time_s >= self.track_duration_s:
                    self._end_with(now, OUTCOME_COMPLETED,
                                   f'tracked for {self.track_time_s:.0f} s'
                                   + self._approach_summary())
                else:
                    rate = track_yaw_rate(o.error_x_norm, c.track_kp, c.track_deadband,
                                          math.radians(c.max_track_yaw_rate_deg_s))
                    if motion_ok:
                        self.last_vx = vx
                    return move(rate, f'tracking {self.target_id}, error '
                                      f'{o.error_x_norm:+.2f}{note}, {self.track_time_s:.0f} of '
                                      f'{self.track_duration_s:.0f} s', vx)
            else:
                self.reacq_side = o.last_seen_side
                self._enter(TARGET_LOST, now, f'target {self.target_id} lost (last seen '
                                              f'{SIDE_NAMES.get(o.last_seen_side, "?")})')

        if self.state == TARGET_LOST:
            if seen:
                self._enter(TRACKING, now, f'tracking {o.target_id} again')
                return Step(TRACKING, HOLD_CMD, None, self.detail)
            if now - self.t_state < c.lost_hold_s:
                return Step(TARGET_LOST, HOLD_CMD, None, self.detail)
            if self.reacquire_attempts >= c.max_reacquire_attempts:
                self._end_with(now, OUTCOME_TARGET_LOST,
                               f'target lost ({self.reacquire_attempts} reacquire attempts '
                               'used)')
            else:
                self._enter(REACQUIRING, now, f'looking {SIDE_NAMES[self._reacq_dir_side()]} '
                                              'for the target')

        if self.state == REACQUIRING:
            self.reacq_yaw_deg += yaw_step
            if seen:
                self._enter(TRACKING, now, f'reacquired {o.target_id}')
                return Step(TRACKING, HOLD_CMD, None, self.detail)
            if (self.reacq_yaw_deg >= c.reacquire_max_yaw_deg
                    or now - self.t_state >= c.reacquire_timeout_s):
                if self.reacquire_attempts >= c.max_reacquire_attempts:
                    self._end_with(now, OUTCOME_TARGET_LOST,
                                   f'target not found again after {self.reacquire_attempts} '
                                   'attempts')
                else:
                    self._enter(SEARCHING, now, 'searching again')
                    return Step(SEARCHING, HOLD_CMD, None, self.detail)
            else:
                side = self._reacq_dir_side()
                rate = -side * math.radians(c.reacquire_yaw_rate_deg_s)   # right = negative
                return move(rate, f'looking {SIDE_NAMES[side]}, turned '
                                  f'{self.reacq_yaw_deg:.0f} deg')

        if self.state == RETURNING:
            return self._returning(now, o, motion_ok, paused)
        return Step(self.state, HOLD_CMD, None, self.detail)

    def _approach(self, now, o):
        """(forward speed, detail) while TRACKING with approach on."""
        c = self.cfg
        if self.approach_since is None:
            self.approach_since = now
        margin = c.approach_edge_margin
        top_cut = math.isfinite(o.bbox_top_norm) and o.bbox_top_norm <= margin
        feet_cut = math.isfinite(o.bbox_bottom_norm) and o.bbox_bottom_norm >= 1.0 - margin
        if top_cut:
            # the head is out of the picture: closer than any estimate. Never move forward;
            # with reverse on, back away (still only while centred and within the limit).
            self.distance_m = math.nan
            self.approach_arrived = True
            v = self._limit_reverse(-c.approach_max_reverse_speed_mps, o) \
                if c.approach_allow_reverse else 0.0
            return v, (', person fills the picture (close): '
                       + (f'backing away, vx {v:.2f}' if v < 0.0 else 'holding')
                       + self._travel_text())
        if feet_cut:
            # normal below about 2.8 m at 1.2 m height: use the head position instead
            d = estimate_distance_from_top_m(o.bbox_top_norm, c.approach_person_height_m,
                                             o.height_m, c.camera_vfov_deg)
            how = 'head'
        else:
            d = estimate_distance_m(o.bbox_height_norm, c.approach_person_height_m,
                                    c.camera_vfov_deg)
            how = 'size'
        self.distance_m = d
        if not math.isfinite(d):
            self.approach_arrived = self.approach_arrived or feet_cut
            return 0.0, ', no distance estimate: holding'
        target = self.approach_distance_m
        if not self.approach_arrived:
            if d <= target + c.approach_deadband_m:
                self.approach_arrived = True
            elif now - self.approach_since >= c.approach_timeout_s:
                self.approach_arrived = True
                self.approach_note = f'{target:.1f} m not reached in {c.approach_timeout_s:.0f} s'
        v = approach_speed(d, target, c.approach_kp, c.approach_deadband_m,
                           c.approach_max_speed_mps, c.approach_allow_reverse,
                           c.approach_max_reverse_speed_mps)
        if abs(o.error_x_norm) > c.approach_align_max_error:
            v = 0.0                               # turn to face them first
        if v > 0.0 and self.travel_m >= c.approach_max_travel_m:
            if not self.travel_note:
                self.travel_note = f'travel limit {c.approach_max_travel_m:.1f} m reached'
            v = 0.0
        if v < 0.0:
            v = self._limit_reverse(v, o)
        state = 'approaching' if not self.approach_arrived else (
            'backing away' if v < 0.0 else 'keeping distance')
        return v, (f', ~{d:.1f} m by {how} (want {target:.1f}), {state}, vx {v:.2f}'
                   + self._travel_text())

    def _limit_reverse(self, v, o):
        """Backward speed v (< 0) after the centring and reverse travel checks."""
        c = self.cfg
        if abs(o.error_x_norm) > c.approach_align_max_error:
            return 0.0
        if self.reverse_m >= c.approach_max_reverse_travel_m:
            if not self.reverse_note:
                self.reverse_note = (f'reverse limit {c.approach_max_reverse_travel_m:.1f} m '
                                     'reached')
            return 0.0
        return max(v, -c.approach_max_reverse_speed_mps)

    def _travel_text(self):
        t = f', travelled {self.travel_m:.1f} m'
        if self.cfg.approach_allow_reverse:
            t += f', back {self.reverse_m:.1f} m'
        return t

    def _approach_summary(self):
        if not self.approach:
            return ''
        d = f'~{self.distance_m:.1f} m' if math.isfinite(self.distance_m) else 'unknown'
        notes = [n for n in (self.approach_note, self.travel_note, self.reverse_note) if n]
        return (f' at {d} (wanted {self.approach_distance_m:.1f} m)' + self._travel_text()
                + ''.join(f'; {n}' for n in notes))

    def _reacq_dir_side(self):
        """Side to turn towards: where the target was last seen, else the search direction."""
        if self.reacq_side:
            return self.reacq_side
        return -1 if self.cfg.search_direction >= 0 else 1      # CCW search = to the left

    def _returning(self, now, o, motion_ok, paused):
        c = self.cfg
        if c.return_mode == 'land_in_place' or self.start_yaw is None \
                or not math.isfinite(o.yaw_rad):
            return self._after_return(now, o, 'landing in place')
        err = wrap_rad(self.start_yaw - o.yaw_rad)
        if abs(math.degrees(err)) <= c.return_yaw_tol_deg:
            if self.return_ok_since is None:
                self.return_ok_since = now
            if now - self.return_ok_since >= 1.0:
                return self._after_return(now, o, 'back at the start heading')
            return Step(RETURNING, HOLD_CMD, None, 'at the start heading, settling')
        self.return_ok_since = None
        if now - self.t_state > c.return_timeout_s:
            return self._after_return(now, o, 'start heading not reached in time')
        rate = clamp(1.0 * err, math.radians(c.return_yaw_rate_deg_s))   # + err = turn left
        return Step(RETURNING, (MODE_BODY_VELOCITY, rate, 0.0) if motion_ok else HOLD_CMD, None,
                    f'{self.reason}; turning back to the start heading '
                    f'({math.degrees(err):+.0f} deg){paused}')

    def _after_return(self, now, o, note):
        if self.goal.land_on_finish:
            self.reason = f'{self.reason}; {note}'
            self._enter(LANDING, now, f'{self.reason}; landing')
            return self._landing(now, o)
        state = ERROR if self.outcome == OUTCOME_ERROR else MISSION_COMPLETE
        return self._finish(now, o, state, self.outcome,
                            f'{self.reason}; {note}; hovering (land_on_finish false)')
