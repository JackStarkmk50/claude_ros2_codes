#!/bin/bash
# One-time install of the SLAM engine (stella_vslam + its ROS 2 wrapper) on Ubuntu 24.04 + Jazzy.
# For the PC/WSL now; the Pi later (same steps, slower). 20 to 40 minutes.
#
#   bash ~/drone_ws/src/drone_slam/sim/setup_stella.sh
#
# Installs: stella_vslam into /usr/local, stella_vslam_ros into ~/stella_ws, and the ORB
# vocabulary ~/stella_ws/orb_vocab.fbow. Steps follow stella_vslam_ros's own Dockerfile, without
# the viewers (we look at the map in RViz and with make_map instead).
# JOBS=2 bash setup_stella.sh   if the build runs out of memory (WSL default limits).

set -e
JOBS="${JOBS:-$(nproc)}"
STELLA_WS="${STELLA_WS:-$HOME/stella_ws}"
source /opt/ros/jazzy/setup.bash

echo "== apt packages"
sudo apt-get update -qq
sudo apt-get install -y build-essential cmake git libgoogle-glog-dev libsuitesparse-dev \
  libyaml-cpp-dev libopencv-dev libeigen3-dev libsqlite3-dev \
  ros-jazzy-libg2o ros-jazzy-cv-bridge ros-jazzy-image-transport ros-jazzy-nav2-map-server \
  python3-msgpack python3-colcon-common-extensions

mkdir -p "$STELLA_WS/src"
cd "$STELLA_WS"

echo "== stella_vslam (library)"
[ -d stella_vslam ] || git clone --recursive --depth 1 https://github.com/stella-cv/stella_vslam.git
cd stella_vslam && git submodule update --init --recursive
mkdir -p build && cd build
CMAKE_PREFIX_PATH=/opt/ros/jazzy/lib/cmake cmake -DCMAKE_BUILD_TYPE=Release ..
make -j"$JOBS"
sudo make install
sudo ldconfig
cd "$STELLA_WS"

echo "== stella_vslam_ros (ROS 2 wrapper)"
[ -d src/stella_vslam_ros ] || git clone --recursive --depth 1 \
  https://github.com/stella-cv/stella_vslam_ros.git src/stella_vslam_ros
colcon build --packages-select stella_vslam_ros --parallel-workers "$JOBS" \
  --cmake-args -DCMAKE_BUILD_TYPE=Release

echo "== ORB vocabulary"
if [ ! -f orb_vocab.fbow ]; then
  [ -d FBoW_orb_vocab ] || git clone --depth 1 https://github.com/stella-cv/FBoW_orb_vocab.git
  cp FBoW_orb_vocab/orb_vocab.fbow .
fi

grep -q "stella_ws/install/setup.bash" "$HOME/drone_ws/env.sh" 2>/dev/null || cat <<MSG

Add the SLAM engine to every terminal: put this line at the END of ~/drone_ws/env.sh
  [ -f $STELLA_WS/install/setup.bash ] && source $STELLA_WS/install/setup.bash
MSG
echo "STELLA SETUP DONE"
