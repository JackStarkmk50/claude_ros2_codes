#!/usr/bin/env python3
"""SIMULATOR ONLY: fly the SLAM mapping path in Gazebo (take off, slow loop of both rooms, land).

Talks straight to ArduCopter SITL on tcp:127.0.0.1:5762 with pymavlink, like the "set the mode
back to STABILIZE" line in GAZEBO_SIM.md. It bypasses the drone stack and its safety supervisor on
purpose: the stack has no position commands yet, and this is only a way to move the simulated
camera around the room for SLAM. Never point it at the real drone (the real drone is carried
by hand for mapping, see SLAM_S1_GAZEBO.md).

    python3 sim_survey.py --dry        print the path and how long it takes
    python3 sim_survey.py              fly it (altitude 1.0 m, 0.25 m/s, turns at 15 deg/s)

Ctrl-C at any time switches to LAND.
"""

import argparse
import math
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from drone_slam.core.survey import TEXTURED_ROOM, SurveyPath  # noqa: E402

HOME = (-35.363261, 149.165230, 584.0)          # run_sim.sh --home
POS_YAW_ONLY = 0b0000_1001_1111_1000           # use x y z + yaw; ignore vel, acc, yaw rate


def wait(m, cond, timeout, what):
    end = time.time() + timeout
    while time.time() < end:
        msg = m.recv_match(blocking=True, timeout=0.5)
        if msg is None:
            continue
        if msg.get_type() == 'STATUSTEXT':
            print('  FCU:', msg.text)
        if cond(msg):
            return msg
    sys.exit(f'FAILED: {what} (no answer within {timeout:.0f} s)')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument('--url', default='tcp:127.0.0.1:5762')
    ap.add_argument('--alt', type=float, default=1.0)
    ap.add_argument('--speed', type=float, default=0.25)
    ap.add_argument('--yaw-rate', type=float, default=15.0)
    ap.add_argument('--dry', action='store_true')
    a = ap.parse_args()
    path = SurveyPath(TEXTURED_ROOM, a.speed, a.yaw_rate)
    print(f'path: {len(path.legs)} legs, {path.duration / 60:.1f} min at {a.speed} m/s, '
          f'altitude {a.alt} m')
    if a.dry:
        for leg in path.legs:
            print(f'  ({leg.x0:5.2f},{leg.y0:5.2f}) -> ({leg.x1:5.2f},{leg.y1:5.2f})  '
                  f'heading {leg.yaw:6.1f}  turn {leg.turn_s:4.1f} s  move {leg.move_s:4.1f} s')
        return 0

    from pymavlink import mavutil

    m = mavutil.mavlink_connection(a.url, source_system=254)
    m.wait_heartbeat(timeout=10)
    print(f'connected to system {m.target_system}')
    ts, tc = m.target_system, m.target_component
    m.mav.set_gps_global_origin_send(ts, int(HOME[0] * 1e7), int(HOME[1] * 1e7), int(HOME[2] * 1000))
    m.mav.request_data_stream_send(ts, tc, mavutil.mavlink.MAV_DATA_STREAM_ALL, 10, 1)
    m.set_mode('GUIDED')
    wait(m, lambda x: x.get_type() == 'HEARTBEAT' and x.get_srcSystem() == ts
         and mavutil.mode_string_v10(x) == 'GUIDED', 10, 'switch to GUIDED')
    m.arducopter_arm()
    wait(m, lambda x: x.get_type() == 'HEARTBEAT' and x.get_srcSystem() == ts
         and x.base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED, 20, 'arm')
    m.mav.command_long_send(ts, tc, mavutil.mavlink.MAV_CMD_NAV_TAKEOFF, 0, 0, 0, 0, 0, 0, 0, a.alt)
    wait(m, lambda x: x.get_type() == 'LOCAL_POSITION_NED' and -x.z > 0.9 * a.alt, 25, 'take off')
    print('airborne; flying the survey (Ctrl-C lands)')

    t_path, last, pos = 0.0, time.time(), None
    try:
        while True:
            now = time.time()
            x, y, yaw, done = path.at(t_path)
            msg = m.recv_match(type='LOCAL_POSITION_NED', blocking=False)
            if msg is not None:
                pos = (msg.y, msg.x)                    # NED north, east -> Gazebo x east, y north
            behind = pos is not None and math.hypot(pos[0] - x, pos[1] - y) > 0.6
            if not behind:                              # wait for the drone if it falls behind
                t_path += now - last
            last = now
            m.mav.set_position_target_local_ned_send(
                0, ts, tc, mavutil.mavlink.MAV_FRAME_LOCAL_NED, POS_YAW_ONLY,
                y, x, -a.alt, 0, 0, 0, 0, 0, 0, math.radians(90.0 - yaw), 0)
            if done and pos is not None and math.hypot(pos[0] - x, pos[1] - y) < 0.2:
                break
            if int(t_path) % 30 == 0 and t_path - int(t_path) < 0.1:
                print(f'  {t_path:5.0f} / {path.duration:.0f} s  at ({x:.1f}, {y:.1f})')
            time.sleep(0.1)
    except KeyboardInterrupt:
        print('\nstopped by you')
    m.set_mode('LAND')
    print('landing')
    wait(m, lambda x: x.get_type() == 'HEARTBEAT' and x.get_srcSystem() == ts
         and not x.base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED, 60, 'land and disarm')
    print('SURVEY DONE: landed and disarmed')
    return 0


if __name__ == '__main__':
    sys.exit(main())
