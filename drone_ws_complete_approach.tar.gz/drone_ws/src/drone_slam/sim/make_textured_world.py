#!/usr/bin/env python3
"""Write sim/worlds/indoor_search_textured.sdf and its textures (sim/textures/*.png).

Monocular SLAM tracks corners and texture. The original sim room (sim/gazebo/worlds/
indoor_search.sdf) has flat-colour walls and floor, so SLAM finds almost nothing there. This copy:
- keeps <world name="indoor_search">, the drone, its camera and both people exactly as they are
  (move_person.py, gz_scenarios.py and camera_relay.py keep working);
- puts picture-like textures on the floor, the four walls and the boxes;
- adds a partition wall at x = 1.5 m with a doorway (y = 1.0 .. 2.5 m), so there are two rooms:
  west room (x -5 .. 1.5, the drone starts here) and east room (x 1.5 .. 5).

Run it again only to change the room; the generated files are committed.
    python3 make_textured_world.py
"""

import os
import re

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SRC_WORLD = os.path.join(HERE, '..', '..', '..', 'sim', 'gazebo', 'worlds', 'indoor_search.sdf')
OUT_WORLD = os.path.join(HERE, 'worlds', 'indoor_search_textured.sdf')
TEX = os.path.join(HERE, 'textures')
MODELS_REL = '../../../../sim/gazebo/models'      # from sim/worlds/ to drone_ws/sim/gazebo/models

PARTITION_X = 1.5
DOOR = (1.0, 2.5)          # doorway between these y values


def busy_texture(w, h, seed, base):
    """Random shapes, lines and 'posters': lots of corners at many sizes, no repeating pattern
    (repeats confuse SLAM's place recognition)."""
    rng = np.random.default_rng(seed)
    img = np.full((h, w, 3), base, np.uint8)
    noise = rng.integers(-18, 18, (h // 8, w // 8, 1))
    img = np.clip(img.astype(int) + cv2.resize(noise, (w, h), interpolation=cv2.INTER_NEAREST)
                  [..., None], 0, 255).astype(np.uint8)
    for _ in range(int(w * h / 9000)):
        col = tuple(int(c) for c in rng.integers(0, 255, 3))
        kind = rng.integers(5)
        x, y = int(rng.integers(0, w)), int(rng.integers(0, h))
        s = int(rng.integers(6, max(8, h // 6)))
        if kind == 0:
            cv2.rectangle(img, (x, y), (x + s, y + int(s * rng.uniform(0.4, 2))), col, -1)
        elif kind == 1:
            cv2.circle(img, (x, y), s // 2, col, -1)
        elif kind == 2:
            cv2.line(img, (x, y), (x + int(rng.integers(-3 * s, 3 * s)),
                                   y + int(rng.integers(-s, s))), col, int(rng.integers(2, 6)))
        elif kind == 3:
            pts = rng.integers(-s, s, (3, 2)) + [x, y]
            cv2.fillPoly(img, [pts.astype(np.int32)], col)
        else:
            cv2.putText(img, ''.join(rng.choice(list('ABCDEFGHKMNPRSTUWXZ23456789'), 3)), (x, y),
                        cv2.FONT_HERSHEY_SIMPLEX, s / 30, col, max(1, s // 12))
    for _ in range(max(2, w // 300)):            # framed 'posters': strong, large-scale corners
        pw, ph = int(rng.integers(h // 5, h // 2)), int(rng.integers(h // 5, h // 2))
        x, y = int(rng.integers(0, w - pw)), int(rng.integers(0, h - ph))
        cv2.rectangle(img, (x - 6, y - 6), (x + pw + 6, y + ph + 6), (30, 30, 30), -1)
        poster = rng.integers(0, 255, (int(rng.integers(3, 7)), int(rng.integers(3, 7)), 3))
        img[y:y + ph, x:x + pw] = cv2.resize(poster.astype(np.uint8), (pw, ph),
                                             interpolation=cv2.INTER_NEAREST)
    return img


def floor_texture(n, seed):
    """Wooden planks with grain and a few rugs."""
    rng = np.random.default_rng(seed)
    img = np.zeros((n, n, 3), np.uint8)
    plank = n // 48
    for i in range(0, n, plank):
        c = np.array([60, 105, 150]) + rng.integers(-25, 25, 3)
        img[i:i + plank] = c
        cv2.line(img, (0, i), (n, i), (40, 60, 80), 2)
        for x in rng.integers(0, n, 3):
            cv2.line(img, (int(x), i), (int(x), i + plank), (40, 60, 80), 2)
    grain = rng.integers(-20, 20, (n // 4, n, 1))
    img = np.clip(img.astype(int) + np.repeat(grain, 4, axis=0)[..., :1], 0, 255).astype(np.uint8)
    for _ in range(4):
        rug = busy_texture(int(rng.integers(n // 8, n // 4)), int(rng.integers(n // 10, n // 5)),
                           int(rng.integers(1 << 30)), tuple(int(c) for c in rng.integers(60, 200, 3)))
        x, y = int(rng.integers(0, n - rug.shape[1])), int(rng.integers(0, n - rug.shape[0]))
        img[y:y + rug.shape[0], x:x + rug.shape[1]] = rug
    return img


def material(tex):
    return (f'<material><ambient>1 1 1 1</ambient><diffuse>1 1 1 1</diffuse>'
            f'<pbr><metal><albedo_map>../textures/{tex}</albedo_map>'
            f'<roughness>0.9</roughness><metalness>0</metalness></metal></pbr></material>')


def wall(name, pose, size, tex):
    geo = f'<geometry><box><size>{size}</size></box></geometry>'
    return (f'        <collision name="{name}"><pose>{pose}</pose>{geo}</collision>\n'
            f'        <visual name="{name}"><pose>{pose}</pose>{geo}\n          {material(tex)}</visual>\n')


def main():
    os.makedirs(TEX, exist_ok=True)
    walls = {'wall_n.png': 11, 'wall_s.png': 12, 'wall_e.png': 13, 'wall_w.png': 14,
             'wall_p1.png': 15, 'wall_p2.png': 16}
    bases = [(205, 200, 190), (190, 205, 205), (210, 195, 195), (195, 195, 210), (200, 210, 195),
             (210, 205, 185)]
    for (name, seed), base in zip(walls.items(), bases):
        cv2.imwrite(os.path.join(TEX, name), busy_texture(2048, 614, seed, base))
    cv2.imwrite(os.path.join(TEX, 'floor.jpg'), floor_texture(2048, 21), [cv2.IMWRITE_JPEG_QUALITY, 90])
    cv2.imwrite(os.path.join(TEX, 'box1.png'), busy_texture(512, 512, 31, (60, 110, 160)))
    cv2.imwrite(os.path.join(TEX, 'box2.png'), busy_texture(512, 512, 32, (160, 110, 70)))

    sdf = open(SRC_WORLD).read()
    sdf = sdf.replace('../models/', MODELS_REL + '/')
    # floor
    sdf = re.sub(r'(<model name="floor">.*?<visual name="v">.*?</geometry>)\s*<material>.*?</material>',
                 lambda m: m.group(1) + '\n          ' + material('floor.jpg'), sdf, flags=re.S)
    # walls: outer four + the partition with a doorway
    lo, hi = DOOR
    s_len, n_len = lo + 5.0, 5.0 - hi
    body = (wall('n', '0 5 1.5 0 0 0', '10 0.1 3', 'wall_n.png')
            + wall('s', '0 -5 1.5 0 0 0', '10 0.1 3', 'wall_s.png')
            + wall('e', '5 0 1.5 0 0 0', '0.1 10 3', 'wall_e.png')
            + wall('w', '-5 0 1.5 0 0 0', '0.1 10 3', 'wall_w.png')
            + wall('p_south', f'{PARTITION_X} {-5 + s_len / 2:.3f} 1.5 0 0 0',
                   f'0.1 {s_len:.3f} 3', 'wall_p1.png')
            + wall('p_north', f'{PARTITION_X} {hi + n_len / 2:.3f} 1.5 0 0 0',
                   f'0.1 {n_len:.3f} 3', 'wall_p2.png')
            + wall('p_lintel', f'{PARTITION_X} {(lo + hi) / 2:.3f} 2.6 0 0 0',
                   f'0.1 {hi - lo:.3f} 0.8', 'wall_p2.png'))
    sdf = re.sub(r'(<model name="walls">\s*<static>true</static>\s*<link name="link">\n).*?(      </link>)',
                 lambda m: m.group(1) + body + m.group(2), sdf, count=1, flags=re.S)
    # boxes
    for b, tex in (('b1', 'box1.png'), ('b2', 'box2.png')):
        sdf = re.sub(rf'(<visual name="{b}">.*?</geometry>)\s*<material>.*?</material>',
                     lambda m, t=tex: m.group(1) + '\n          ' + material(t), sdf, flags=re.S)
    sdf = sdf.replace('<sdf version="1.9">', '''<!--
  GENERATED by drone_slam/sim/make_textured_world.py from sim/gazebo/worlds/indoor_search.sdf.
  Same world name, drone, camera and people; textured floor, walls and boxes for monocular SLAM;
  a partition wall at x = 1.5 m with a doorway at y = 1.0 .. 2.5 m (two rooms).
-->
<sdf version="1.9">''', 1)
    os.makedirs(os.path.dirname(OUT_WORLD), exist_ok=True)
    with open(OUT_WORLD, 'w') as f:
        f.write(sdf)
    print('wrote', OUT_WORLD)


if __name__ == '__main__':
    main()
