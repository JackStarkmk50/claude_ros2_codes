import math

import numpy as np
import pytest
import yaml

from drone_slam.core.calibration import board_points, calibrate, coverage, from_hfov

cv2 = pytest.importorskip('cv2')

W, H = 640, 480
K = np.array([[520.0, 0, 330.0], [0, 515.0, 236.0], [0, 0, 1]])
DIST = np.array([-0.21, 0.05, 0.001, -0.0005, 0.0])


def synthetic_views(n=20, spread=1.0, seed=1):
    rng = np.random.default_rng(seed)
    obj = board_points(9, 6, 0.025)
    centre = obj.mean(axis=0)
    views = []
    while len(views) < n:
        rvec = rng.normal(0, 0.35, 3)
        t = np.array([rng.uniform(-0.12, 0.12) * spread, rng.uniform(-0.08, 0.08) * spread,
                      rng.uniform(0.3, 0.6)])
        rot, _ = cv2.Rodrigues(rvec)
        tvec = t - rot @ centre
        img, _ = cv2.projectPoints(obj, rvec, tvec, K, DIST)
        img = img.reshape(-1, 2) + rng.normal(0, 0.2, (len(obj), 2))
        if (img[:, 0] > 2).all() and (img[:, 0] < W - 2).all() and (img[:, 1] > 2).all() \
                and (img[:, 1] < H - 2).all():
            views.append(img)
    return views


def test_recovers_known_camera():
    res = calibrate(synthetic_views(), W, H, 9, 6, 0.025)
    i = res.intrinsics
    assert res.ok, res.problems
    assert i.fx == pytest.approx(520, rel=0.02) and i.fy == pytest.approx(515, rel=0.02)
    assert i.cx == pytest.approx(330, abs=6) and i.cy == pytest.approx(236, abs=6)
    assert i.dist[0] == pytest.approx(-0.21, abs=0.05)
    assert i.rms_px < 0.5


def test_too_few_and_centre_only_views_are_flagged():
    res = calibrate(synthetic_views(n=5, spread=0.05), W, H, 9, 6, 0.025)
    text = ' '.join(res.problems)
    assert not res.ok and 'usable pictures' in text and 'covered' in text


def test_coverage_counts_grid_cells():
    assert coverage([np.array([[10, 10]])], W, H) == pytest.approx(1 / 9)
    corners = np.array([[x, y] for x in (50, 320, 600) for y in (40, 240, 440)])
    assert coverage([corners], W, H) == 1.0


def test_sim_camera_from_fov():
    i = from_hfov(640, 480, 1.047)
    assert i.fx == pytest.approx(320 / math.tan(0.5235), rel=1e-6)
    assert i.hfov_deg() == pytest.approx(math.degrees(1.047), abs=1e-6)


def test_camera_info_yaml_is_valid():
    d = yaml.safe_load(from_hfov(640, 480, 1.047).camera_info_yaml())
    assert d['image_width'] == 640 and len(d['camera_matrix']['data']) == 9
    assert len(d['projection_matrix']['data']) == 12 and d['distortion_model'] == 'plumb_bob'


def test_fill_stella_template():
    import os
    path = os.path.join(os.path.dirname(__file__), '..', 'config', 'stella_webcam.yaml')
    i = from_hfov(640, 480, 1.047)
    i.dist = [-0.2, 0.05, 0.001, -0.002, 0.0]
    d = yaml.safe_load(i.fill_stella(open(path).read()))['Camera']
    assert d['fx'] == pytest.approx(554.383, abs=1e-3) and d['cx'] == 320
    assert d['k1'] == pytest.approx(-0.2) and d['p2'] == pytest.approx(-0.002)
    assert d['setup'] == 'monocular' and d['color_order'] == 'RGB'


def test_sim_config_matches_sim_camera():
    import os
    path = os.path.join(os.path.dirname(__file__), '..', 'config', 'stella_sim.yaml')
    d = yaml.safe_load(open(path))['Camera']
    i = from_hfov(640, 480, 1.047)
    assert d['fx'] == pytest.approx(i.fx, abs=1e-3) and (d['cols'], d['rows']) == (640, 480)
