import math

import numpy as np
import pytest

from drone_slam.core.stella_map import from_database, load_csv, load_stella


def fake_db():
    # keyframe 0 at the origin; keyframe 1 one unit forward (+z optical), turned 90 deg
    a = math.radians(90) / 2
    q90 = [0.0, math.sin(a), 0.0, math.cos(a)]       # world->camera rotation about y
    c1 = np.array([0.0, 0.0, 1.0])
    from drone_slam.core.frames import quat_to_rot
    t1 = -quat_to_rot(q90) @ c1
    return {
        'keyframes': {'0': {'rot_cw': [0, 0, 0, 1], 'trans_cw': [0, 0, 0], 'lm_ids': [5, 7, -1]},
                    '1': {'rot_cw': q90, 'trans_cw': t1.tolist(), 'lm_ids': [7, 99]}},
        'landmarks': {'5': {'pos_w': [1.0, 0.0, 3.0]}, '7': {'pos_w': [0.0, -0.5, 2.0]}},
        'cameras': {},
    }


def test_reads_points_keyframe_centres_and_observations():
    pts, kfs, obs = from_database(fake_db())
    assert np.allclose(pts, [[1, 0, 3], [0, -0.5, 2]])
    assert np.allclose(kfs, [[0, 0, 0], [0, 0, 1]])
    assert obs == [[0], [0, 1]]


def test_missing_key_is_explained():
    with pytest.raises(KeyError, match='landmarks'):
        from_database({'keyframes': {}})


def test_older_keyfrms_key_still_read():
    db = fake_db()
    db['keyfrms'] = db.pop('keyframes')
    assert len(from_database(db)[1]) == 2


def test_msgpack_file(tmp_path):
    msgpack = pytest.importorskip('msgpack')
    db = fake_db()
    db['keyframes'] = {int(k): v for k, v in db['keyframes'].items()}
    db['landmarks'] = {int(k): v for k, v in db['landmarks'].items()}
    path = tmp_path / 'map.msg'
    path.write_bytes(msgpack.packb(db))
    pts, kfs, obs = load_stella(str(path))
    assert len(pts) == 2 and len(kfs) == 2 and obs[1] == [0, 1]


def test_csv(tmp_path):
    p = tmp_path / 'm.csv'
    p.write_text('kind,x,y,z\npoint,1,2,3\nkeyframe,0,0,0\npoint,4,5,6\n')
    pts, kfs, obs = load_csv(str(p))
    assert pts.shape == (2, 3) and kfs.shape == (1, 3) and obs is None
