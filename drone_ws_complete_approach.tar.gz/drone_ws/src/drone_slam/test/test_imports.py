"""Every executable module imports cleanly and exposes main()."""

import pytest


def test_tools_import():
    from drone_slam import calibrate_camera, make_map
    assert callable(calibrate_camera.main) and callable(make_map.main)


def test_node_imports():
    pytest.importorskip('rclpy')
    from drone_slam import slam_scale_node
    assert callable(slam_scale_node.main)
