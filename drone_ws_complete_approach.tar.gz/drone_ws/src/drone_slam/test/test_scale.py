import math

import numpy as np

from drone_slam.core.scale import ScaleConfig, ScaleEstimator

TRUE_SCALE = 0.42      # metres per SLAM unit


def rot_z(a):
    return np.array([[math.cos(a), -math.sin(a), 0], [math.sin(a), math.cos(a), 0], [0, 0, 1]])


def fly(est, path, slam_noise=0.0, metric_noise=0.0, drift=(0.0, 0.0, 0.0), seed=0, dt=0.1):
    """path: metric positions at 10 Hz. SLAM sees them rotated and in its own units."""
    rng = np.random.default_rng(seed)
    r = rot_z(1.1) @ np.array([[1, 0, 0], [0, 0, -1], [0, 1, 0]])   # arbitrary SLAM axes
    for i, p in enumerate(path):
        t = 100.0 + i * dt
        m = p + np.array(drift) * (t - 100.0) + rng.normal(0, metric_noise, 3)
        est.add_metric(t, m)
        s = r @ (p / TRUE_SCALE) + rng.normal(0, slam_noise, 3)
        est.add_slam(t + 0.01, s)
    return est.status


def square_path(n=600, side=3.0):
    pts = []
    for i in range(n):
        u = (i / n * 4) % 4
        k, f = int(u), u - int(u)
        corners = [(0, 0), (side, 0), (side, side), (0, side), (0, 0)]
        a, b = np.array(corners[k]), np.array(corners[k + 1])
        xy = a + (b - a) * f
        pts.append(np.array([xy[0], xy[1], 1.0 + 0.2 * math.sin(i / 30)]))
    return pts


def test_locks_on_true_scale_with_noise_and_drift():
    st = fly(ScaleEstimator(), square_path(), slam_noise=0.01, metric_noise=0.02,
             drift=(0.02, -0.01, 0.0))
    assert st.locked
    assert abs(st.scale - TRUE_SCALE) / TRUE_SCALE < 0.05


def test_hover_and_turning_on_the_spot_never_lock():
    path = [np.array([0.0, 0.0, 1.0])] * 400
    st = fly(ScaleEstimator(), path, metric_noise=0.01)
    assert not st.locked and st.pairs == 0


def test_needs_enough_moves():
    st = fly(ScaleEstimator(ScaleConfig(min_pairs=50)), square_path(n=300))
    assert not st.locked and 'moves seen' in st.reason


def test_disagreeing_moves_do_not_lock():
    rng = np.random.default_rng(3)
    est = ScaleEstimator()
    for i in range(400):
        t = 100 + i * 0.1
        est.add_metric(t, (i * 0.03, 0, 0))
        est.add_slam(t, (i * 0.03 / TRUE_SCALE * rng.uniform(0.3, 3.0), 0, 0))
    assert not est.status.locked


def test_reset_forgets():
    est = ScaleEstimator()
    fly(est, square_path())
    est.reset()
    assert not est.status.locked and est.status.pairs == 0


def test_no_metric_data_means_no_estimate():
    est = ScaleEstimator()
    for i in range(100):
        est.add_slam(100 + i * 0.1, (i, 0, 0))
    assert est.status.pairs == 0 and math.isnan(est.status.scale)
