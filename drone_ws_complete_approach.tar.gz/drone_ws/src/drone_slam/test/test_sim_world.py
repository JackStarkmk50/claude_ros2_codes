"""The sim pieces fit together: survey path keyframes + walls of the textured world -> a floor
map on which every room in rooms_sim.yaml is free and clear."""

import os

import numpy as np

from drone_slam.core.grid import OCCUPIED, GridConfig, build_grid
from drone_slam.core.rooms import Rooms
from drone_slam.core.survey import TEXTURED_ROOM, SurveyPath

HERE = os.path.dirname(__file__)


def textured_world_points(rng):
    pts = []
    for _ in range(2500):
        u, z = rng.uniform(-5, 5), rng.uniform(0.0, 2.2)
        pts += [(u, -5, z), (u, 5, z), (-5, u, z), (5, u, z)]
        if not 1.0 <= u <= 2.5:
            pts.append((1.5, u, z))                    # partition, doorway left open
    return np.array(pts)


def test_rooms_sim_are_free_on_a_map_of_the_textured_world():
    rng = np.random.default_rng(0)
    path = SurveyPath(TEXTURED_ROOM)
    kfs = np.array([(*path.at(t)[:2], 1.0) for t in np.arange(0, path.duration, 2.0)])
    g = build_grid(textured_world_points(rng), kfs, None, GridConfig())
    rooms = Rooms.load(os.path.join(HERE, '..', 'config', 'rooms_sim.yaml'))
    assert rooms.check(g) == []
    assert g.value(1.5, -2.0) == OCCUPIED or g.value(1.45, -2.0) == OCCUPIED   # partition
    assert g.value(1.5, 1.75) != OCCUPIED                                        # doorway


def test_textured_world_file_keeps_names_the_sim_scripts_use():
    sdf = open(os.path.join(HERE, '..', 'sim', 'worlds', 'indoor_search_textured.sdf')).read()
    for needle in ('<world name="indoor_search">', '<model name="person_a">',
                   '<model name="person_b">', '<model name="drone">',
                   '<topic>sim/camera/image_raw</topic>', 'p_south', 'p_north'):
        assert needle in sdf
    for tex in ('floor.jpg', 'wall_n.png', 'wall_p1.png', 'box1.png'):
        assert os.path.isfile(os.path.join(HERE, '..', 'sim', 'textures', tex))
