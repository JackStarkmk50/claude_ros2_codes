import math

import numpy as np
import pytest

from drone_slam.core.frames import OPTICAL_TO_BODY, camera_pose_to_map, level_rotation, quat_to_rot, rot_to_quat

IDENT = (0.0, 0.0, 0.0, 1.0)


def q_about(axis, deg):
    a = math.radians(deg) / 2
    v = np.asarray(axis, float) / np.linalg.norm(axis) * math.sin(a)
    return (*v, math.cos(a))


def test_start_is_origin_level_yaw_zero():
    p, q, yaw = camera_pose_to_map((0, 0, 0), IDENT, 0.0, 0.9, 0.5)
    assert np.allclose(p, (0, 0, 0.9)) and np.allclose(q, IDENT) and yaw == pytest.approx(0)


def test_camera_forward_is_map_x_and_right_is_minus_y():
    p, _, _ = camera_pose_to_map((0, 0, 2.0), IDENT, 0.0, 0.0, 0.5)
    assert np.allclose(p, (1.0, 0, 0))
    p, _, _ = camera_pose_to_map((2.0, 0, 0), IDENT, 0.0, 0.0, 0.5)
    assert np.allclose(p, (0, -1.0, 0))
    p, _, _ = camera_pose_to_map((0, 2.0, 0), IDENT, 0.0, 0.0, 0.5)   # optical y is down
    assert np.allclose(p, (0, 0, -1.0))


def test_tilted_camera_forward_goes_down():
    p, _, _ = camera_pose_to_map((0, 0, 1.0), IDENT, 30.0, 0.0, 1.0)
    assert np.allclose(p, (math.cos(math.radians(30)), 0, -math.sin(math.radians(30))))


def test_left_turn_is_positive_yaw():
    # level camera: turning left = rotating about optical -y (up)
    _, _, yaw = camera_pose_to_map((0, 0, 0), q_about((0, -1, 0), 40), 0.0, 0.0, 1.0)
    assert yaw == pytest.approx(40, abs=1e-6)


def test_tilted_camera_yaw_stays_level():
    # the drone yaws about the world vertical; seen from a tilted camera that is L^T Rz L
    lev = level_rotation(20.0)
    a = math.radians(40)
    rz = np.array([[math.cos(a), -math.sin(a), 0], [math.sin(a), math.cos(a), 0], [0, 0, 1]])
    _, q, yaw = camera_pose_to_map((0, 0, 0), rot_to_quat(lev.T @ rz @ lev), 20.0, 0.0, 1.0)
    assert yaw == pytest.approx(40, abs=1e-6)
    assert quat_to_rot(q)[2, 2] == pytest.approx(1.0, abs=1e-9)   # still level


def test_quaternion_round_trip():
    rng = np.random.default_rng(0)
    for _ in range(50):
        q = rng.normal(size=4)
        q /= np.linalg.norm(q)
        q = q if q[3] >= 0 else -q
        assert np.allclose(rot_to_quat(quat_to_rot(q)), q, atol=1e-9)


def test_ros_axes_input_matches_optical():
    """stella_vslam_ros publishes O p and O R O^T; the result must be the same."""
    rng = np.random.default_rng(1)
    o = OPTICAL_TO_BODY
    for _ in range(20):
        p = rng.normal(size=3)
        q = rng.normal(size=4)
        q /= np.linalg.norm(q)
        r = quat_to_rot(q)
        a = camera_pose_to_map(p, q, 25.0, 1.1, 0.4, axes='optical')
        b = camera_pose_to_map(o @ p, rot_to_quat(o @ r @ o.T), 25.0, 1.1, 0.4, axes='ros')
        assert np.allclose(a[0], b[0]) and np.allclose(a[1], b[1]) and a[2] == pytest.approx(b[2])


def test_bad_axes_name():
    with pytest.raises(ValueError):
        camera_pose_to_map((0, 0, 0), IDENT, 0, 0, 1, axes='enu')
