import math

import pytest

from drone_slam.core.survey import TEXTURED_ROOM, SurveyPath


def samples(path, dt=0.1):
    out, t = [], 0.0
    while True:
        x, y, yaw, done = path.at(t)
        out.append((t, x, y, yaw))
        if done:
            return out
        t += dt


def test_speed_and_yaw_rate_limits():
    p = SurveyPath(TEXTURED_ROOM, speed_m_s=0.25, max_yaw_rate_deg_s=15)
    s = samples(p)
    for (t0, x0, y0, a0), (t1, x1, y1, a1) in zip(s, s[1:]):
        assert math.hypot(x1 - x0, y1 - y0) / (t1 - t0) <= 0.25 + 1e-6
        assert abs((a1 - a0 + 180) % 360 - 180) / (t1 - t0) <= 15 + 1e-6


def test_turns_on_the_spot_only_when_stopped():
    p = SurveyPath([(0, 0), (2, 0), (2, 2)], shuffle=None)
    x, y, yaw, _ = p.at(2 / 0.25 + 3.0)          # 3 s into the 90 deg turn at (2, 0)
    assert (x, y) == pytest.approx((2, 0)) and yaw == pytest.approx(45)


def test_shuffle_keeps_heading_then_ends_where_it_started():
    p = SurveyPath(TEXTURED_ROOM)
    for t in range(0, 9):
        assert p.at(t)[2] == pytest.approx(0)
    x, y, _, done = p.at(p.duration + 1)
    assert done and (x, y) == pytest.approx((0, 0))


def test_textured_room_path_keeps_clear_of_walls_and_person():
    p = SurveyPath(TEXTURED_ROOM)
    for _, x, y, _ in samples(p, 0.5):
        assert -3.8 <= x <= 3.8 and -3.8 <= y <= 3.8          # outer walls at +-5
        if abs(x - 1.5) < 0.6:                                 # crossing the partition
            assert 1.4 <= y <= 2.1                             # through the doorway (1.0 .. 2.5)
        assert math.hypot(x + 1.5, y - 2.598) > 0.9            # person_a


def test_bad_limits():
    with pytest.raises(ValueError):
        SurveyPath(TEXTURED_ROOM, speed_m_s=0)
