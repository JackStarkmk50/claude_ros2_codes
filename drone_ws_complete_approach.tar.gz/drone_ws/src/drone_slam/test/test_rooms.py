import numpy as np
import pytest

from drone_slam.core.grid import GridConfig, build_grid
from drone_slam.core.rooms import Room, Rooms, normalize

DOC = {'frame': 'map', 'rooms': {
    'Living Room': {'x': 3.0, 'y': 0.0, 'aliases': ['hall', 'lounge']},
    'bedroom_2': {'x': 5.0, 'y': 2.0, 'yaw_deg': 90, 'aliases': ['room 2', 'second room']},
}}


def grid():
    rng = np.random.default_rng(0)
    pts = [(rng.uniform(-1, 7), w, rng.uniform(0.3, 1.5)) for w in (-3, 3) for _ in range(800)]
    pts += [(w, rng.uniform(-3, 3), rng.uniform(0.3, 1.5)) for w in (-1, 7) for _ in range(800)]
    kfs = [(x, y, 1.0) for x in np.linspace(0, 6, 7) for y in (-2, 0, 2)]
    return build_grid(np.array(pts), np.array(kfs), None, GridConfig())


def test_names_and_aliases():
    r = Rooms.from_dict(DOC)
    assert r.names() == ['bedroom_2', 'living_room']
    assert r.get('Room 2').name == 'bedroom_2' and r.get('LOUNGE').name == 'Living Room'
    assert r.get('kitchen') is None
    assert normalize('  Second-Room! ') == 'second_room'


def test_duplicates_rejected():
    with pytest.raises(ValueError):
        Rooms([Room('a', 0, 0, aliases=['x']), Room('b', 1, 1, aliases=['x'])])
    with pytest.raises(ValueError):
        Rooms([Room('Kitchen', 0, 0), Room('kitchen', 1, 1)])


def test_nearest():
    r = Rooms.from_dict(DOC)
    assert r.nearest(4.6, 1.0).name == 'bedroom_2'
    assert r.nearest(100, 100, max_dist_m=3) is None


def test_check_against_map():
    g = grid()
    assert Rooms.from_dict(DOC).check(g) == []
    bad = Rooms([Room('wall', 3.0, -2.98), Room('outside', 20, 20), Room('tight', 3.0, -2.75)])
    problems = ' '.join(bad.check(g))
    assert 'wall' in problems and 'obstacle' in problems
    assert 'outside' in problems and 'unknown' in problems
    assert 'tight' in problems


def test_load_example_file():
    import os
    path = os.path.join(os.path.dirname(__file__), '..', 'config', 'rooms.example.yaml')
    r = Rooms.load(path)
    assert 'living_room' in r.names() and r.get('room 2').name == 'bedroom_2'
