import numpy as np
import pytest

from drone_slam.core.frames import level_rotation
from drone_slam.core.grid import FREE, OCCUPIED, UNKNOWN, GridConfig, build_grid, \
    level_points, load_map_server, save_map_server

SCALE = 0.5      # metres per SLAM unit
TILT = 15.0
H0 = 1.0         # camera height at the start


def to_slam(p_map):
    """Inverse of level_points, to fake what the SLAM system would store."""
    p = np.asarray(p_map, float).copy()
    p[:, 2] -= H0
    return (p @ level_rotation(TILT)) / SCALE


def room(seed=0):
    """8 m x 6 m room from x = -1..7, y = -3..3; texture points on the walls, floor and ceiling."""
    rng = np.random.default_rng(seed)
    pts = []
    for _ in range(3000):
        side = rng.integers(4)
        u, z = rng.uniform(0, 1), rng.uniform(0.0, 2.6)
        pts.append([(-1 + 8 * u, -3, z), (-1 + 8 * u, 3, z), (-1, -3 + 6 * u, z),
                    (7, -3 + 6 * u, z)][side])
    for _ in range(300):
        pts.append((rng.uniform(-1, 7), rng.uniform(-3, 3), 0.0))      # floor
        pts.append((rng.uniform(-1, 7), rng.uniform(-3, 3), 2.6))      # ceiling
    kfs = [(x, 0.0, H0) for x in np.linspace(0, 6, 13)]
    return np.array(pts), np.array(kfs)


def build():
    pts, kfs = room()
    p = level_points(to_slam(pts), TILT, H0, SCALE)
    k = level_points(to_slam(kfs), TILT, H0, SCALE)
    return build_grid(p, k, None, GridConfig())


def test_level_points_inverts_the_slam_frame():
    pts, _ = room()
    assert np.allclose(level_points(to_slam(pts), TILT, H0, SCALE), pts)


def test_walls_occupied_inside_free_outside_unknown():
    g = build()
    assert g.value(3.0, 0.0) == FREE and g.value(5.0, 1.5) == FREE
    # a wall at exactly y = -3 / x = 7 may land in either neighbouring cell
    assert OCCUPIED in (g.value(3.0, -3.05), g.value(3.0, -2.95))
    assert OCCUPIED in (g.value(6.95, 0.5), g.value(7.05, 0.5))
    assert g.value(3.0, 5.0) == UNKNOWN and g.value(-5, 0) == UNKNOWN


def test_floor_and_ceiling_points_are_not_obstacles():
    g = build()
    inside = [g.value(x, y) for x in np.arange(0, 6, 0.5) for y in np.arange(-2, 2.1, 0.5)]
    assert OCCUPIED not in inside


def test_clearance():
    g = build()
    assert g.clearance_m(3.0, 0.0, limit_m=5) == pytest.approx(2.9, abs=0.2)
    assert g.clearance_m(3.0, -2.6) < 0.5


def test_observations_limit_clearing_to_rays():
    pts = np.array([[4.0, 0.0, 1.0]] * 3)
    kfs = np.array([[0.0, 0.0, 1.0], [0.0, 3.0, 1.0]])
    g = build_grid(pts, kfs, [[0], [0], [0]], GridConfig(padding_m=0.5))
    assert g.value(2.0, 0.0) == FREE and g.value(2.0, 1.5) == UNKNOWN
    assert g.value(4.0, 0.0) == OCCUPIED


def test_no_usable_points_explains():
    with pytest.raises(ValueError, match='min_z'):
        build_grid(np.array([[1, 1, 5.0]]), np.zeros((0, 3)))


def test_map_server_round_trip(tmp_path):
    g = build()
    save_map_server(g, str(tmp_path / 'm.pgm'), str(tmp_path / 'm.yaml'))
    back = load_map_server(str(tmp_path / 'm.yaml'))
    assert np.array_equal(back.data, g.data)
    assert back.origin_x == pytest.approx(g.origin_x, abs=1e-3)
    assert back.value(3.0, 0.0) == FREE
