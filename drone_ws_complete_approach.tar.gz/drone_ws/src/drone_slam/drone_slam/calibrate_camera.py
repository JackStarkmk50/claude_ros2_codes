"""calibrate_camera: measure the webcam's intrinsics with a printed checkerboard.

    # live, from the camera (stop the perception launch first, it holds /dev/video0)
    ros2 run drone_slam calibrate_camera --device /dev/video0
    # or from pictures you took
    ros2 run drone_slam calibrate_camera --images ~/calib_pics
    # the Gazebo camera (ideal, from its FOV): no board needed
    ros2 run drone_slam calibrate_camera --sim

Board: the default is 9 x 6 INNER corners (a 10 x 7 square board), 25 mm squares. Measure your
printed square with a ruler and pass --square-mm. Tape it flat on a board.

Writes ~/drone_ws/camera_calib.yaml (camera_info format) and the stella_vslam config with these
numbers filled in (~/drone_ws/stella_webcam.yaml, or stella_sim.yaml with --sim), and prints PASS
or what to redo.
"""

import argparse
import glob
import os
import sys
import time

from drone_slam.core.calibration import calibrate, find_corners, from_hfov

SIM_W, SIM_H, SIM_HFOV = 640, 480, 1.047     # sim/gazebo/worlds/indoor_search.sdf


def _package_config(name):
    try:
        from ament_index_python.packages import get_package_share_directory
        return os.path.join(get_package_share_directory('drone_slam'), 'config', name)
    except (ImportError, LookupError):
        return os.path.join(os.path.dirname(__file__), '..', 'config', name)


def _gray(img):
    import cv2

    return img if img.ndim == 2 else cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def from_images(folder, cols, rows):
    import cv2

    sets, size = [], None
    files = sorted(glob.glob(os.path.join(os.path.expanduser(folder), '*')))
    for f in files:
        img = cv2.imread(f)
        if img is None:
            continue
        g = _gray(img)
        size = (g.shape[1], g.shape[0])
        c = find_corners(g, cols, rows)
        print(f'  {os.path.basename(f)}: {"board found" if c is not None else "no board"}')
        if c is not None:
            sets.append(c)
    return sets, size


def from_device(device, cols, rows, views, width, height):
    """Grab a picture every second while the board is visible and has moved since the last one."""
    import cv2
    import numpy as np

    cap = cv2.VideoCapture(device)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    if not cap.isOpened():
        sys.exit(f'cannot open {device} (is the perception launch still running?)')
    sets, last, size, t_last = [], None, None, 0.0
    print(f'Move the board slowly: near, far, tilted, and into every corner. Need {views}.')
    while len(sets) < views:
        ok, img = cap.read()
        if not ok:
            sys.exit('camera read failed')
        g = _gray(img)
        size = (g.shape[1], g.shape[0])
        if time.monotonic() - t_last < 1.0:
            continue
        c = find_corners(g, cols, rows)
        if c is None:
            continue
        if last is not None and np.abs(c - last).mean() < 0.05 * size[0]:
            continue    # board hasn't moved enough to add new information
        sets.append(c)
        last, t_last = c, time.monotonic()
        print(f'  picture {len(sets)}/{views}')
    cap.release()
    return sets, size


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument('--device')
    src.add_argument('--images')
    src.add_argument('--sim', action='store_true')
    ap.add_argument('--cols', type=int, default=9, help='inner corners across')
    ap.add_argument('--rows', type=int, default=6, help='inner corners down')
    ap.add_argument('--square-mm', type=float, default=25.0)
    ap.add_argument('--views', type=int, default=20)
    ap.add_argument('--width', type=int, default=640)
    ap.add_argument('--height', type=int, default=480)
    ap.add_argument('--out', default='~/drone_ws/camera_calib.yaml')
    ap.add_argument('--stella-template', help='default: the package config/stella_*.yaml')
    a = ap.parse_args(argv)
    out = os.path.expanduser(a.out)

    if a.sim:
        intr = from_hfov(SIM_W, SIM_H, SIM_HFOV)
        problems = []
    else:
        if a.images:
            sets, size = from_images(a.images, a.cols, a.rows)
        else:
            sets, size = from_device(a.device, a.cols, a.rows, a.views, a.width, a.height)
        if not size:
            sys.exit('no pictures read')
        res = calibrate(sets, size[0], size[1], a.cols, a.rows, a.square_mm / 1000.0)
        intr, problems = res.intrinsics, res.problems
        if intr is None:
            sys.exit('CALIBRATION FAILED: ' + '; '.join(problems))
        print(f'board coverage {res.coverage:.0%}')

    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, 'w') as f:
        f.write(intr.camera_info_yaml())
    name = 'stella_sim.yaml' if a.sim else 'stella_webcam.yaml'
    template = a.stella_template or _package_config(name)
    stella_out = os.path.join(os.path.dirname(out), name)
    with open(template) as f:
        text = intr.fill_stella(f.read())
    with open(stella_out, 'w') as f:
        f.write(text)
    print(f'size {intr.width}x{intr.height}  fx {intr.fx:.1f} fy {intr.fy:.1f}  '
          f'cx {intr.cx:.1f} cy {intr.cy:.1f}  FOV {intr.hfov_deg():.1f} deg  '
          f'error {intr.rms_px:.2f} px  ({intr.views} pictures)')
    print(f'dist {[round(d, 4) for d in intr.dist]}')
    print(f'wrote {out} and {stella_out}')
    if problems:
        print('CALIBRATION: REDO\n  ' + '\n  '.join(problems))
        return 1
    print('CALIBRATION: PASS')
    return 0


if __name__ == '__main__':
    sys.exit(main())

