"""make_map: saved SLAM map -> Nav2 floor map (map.pgm + map.yaml) + a preview with the rooms.

    ros2 run drone_slam make_map ~/maps/house.msg --session ~/drone_ws/slam_session.yaml \\
        --rooms ~/maps/rooms.yaml --out ~/maps/house

--session      the file slam_scale wrote while mapping (scale, start height, tilt), or give
--scale        metres per SLAM unit (what slam_scale reported, locked)
--tilt         camera_mount.tilt_down_deg
--start-height camera height above the floor when SLAM started

Prints how many points went into the map, and any room point that is not on free floor.
Run it on the laptop, not the Pi.
"""

import argparse
import os
import sys

import numpy as np

from drone_slam.core import stella_map
from drone_slam.core.grid import FREE, OCCUPIED, GridConfig, build_grid, level_points, \
    save_map_server
from drone_slam.core.rooms import Rooms


def preview_png(grid, rooms, path, scale_px=4):
    import cv2

    img = np.full(grid.data.shape + (3,), 160, np.uint8)
    img[grid.data == FREE] = (255, 255, 255)
    img[grid.data == OCCUPIED] = (0, 0, 0)
    img = cv2.resize(img[::-1], None, fx=scale_px, fy=scale_px, interpolation=cv2.INTER_NEAREST)
    h = img.shape[0]

    def px(x, y):
        r, c = grid.cell(x, y)
        return int((c + 0.5) * scale_px), int(h - (r + 0.5) * scale_px)

    cv2.drawMarker(img, px(0.0, 0.0), (0, 160, 0), cv2.MARKER_TRIANGLE_UP, 14, 2)
    for key, r in sorted((rooms.rooms if rooms else {}).items()):
        p = px(r.x, r.y)
        cv2.circle(img, p, 6, (0, 0, 220), -1)
        cv2.putText(img, key, (p[0] + 8, p[1] - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 180), 1)
    cv2.imwrite(path, img)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument('map', help='stella_vslam .msg map, or a .csv (kind,x,y,z)')
    ap.add_argument('--session')
    ap.add_argument('--scale', type=float)
    ap.add_argument('--tilt', type=float)
    ap.add_argument('--start-height', type=float)
    ap.add_argument('--resolution', type=float, default=0.10)
    ap.add_argument('--min-z', type=float, default=0.20)
    ap.add_argument('--max-z', type=float, default=1.80)
    ap.add_argument('--min-hits', type=int, default=2)
    ap.add_argument('--rooms')
    ap.add_argument('--out', required=True, help='output path without extension')
    a = ap.parse_args(argv)
    if a.session:
        import yaml

        with open(os.path.expanduser(a.session)) as f:
            sess = yaml.safe_load(f)
        a.scale = a.scale if a.scale is not None else float(sess['scale'])
        a.tilt = a.tilt if a.tilt is not None else float(sess.get('tilt', 0.0))
        a.start_height = a.start_height if a.start_height is not None \
            else float(sess['start_height'])
    if a.scale is None:
        ap.error('give --session or --scale')
    a.tilt = a.tilt or 0.0
    a.start_height = a.start_height or 0.0
    print(f'scale {a.scale:.4f} m/unit, tilt {a.tilt} deg, start height {a.start_height:.2f} m')

    pts, kfs, obs = stella_map.load(os.path.expanduser(a.map))
    pts = level_points(pts, a.tilt, a.start_height, a.scale)
    kfs = level_points(kfs, a.tilt, a.start_height, a.scale)
    cfg = GridConfig(a.resolution, a.min_z, a.max_z, a.min_hits)
    grid = build_grid(pts, kfs, obs, cfg)

    out = os.path.expanduser(a.out)
    os.makedirs(os.path.dirname(out) or '.', exist_ok=True)
    save_map_server(grid, out + '.pgm', out + '.yaml')
    rooms = Rooms.load(os.path.expanduser(a.rooms)) if a.rooms else None
    preview_png(grid, rooms, out + '_preview.png')

    band = int(((pts[:, 2] >= a.min_z) & (pts[:, 2] <= a.max_z)).sum())
    area = grid.data.size * a.resolution ** 2
    print(f'{len(pts)} points ({band} at obstacle height), {len(kfs)} keyframes')
    print(f'map {grid.data.shape[1]} x {grid.data.shape[0]} cells ({area:.0f} m2): '
          f'{(grid.data == FREE).mean():.0%} free, {(grid.data == OCCUPIED).mean():.0%} '
          f'occupied, rest unknown')
    print(f'wrote {out}.pgm, {out}.yaml, {out}_preview.png')
    if rooms:
        problems = rooms.check(grid)
        print('rooms: ' + ', '.join(rooms.names()))
        if problems:
            print('ROOMS: FIX\n  ' + '\n  '.join(problems))
            return 1
        print('ROOMS: OK')
    return 0


if __name__ == '__main__':
    sys.exit(main())
