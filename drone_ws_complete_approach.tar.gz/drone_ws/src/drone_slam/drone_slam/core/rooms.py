"""Named places on the map (rooms.yaml): what the LLM may choose from.

    frame: map
    rooms:
      living_room:
        x: 2.4
        y: -0.8
        yaw_deg: 90          # optional: which way to face on arrival
        aliases: [hall, lounge]

The LLM only ever gets `names()`; it picks one, and code looks up the point. It can't invent
coordinates. `check()` makes sure each point is on known free floor with room around it, so a
typo in the file can't send the drone into a wall.
"""

import math
import re
from dataclasses import dataclass, field

from drone_slam.core.grid import FREE


@dataclass
class Room:
    name: str
    x: float
    y: float
    yaw_deg: float = float('nan')
    aliases: list = field(default_factory=list)


def normalize(name):
    return re.sub(r'[^a-z0-9]+', '_', str(name).strip().lower()).strip('_')


class Rooms:
    def __init__(self, rooms, frame='map'):
        self.frame = frame
        self.rooms = {}
        self._alias = {}
        for r in rooms:
            key = normalize(r.name)
            if key in self._alias:
                raise ValueError(f'room name "{r.name}" used twice')
            self.rooms[key] = r
            self._alias[key] = key
            for a in r.aliases:
                ak = normalize(a)
                if ak in self._alias and self._alias[ak] != key:
                    raise ValueError(f'alias "{a}" used by two rooms')
                self._alias[ak] = key

    @classmethod
    def from_dict(cls, d):
        rooms = []
        for name, v in (d.get('rooms') or {}).items():
            rooms.append(Room(str(name), float(v['x']), float(v['y']),
                              float(v.get('yaw_deg', float('nan'))), list(v.get('aliases', []))))
        return cls(rooms, d.get('frame', 'map'))

    @classmethod
    def load(cls, path):
        import yaml

        with open(path) as f:
            return cls.from_dict(yaml.safe_load(f) or {})

    def names(self):
        return sorted(self.rooms)

    def get(self, name):
        """Room for a name or alias, or None."""
        key = self._alias.get(normalize(name))
        return self.rooms.get(key) if key else None

    def nearest(self, x, y, max_dist_m=float('inf')):
        """The room whose point is closest to (x, y): 'you are in the hallway'."""
        best = None
        for r in self.rooms.values():
            d = math.hypot(r.x - x, r.y - y)
            if d <= max_dist_m and (best is None or d < best[0]):
                best = (d, r)
        return best[1] if best else None

    def check(self, grid, min_clearance_m=0.5):
        """Problems with the room points on this map, as readable lines (empty = all good)."""
        problems = []
        for key, r in sorted(self.rooms.items()):
            v = grid.value(r.x, r.y)
            if v != FREE:
                what = 'unknown (not mapped)' if v < 0 else 'an obstacle'
                problems.append(f'{key}: point ({r.x:.2f}, {r.y:.2f}) is on {what}')
                continue
            c = grid.clearance_m(r.x, r.y, limit_m=min_clearance_m * 2)
            if c < min_clearance_m:
                problems.append(f'{key}: only {c:.2f} m from an obstacle, need {min_clearance_m}')
        return problems
