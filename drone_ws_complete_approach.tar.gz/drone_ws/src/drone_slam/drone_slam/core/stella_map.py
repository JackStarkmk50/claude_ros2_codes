"""Read the points and keyframes out of a saved stella_vslam map (.msg, MessagePack).

stella_vslam (map_format: msgpack, the default) saves its map database as MessagePack:
    keyframes: {id: {rot_cw: [qx, qy, qz, qw], trans_cw: [x, y, z], lm_ids: [id or -1, ...], ...}}
    landmarks: {id: {pos_w: [x, y, z], ...}}
(checked against stella_vslam's source, src/stella_vslam/io/map_database_io_msgpack.cc and
data/keyframe.cc, 2026-10-08). rot_cw / trans_cw map WORLD to CAMERA, so the camera centre is
-R^T t. All in optical axes. The sqlite3 map format is not read here.

A plain CSV is also accepted, for other SLAM systems or hand-made tests:
    kind,x,y,z          kind = point | keyframe
"""

import numpy as np

from drone_slam.core.frames import quat_to_rot


def from_database(db):
    """(points [N,3], keyframes [K,3], observations list per point) from a decoded map dict."""
    kf_key = 'keyframes' if 'keyframes' in db else 'keyfrms'    # older versions: keyfrms
    for key in (kf_key, 'landmarks'):
        if key not in db:
            raise KeyError(f'map has no "{key}" (keys: {sorted(db)[:10]}); format changed?')
    kfdb = db[kf_key]
    kf_ids = sorted(kfdb, key=lambda k: int(k))
    kf_index = {int(k): i for i, k in enumerate(kf_ids)}
    centres = []
    for k in kf_ids:
        kf = kfdb[k]
        rot = quat_to_rot(kf['rot_cw'])
        centres.append(-rot.T @ np.asarray(kf['trans_cw'], float))
    lm_ids = sorted(db['landmarks'], key=lambda k: int(k))
    lm_index = {int(k): i for i, k in enumerate(lm_ids)}
    points = np.array([db['landmarks'][k]['pos_w'] for k in lm_ids], float).reshape(-1, 3)
    obs = [[] for _ in lm_ids]
    for k in kf_ids:
        for lm in kfdb[k].get('lm_ids', []) or []:
            if lm is not None and int(lm) >= 0 and int(lm) in lm_index:
                obs[lm_index[int(lm)]].append(kf_index[int(k)])
    return points, np.array(centres, float).reshape(-1, 3), obs


def load_stella(path):
    import msgpack

    with open(path, 'rb') as f:
        db = msgpack.unpackb(f.read(), strict_map_key=False)
    return from_database(db)


def load_csv(path):
    points, kfs = [], []
    with open(path) as f:
        for line in f:
            parts = [p.strip() for p in line.split(',')]
            if len(parts) != 4 or parts[0] not in ('point', 'keyframe'):
                continue
            (points if parts[0] == 'point' else kfs).append([float(v) for v in parts[1:]])
    return np.array(points, float).reshape(-1, 3), np.array(kfs, float).reshape(-1, 3), None


def load(path):
    return load_csv(path) if path.endswith('.csv') else load_stella(path)
