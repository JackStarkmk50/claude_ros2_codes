"""Pure-Python SLAM helpers (no ROS imports), unit-tested in test/."""
