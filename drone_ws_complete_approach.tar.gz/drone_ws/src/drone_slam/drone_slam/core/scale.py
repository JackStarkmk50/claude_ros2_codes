"""Metric scale for monocular SLAM, from the drone's own short-term motion.

One camera gives the path in unknown units: "moved 1.0" may be 0.3 m or 3 m. ArduPilot's EKF
(MTF-01 flow + ToF range + IMU) gives position in metres that DRIFTS over minutes but is good over
a few seconds. So we compare how far each one says the drone moved over the same short interval:

    metric_distance ~= scale * slam_distance

and fit `scale` over a sliding window of such pairs. Distances (norms), not vectors, are compared,
so the SLAM frame's unknown rotation doesn't matter. Intervals where the drone barely moved are
skipped: there the flow noise is as big as the motion. Pure turning on the spot also gives no
pairs, since neither position moves.

The estimate is only trusted (`locked`) once enough motion was seen and the pairs agree.
"""

import bisect
import math
from collections import deque
from dataclasses import dataclass


@dataclass
class ScaleConfig:
    interval_s: float = 1.0          # compare motion over this long
    min_metric_move_m: float = 0.15  # skip intervals shorter than this (flow noise)
    window: int = 30                 # keep this many pairs
    min_pairs: int = 8               # need this many before locking
    max_spread: float = 0.25         # robust spread of per-pair scales / scale, to lock
    max_age_s: float = 0.25          # metric sample must be within this of the SLAM stamp


@dataclass
class ScaleStatus:
    scale: float = float('nan')
    locked: bool = False
    pairs: int = 0
    spread: float = float('nan')
    reason: str = 'no motion yet'


def _dist(a, b):
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))


class ScaleEstimator:
    def __init__(self, cfg=None):
        self.cfg = cfg or ScaleConfig()
        self._metric_t = []          # sorted stamps
        self._metric_p = []
        self._anchor = None          # (t, slam_pos, metric_pos) at the start of the interval
        self._pairs = deque(maxlen=self.cfg.window)   # (slam_d, metric_d)
        self.status = ScaleStatus()

    def add_metric(self, t, pos):
        """EKF position in metres (e.g. /mavros/local_position/pose), any fixed frame."""
        if self._metric_t and t <= self._metric_t[-1]:
            return
        self._metric_t.append(t)
        self._metric_p.append(tuple(pos))
        horizon = t - 4.0 * self.cfg.interval_s - 1.0
        cut = bisect.bisect_left(self._metric_t, horizon)
        if cut:
            del self._metric_t[:cut]
            del self._metric_p[:cut]

    def _metric_at(self, t):
        i = bisect.bisect_left(self._metric_t, t)
        best = None
        for j in (i - 1, i):
            if 0 <= j < len(self._metric_t):
                dt = abs(self._metric_t[j] - t)
                if dt <= self.cfg.max_age_s and (best is None or dt < best[0]):
                    best = (dt, self._metric_p[j])
        return None if best is None else best[1]

    def add_slam(self, t, pos):
        """SLAM camera position in SLAM units. Returns the updated status."""
        metric = self._metric_at(t)
        if metric is None:
            return self.status
        if self._anchor is None:
            self._anchor = (t, tuple(pos), metric)
            return self.status
        t0, s0, m0 = self._anchor
        if t - t0 < self.cfg.interval_s:
            return self.status
        self._anchor = (t, tuple(pos), metric)
        md, sd = _dist(metric, m0), _dist(pos, s0)
        if md >= self.cfg.min_metric_move_m and sd > 1e-9:
            self._pairs.append((sd, md))
        self._update()
        return self.status

    def reset(self):
        """Call when the SLAM system re-initializes: its units change."""
        self._anchor = None
        self._pairs.clear()
        self.status = ScaleStatus(reason='reset')

    def _update(self):
        c, n = self.cfg, len(self._pairs)
        st = ScaleStatus(pairs=n)
        if n == 0:
            st.reason = 'no motion yet'
            self.status = st
            return
        # least squares through the origin: scale = sum(s*m) / sum(s*s)
        st.scale = sum(s * m for s, m in self._pairs) / sum(s * s for s, _ in self._pairs)
        ratios = sorted(m / s for s, m in self._pairs)
        med = ratios[n // 2]
        mad = sorted(abs(r - med) for r in ratios)[n // 2]
        st.spread = 1.4826 * mad / med if med > 0 else float('inf')
        if n < c.min_pairs:
            st.reason = f'{n}/{c.min_pairs} moves seen'
        elif st.spread > c.max_spread:
            st.reason = f'moves disagree (spread {st.spread:.0%})'
        else:
            st.locked, st.reason = True, 'locked'
        self.status = st
