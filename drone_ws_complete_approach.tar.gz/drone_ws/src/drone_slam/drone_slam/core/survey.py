"""A slow mapping path: position + heading at any time, for flying a SLAM survey in the simulator.

Monocular SLAM maps best when the camera moves sideways or forwards slowly and turns gently, so:
- the drone moves along straight legs at `speed_m_s`;
- it faces the direction it is moving (`face_travel`), turning at most `max_yaw_rate_deg_s`, and
  waits at a corner until it has turned (no fast spins on the spot);
- the first legs can be a small sideways shuffle with a fixed heading, which gives SLAM the
  parallax it needs to start.

Coordinates are Gazebo world metres (x east, y north), heading in degrees from +x, CCW.
"""

import math
from dataclasses import dataclass

# west room loop, through the doorway, east room, back. For indoor_search_textured.sdf
# (partition at x = 1.5, doorway y = 1.0 .. 2.5). Stays >= 1.2 m from walls and away from person_a.
TEXTURED_ROOM = [
    (0.0, 0.0), (-3.5, -3.5), (-3.5, 3.5), (-3.5, 0.0), (0.3, 1.75), (2.6, 1.75),
    (3.3, -3.5), (3.3, 3.5), (2.6, 1.75), (0.3, 1.75), (0.0, 0.0),
]
SHUFFLE = [(0.0, 0.0), (0.0, 0.6), (0.0, -0.6), (0.0, 0.0)]


@dataclass
class Leg:
    x0: float
    y0: float
    x1: float
    y1: float
    yaw: float           # heading to hold on this leg
    turn_s: float        # time spent turning to `yaw` before moving
    move_s: float


def _wrap(a):
    return (a + 180.0) % 360.0 - 180.0


class SurveyPath:
    def __init__(self, waypoints, speed_m_s=0.25, max_yaw_rate_deg_s=15.0, start_yaw_deg=0.0,
                 shuffle=SHUFFLE):
        if speed_m_s <= 0 or max_yaw_rate_deg_s <= 0:
            raise ValueError('speed and yaw rate must be > 0')
        self.legs = []
        yaw = start_yaw_deg
        pts = list(shuffle or []) + list(waypoints)
        fixed = len(shuffle or [])
        for i in range(len(pts) - 1):
            (x0, y0), (x1, y1) = pts[i], pts[i + 1]
            d = math.hypot(x1 - x0, y1 - y0)
            if d < 1e-6:
                continue
            target = yaw if i < fixed else math.degrees(math.atan2(y1 - y0, x1 - x0))
            turn = abs(_wrap(target - yaw)) / max_yaw_rate_deg_s
            self.legs.append(Leg(x0, y0, x1, y1, target, turn, d / speed_m_s))
            yaw = target
        self.start_yaw = start_yaw_deg
        self.rate = max_yaw_rate_deg_s
        self.duration = sum(leg.turn_s + leg.move_s for leg in self.legs)

    def at(self, t):
        """(x, y, yaw_deg, done) at time t seconds after the start."""
        prev_yaw = self.start_yaw
        for leg in self.legs:
            if t < leg.turn_s:
                step = _wrap(leg.yaw - prev_yaw)
                return leg.x0, leg.y0, _wrap(prev_yaw + math.copysign(min(abs(step), t * self.rate),
                                                                      step)), False
            t -= leg.turn_s
            if t < leg.move_s:
                f = t / leg.move_s
                return leg.x0 + (leg.x1 - leg.x0) * f, leg.y0 + (leg.y1 - leg.y0) * f, leg.yaw, False
            t -= leg.move_s
            prev_yaw = leg.yaw
        last = self.legs[-1] if self.legs else Leg(0, 0, 0, 0, self.start_yaw, 0, 0)
        return last.x1, last.y1, last.yaw, True
