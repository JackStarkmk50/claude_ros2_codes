"""The SLAM world frame vs the drone's map frame.

Monocular SLAM puts its world at the FIRST camera pose, in optical axes (x right, y down,
z forward), and the camera looks down by camera_mount.tilt_down_deg. The map frame we use
(like ROS REP 103) is x forward at the start, y left, z up, with the floor at z = 0.

    p_map = L @ (scale * p_slam) + [0, 0, start_height]
    L     = pitch_down(tilt) @ optical_to_body

Assumes the drone is level when SLAM starts (on the ground, or held level by hand). The 8 cm
camera offset from the frame centre is ignored: it's below the map resolution.
"""

import math

import numpy as np

OPTICAL_TO_BODY = np.array([[0.0, 0.0, 1.0], [-1.0, 0.0, 0.0], [0.0, -1.0, 0.0]])


def level_rotation(tilt_down_deg):
    th = math.radians(tilt_down_deg)
    c, s = math.cos(th), math.sin(th)
    pitch_down = np.array([[c, 0.0, s], [0.0, 1.0, 0.0], [-s, 0.0, c]])
    return pitch_down @ OPTICAL_TO_BODY


def quat_to_rot(q):
    """[x, y, z, w] -> 3x3."""
    x, y, z, w = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def rot_to_quat(r):
    """3x3 -> [x, y, z, w], w >= 0."""
    tr = r[0, 0] + r[1, 1] + r[2, 2]
    if tr > 0:
        s = math.sqrt(tr + 1.0) * 2
        q = [(r[2, 1] - r[1, 2]) / s, (r[0, 2] - r[2, 0]) / s, (r[1, 0] - r[0, 1]) / s, 0.25 * s]
    elif r[0, 0] > r[1, 1] and r[0, 0] > r[2, 2]:
        s = math.sqrt(1.0 + r[0, 0] - r[1, 1] - r[2, 2]) * 2
        q = [0.25 * s, (r[0, 1] + r[1, 0]) / s, (r[0, 2] + r[2, 0]) / s, (r[2, 1] - r[1, 2]) / s]
    elif r[1, 1] > r[2, 2]:
        s = math.sqrt(1.0 + r[1, 1] - r[0, 0] - r[2, 2]) * 2
        q = [(r[0, 1] + r[1, 0]) / s, 0.25 * s, (r[1, 2] + r[2, 1]) / s, (r[0, 2] - r[2, 0]) / s]
    else:
        s = math.sqrt(1.0 + r[2, 2] - r[0, 0] - r[1, 1]) * 2
        q = [(r[0, 2] + r[2, 0]) / s, (r[1, 2] + r[2, 1]) / s, 0.25 * s, (r[1, 0] - r[0, 1]) / s]
    q = np.array(q)
    q /= np.linalg.norm(q)
    return q if q[3] >= 0 else -q


def camera_pose_to_map(pos_slam, quat_slam, tilt_down_deg, start_height_m, scale, axes='optical'):
    """Camera pose in the SLAM world (camera -> world) -> drone pose in the map frame.

    axes='optical': world and camera in optical axes, as stored in stella_vslam's map file.
    axes='ros': already turned into ROS axes (x forward, y left, z up) for both, as
    stella_vslam_ros publishes on ~/camera_pose (it applies OPTICAL_TO_BODY on both sides).
    Returns (position [3], quaternion [x, y, z, w], yaw_deg) of base_link. At the SLAM start the
    result is (0, 0, start_height), identity, yaw 0.
    """
    lev = level_rotation(tilt_down_deg)
    if axes == 'ros':
        lev = lev @ OPTICAL_TO_BODY.T      # = pitch_down only
    elif axes != 'optical':
        raise ValueError(f'axes must be optical or ros, not {axes}')
    pos = lev @ (np.asarray(pos_slam, float) * scale)
    pos[2] += start_height_m
    r_map_base = lev @ quat_to_rot(quat_slam) @ lev.T
    yaw = math.degrees(math.atan2(r_map_base[1, 0], r_map_base[0, 0]))
    return pos, rot_to_quat(r_map_base), yaw
