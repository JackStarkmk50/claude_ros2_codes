"""Camera intrinsics: checkerboard calibration and the pinhole model from a known FOV.

Monocular SLAM needs the camera's focal length, centre and lens distortion. The Zebronics webcam
has no factory calibration, so it is measured once with a printed checkerboard (S0 in
SLAM_NAV_PLAN.md). The Gazebo camera is an ideal pinhole, so its intrinsics follow from the FOV.

Output is written in the ROS camera_info YAML format (what camera_calibration and v4l2_camera's
camera_info_url use), plus the fields a SLAM config needs.
"""

import math
from dataclasses import dataclass, field

import numpy as np


@dataclass
class Intrinsics:
    width: int
    height: int
    fx: float
    fy: float
    cx: float
    cy: float
    dist: list = field(default_factory=lambda: [0.0, 0.0, 0.0, 0.0, 0.0])  # k1 k2 p1 p2 k3
    rms_px: float = 0.0          # reprojection error of the calibration, 0 for ideal
    views: int = 0

    def hfov_deg(self):
        return math.degrees(2.0 * math.atan(self.width / (2.0 * self.fx)))

    def k_matrix(self):
        return np.array([[self.fx, 0.0, self.cx], [0.0, self.fy, self.cy], [0.0, 0.0, 1.0]])

    def camera_info_yaml(self, name='camera'):
        k = self.k_matrix().ravel().tolist()
        p = [self.fx, 0.0, self.cx, 0.0, 0.0, self.fy, self.cy, 0.0, 0.0, 0.0, 1.0, 0.0]
        lines = [
            f'image_width: {self.width}',
            f'image_height: {self.height}',
            f'camera_name: {name}',
            'camera_matrix:', '  rows: 3', '  cols: 3', f'  data: {_fmt(k)}',
            'distortion_model: plumb_bob',
            'distortion_coefficients:', '  rows: 1', '  cols: 5', f'  data: {_fmt(self.dist)}',
            'rectification_matrix:', '  rows: 3', '  cols: 3',
            '  data: [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0]',
            'projection_matrix:', '  rows: 3', '  cols: 4', f'  data: {_fmt(p)}',
        ]
        return '\n'.join(lines) + '\n'


    def fill_stella(self, template):
        """stella_vslam config text with this camera's numbers put into the Camera block."""
        import re

        values = {'fx': self.fx, 'fy': self.fy, 'cx': self.cx, 'cy': self.cy,
                  'k1': self.dist[0], 'k2': self.dist[1], 'p1': self.dist[2], 'p2': self.dist[3],
                  'k3': self.dist[4], 'cols': self.width, 'rows': self.height}
        for k, v in values.items():
            num = f'{v:.6g}' if isinstance(v, float) else str(v)
            template, n = re.subn(rf'^(  {k}:\s*)[-+0-9.eE]+[^\n]*$', rf'\g<1>{num}', template,
                                  count=1, flags=re.M)
            if n != 1:
                raise ValueError(f'stella template has no "  {k}:" line')
        return template


def _fmt(values):
    return '[' + ', '.join(f'{v:.6g}' for v in values) + ']'


def from_hfov(width, height, hfov_rad):
    """Ideal pinhole (square pixels, centred, no distortion), e.g. the Gazebo camera."""
    f = width / (2.0 * math.tan(hfov_rad / 2.0))
    return Intrinsics(width, height, f, f, width / 2.0, height / 2.0)


def board_points(cols, rows, square_m):
    """3D corner positions of a checkerboard with cols x rows INNER corners, on z = 0."""
    grid = np.zeros((rows * cols, 3), np.float32)
    grid[:, :2] = np.mgrid[0:cols, 0:rows].T.reshape(-1, 2) * square_m
    return grid


def coverage(corner_sets, width, height, cells=3):
    """Fraction of a cells x cells grid over the image that some board corner fell into.

    A calibration from boards that all sat in the middle of the picture fits the centre and guesses
    the edges, where distortion is largest. We ask for most cells to be covered.
    """
    hit = np.zeros((cells, cells), bool)
    for corners in corner_sets:
        pts = np.asarray(corners).reshape(-1, 2)
        ix = np.clip((pts[:, 0] / width * cells).astype(int), 0, cells - 1)
        iy = np.clip((pts[:, 1] / height * cells).astype(int), 0, cells - 1)
        hit[iy, ix] = True
    return float(hit.mean())


@dataclass
class CalibrationResult:
    intrinsics: Intrinsics
    coverage: float
    problems: list

    @property
    def ok(self):
        return not self.problems


def calibrate(corner_sets, width, height, cols, rows, square_m,
              min_views=12, max_rms_px=1.0, min_coverage=0.7):
    """OpenCV calibration from detected corners. Returns the result and what is wrong with it."""
    import cv2

    obj = board_points(cols, rows, square_m)
    problems = []
    if len(corner_sets) < min_views:
        problems.append(f'only {len(corner_sets)} usable pictures, need {min_views}')
    if len(corner_sets) < 3:
        return CalibrationResult(None, 0.0, problems)
    rms, k, dist, _, _ = cv2.calibrateCamera(
        [obj] * len(corner_sets), [np.asarray(c, np.float32).reshape(-1, 1, 2) for c in corner_sets],
        (width, height), None, None)
    intr = Intrinsics(width, height, float(k[0, 0]), float(k[1, 1]), float(k[0, 2]),
                      float(k[1, 2]), [float(v) for v in np.ravel(dist)[:5]], float(rms),
                      len(corner_sets))
    cov = coverage(corner_sets, width, height)
    if rms > max_rms_px:
        problems.append(f'reprojection error {rms:.2f} px > {max_rms_px} (blurred or moving board?)')
    if cov < min_coverage:
        problems.append(f'board covered {cov:.0%} of the picture, need {min_coverage:.0%}: '
                        'hold it near the edges and corners too')
    if not 0.5 < intr.fx / intr.fy < 2.0:
        problems.append(f'fx/fy = {intr.fx / intr.fy:.2f} looks wrong')
    return CalibrationResult(intr, cov, problems)


def find_corners(gray, cols, rows):
    """Checkerboard corners in one grey image (sub-pixel), or None."""
    import cv2

    found, corners = cv2.findChessboardCorners(
        gray, (cols, rows), cv2.CALIB_CB_ADAPTIVE_THRESH | cv2.CALIB_CB_NORMALIZE_IMAGE)
    if not found:
        return None
    crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 1e-3)
    return cv2.cornerSubPix(gray, corners, (5, 5), (-1, -1), crit).reshape(-1, 2)
