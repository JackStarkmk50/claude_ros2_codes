"""Sparse SLAM points -> 2D occupancy grid that Nav2's map_server can load.

Monocular SLAM keeps a cloud of 3D points (corners and texture it tracked) and the camera
positions it saw them from (keyframes). For a floor map we:

1. level the cloud: the SLAM world frame is the FIRST camera frame (optical: x right, y down,
   z forward), tilted down by the camera mount. `level_points` turns it into map axes
   (x forward at the start, y left, z up, floor at z = 0);
2. mark a cell OCCUPIED when enough points between `min_z` and `max_z` (above the floor, below
   the ceiling) fall in it;
3. mark cells FREE along the line from the camera that saw a point to that point (it saw through
   them), when observations are known, else from the few nearest keyframes.

Honest limit: points come only from textured surfaces. A plain white wall can have almost no
points, so it shows as a gap (unknown), not as a wall. Nav2 must treat unknown as not free.
"""

import math
from dataclasses import dataclass

import numpy as np

from drone_slam.core.frames import level_rotation

UNKNOWN, FREE, OCCUPIED = -1, 0, 100


@dataclass
class GridConfig:
    resolution_m: float = 0.10
    min_z: float = 0.20        # ignore floor points
    max_z: float = 1.80        # ignore ceiling points
    min_hits: int = 2          # points per cell to call it occupied (single points are noise)
    max_ray_m: float = 6.0     # don't clear further than this from the camera
    padding_m: float = 1.0
    fill_passes: int = 2       # close thin unknown gaps between rays (see _fill_gaps)
    fallback_views: int = 3    # without observations: rays from this many nearest keyframes
    path_radius_m: float = 0.3  # the camera was carried/flown along the keyframe path: free


def level_points(points_slam, tilt_down_deg=0.0, start_height_m=0.0, scale=1.0):
    """SLAM world (first camera optical frame) -> level map frame, metres, floor at z = 0.

    tilt_down_deg: camera_mount.tilt_down_deg. start_height_m: camera height above the floor when
    SLAM started (rangefinder + mount offset). Assumes the drone was level at that moment.
    """
    p = np.asarray(points_slam, float).reshape(-1, 3) * scale
    out = p @ level_rotation(tilt_down_deg).T
    out[:, 2] += start_height_m
    return out


@dataclass
class GridMap:
    data: np.ndarray            # int8 [rows, cols], row 0 = lowest y (ROS OccupancyGrid order)
    resolution: float
    origin_x: float
    origin_y: float

    def cell(self, x, y):
        return (int(math.floor((y - self.origin_y) / self.resolution)),
                int(math.floor((x - self.origin_x) / self.resolution)))

    def value(self, x, y):
        r, c = self.cell(x, y)
        if 0 <= r < self.data.shape[0] and 0 <= c < self.data.shape[1]:
            return int(self.data[r, c])
        return UNKNOWN

    def clearance_m(self, x, y, limit_m=2.0):
        """Distance to the nearest occupied cell (capped at limit_m)."""
        r0, c0 = self.cell(x, y)
        n = int(math.ceil(limit_m / self.resolution))
        rows, cols = self.data.shape
        r1, r2, c1, c2 = max(0, r0 - n), min(rows, r0 + n + 1), max(0, c0 - n), min(cols, c0 + n + 1)
        rr, cc = np.nonzero(self.data[r1:r2, c1:c2] == OCCUPIED)
        if rr.size == 0:
            return limit_m
        d = np.hypot(rr + r1 - r0, cc + c1 - c0).min() * self.resolution
        return float(min(d, limit_m))


def _line(r0, c0, r1, c1):
    """Bresenham cells from (r0, c0) to (r1, c1), excluding the end cell."""
    dr, dc = abs(r1 - r0), abs(c1 - c0)
    sr, sc = (1 if r1 > r0 else -1), (1 if c1 > c0 else -1)
    err = dc - dr
    r, c = r0, c0
    while (r, c) != (r1, c1):
        yield r, c
        e2 = 2 * err
        if e2 > -dr:
            err -= dr
            c += sc
        if e2 < dc:
            err += dc
            r += sr


def build_grid(points, keyframes, observations=None, cfg=None):
    """points [N,3] and keyframes [K,3] in the level map frame (metres).

    observations: optional list, for each point, of keyframe indices that saw it.
    """
    cfg = cfg or GridConfig()
    pts = np.asarray(points, float).reshape(-1, 3)
    kfs = np.asarray(keyframes, float).reshape(-1, 3)
    band = (pts[:, 2] >= cfg.min_z) & (pts[:, 2] <= cfg.max_z)
    xy = np.concatenate([pts[band, :2], kfs[:, :2]]) if len(kfs) else pts[band, :2]
    if len(xy) == 0:
        raise ValueError('no points between min_z and max_z: check scale, tilt and start height')
    lo = xy.min(axis=0) - cfg.padding_m
    hi = xy.max(axis=0) + cfg.padding_m
    res = cfg.resolution_m
    cols, rows = (np.ceil((hi - lo) / res).astype(int) + 1)
    grid = GridMap(np.full((rows, cols), UNKNOWN, np.int8), res, float(lo[0]), float(lo[1]))

    hits = np.zeros((rows, cols), np.int32)
    idx = np.nonzero(band)[0]
    for i in idx:
        r, c = grid.cell(pts[i, 0], pts[i, 1])
        hits[r, c] += 1
    free = np.zeros((rows, cols), bool)
    for i in idx:
        srcs = observations[i] if observations is not None and observations[i] else None
        if srcs is None:
            if not len(kfs):
                continue
            d = np.hypot(*(kfs[:, :2] - pts[i, :2]).T)
            srcs = np.argsort(d)[:cfg.fallback_views].tolist()
        for k in srcs:
            if k >= len(kfs):
                continue
            if math.hypot(*(pts[i, :2] - kfs[k, :2])) > cfg.max_ray_m:
                continue
            r0, c0 = grid.cell(kfs[k, 0], kfs[k, 1])
            r1, c1 = grid.cell(pts[i, 0], pts[i, 1])
            for r, c in _line(r0, c0, r1, c1):
                free[r, c] = True
    _mark_path(free, grid, kfs, cfg.path_radius_m)
    occupied = hits >= cfg.min_hits
    free = _fill_gaps(free & ~occupied, occupied, cfg.fill_passes)
    grid.data[free] = FREE
    grid.data[occupied] = OCCUPIED
    return grid


def _mark_path(free, grid, kfs, radius_m):
    """The camera itself passed along the keyframes (in order), so that corridor is free."""
    path = np.zeros_like(free)
    cells = [grid.cell(k[0], k[1]) for k in kfs]
    for (r0, c0), (r1, c1) in zip(cells, cells[1:] or cells):
        for r, c in _line(r0, c0, r1, c1):
            path[r, c] = True
        path[r1, c1] = True
    n = int(round(radius_m / grid.resolution))
    rows, cols = free.shape
    for r, c in zip(*np.nonzero(path)):
        for dr in range(-n, n + 1):
            for dc in range(-n, n + 1):
                if dr * dr + dc * dc <= n * n and 0 <= r + dr < rows and 0 <= c + dc < cols:
                    free[r + dr, c + dc] = True


def _fill_gaps(free, occupied, passes):
    """Rays fan out from each camera position, leaving thin unknown stripes between them. A cell
    with at least 6 of its 8 neighbours free (and not an obstacle) is called free too. Gaps wider
    than ~2 cells, and anything behind a wall, stay unknown."""
    for _ in range(passes):
        p = np.pad(free, 1)
        n = sum(p[1 + dr:p.shape[0] - 1 + dr, 1 + dc:p.shape[1] - 1 + dc].astype(np.int8)
                for dr in (-1, 0, 1) for dc in (-1, 0, 1) if dr or dc)
        free = free | ((n >= 6) & ~occupied)
    return free


def save_map_server(grid, pgm_path, yaml_path):
    """Write the nav2_map_server pair: a PGM picture (row 0 = top = highest y) and its YAML."""
    import os

    img = np.full(grid.data.shape, 205, np.uint8)       # unknown grey
    img[grid.data == FREE] = 254
    img[grid.data == OCCUPIED] = 0
    img = img[::-1]
    with open(pgm_path, 'wb') as f:
        f.write(f'P5\n{img.shape[1]} {img.shape[0]}\n255\n'.encode())
        f.write(img.tobytes())
    with open(yaml_path, 'w') as f:
        f.write(f'image: {os.path.basename(pgm_path)}\n'
                f'mode: trinary\n'
                f'resolution: {grid.resolution}\n'
                f'origin: [{grid.origin_x:.3f}, {grid.origin_y:.3f}, 0.0]\n'
                'negate: 0\noccupied_thresh: 0.65\nfree_thresh: 0.25\n')


def load_map_server(yaml_path):
    """Read back a map written by save_map_server (or nav2's map_saver, trinary mode)."""
    import os

    import yaml

    with open(yaml_path) as f:
        meta = yaml.safe_load(f)
    pgm = os.path.join(os.path.dirname(yaml_path), meta['image'])
    with open(pgm, 'rb') as f:
        raw = f.read()
    parts = raw.split(maxsplit=4)
    w, h = int(parts[1]), int(parts[2])
    img = np.frombuffer(parts[4][:w * h], np.uint8).reshape(h, w)[::-1]
    data = np.full((h, w), UNKNOWN, np.int8)
    data[img >= 250] = FREE
    data[img <= 50] = OCCUPIED
    return GridMap(data, float(meta['resolution']), float(meta['origin'][0]),
                   float(meta['origin'][1]))
