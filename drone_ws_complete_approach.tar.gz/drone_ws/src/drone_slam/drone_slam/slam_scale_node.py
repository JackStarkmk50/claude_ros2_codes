"""slam_scale_node: monocular SLAM pose (no units) -> drone pose in metres on the map.

  /run_slam/camera_pose          (nav_msgs/Odometry, stella_vslam_ros, ROS axes, no units)
  /mavros/local_position/pose    (geometry_msgs/PoseStamped, EKF metres, drifts)
        ->  /drone/slam/pose     (geometry_msgs/PoseStamped, frame "map", only while scale locked)
            /diagnostics          scale, pairs, spread, why not locked
            ~/drone_ws/slam_session.yaml   scale + start height, for make_map (rewritten on change)

The scale is learnt from how far the EKF says the drone moved over 1 s windows (core/scale.py).
The map frame is the SLAM start, levelled with camera_mount.tilt_down_deg (core/frames.py).
start_height_m < 0 means: take the EKF height when the first SLAM pose arrives, plus
camera_z_m (the EKF origin is on the floor where the drone was armed).

This node commands nothing and does not feed ArduPilot yet. Its pose is for watching in RViz and
for later phases (Nav2, vision_pose into EKF3), which will be added through their owners.
"""

import os

import rclpy
from diagnostic_msgs.msg import DiagnosticStatus
from diagnostic_updater import Updater
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Odometry
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data

from drone_slam.core.frames import camera_pose_to_map
from drone_slam.core.scale import ScaleConfig, ScaleEstimator

PARAMETERS = {
    'slam_pose_topic': '/run_slam/camera_pose',   # stella_vslam_ros: node run_slam, ~/camera_pose
    'metric_pose_topic': '/mavros/local_position/pose',
    'tilt_down_deg': 0.0,          # same as camera_mount.tilt_down_deg
    'start_height_m': -1.0,        # camera height above the floor at SLAM start; < 0 = from EKF
    'camera_z_m': 0.02,            # camera_mount.z_m, added to the EKF height
    'session_file': '~/drone_ws/slam_session.yaml',
    'interval_s': 1.0,
    'min_metric_move_m': 0.15,
    'min_pairs': 8,
    'max_spread': 0.25,
}


def stamp_s(msg):
    return msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9


class SlamScaleNode(Node):
    def __init__(self):
        super().__init__('slam_scale')
        for k, v in PARAMETERS.items():
            self.declare_parameter(k, v)
        p = {k: self.get_parameter(k).value for k in PARAMETERS}
        self.p = p
        self.est = ScaleEstimator(ScaleConfig(
            interval_s=p['interval_s'], min_metric_move_m=p['min_metric_move_m'],
            min_pairs=p['min_pairs'], max_spread=p['max_spread']))
        self.pub = self.create_publisher(PoseStamped, '/drone/slam/pose', 10)
        self.create_subscription(Odometry, p['slam_pose_topic'], self._slam, 10)
        self.create_subscription(PoseStamped, p['metric_pose_topic'], self._metric,
                                 qos_profile_sensor_data)
        self.updater = Updater(self)
        self.updater.setHardwareID('monocular_slam')
        self.updater.add('slam_scale', self._diag)
        self.last_slam = None
        self.metric_z = None
        self.start_height = p['start_height_m'] if p['start_height_m'] >= 0 else None
        self.saved = None

    def _metric(self, msg):
        q = msg.pose.position
        self.metric_z = q.z
        self.est.add_metric(stamp_s(msg), (q.x, q.y, q.z))

    def _slam(self, msg):
        t = stamp_s(msg)
        pos = msg.pose.pose.position
        ori = msg.pose.pose.orientation
        if self.last_slam is not None and t < self.last_slam - 1.0:
            self.get_logger().warn('SLAM time went backwards: assuming it restarted, scale reset')
            self.est.reset()
        self.last_slam = t
        if self.start_height is None and self.metric_z is not None:
            self.start_height = self.metric_z + self.p['camera_z_m']
            self.get_logger().info(f'SLAM started at camera height {self.start_height:.2f} m')
        st = self.est.add_slam(t, (pos.x, pos.y, pos.z))
        if not st.locked or self.start_height is None:
            return
        self._save(st.scale)
        p, q, _ = camera_pose_to_map((pos.x, pos.y, pos.z), (ori.x, ori.y, ori.z, ori.w),
                                     self.p['tilt_down_deg'], self.start_height, st.scale,
                                     axes='ros')
        out = PoseStamped()
        out.header.stamp = msg.header.stamp
        out.header.frame_id = 'map'
        out.pose.position.x, out.pose.position.y, out.pose.position.z = (float(v) for v in p)
        (out.pose.orientation.x, out.pose.orientation.y, out.pose.orientation.z,
         out.pose.orientation.w) = (float(v) for v in q)
        self.pub.publish(out)

    def _save(self, scale):
        """Keep the numbers make_map needs, when they change by more than 1 %."""
        if self.saved is not None and abs(scale - self.saved) < 0.01 * self.saved:
            return
        self.saved = scale
        path = os.path.expanduser(self.p['session_file'])
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, 'w') as f:
                f.write(f'scale: {scale:.6f}\nstart_height: {self.start_height:.3f}\n'
                        f'tilt: {self.p["tilt_down_deg"]}\n')
        except OSError as e:
            self.get_logger().warn(f'cannot write {path}: {e}')

    def _diag(self, stat):
        st = self.est.status
        level = DiagnosticStatus.OK if st.locked else DiagnosticStatus.WARN
        stat.summary(level, st.reason)
        stat.add('scale_m_per_unit', f'{st.scale:.4f}')
        stat.add('pairs', str(st.pairs))
        stat.add('spread', f'{st.spread:.3f}')
        stat.add('start_height_m', 'unknown' if self.start_height is None
                 else f'{self.start_height:.2f}')
        return stat


def main():
    rclpy.init()
    node = SlamScaleNode()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
