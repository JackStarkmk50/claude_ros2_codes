"""Monocular SLAM: stella_vslam (run_slam) on /camera/image_raw + slam_scale.

    # build a map (sim): the map is saved when you stop with Ctrl-C
    ros2 launch drone_slam slam.launch.py config:=sim map:=~/drone_ws/maps/sim.msg
    # find yourself in a saved map, no mapping (lighter; what the Pi will run)
    ros2 launch drone_slam slam.launch.py config:=webcam mode:=localize map:=~/drone_ws/maps/house.msg

config: sim | webcam | a path to a stella_vslam yaml. "webcam" uses ~/drone_ws/stella_webcam.yaml,
written by calibrate_camera. vocab: stella's ORB vocabulary (setup_stella.sh downloads it).
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def _setup(context):
    cfg = LaunchConfiguration('config').perform(context)
    mode = LaunchConfiguration('mode').perform(context)
    map_path = os.path.expanduser(LaunchConfiguration('map').perform(context))
    vocab = os.path.expanduser(LaunchConfiguration('vocab').perform(context))
    if cfg == 'sim':
        cfg = os.path.join(get_package_share_directory('drone_slam'), 'config', 'stella_sim.yaml')
    elif cfg == 'webcam':
        cfg = os.path.expanduser('~/drone_ws/stella_webcam.yaml')
    for f, what in ((cfg, 'config (webcam: run calibrate_camera first)'),
                    (vocab, 'vocabulary (run setup_stella.sh)')):
        if not os.path.isfile(f):
            raise RuntimeError(f'{what} not found: {f}')
    args = ['-v', vocab, '-c', cfg, '--viewer', 'none']
    if mode == 'map':
        os.makedirs(os.path.dirname(map_path), exist_ok=True)
        args += ['--map-db-out', map_path]
    elif mode == 'localize':
        if not os.path.isfile(map_path):
            raise RuntimeError(f'map not found: {map_path}')
        args += ['--map-db-in', map_path, '--disable-mapping']
    else:
        raise RuntimeError(f'mode must be map or localize, not {mode}')
    return [
        Node(package='stella_vslam_ros', executable='run_slam', name='run_slam', output='screen',
             arguments=args, parameters=[{'publish_tf': False}]),
        Node(package='drone_slam', executable='slam_scale', name='slam_scale', output='screen',
             parameters=[{'tilt_down_deg': float(LaunchConfiguration('tilt').perform(context))}]),
    ]


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('config', default_value='sim'),
        DeclareLaunchArgument('mode', default_value='map', description='map | localize'),
        DeclareLaunchArgument('map', default_value='~/drone_ws/maps/sim.msg'),
        DeclareLaunchArgument('vocab', default_value='~/stella_ws/orb_vocab.fbow'),
        DeclareLaunchArgument('tilt', default_value='0.0',
                              description='camera_mount.tilt_down_deg'),
        OpaqueFunction(function=_setup),
    ])
