from setuptools import find_packages, setup

package_name = 'drone_slam'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml', 'README.md']),
        ('share/' + package_name + '/launch', ['launch/slam.launch.py']),
        ('share/' + package_name + '/config', ['config/rooms.example.yaml', 'config/stella_sim.yaml',
                                            'config/stella_webcam.yaml', 'config/rooms_sim.yaml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Moganesan',
    maintainer_email='ht.moganesan@gmail.com',
    description='Monocular visual SLAM support: camera calibration, metric scale, 2D floor map, '
                'named rooms.',
    license='MIT',
    extras_require={'test': ['pytest']},
    entry_points={
        'console_scripts': [
            'slam_scale = drone_slam.slam_scale_node:main',
            'calibrate_camera = drone_slam.calibrate_camera:main',
            'make_map = drone_slam.make_map:main',
        ],
    },
)
