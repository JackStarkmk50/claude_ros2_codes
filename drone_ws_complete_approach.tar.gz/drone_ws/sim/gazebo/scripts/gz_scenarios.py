#!/usr/bin/env python3
"""Mission scenarios in the Gazebo room. Needs run_sim.sh and the drone stack running.

  python3 gz_scenarios.py G1 G2 G3 G4 G5 G6 G7 G8 G9  (any subset, in that order)

  G1  person standing 120 deg left: take off, search, track 15 s, turn back, land -> COMPLETED
  G2  person walking round the drone at 8 deg/s: the drone turns with them -> COMPLETED
  G3  person hides for 3 s while tracked: LOST, REACQUIRING, TRACKING -> COMPLETED
  G4  nobody in the room: 360 deg search, turn back, land -> TARGET_NOT_FOUND
  G5  text command "look for a person and track them for 60 seconds", then "stop"
      while tracking -> CANCELLED (needs intent_bridge allow_execute: true)
  G6  cancel while tracking (Ctrl-C equivalent) -> CANCELLED
  G7  approach: person standing 4.6 m away, "go near them and stay 10 s": flies closer to about
      3 m, holds 10 s, turns back, lands -> COMPLETED (needs approach ON: make_sim_config.py)
  G8  text command "look for a person, follow them for 20 seconds and keep 2.5 m away":
      closer than about 2.8 m the feet leave the picture and the head position is used
      -> COMPLETED
  G9  reverse: person 3 m away walks 1.2 m towards the drone while it keeps 3 m: the drone backs
      away (approach_allow_reverse, make_sim_config.py) -> COMPLETED near 3 m
G7 to G9 measure the true distance from Gazebo's poses and put the drone back at the start
point afterwards (it lands where the approach took it).

Between scenarios the flight mode is put back to STABILIZE over MAVLink (tcp 5762), which
stands in for your RC mode switch, and the safety latch is reset.
Writes ~/drone_ws/gazebo_report.txt and a camera snapshot per scenario
(~/drone_ws/gazebo_G1.jpg, ...) taken while tracking.
"""

import math
import os
import statistics
import subprocess
import sys
import time

import numpy as np
import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import Image
from std_srvs.srv import Trigger

from drone_interfaces.action import SearchAndTrack
from drone_interfaces.msg import MissionStatus, TrackedTarget, VehicleState
from drone_interfaces.srv import SubmitCommand
from drone_perception.core.image_convert import image_to_rgb
from drone_perception.qos import IMAGE_QOS

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.expanduser('~/drone_ws')
REPORT = os.path.join(OUT_DIR, 'gazebo_report.txt')
OUTCOMES = ('COMPLETED', 'CANCELLED', 'TARGET_NOT_FOUND', 'TARGET_LOST', 'SAFETY_STOP',
            'MANUAL_OVERRIDE', 'PREFLIGHT_FAILED', 'TAKEOFF_FAILED', 'ERROR')
LATCHED = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                     durability=DurabilityPolicy.TRANSIENT_LOCAL)
END = ('MISSION_COMPLETE', 'MISSION_CANCELLED', 'SAFETY_STOP', 'MANUAL_OVERRIDE', 'ERROR')
LINES = []


def out(s=''):
    print(s, flush=True)
    LINES.append(s)


class TruePose:
    """The drone's real position in the Gazebo world (for checking the approach only)."""

    def __init__(self):
        self.xy = None
        try:
            from gz.msgs10.pose_v_pb2 import Pose_V
            from gz.transport13 import Node as GzNode
        except ImportError:
            self.node = None
            return
        self.node = GzNode()

        def cb(msg):
            for p in msg.pose:
                if p.name == 'drone':
                    self.xy = (p.position.x, p.position.y)
        self.node.subscribe(Pose_V, '/world/indoor_search/dynamic_pose/info', cb)


def person_xy(bearing_deg, dist):
    b = math.radians(bearing_deg)
    return dist * math.cos(b), dist * math.sin(b)


def reset_drone():
    """Put the landed, disarmed drone back on the start point (after an approach)."""
    sys.path.insert(0, HERE)
    import move_person
    move_person.set_pose('drone', 0.0, 0.0, 0.0, z=0.195)


def person(*args):
    subprocess.run([sys.executable, os.path.join(HERE, 'move_person.py'), *map(str, args)],
                   stdout=subprocess.DEVNULL, check=False)


def set_mode(mode):
    from pymavlink import mavutil
    m = mavutil.mavlink_connection('tcp:127.0.0.1:5762', source_system=255)
    m.wait_heartbeat(timeout=10)
    m.set_mode(mode)
    time.sleep(1)
    m.close()


class Runner(Node):
    def __init__(self):
        super().__init__('gz_scenarios')
        self.v = self.m = self.img = None
        self.errs, self.states = [], []
        self.create_subscription(VehicleState, '/drone/vehicle_state',
                                 lambda m: setattr(self, 'v', m), 10)
        self.create_subscription(MissionStatus, '/drone/mission/status', self._m, LATCHED)
        self.create_subscription(TrackedTarget, '/drone/perception/target', self._t, 10)
        self.create_subscription(Image, '/camera/image_raw', lambda m: setattr(self, 'img', m),
                                 IMAGE_QOS)
        self.ac = ActionClient(self, SearchAndTrack, '/drone/mission/search_and_track')
        self.reset = self.create_client(Trigger, '/drone/safety/reset')
        self.cmd = self.create_client(SubmitCommand, '/drone/llm/submit_command')

    def _m(self, m):
        self.m = m
        if not self.states or self.states[-1] != m.state_name:
            self.states.append(m.state_name)

    def _t(self, t):
        if self.m is not None and self.m.state_name == 'TRACKING' and t.state == 2:
            self.errs.append(t.error_x_norm)

    def spin(self, t, until=None):
        end = time.time() + t
        while time.time() < end:
            rclpy.spin_once(self, timeout_sec=0.05)
            if until and until():
                return True
        return False

    def prepare(self):
        set_mode('STABILIZE')
        self.spin(2)
        if self.reset.wait_for_service(timeout_sec=5):
            f = self.reset.call_async(Trigger.Request())
            rclpy.spin_until_future_complete(self, f, timeout_sec=5)
        self.errs, self.states = [], []
        self.spin(2)

    def snapshot(self, name):
        if self.img is None:
            return
        try:
            import cv2
            m = self.img
            rgb = image_to_rgb(m.encoding, m.width, m.height, m.step, bytes(m.data))
            path = os.path.join(OUT_DIR, f'gazebo_{name}.jpg')
            cv2.imwrite(path, cv2.cvtColor(np.asarray(rgb), cv2.COLOR_RGB2BGR))
            out(f'  snapshot while tracking: {path}')
        except Exception as e:  # snapshots are a nice-to-have
            out(f'  (snapshot failed: {e})')

    def mission(self, track, hook=None, timeout=240, approach=False, approach_distance=0.0):
        if not self.ac.wait_for_server(timeout_sec=5):
            out('  mission_manager not reachable: is the stack running?')
            return None
        g = SearchAndTrack.Goal(target_class='person', autonomous_takeoff=True,
                                takeoff_altitude_m=0.0, search_timeout_s=0.0,
                                track_duration_s=float(track), land_on_finish=True,
                                approach=approach, approach_distance_m=float(approach_distance))
        f = self.ac.send_goal_async(g)
        rclpy.spin_until_future_complete(self, f, timeout_sec=5)
        gh = f.result()
        if gh is None or not gh.accepted:
            out('  goal rejected')
            return None
        rf = gh.get_result_async()
        t0 = time.time()
        while not rf.done() and time.time() - t0 < timeout:
            rclpy.spin_once(self, timeout_sec=0.05)
            if hook:
                hook(gh, time.time() - t0)
        return rf.result().result if rf.done() else None

    def say(self, text):
        self.cmd.wait_for_service(timeout_sec=5)
        f = self.cmd.call_async(SubmitCommand.Request(text=text, execute=True, use_llm=False))
        rclpy.spin_until_future_complete(self, f, timeout_sec=30)
        r = f.result()
        out(f'  > "{text}": {r.message}')
        return r

    def report(self, name, r, want):
        if r is None:
            out('  NO RESULT (timeout)')
            return False
        got = OUTCOMES[r.outcome]
        out(f'  result {got}: {r.message} ({r.duration_s:.0f} s)')
        out('  states: ' + ' > '.join(self.states))
        if self.errs:
            e = [abs(x) for x in self.errs]
            late = e[len(e) // 3:] if len(e) > 6 else e
            out(f'  tracking |error_x|: median {statistics.median(late):.2f}, '
                f'max {max(late):.2f} ({len(e)} samples)')
        ok = got == want and r.landed_and_disarmed
        out(f'{"PASS" if ok else "FAIL"}  {name} (want {want}, landed and disarmed)')
        return ok


def snap_hook(r, name):
    done = []

    def hook(gh, t):
        if not done and r.m is not None and r.m.state_name == 'TRACKING' and len(r.errs) > 30:
            r.snapshot(name)
            done.append(1)
    return hook


def g1(r):
    out('G1 person standing 120 deg left: search, track 15 s, turn back, land')
    person('hide', 'person_b')
    person('place', 'person_a', 120, 3)
    r.prepare()
    return r.report('G1', r.mission(15, snap_hook(r, 'G1')), 'COMPLETED')


def g2(r):
    out('G2 person walking round the drone at 8 deg/s (to the right)')
    person('hide', 'person_a')
    walker = subprocess.Popen([sys.executable, os.path.join(HERE, 'move_person.py'), 'walk',
                               'person_b', '70', '3', '-8'])
    try:
        r.prepare()
        res = r.mission(20, snap_hook(r, 'G2'))
    finally:
        walker.terminate()
        walker.wait()
    return r.report('G2', res, 'COMPLETED')


def g3(r):
    out('G3 person hides for 3 s while tracked: lost, reacquired, completes')
    person('hide', 'person_b')
    person('place', 'person_a', 40, 3)
    r.prepare()
    state = {}

    def hook(gh, t):
        if r.m is None:
            return
        if 'hid' not in state and r.m.state_name == 'TRACKING' and len(r.errs) > 40:
            r.snapshot('G3')
            person('hide', 'person_a')
            state['hid'] = time.time()
        elif 'hid' in state and 'back' not in state and time.time() - state['hid'] > 3:
            person('place', 'person_a', 40, 3)
            state['back'] = 1
    return r.report('G3', r.mission(25, hook), 'COMPLETED')


def g4(r):
    out('G4 nobody in the room: full search, turn back, land')
    person('hide', 'person_a')
    person('hide', 'person_b')
    r.prepare()
    return r.report('G4', r.mission(15), 'TARGET_NOT_FOUND')


def g5(r):
    out('G5 text command, then "stop" while tracking')
    person('hide', 'person_b')
    person('place', 'person_a', 60, 3)
    r.prepare()
    res = r.say('look for a person and track them for 60 seconds')
    if not res.executed:
        out('FAIL  G5: not started (intent_bridge allow_execute must be true for this test)')
        return False
    r.spin(120, lambda: r.m is not None and r.m.state_name == 'TRACKING' and len(r.errs) > 30)
    r.snapshot('G5')
    r.say('stop')
    r.spin(120, lambda: r.m is not None and r.m.state_name in END)
    r.spin(30, lambda: r.v is not None and not r.v.armed)
    out(f'  final: {r.m.state_name}: {r.m.detail}')
    out('  states: ' + ' > '.join(r.states))
    ok = r.m.state_name == 'MISSION_CANCELLED' and r.v is not None and not r.v.armed
    out(f'{"PASS" if ok else "FAIL"}  G5 (want CANCELLED, landed and disarmed)')
    return ok


def g6(r):
    out('G6 cancel while tracking')
    person('hide', 'person_b')
    person('place', 'person_a', 30, 3)
    r.prepare()
    sent = []

    def hook(gh, t):
        if not sent and r.m is not None and r.m.state_name == 'TRACKING' and len(r.errs) > 30:
            gh.cancel_goal_async()
            sent.append(1)
    return r.report('G6', r.mission(60, hook), 'CANCELLED')


def distance_log(r, pose, pxy):
    """Hook that records the true drone-person distance while TRACKING."""
    log = []

    def hook(gh=None, t=0.0):
        if pose.xy is not None and r.m is not None and r.m.state_name == 'TRACKING':
            log.append((time.time(), math.hypot(pxy[0] - pose.xy[0], pxy[1] - pose.xy[1]),
                        r.m.detail))
    return log, hook


def check_distance(log, want, tol, closest):
    """The last 5 s of tracking within want +- tol, and never closer than `closest`."""
    if not log:
        out('  no true distance (gz-transport Python bindings missing?)')
        return False
    t_end = log[-1][0]
    hold = [d for t, d, _ in log if t > t_end - 5.0]
    start, nearest = log[0][1], min(d for _, d, _ in log)
    med = statistics.median(hold)
    out(f'  true distance: {start:.2f} m at the start of tracking, {med:.2f} m held '
        f'(median of the last 5 s), closest {nearest:.2f} m; wanted {want:.1f} m')
    est = [x for x in log[-1][2].split(', ') if x.startswith('~')]
    if est:
        out(f'  the mission\'s own estimate at the end: {est[0]}')
    return abs(med - want) <= tol and nearest >= closest


def g7(r):
    out('G7 approach: person 4.6 m away, go near them (about 3 m) and stay 10 s, land')
    person('hide', 'person_b')
    person('place', 'person_a', -30, 4.6)
    reset_drone()
    r.prepare()
    log, rec = distance_log(r, r.pose, person_xy(-30, 4.6))
    snap = snap_hook(r, 'G7')

    def hook(gh, t):
        rec()
        snap(gh, t)
    res = r.mission(10, hook, approach=True)
    near = check_distance(log, 3.0, 0.5, 2.0)
    ok = r.report('G7', res, 'COMPLETED') and near
    if not near:
        out('FAIL  G7 distance')
    r.spin(5)
    reset_drone()
    return ok


def g8(r):
    out('G8 text: "look for a person, follow them for 20 seconds and keep 2.5 m away"')
    person('hide', 'person_b')
    person('place', 'person_a', -15, 4.6)
    reset_drone()
    r.prepare()
    log, rec = distance_log(r, r.pose, person_xy(-15, 4.6))
    res = r.say('look for a person, follow them for 20 seconds and keep 2.5 m away')
    if not res.executed:
        out('FAIL  G8: not started (needs allow_execute and allow_approach: make_sim_config.py)')
        return False
    end = time.time() + 180
    while time.time() < end and not (r.m is not None and r.m.state_name in END
                                     and r.v is not None and not r.v.armed):
        r.spin(0.1)
        rec()
    out(f'  final: {r.m.state_name}: {r.m.detail}')
    out('  states: ' + ' > '.join(r.states))
    near = check_distance(log, 2.5, 0.5, 1.8)
    head = any('by head' in d for _, _, d in log)
    out(f'  head-position estimate used: {head}')
    ok = r.m.state_name == 'MISSION_COMPLETE' and not r.v.armed and near and head
    out(f'{"PASS" if ok else "FAIL"}  G8 (want COMPLETED near 2.5 m, landed and disarmed)')
    r.spin(5)
    reset_drone()
    return ok


def g9(r):
    out('G9 reverse: person 3 m away walks 1.2 m towards the drone, which keeps 3 m by backing '
        'away')
    sys.path.insert(0, HERE)
    import move_person
    person('hide', 'person_b')
    person('place', 'person_a', 0, 3.0)
    reset_drone()
    r.prepare()
    pxy = [3.0, 0.0]                                  # the person's position, updated as it walks
    log, rec = distance_log(r, r.pose, pxy)
    walk = {'keep': None, 'start': None, 'last': 0.0}
    drone_x = []

    def hook(gh, t):
        rec()
        if r.pose.xy is not None:
            drone_x.append(r.pose.xy[0])
        if r.m is None or r.m.state_name != 'TRACKING':
            return
        if walk['keep'] is None and 'keeping distance' in r.m.detail:
            walk['keep'] = t
        if walk['start'] is None and walk['keep'] is not None and t - walk['keep'] > 3.0:
            walk['start'] = t
            out(f'  person starts walking towards the drone ({r.m.detail.split(", ")[2]})')
        if walk['start'] is not None and t - walk['last'] >= 0.1 and pxy[0] > 1.8:
            walk['last'] = t
            pxy[0] = max(1.8, 3.0 - 0.3 * (t - walk['start']))     # 0.3 m/s
            move_person.set_pose('person_a', *move_person.at(0, pxy[0]))
    res = r.mission(25, hook, approach=True, approach_distance=3.0)
    backed = any('backing away' in d for _, _, d in log)
    moved = -min(drone_x) if drone_x else 0.0
    out(f'  person walked to {pxy[0]:.1f} m from the start point; drone moved back '
        f'{moved:.2f} m (true); "backing away" seen: {backed}')
    near = check_distance(log, 3.0, 0.6, 1.5)
    ok = r.report('G9', res, 'COMPLETED') and near and backed and moved >= 0.5
    if not (near and backed and moved >= 0.5):
        out('FAIL  G9 reverse (needs approach_allow_reverse and max_reverse_speed_mps: '
            'make_sim_config.py)')
    r.spin(5)
    reset_drone()
    return ok


def main():
    names = [a.upper() for a in sys.argv[1:]] or ['G1', 'G2', 'G3', 'G4', 'G5', 'G6', 'G7',
                                                   'G8', 'G9']
    rclpy.init()
    r = Runner()
    r.pose = TruePose()
    r.spin(3)
    results = []
    for n in names:
        results.append((n, globals()[n.lower()](r)))
        out()
    person('place', 'person_a', 120, 3)
    out('GAZEBO SCENARIOS: ' + ('ALL PASSED' if all(ok for _, ok in results) else
                                'FAILED: ' + ' '.join(n for n, ok in results if not ok)))
    os.makedirs(OUT_DIR, exist_ok=True)
    with open(REPORT, 'a') as f:
        f.write(f'--- {time.strftime("%Y-%m-%d %H:%M")}\n' + '\n'.join(LINES) + '\n')
    print(f'report appended to {REPORT}')
    r.destroy_node()
    rclpy.try_shutdown()


if __name__ == '__main__':
    main()
