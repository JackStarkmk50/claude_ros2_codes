#!/usr/bin/env python3
"""Write ~/sim_drone.yaml: the simulator copy of drone.yaml (your real drone.yaml is not changed).

  python3 make_sim_config.py [out_path]

Changes against drone.yaml, for the Gazebo room and SITL only:
  - EKF origin set (SITL has no GPS), SITL's flow quality (about 51) allowed
  - 8 s instead of 5 s for the lift-off (the Gazebo iris needs 3.5 to 4.7 s)
  - the YOLO model path of this PC
  - text commands may start missions (allow_execute)
  - approach ON: mission_manager enable_approach, intent_bridge allow_approach, and the safety
    gate lets 0.3 m/s forward speed through. The Gazebo person is 1.9 m tall
    (approach_person_height_m).
  - reverse ON: mission_manager approach_allow_reverse, and the gate lets 0.2 m/s backwards
    through (max_reverse_speed_mps). None of this is on in drone.yaml.
"""

import os
import sys

import yaml

SRC = os.path.expanduser('~/drone_ws/src/drone_bringup/config/drone.yaml')
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.expanduser('~/sim_drone.yaml')

c = yaml.safe_load(open(SRC))


def node(name):
    return c[name]['ros__parameters']


node('fcu_command_node').update(ekf_origin_lat_deg=-35.3633, ekf_origin_lon_deg=149.1652,
                                takeoff_start_timeout_s=8.0)
node('fcu_state_node')['flow_min_quality'] = 40
node('yolo_detector')['model_path'] = os.path.expanduser('~/drone_ws/models/yolo11n_320.onnx')
node('intent_bridge').update(allow_execute=True, allow_approach=True)
node('mission_manager').update(enable_approach=True, approach_person_height_m=1.9,
                               approach_allow_reverse=True)
node('safety_supervisor').update(max_horizontal_speed_mps=0.3, max_reverse_speed_mps=0.2)
yaml.safe_dump(c, open(OUT, 'w'), sort_keys=False)
print(f'wrote {OUT} (approach ON, simulator only)')
