"""plan(): what the drone's state allows, and intent JSON / parameters."""

import ast
import json
import pathlib

from drone_llm.core.decide import World, plan
from drone_llm.core.intent import Intent, Limits

SEARCH = Intent(action='search_and_track')
CANCEL = Intent(action='cancel')


def ground(**kw):
    w = World(vehicle_fresh=True, armed=False, mode='STABILIZE', landed_state=1,
              safety_fresh=True, safety_level=0, mission_known=True, mission_state='IDLE')
    for k, v in kw.items():
        setattr(w, k, v)
    return w


def test_on_the_ground_means_autonomous_takeoff():
    assert plan(SEARCH, ground()) == (True, '', True)


def test_hovering_in_guided_means_start_in_the_air():
    ok, _, auto = plan(SEARCH, ground(armed=True, mode='GUIDED', landed_state=2))
    assert ok and auto is False


def test_refusals():
    assert not plan(SEARCH, ground(mission_state='TRACKING'))[0]
    assert not plan(SEARCH, ground(safety_level=4))[0]
    assert 'latched' in plan(SEARCH, ground(safety_latched=True))[1]
    assert not plan(SEARCH, ground(safety_level=3, safety_faults=['BATTERY_LAND: 13.4 V']))[0]
    assert not plan(SEARCH, ground(vehicle_fresh=False))[0]
    assert not plan(SEARCH, ground(safety_fresh=False))[0]
    assert not plan(SEARCH, ground(mission_known=False))[0]
    assert not plan(SEARCH, ground(armed=True, mode='LOITER', landed_state=2))[0]
    assert not plan(SEARCH, ground(armed=True, landed_state=1))[0]


def test_cancel_only_when_a_mission_runs():
    assert not plan(CANCEL, ground())[0]
    assert plan(CANCEL, ground(mission_state='TAKING_OFF'))[0]
    assert plan(CANCEL, ground(mission_state='LANDING'))[0]
    assert not plan(CANCEL, ground(mission_state='MISSION_COMPLETE'))[0]


def test_intent_json():
    d = json.loads(Intent(action='search_and_track', track_duration_s=30).to_json())
    assert d['action'] == 'search_and_track' and d['track_duration_s'] == 30
    assert set(json.loads(CANCEL.to_json())) == {'action', 'reason', 'notes'}


def test_node_parameters_match_limits():
    src = pathlib.Path(__file__).resolve().parents[1] / 'drone_llm' / 'intent_bridge.py'
    tree = ast.parse(src.read_text())
    params = next(ast.literal_eval(n.value) for n in ast.walk(tree)
                  if isinstance(n, ast.Assign) and getattr(n.targets[0], 'id', '') == 'PARAMETERS')
    lim = Limits()
    assert tuple(params['allowed_targets']) == lim.allowed_targets
    for k in ('min_altitude_m', 'max_altitude_m', 'max_search_timeout_s',
              'max_track_duration_s', 'max_text_length', 'default_track_duration_s'):
        assert params[k] == getattr(lim, k), k
    assert params['allow_execute'] is False and params['llm_enabled'] is False


def test_default_track_time_is_filled_in():
    from drone_llm.core.decide import interpret
    it = interpret('look for a person', Limits())
    assert it.understood and it.intent.track_duration_s == 60.0
    assert interpret('look for a person for 20 s', Limits()).intent.track_duration_s == 20.0
