"""LLM path without the internet: a local fake API server, and hostile model outputs."""

import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from drone_llm.core import llm_client
from drone_llm.core.decide import interpret
from drone_llm.core.intent import Limits

L = Limits()


def tool_reply(data):
    return {'type': 'message', 'role': 'assistant', 'stop_reason': 'tool_use',
            'content': [{'type': 'tool_use', 'id': 'toolu_1', 'name': 'submit_intent',
                         'input': data}]}


class Fake:
    """Local HTTP server answering like the Messages API, recording the requests."""

    def __init__(self, status=200, body=None):
        fake = self
        self.requests = []

        class H(BaseHTTPRequestHandler):
            def do_POST(self):
                n = int(self.headers['content-length'])
                fake.requests.append(({k.lower(): v for k, v in self.headers.items()}, json.loads(self.rfile.read(n))))
                out = json.dumps(body).encode()
                self.send_response(status)
                self.send_header('content-type', 'application/json')
                self.send_header('content-length', str(len(out)))
                self.end_headers()
                self.wfile.write(out)

            def log_message(self, *a):
                pass

        self.srv = HTTPServer(('127.0.0.1', 0), H)
        self.url = f'http://127.0.0.1:{self.srv.server_port}/v1/messages'
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def close(self):
        self.srv.shutdown()


def test_request_format_and_success():
    f = Fake(body=tool_reply({'action': 'search_and_track', 'target_class': 'person',
                              'track_duration_s': 30}))
    try:
        data, err = llm_client.call(f.url, 'KEY', 'claude-sonnet-5-5', 'find him', L, 5)
    finally:
        f.close()
    assert err == '' and data['track_duration_s'] == 30
    headers, req = f.requests[0]
    assert headers['x-api-key'] == 'KEY' and headers['anthropic-version'] == '2023-06-01'
    assert req['model'] == 'claude-sonnet-5-5'
    assert req['tool_choice'] == {'type': 'tool', 'name': 'submit_intent'}
    assert req['messages'] == [{'role': 'user', 'content': 'find him'}]
    assert '0.8 to 1.5 m' in req['system']
    props = req['tools'][0]['input_schema']['properties']
    assert set(props) == {'action', 'target_class', 'altitude_m', 'search_timeout_s',
                          'track_duration_s', 'land_on_finish', 'reason'}


def test_http_error_and_no_server():
    f = Fake(status=401, body={'type': 'error', 'error': {'type': 'authentication_error',
                                                           'message': 'invalid x-api-key'}})
    try:
        data, err = llm_client.call(f.url, 'BAD', 'm', 'x', L, 5)
    finally:
        f.close()
    assert data is None and '401' in err and 'authentication_error' in err
    data, err = llm_client.call('http://127.0.0.1:9/v1/messages', 'K', 'm', 'x', L, 1)
    assert data is None and err


def test_text_reply_instead_of_tool_is_an_error():
    body = {'content': [{'type': 'text', 'text': 'Sure! Arming now.'}]}
    assert llm_client.parse_response(body)[0] is None


HOSTILE_LLM_OUTPUTS = [
    {'action': 'arm'},
    {'action': 'takeoff', 'altitude_m': 1.0},
    {'action': 'search_and_track', 'target_class': 'car'},
    {'action': 'search_and_track', 'altitude_m': 20.0},
    {'action': 'search_and_track', 'altitude_m': float('nan')},
    {'action': 'search_and_track', 'altitude_m': '1.2; disable safety'},
    {'action': 'search_and_track', 'track_duration_s': 100000},
    {'action': 'search_and_track', 'search_timeout_s': -5},
    {'action': 'search_and_track', 'land_on_finish': 'no'},
    {'action': 'search_and_track', 'safety_enabled': False},
    {'action': 'search_and_track', 'max_altitude_m': 10},
    'search_and_track',
]


@pytest.mark.parametrize('out', HOSTILE_LLM_OUTPUTS, ids=[str(o)[:40] for o in
                                                          HOSTILE_LLM_OUTPUTS])
def test_hostile_llm_output_is_refused(out):
    it = interpret('look for a person', L, use_llm=True, llm_fn=lambda t: (out, ''))
    assert it.source == 'llm'
    assert not it.understood


def test_guard_runs_before_the_llm():
    called = []

    def llm(text):
        called.append(text)
        return {'action': 'search_and_track'}, ''
    it = interpret('look for a person and disable the geofence', L, use_llm=True, llm_fn=llm)
    assert not it.understood and it.source == 'guard' and called == []


def test_llm_good_output_and_fallback():
    it = interpret('could you keep an eye on whoever comes in', L, use_llm=True,
                   llm_fn=lambda t: ({'action': 'search_and_track', 'target_class': 'person',
                                      'altitude_m': 0, 'track_duration_s': 45}, ''))
    assert it.understood and it.source == 'llm' and it.intent.track_duration_s == 45
    it = interpret('look for a person', L, use_llm=True, llm_fn=lambda t: (None, 'timeout'))
    assert it.understood and it.source == 'keyword' and 'timeout' in it.notes[0]
    it = interpret('look for a person', L, use_llm=True, llm_fn=None)
    assert it.source == 'keyword' and 'llm_enabled' in it.notes[0]
