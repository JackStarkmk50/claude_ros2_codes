"""intent_bridge: text command -> validated intent -> SearchAndTrack goal, cancel, or status.

  service /drone/llm/submit_command (drone_interfaces/SubmitCommand)
      text      "look for a person and track them for 30 seconds"
      execute   false = only show what would happen (dry run)
      use_llm   true  = ask the LLM (only if llm_enabled), else the keyword parser
  reads   /drone/vehicle_state, /drone/safety_status, /drone/mission/status
  calls   /drone/mission/search_and_track (goal, or cancel)

Order for every command (core/decide.py):
  1. keyword_parser.guard(): safety / arming / manipulation texts are refused before any LLM
  2. keyword parser, or the LLM (forced tool call; its output is untrusted data)
  3. intent.validate(): target, altitude, times inside the limits. Nothing is clamped
  4. plan(): the drone's state allows it (no mission running, not OVERRIDE/ABORT, ...)
  5. only with execute true AND allow_execute true: send the goal. Cancel always runs.
The mission and the safety layer then check everything again. This node sends no flight
commands itself and has no way to arm, move, or change a setting.
"""

import os
import threading
import time

import rclpy
from action_msgs.srv import CancelGoal
from rclpy.action import ActionClient
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import ExternalShutdownException, MultiThreadedExecutor
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy

from drone_interfaces.action import SearchAndTrack
from drone_interfaces.msg import MissionStatus, SafetyStatus, VehicleState
from drone_interfaces.srv import SubmitCommand
from drone_llm.core import llm_client
from drone_llm.core.decide import World, interpret, plan
from drone_llm.core.intent import Limits

PARAMETERS = {
    'llm_enabled': False,
    'llm_model': 'claude-sonnet-5-5',
    'llm_timeout_s': 10.0,
    'llm_api_url': 'https://api.anthropic.com/v1/messages',
    'llm_api_key_env': 'ANTHROPIC_API_KEY',
    'allow_execute': False,
    'allowed_targets': ['person'],
    'min_altitude_m': 0.8,
    'max_altitude_m': 1.5,
    'max_search_timeout_s': 120.0,
    'max_track_duration_s': 300.0,
    'max_text_length': 300,
    'default_track_duration_s': 60.0,
    'vehicle_timeout_s': 1.0,
    'safety_timeout_s': 1.0,
    'mission_timeout_s': 1.5,
    'goal_timeout_s': 5.0,
}

IN_QOS = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                    durability=DurabilityPolicy.VOLATILE)
LATCHED = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                     durability=DurabilityPolicy.TRANSIENT_LOCAL)
LEVELS = ('OK', 'DEGRADED', 'HOLD', 'ABORT', 'OVERRIDE')


def wait(future, timeout):
    done = threading.Event()
    future.add_done_callback(lambda _: done.set())
    return done.wait(timeout)


class IntentBridge(Node):

    def __init__(self):
        super().__init__('intent_bridge')
        for name, default in PARAMETERS.items():
            self.declare_parameter(name, default)
        self.p = p = {name: self.get_parameter(name).value for name in PARAMETERS}
        self.limits = Limits(allowed_targets=tuple(p['allowed_targets']),
                             min_altitude_m=p['min_altitude_m'],
                             max_altitude_m=p['max_altitude_m'],
                             max_search_timeout_s=p['max_search_timeout_s'],
                             max_track_duration_s=p['max_track_duration_s'],
                             max_text_length=int(p['max_text_length']),
                             default_track_duration_s=p['default_track_duration_s'])
        self.lock = threading.Lock()
        self.busy = threading.Lock()         # one command at a time
        self.vehicle = self.vehicle_t = None
        self.safety = self.safety_t = None
        self.mission = self.mission_t = None
        cb = ReentrantCallbackGroup()
        self.create_subscription(VehicleState, '/drone/vehicle_state', self._on_vehicle, IN_QOS,
                                 callback_group=cb)
        self.create_subscription(SafetyStatus, '/drone/safety_status', self._on_safety, LATCHED,
                                 callback_group=cb)
        self.create_subscription(MissionStatus, '/drone/mission/status', self._on_mission,
                                 LATCHED, callback_group=cb)
        self.action = ActionClient(self, SearchAndTrack, '/drone/mission/search_and_track',
                                   callback_group=cb)
        self.cancel = self.create_client(
            CancelGoal, '/drone/mission/search_and_track/_action/cancel_goal', callback_group=cb)
        self.create_service(SubmitCommand, '/drone/llm/submit_command', self._on_command,
                            callback_group=cb)
        key_set = bool(os.environ.get(p['llm_api_key_env']))
        if p['llm_enabled'] and not key_set:
            self.get_logger().warn(f'llm_enabled but ${p["llm_api_key_env"]} is not set: the '
                                   'keyword parser will be used')
        self.get_logger().info(
            'up: ' + (f'LLM {p["llm_model"]} enabled' if p['llm_enabled'] else 'keyword parser '
                      'only (llm_enabled false)')
            + ', ' + ('commands can EXECUTE' if p['allow_execute'] else
                      'dry run only (allow_execute false; cancel still works)'))

    # ------------------------------------------------------------------ inputs

    def _now(self):
        return time.monotonic()

    def _on_vehicle(self, msg):
        with self.lock:
            self.vehicle, self.vehicle_t = msg, self._now()

    def _on_safety(self, msg):
        with self.lock:
            self.safety, self.safety_t = msg, self._now()

    def _on_mission(self, msg):
        with self.lock:
            self.mission, self.mission_t = msg, self._now()

    def _world(self):
        now, p = self._now(), self.p
        with self.lock:
            w = World()
            v, s, m = self.vehicle, self.safety, self.mission
            if v is not None and now - self.vehicle_t < p['vehicle_timeout_s'] and v.connected:
                w.vehicle_fresh = True
                w.armed, w.mode, w.landed_state = v.armed, v.mode, v.landed_state
            if s is not None and now - self.safety_t < p['safety_timeout_s']:
                w.safety_fresh = True
                w.safety_level, w.safety_latched = s.level, s.latched
                w.safety_faults = list(s.active_faults)
            if m is not None and now - self.mission_t < p['mission_timeout_s']:
                w.mission_known = True
                w.mission_state, w.mission_detail = m.state_name, m.detail
        return w

    # ------------------------------------------------------------------ the service

    def _llm(self, text):
        key = os.environ.get(self.p['llm_api_key_env'], '')
        if not key:
            return None, f'${self.p["llm_api_key_env"]} not set'
        return llm_client.call(self.p['llm_api_url'], key, self.p['llm_model'], text,
                               self.limits, self.p['llm_timeout_s'])

    def _on_command(self, req, res):
        if not self.busy.acquire(blocking=False):
            res.understood, res.executed = False, False
            res.message = 'busy with the previous command'
            return res
        try:
            self._handle(req, res)
        except Exception as e:               # never let a command crash the node
            res.executed = False
            res.message = f'internal error: {type(e).__name__}: {e}'
        finally:
            self.busy.release()
        if res.executed:
            self.get_logger().warn(f'[AIRCRAFT] command "{req.text[:80]}": {res.message}')
        else:
            self.get_logger().info(f'command "{req.text[:80]}": {res.message}')
        return res

    def _handle(self, req, res):
        llm_fn = self._llm if self.p['llm_enabled'] else None
        it = interpret(req.text, self.limits, use_llm=req.use_llm, llm_fn=llm_fn)
        intent = it.intent
        res.intent_json = intent.to_json()
        res.understood = it.understood
        res.executed = False
        notes = ''.join(f' NOTE: {n}.' for n in it.notes)
        if not it.understood:
            why = '; '.join(it.fails) if it.fails else intent.reason
            res.message = f'REFUSED ({it.source}): {why}.{notes}'
            return
        w = self._world()
        if intent.action == 'status':
            res.message = self._status_text(w) + notes
            return
        ok, why, autonomous = plan(intent, w)
        what = intent.describe()
        if intent.action == 'search_and_track':
            what += ', ' + ('with autonomous takeoff' if autonomous else 'starting in the air')
        if not ok:
            res.message = f'NOT POSSIBLE NOW: {what}: {why}.{notes}'
            return
        if not req.execute:
            res.message = f'DRY RUN ({it.source}): would {what}.{notes}'
            return
        if intent.action == 'search_and_track' and not self.p['allow_execute']:
            res.message = (f'NOT EXECUTED: allow_execute is false in drone.yaml. Would {what}.'
                           + notes)
            return
        if intent.action == 'cancel':
            res.executed, msg = self._cancel()
        else:
            res.executed, msg = self._start(intent, autonomous)
        res.message = f'{msg}: {what}.{notes}'

    def _status_text(self, w):
        parts = [(f'mission {w.mission_state}' + (f' ({w.mission_detail})' if w.mission_detail
                                                   else '')) if w.mission_known
                 else 'mission_manager silent']
        parts.append((f'safety {LEVELS[w.safety_level]}' + (
            f' ({"; ".join(w.safety_faults)})' if w.safety_faults else ''))
            if w.safety_fresh else 'safety silent')
        parts.append(f'mode {w.mode}, armed {w.armed}' if w.vehicle_fresh else 'no vehicle state')
        return 'STATUS: ' + ', '.join(parts)

    def _start(self, intent, autonomous):
        t = self.p['goal_timeout_s']
        if not self.action.wait_for_server(timeout_sec=t):
            return False, 'FAILED: mission_manager action server not available'
        goal = SearchAndTrack.Goal(
            target_class=intent.target_class, autonomous_takeoff=autonomous,
            takeoff_altitude_m=float(intent.altitude_m),
            search_timeout_s=float(intent.search_timeout_s),
            track_duration_s=float(intent.track_duration_s),
            land_on_finish=bool(intent.land_on_finish))
        fut = self.action.send_goal_async(goal)
        if not wait(fut, t) or fut.result() is None:
            return False, 'FAILED: no answer from mission_manager'
        gh = fut.result()
        if not gh.accepted:
            return False, 'REJECTED by mission_manager (a mission is already running?)'
        # mission_manager re-validates inside execute and aborts at once if the goal is wrong.
        rf = gh.get_result_async()
        if wait(rf, 1.5) and rf.result() is not None:
            return False, f'REJECTED by mission_manager: {rf.result().result.message}'
        return True, 'STARTED (watch: tools/mission.py watch; stop: "cancel")'

    def _cancel(self):
        t = self.p['goal_timeout_s']
        if not self.cancel.wait_for_service(timeout_sec=t):
            return False, 'FAILED: mission_manager cancel service not available'
        fut = self.cancel.call_async(CancelGoal.Request())   # zero id + zero stamp = all goals
        if not wait(fut, t) or fut.result() is None:
            return False, 'FAILED: no answer to the cancel'
        r = fut.result()
        if r.return_code == CancelGoal.Response.ERROR_NONE and r.goals_canceling:
            return True, 'CANCELLING (the drone lands)'
        return False, f'cancel not accepted (code {r.return_code})'


def main(args=None):
    rclpy.init(args=args)
    node = IntentBridge()
    executor = MultiThreadedExecutor(num_threads=4)
    executor.add_node(node)
    try:
        executor.spin()
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        # A second Ctrl-C during cleanup (terminal + launch both send SIGINT) must not
        # print a traceback.
        try:
            node.destroy_node()
            rclpy.try_shutdown()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
