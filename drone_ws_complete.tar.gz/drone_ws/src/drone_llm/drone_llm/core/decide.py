"""From text to a decision: guard, parse (keyword or LLM), validate, check the drone's state.

Pure Python, no ROS. The node gives it the text, the limits, the current world and (optionally)
a function that calls the LLM. It returns what to do and a message for the operator.
"""

from dataclasses import dataclass, field

from .intent import Intent, from_dict, validate
from .keyword_parser import guard, parse

LANDED_ON_GROUND, LANDED_IN_AIR = 1, 2
LEVEL_ABORT, LEVEL_OVERRIDE = 3, 4
ACTIVE_STATES = ('PREFLIGHT', 'TAKING_OFF', 'SEARCHING', 'PERSON_DETECTED', 'TARGET_SELECTED',
                 'TRACKING', 'TARGET_LOST', 'REACQUIRING', 'RETURNING', 'LANDING')


@dataclass
class World:
    vehicle_fresh: bool = False
    armed: bool = False
    mode: str = ''
    landed_state: int = 0
    safety_fresh: bool = False
    safety_level: int = 0
    safety_latched: bool = False
    safety_faults: list = field(default_factory=list)
    mission_known: bool = False
    mission_state: str = 'IDLE'
    mission_detail: str = ''

    @property
    def mission_active(self):
        return self.mission_state in ACTIVE_STATES


@dataclass
class Interpretation:
    intent: Intent
    source: str                        # 'guard', 'keyword', 'llm'
    fails: list                        # validation failures (empty = valid)
    notes: list = field(default_factory=list)

    @property
    def understood(self):
        return self.intent.action != 'refuse' and not self.fails


def interpret(text, limits, use_llm=False, llm_fn=None):
    g = guard(text, limits)
    if g is not None:
        return Interpretation(g, 'guard', [])
    notes = []
    if use_llm and llm_fn is not None:
        data, err = llm_fn(text)
        if data is not None:
            intent, fails = from_dict(data)
            if fails:
                return Interpretation(Intent(action='refuse', reason='LLM output invalid: '
                                             + '; '.join(fails)), 'llm', fails)
            fails = validate(intent, limits)
            return _defaults(Interpretation(intent, 'llm', fails, intent.notes), limits)
        notes.append(f'LLM not used ({err}); keyword parser used instead')
    elif use_llm:
        notes.append('LLM disabled in drone.yaml (llm_enabled: false); keyword parser used')
    intent = parse(text, limits)
    return _defaults(Interpretation(intent, 'keyword', validate(intent, limits),
                                    notes + intent.notes), limits)


def _defaults(it, limits):
    if it.understood and it.intent.action == 'search_and_track' \
            and it.intent.track_duration_s == 0.0:
        it.intent.track_duration_s = limits.default_track_duration_s
    return it


def plan(intent, w):
    """(ok, message, autonomous_takeoff) for executing a valid intent in the current world."""
    if intent.action == 'status':
        return True, '', False
    if intent.action == 'cancel':
        if not w.mission_known:
            return False, 'no mission status from mission_manager (is it running?)', False
        if not w.mission_active:
            return False, (f'no mission is running (mission {w.mission_state}). A hover started '
                           'with flight_op.py is landed with "flight_op.py land" or the RC'), False
        return True, '', False
    if intent.action != 'search_and_track':
        return False, intent.reason or 'nothing to do', False
    if not w.mission_known:
        return False, 'no mission status from mission_manager (is it running?)', False
    if w.mission_active:
        return False, f'a mission is already running ({w.mission_state}). Say "cancel" first', False
    if not w.vehicle_fresh:
        return False, 'no fresh vehicle state', False
    if not w.safety_fresh:
        return False, 'no fresh safety status', False
    if w.safety_level == LEVEL_OVERRIDE:
        return False, 'the pilot has control (OVERRIDE). The Pi does not start anything', False
    if w.safety_level >= LEVEL_ABORT or w.safety_latched:
        return False, ('safety: ' + ('; '.join(w.safety_faults) or f'level {w.safety_level}')
                       + (' (latched: reset on the ground first)' if w.safety_latched else '')), \
            False
    if not w.armed and w.landed_state == LANDED_ON_GROUND:
        return True, '', True
    if w.armed and w.mode == 'GUIDED' and w.landed_state == LANDED_IN_AIR:
        return True, '', False
    return False, (f'the drone must be disarmed on the ground, or hovering in GUIDED (armed '
                   f'{w.armed}, mode "{w.mode}", landed_state {w.landed_state})'), False
