"""Pure-Python intent logic (no ROS imports), unit-tested in test/."""
