"""The structured intent: the only thing a text command (keyword parser or LLM) can produce.

Pure Python, no ROS. Whatever produced the intent, validate() decides. The mission then checks
again, and the safety layer checks every command after that. Nothing here can arm, move the drone
to a place, or change a safety setting: there is no field for it.
"""

import json
from dataclasses import asdict, dataclass, field

ACTIONS = ('search_and_track', 'cancel', 'status', 'refuse')


@dataclass
class Limits:
    allowed_targets: tuple = ('person',)
    min_altitude_m: float = 0.8            # same as mission_manager / safety_supervisor
    max_altitude_m: float = 1.5
    max_search_timeout_s: float = 120.0
    max_track_duration_s: float = 300.0
    max_text_length: int = 300
    default_track_duration_s: float = 60.0  # used when the command gives no track time


@dataclass
class Intent:
    action: str = 'refuse'
    target_class: str = 'person'
    altitude_m: float = 0.0                # 0 = the mission's default
    search_timeout_s: float = 0.0          # 0 = the mission's default
    track_duration_s: float = 0.0          # 0 = the mission's default
    land_on_finish: bool = True
    reason: str = ''                       # why refused, or a note for the operator
    notes: list = field(default_factory=list)

    def to_json(self):
        d = asdict(self)
        if self.action != 'search_and_track':
            for k in ('target_class', 'altitude_m', 'search_timeout_s', 'track_duration_s',
                      'land_on_finish'):
                d.pop(k)
        return json.dumps(d, sort_keys=True)

    def describe(self):
        if self.action == 'search_and_track':
            parts = [f'search for a {self.target_class} and keep them in view by turning']
            parts.append(f'altitude {self.altitude_m:.1f} m' if self.altitude_m > 0
                         else 'default altitude')
            if self.search_timeout_s > 0:
                parts.append(f'search up to {self.search_timeout_s:.0f} s')
            parts.append(f'track {self.track_duration_s:.0f} s' if self.track_duration_s > 0
                         else 'track for the default time')
            parts.append('land at the end' if self.land_on_finish else 'hover at the end')
            return ', '.join(parts)
        if self.action == 'cancel':
            return 'cancel the running mission (the drone lands)'
        if self.action == 'status':
            return 'report the mission status'
        return f'refused: {self.reason}'


def _num(value, name, fails):
    try:
        v = float(value)
    except (TypeError, ValueError):
        fails.append(f'{name} is not a number')
        return 0.0
    if v != v or v in (float('inf'), float('-inf')):
        fails.append(f'{name} is not a finite number')
        return 0.0
    return v


def from_dict(d):
    """Build an Intent from untrusted data (an LLM tool call). Unknown keys are an error."""
    if not isinstance(d, dict):
        return None, ['intent is not an object']
    known = set(Intent.__dataclass_fields__) - {'notes'}
    fails = [f'unknown field "{k}"' for k in d if k not in known]
    i = Intent()
    i.action = str(d.get('action', ''))
    i.target_class = str(d.get('target_class', 'person'))
    i.altitude_m = _num(d.get('altitude_m', 0.0), 'altitude_m', fails)
    i.search_timeout_s = _num(d.get('search_timeout_s', 0.0), 'search_timeout_s', fails)
    i.track_duration_s = _num(d.get('track_duration_s', 0.0), 'track_duration_s', fails)
    lof = d.get('land_on_finish', True)
    if not isinstance(lof, bool):
        fails.append('land_on_finish is not true/false')
        lof = True
    i.land_on_finish = lof
    i.reason = str(d.get('reason', ''))[:300]
    return i, fails


def validate(intent, limits):
    """Reasons to refuse this intent; empty = acceptable. Refusals are never 'fixed' by clamping."""
    fails = []
    if intent.action not in ACTIONS:
        return [f'action "{intent.action}" is not allowed (only {", ".join(ACTIONS[:3])})']
    if intent.action != 'search_and_track':
        return fails
    if intent.target_class not in limits.allowed_targets:
        fails.append(f'target "{intent.target_class}" not supported '
                     f'(only {", ".join(limits.allowed_targets)})')
    a = intent.altitude_m
    if a != 0.0 and not (limits.min_altitude_m <= a <= limits.max_altitude_m):
        fails.append(f'altitude {a:.2f} m is outside {limits.min_altitude_m:.1f} to '
                     f'{limits.max_altitude_m:.1f} m')
    s = intent.search_timeout_s
    if s < 0 or s > limits.max_search_timeout_s:
        fails.append(f'search time {s:.0f} s is outside 0 to {limits.max_search_timeout_s:.0f} s')
    t = intent.track_duration_s
    if t < 0 or t > limits.max_track_duration_s:
        fails.append(f'track time {t:.0f} s is outside 0 to {limits.max_track_duration_s:.0f} s')
    return fails
