"""Deterministic keyword parser: text -> Intent. Also the guard that runs before any LLM.

Rules, in this order (the first that matches decides):
  1. empty / too long                           -> not understood / refused
  2. anything about safety, limits, failsafes   -> refused (commands can never change safety)
  3. stop / cancel / abort / land (no search)   -> cancel (the mission lands)
  4. arm / disarm / motors / take off alone     -> refused (only the mission's checked takeoff)
  5. status questions                           -> status
  6. search words + a person word               -> search_and_track (+ altitude, times, no-land)
     search words + another object              -> refused (people only)
     approach / come closer / go to them        -> refused (the drone only turns)
  7. flying somewhere / moving / climbing       -> refused (the drone is not flown by text)
  8. anything else                              -> not understood

guard(text) runs rules 1, 2 and 4 only. The bridge applies it to the text before the LLM sees it,
so an LLM cannot turn "look for a person and disable the geofence" into an accepted mission.
"""

import re

from .intent import Intent

PERSON_WORDS = r'person|people|persons|someone|somebody|anyone|anybody|human|humans|man|men|' \
    r'woman|women|guy|guys|kid|kids|child|children|me|him|her|them|intruder|visitor|' \
    r'player|runner|pilot|operator'
SEARCH_WORDS = r'search|searching|look|looking|find|finding|track|tracking|follow|following|' \
    r'watch|watching|scan|scanning|spot|detect|seek|monitor|keep an eye|locate|guard'
# Objects YOLO knows that are not people (COCO), plus a few common words.
OBJECTS = r'dogs?|cats?|cars?|bikes?|bicycles?|motorcycles?|buses|bus|trucks?|birds?|horses?|' \
    r'sheep|cows?|balls?|bottles?|cups?|chairs?|couch|sofa|tables?|tvs?|laptops?|phones?|' \
    r'books?|keys?|bags?|backpacks?|umbrellas?|toys?|drones?|animals?|pets?|boxe?s?|plants?|' \
    r'doors?|windows?|objects?|things?|faces?|vehicles?'
SAFETY_WORDS = r'safety|safe|failsafe|fail-safe|limits?|geofence|fence|watchdog|checks?|' \
    r'pre-?flight|supervisor|rules?|restrictions?|protections?|estop|e-stop|kill switch|override|' \
    r'max(imum)? (altitude|height|speed)|(altitude|height|speed) limits?|instructions?|' \
    r'developer mode|admin mode|debug mode|jailbreak|system prompt'
DISABLE_WORDS = r'disable|disabled|turn off|switch off|bypass|ignore|skip|remove|deactivate|' \
    r'without|no|raise|increase|change|set|unlock|relax|lift|mute|cheat|hack'
STOP_WORDS = r'stop|cancel|abort|halt|enough|quit|end the mission|end mission|come down|' \
    r'land now|land|finish|emergency'
ARM_WORDS = r'arm|arming|disarm|disarming|motors?|props?|propellers?|throttle|kill|' \
    r'take ?off|takeoff|launch|lift ?off|start the motors'
STATUS_WORDS = r'status|what are you doing|what is happening|what\'s happening|where are you|' \
    r'report|state|how is it going|progress'
MOVE_WORDS = r'fly|go|move|climb|ascend|descend|rise|higher|lower|up|down|forward|forwards|' \
    r'backward|backwards|back|left|right|sideways|ceiling|roof|sky|outside|window|door|' \
    r'rotate|spin|turn|flip|yaw|speed|faster|hover|come here|come to'
APPROACH_WORDS = r'approach|closer|come to|go to|fly to|move to|towards|toward|chase|' \
    r'catch|reach|land on|touch|hit'
NO_LAND = r"(don'?t|do not|never) land|without landing|stay (up|in the air|airborne)|" \
    r'keep hovering|hover at the end|remain in the air'

NUMBER_WORDS = {'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6, 'seven': 7,
                'eight': 8, 'nine': 9, 'ten': 10, 'fifteen': 15, 'twenty': 20, 'thirty': 30,
                'forty': 40, 'forty-five': 45, 'fifty': 50, 'sixty': 60, 'ninety': 90,
                'a': 1, 'an': 1, 'half a': 0.5, 'half an': 0.5}
_NUM = r'(?<![\w.])(\d+(?:\.\d+)?|' + '|'.join(sorted((re.escape(k) for k in NUMBER_WORDS),
                                             key=len, reverse=True)) + r')'
DIST = re.compile(_NUM + r'\s*(m|meters?|metres?|cm|centimet(?:er|re)s?|ft|feet|foot)\b')
DUR = re.compile(_NUM + r'\s*(s|secs?|seconds?|mins?|minutes?|h|hours?)\b')


def _has(pattern, text):
    return re.search(r'(?<![\w-])(?:' + pattern + r')(?![\w-])', text) is not None


def _norm(text):
    t = text.lower().replace('’', "'")
    t = re.sub(r'[^\w\s.\'-]', ' ', t)
    return re.sub(r'\s+', ' ', t).strip()


def _value(tok):
    return float(tok) if tok[0].isdigit() else float(NUMBER_WORDS[tok])


def guard(text, limits):
    """Rules 1, 2, 4. Returns a refusing Intent, or None if the text may go on to a parser."""
    t = _norm(text)
    if len(text) > limits.max_text_length:
        return Intent(action='refuse',
                      reason=f'command longer than {limits.max_text_length} characters')
    if _has(SAFETY_WORDS, t) and (_has(DISABLE_WORDS, t) or not _has(SEARCH_WORDS, t)):
        return Intent(action='refuse', reason='safety settings, limits and checks cannot be '
                      'changed by a command. They are set in drone.yaml and the Pixhawk only')
    if _has(ARM_WORDS, t) and not _has(STOP_WORDS, t):
        if _has(SEARCH_WORDS, t) and _has(PERSON_WORDS, t) and not _has(r'arm|disarm|motors?|'
                                                                        r'kill|throttle', t):
            return None                    # "take off and look for someone": the mission does it
        return Intent(action='refuse', reason='arming, motors and takeoff are never commanded '
                      'directly. Say "look for a person": the mission runs its own checked '
                      'takeoff. For an emergency use the RC motor-stop switch')
    return None


def parse(text, limits):
    """Text -> Intent (action 'refuse' with a reason when not understood or not allowed)."""
    t = _norm(text)
    if not t:
        return Intent(action='refuse', reason='empty command')
    g = guard(text, limits)
    if g is not None:
        return g

    no_land = re.search(NO_LAND, t) is not None
    t_stop = re.sub(NO_LAND, ' ', t)
    if _has(STOP_WORDS, t_stop) and not (_has(SEARCH_WORDS, t_stop) and not
                                         _has(r'stop|cancel|abort|halt|quit|enough', t_stop)):
        if re.search(r"(don'?t|do not|never) (stop|cancel|abort|halt)", t):
            return Intent(action='refuse', reason='unclear: "don\'t stop". Say what to do')
        i = Intent(action='cancel')
        if _has('emergency', t):
            i.notes.append('for a real emergency use the RC: mode switch or motor-stop switch')
        return i
    if _has(STATUS_WORDS, t) and not _has(SEARCH_WORDS, t):
        return Intent(action='status')

    if _has(SEARCH_WORDS, t):
        if _has(APPROACH_WORDS, t):
            return Intent(action='refuse', reason='the drone never flies towards anyone. It '
                          'stays in place and turns to keep the person in view')
        if _has(OBJECTS, t) and not _has(PERSON_WORDS, t):
            return Intent(action='refuse', reason='only people can be searched for')
        if not _has(PERSON_WORDS, t):
            return Intent(action='refuse', reason='say who to look for, e.g. "look for a person"')
        return _search(t, no_land)

    if _has(MOVE_WORDS, t) or _has(APPROACH_WORDS, t):
        return Intent(action='refuse', reason='the drone is not flown by text commands. '
                      'The only mission is "look for a person": take off, turn to search and '
                      'track, turn back, land')
    return Intent(action='refuse', reason='not understood. Try "look for a person and track '
                  'them for 30 seconds", "cancel" or "status"')


def _search(t, no_land):
    i = Intent(action='search_and_track', target_class='person', land_on_finish=not no_land)
    if _has(r'follow|following', t):
        i.notes.append('"follow" means: turn to keep them in view. The drone does not fly '
                       'after anyone')
    if _has(r'higher|lower|ceiling|roof|as high as|max(imum)? height|top', t):
        return Intent(action='refuse', reason='give the height as a number, e.g. "at 1.2 m"')
    dists = DIST.findall(t)
    if len(dists) > 1:
        return Intent(action='refuse', reason='more than one height given')
    if dists:
        v, unit = _value(dists[0][0]), dists[0][1]
        if unit.startswith('c'):
            v /= 100.0
        elif unit in ('ft', 'feet', 'foot'):
            v *= 0.3048
        i.altitude_m = round(v, 2)
        if i.altitude_m == 0.0:
            return Intent(action='refuse', reason='height 0 m')
    for m in DUR.finditer(t):
        v = _value(m.group(1))
        unit = m.group(2)
        v *= 3600 if unit.startswith('h') else 60 if unit.startswith('m') else 1
        before = t[max(0, m.start() - 30):m.start()]
        if re.search(r'(search|searching|look|looking|find|scan|scanning)\w*\s+(for\s+)?'
                     r'((up\s+to|at\s+most|max(imum)?)\s+)?$', before):
            if i.search_timeout_s:
                return Intent(action='refuse', reason='more than one search time given')
            i.search_timeout_s = v
        else:
            if i.track_duration_s:
                return Intent(action='refuse', reason='more than one track time given')
            i.track_duration_s = v
    return i
