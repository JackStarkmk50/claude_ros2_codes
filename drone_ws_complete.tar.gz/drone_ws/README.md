# drone_ws — Indoor Autonomous Drone (ROS 2 Jazzy)

Raspberry Pi 5 (Ubuntu 24.04, ROS 2 Jazzy) companion computer + Pixhawk1 running ArduCopter 4.6.3,
linked over TELEM1 (SERIAL1, 921600, MAVLink 2) through MAVROS.

Full design: `ARCHITECTURE.md` (in the `drone_architecture` folder next to this workspace).
Status: **Phase 13. Text commands (keyword parser, optional LLM) for the mission, tested in SITL. All software phases in the current scope are written; test them in order.**

Phase steps, in order (each phase's tarball contains everything before it):
`docs/PHASE3_MAVROS_LINK.md`, `docs/PHASE4_DRONE_STATE.md`, `docs/PHASE5_OPTICAL_FLOW.md`
(hand-held flow test, deferred: must be done on battery before the first real flight),
`docs/PHASE6_SAFETY.md`, `docs/PHASE7_SETPOINTS.md`, `docs/PHASE8_TAKEOFF_LAND.md`, `docs/PHASE9_CAMERA.md`, `docs/PHASE10_YOLO.md`, `docs/PHASE11_TRACKING.md`, `docs/PHASE12_MISSION.md`, `docs/PHASE13_LLM.md`.
After every update: `tools/carry_settings.py` keeps your own `[SET]` values (see Phase 9 step 1).

Simulation on a PC (not the Pi): `docs/GAZEBO_SIM.md` runs this same workspace against
ArduCopter SITL + Gazebo Harmonic in a virtual room with people (`sim/gazebo/`).

## Current system vs future system

| Current (being built now) | Future (not implemented, no placeholders) |
|---|---|
| MAVROS link, vehicle state, EKF health | LiDAR |
| MTF-01 optical flow + rangefinder monitoring (fused on the Pixhawk EKF3) | VIO / VINS-Mono |
| Safety supervisor, pre-flight checks, command gate, RC override detection | SLAM, 2D mapping, occupancy grids |
| Autonomous GUIDED → arm → takeoff → verified hover → LAND → disarm confirmed | Map-based navigation, true return-to-launch |
| USB camera, YOLO person detection, tracking, search | Obstacle avoidance |
| Deterministic SearchAndTrack mission, LLM intent bridge | Advanced localization |

## Hardware

| Part | Value |
|---|---|
| Companion | Raspberry Pi 5, active cooler |
| FCU | Pixhawk1, ArduCopter V4.6.3 |
| Link | TELEM1 = SERIAL1, 921600 baud, MAVLink 2 (ModemManager disabled) |
| Flow + range | MicoAir MTF-01 |
| Camera | Zebronics USB |
| RC | mode switch with LOITER and GUIDED |

## Packages

| Package | Type | Executables |
|---|---|---|
| `drone_interfaces` | ament_cmake | — (6 msg, 1 srv, 2 action) |
| `drone_fcu` | ament_python | `fcu_state_node`, `fcu_command_node` |
| `drone_safety` | ament_python | `safety_supervisor` |
| `drone_perception` | ament_python | `yolo_detector`, `target_tracker` |
| `drone_mission` | ament_python | `mission_manager` |
| `drone_llm` | ament_python | `intent_bridge` |
| `drone_bringup` | ament_python | launch files + `config/drone.yaml` |

## ROS graph (target design; Phase 2 starts the nodes only)

```text
intent_bridge ──SearchAndTrack──► mission_manager ──ControlCommand / FlightOperation──► safety_supervisor
                                        ▲                                                   │
                         TrackedTarget  │                                 validated command │ approved op
                                        │                                                   ▼
camera ─► yolo_detector ─► target_tracker                                           fcu_command_node ─► MAVROS ─► Pixhawk
                                                                                            ▲
                       fcu_state_node ◄─ MAVROS ◄─ Pixhawk      VehicleState / FlowStatus ──┘ (and to safety, mission)
```

## Install (once, on the Pi)

Follow `ARCHITECTURE.md` §14 for the apt packages and GeographicLib datasets, then:

```bash
bash ~/drone_ws/tools/setup_venv.sh
```

## Build

```bash
cd ~/drone_ws
source /opt/ros/jazzy/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source ~/drone_ws/env.sh
```

`env.sh` sources ROS, this workspace, and adds the venv's pip packages to `PYTHONPATH`.
Use it in every new terminal.

## Test

```bash
bash ~/drone_ws/tools/verify_workspace.sh     # clean build + all checks and tests
```

## Safety

- Default is **bench mode**: `enable_fcu_output:=false`, `allow_arming:=false`. Both are
  **[AIRCRAFT]** switches and are only turned on in the phases that say so, props off first.
- Only `fcu_command_node` may talk to MAVROS for writing. A test enforces this.
- The RC mode switch (out of GUIDED) is the pilot override. A motor emergency-stop switch is
  strongly recommended before any powered test (see `ARCHITECTURE.md` §11.6).

---

## Phase 2: what to run on the Pi

### Step 1: copy the workspace to the Pi

**WHAT** put this folder at `~/drone_ws` on the Pi.
**COMMAND** (from wherever you downloaded `drone_ws_phase2.tar.gz`):

```bash
mkdir -p ~/drone_ws && tar -xzf drone_ws_phase2.tar.gz -C ~/drone_ws --strip-components=1
ls ~/drone_ws/src
```

**EXPECTED** `drone_bringup drone_fcu drone_interfaces drone_llm drone_mission drone_perception drone_safety`
**IF NOT** check the tarball path; `tar -tzf drone_ws_phase2.tar.gz | head` shows what is inside.

If you have an old `~/drone_ws`, rename it first (`mv ~/drone_ws ~/drone_ws_old`) so old packages
can't mix in.

### Step 2: install dependencies

**COMMAND**

```bash
sudo apt update
sudo apt install -y python3-colcon-common-extensions python3-rosdep python3-pytest python3-yaml python3-venv v4l-utils
sudo rosdep init 2>/dev/null || true
rosdep update
cd ~/drone_ws && source /opt/ros/jazzy/setup.bash
rosdep install --from-paths src --ignore-src -r -y
```

**EXPECTED** ends with `#All required rosdeps installed successfully`. This also installs MAVROS,
vision_msgs and v4l2_camera (declared now, used from Phase 3 / Phase 9).
**IF NOT** the message names the missing key; paste it to me.

### Step 3: one-shot check (clean build + everything)

**COMMAND**

```bash
bash ~/drone_ws/tools/verify_workspace.sh
```

**EXPECTED** (last lines)

```text
PASS  drone packages (7)
PASS  drone_interfaces types (9)
PASS  interface show FlightOperation
PASS  python import
PASS  drone executables (7)
PASS  pymavlink importable
Summary: 96 tests, 0 errors, 0 failures, 0 skipped
WORKSPACE CHECK: ALL PASSED
```

**IF NOT**

| Symptom | Why | Check / fix |
|---|---|---|
| `error: option --editable not recognized` | setuptools too new for colcon (pip upgraded it) | `python3 -c "import setuptools;print(setuptools.__version__)"` should be 68.x. Remove the pip one: `pip uninstall setuptools` (outside the venv) |
| `drone_interfaces types (0)` | interfaces not built or not sourced | `ls install/drone_interfaces/share/drone_interfaces/msg`; then `source install/setup.bash` |
| `ModuleNotFoundError: drone_interfaces` | workspace not sourced | `source ~/drone_ws/env.sh` |
| `Plugin 'launch_testing' ... hookspec` | pytest from pip is too new | `python3 -m pytest --version` should be 7.x (apt); uninstall the pip pytest |
| `No executable found` | stale build | the script already does a clean build; paste its output |

### Step 4: run the stack once (bench mode, nothing reaches the Pixhawk)

**COMMAND**

```bash
source ~/drone_ws/env.sh
ros2 launch drone_bringup bringup.launch.py
```

In a second terminal:

```bash
source ~/drone_ws/env.sh
ros2 node list
```

**EXPECTED** seven nodes:

```text
/fcu_command_node
/fcu_state_node
/intent_bridge
/mission_manager
/safety_supervisor
/target_tracker
/yolo_detector
```

and in the launch terminal, seven `skeleton up (Phase 2), N parameters loaded` lines plus
`BENCH SKELETON: output_enabled=False allow_arming=False`. Ctrl-C ends every node with
`process has finished cleanly`.

**IF NOT** a node missing from `ros2 node list` has an error in the launch terminal just above
its `process has died` line; paste that.

### Step 5: tell me the results

Send me the last lines of Step 3, plus the output of these two read-only commands (for Phase 3):

```bash
ls -l /dev/serial* /dev/ttyAMA* /dev/ttyUSB* /dev/ttyACM* 2>/dev/null
v4l2-ctl --list-devices
```
