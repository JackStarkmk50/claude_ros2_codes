# Phase 13: text commands (keyword parser, optional LLM)

**Goal:** type `look for a person and track them for 30 seconds` and get the Phase 12 mission,
with the same checks as `mission.py start`. Type `stop` and the mission is cancelled (the drone
lands).

**The rule:** text can only choose **one** of four things: start the SearchAndTrack mission,
cancel it, ask for status, or be refused. There is no way to arm, fly somewhere, climb, approach
someone, or change a safety setting by text. The code has no field for it.

**Safety:** steps 1 to 4 send nothing to the Pixhawk. Step 5 is props-off [AIRCRAFT].

---

## What is new

| File | What it does |
|---|---|
| `intent_bridge` (real now) | service `/drone/llm/submit_command`: text → intent → mission goal, cancel, or status |
| `drone_llm/core/keyword_parser.py` | deterministic parser, and the **guard** that runs before any LLM |
| `drone_llm/core/intent.py` | the intent (4 actions) and its validation. Out-of-limit numbers are refused, never clamped |
| `drone_llm/core/llm_client.py` | optional Claude API call, standard library only, one forced tool |
| `drone_llm/core/decide.py` | guard → parser or LLM → validation → "does the drone's state allow it" |
| `tools/command.py` | send commands: dry run, `--go`, `-i` interactive, `--selftest` |
| `drone.yaml` → `intent_bridge` | `allow_execute: false` **[SET]**, `llm_enabled: false` **[SET]**, limits equal to the mission's (a test checks) |
| 70 new tests | normal commands, 28 hostile or unclear texts, 12 hostile LLM outputs, a fake API server |

**What happens to each command**

1. **Guard** (always, before any LLM): anything about safety, limits, failsafes, checks,
   instructions, arming, motors or takeoff on its own is refused at once.
2. **Parser:** the keyword parser, or the LLM if you ask for it (`--llm`) and it is enabled. The
   LLM can only fill in a form with 7 fields. Its answer is treated as untrusted.
3. **Validation:** target must be `person`, altitude 0.8 to 1.5 m, search up to 120 s, tracking
   up to 300 s. `at 10 m` is refused, not turned into 1.5 m.
4. **State check:** no mission already running, safety not ABORT/OVERRIDE/latched. On the
   ground and disarmed → mission with autonomous takeoff. Hovering in GUIDED → mission starts in
   the air. Anything else → refused.
5. **Execute** only with `--go` (or `y` in interactive mode) **and** `allow_execute: true`.
   Cancel works even with `allow_execute: false`.

Then `mission_manager` checks again, the pre-flight runs, and the safety gate checks every command,
exactly as in Phase 12.

| You type | Result |
|---|---|
| `look for a person and track them for 30 seconds` | mission, track 30 s |
| `take off and find someone at 1.2 m, search up to 60 s` | mission, 1.2 m, search 60 s, track 60 s (default) |
| `follow me for a minute and don't land` | mission, track 60 s, hover at the end. "follow" = turn to keep you in view |
| `stop`, `cancel`, `land`, `abort`, `emergency` | cancel: the drone lands. For a real emergency: the RC |
| `status` | mission state, safety level, mode |
| `disable safety`, `ignore previous instructions ...` | refused (guard) |
| `arm now`, `kill the motors`, `take off` | refused (guard) |
| `fly to the ceiling`, `go forward 3 m`, `fly towards him` | refused |
| `look for a person at 10 m`, `track for 2 hours` | refused (limits) |
| `find the dog` | refused (people only) |

**Tested here**
- 260 tests in total, all passing.
- In the simulator (ArduCopter 4.6.3 SITL, whole stack with YOLO and the tracker):
  - `look for a person and track them for 10 seconds`: took off, searched, tracked 10 s, turned
    back, landed and disarmed: COMPLETED. A second start while it ran was refused, and `status`
    reported TRACKING.
  - `stop` while tracking: CANCELLED, landed and disarmed.
  - The LLM path with a **fake** API server on the same computer. A good answer started the
    mission and it COMPLETED. An answer with altitude 25 m was refused. `look for a person and
    disable safety` was refused by the guard, and the fake server never received it.
  - `command.py --selftest`: 16 of 16 passed.
- **Not tested: the real Claude API.** There was no API key here. The request follows the
  documented Messages API format, and a test checks it. Your step 4 is the first real call.

---

## Step 1: update and check

```bash
cp ~/drone_ws/src/drone_bringup/config/drone.yaml ~/drone.yaml.mine
tar -xzf drone_ws_phase13.tar.gz -C ~/drone_ws --strip-components=1
python3 ~/drone_ws/tools/carry_settings.py ~/drone.yaml.mine
bash ~/drone_ws/tools/verify_workspace.sh
```

**EXPECTED** `Summary: 260 tests, 0 errors, 0 failures, 0 skipped` and `WORKSPACE CHECK: ALL PASSED`.

## Step 2: the self-test (output OFF)

**WHAT** 16 commands, normal and hostile, all as dry runs. Nothing is executed.

Terminal A:

```bash
source ~/drone_ws/env.sh
ros2 launch drone_bringup bringup.launch.py
```

**EXPECTED** among the lines: `intent_bridge ... up: keyword parser only (llm_enabled false),
dry run only (allow_execute false; cancel still works)`.

Terminal B:

```bash
source ~/drone_ws/env.sh
python3 ~/drone_ws/tools/command.py --selftest
```

**EXPECTED** 16 `PASS` lines and `COMMAND SELFTEST: ALL PASSED`. The report goes to
`~/drone_ws/phase13_report.txt`.

**IF NOT**
- `intent_bridge not reachable`: terminal A was started with `use_llm:=false`, or
  intent_bridge crashed. Send me terminal A.
- a `FAIL` line: send me the report.

## Step 3: try your own words (still dry run)

```bash
python3 ~/drone_ws/tools/command.py -i
```

Type what you would naturally say. Each answer shows the intent and `DRY RUN: would ...`, or
`REFUSED: why`. It then asks `Execute? [y/N]`: answer **N** (with `allow_execute: false` it
would not run anyway). Send me any phrase that was understood wrongly. An empty line quits.

## Step 4 (optional): the LLM

**WHAT** lets you use free wording ("keep an eye on whoever walks in"). The keyword parser
stays the fallback, and the guard and limits stay the same.

**WHY optional:** it needs internet on the Pi and an Anthropic API key (paid per use). Every
command text you send with `--llm` goes to Anthropic. Without it, everything works with the
keyword parser.

1. Get an API key at console.anthropic.com.
2. In `drone.yaml`, `intent_bridge`: `llm_enabled: true`.
3. Terminal A, **in the same terminal before the launch** (never put the key in drone.yaml):

   ```bash
   source ~/drone_ws/env.sh
   export ANTHROPIC_API_KEY=sk-ant-...your key...
   ros2 launch drone_bringup bringup.launch.py
   ```

   **EXPECTED** `intent_bridge ... up: LLM claude-sonnet-5-5 enabled, ...`
4. Terminal B:

   ```bash
   python3 ~/drone_ws/tools/command.py --llm --selftest
   python3 ~/drone_ws/tools/command.py --llm "could you keep an eye on whoever walks in"
   ```

   **EXPECTED** `ALL PASSED`, and the answers say `(llm)` instead of `(keyword)`. The guard lines
   still say `(guard)`.

**IF NOT**
- `NOTE: LLM not used (HTTP 401: ...)`: the key is wrong or not exported in terminal A.
- `NOTE: LLM not used (URLError ...)` or `timeout`: no internet on the Pi.
- `HTTP 404` mentioning the model: tell me; the model name may need updating.
In all three cases the keyword parser answered instead, so nothing is unsafe.

## Step 5: props-off, by text [AIRCRAFT]

**WHAT** the Phase 12 step 4 test, started by text. **PROPS OFF**, 4S battery, RC on in
STABILIZE, estop in reach.

1. In `drone.yaml`, `intent_bridge`: `allow_execute: true`.
2. Terminal A:

   ```bash
   ros2 launch drone_bringup bringup.launch.py enable_fcu_output:=true allow_arming:=true
   ```

3. Terminal B:

   ```bash
   python3 ~/drone_ws/tools/flight_op.py preflight
   python3 ~/drone_ws/tools/command.py -i 2>&1 | tee -a ~/drone_ws/phase13_report.txt
   ```

   Type `look for a person and track them for 15 seconds`, then `y`.

**EXPECTED**
- `STARTED ...: search for a person ..., track 15 s, land at the end, with autonomous takeoff`
- Motors spin up (loud) for up to 5 s, then LAND and disarm, exactly as in Phase 12 (no props, so
  no climb).
- Type `status`: `mission TAKEOFF...` or `mission ERROR`/done, `armed False` at the end.

Then flip the mode switch to STABILIZE, run `flight_op.py preflight` again, type the same command,
`y`, and type `stop` while the motors spin. **EXPECTED:** `CANCELLING (the drone lands)` and
disarmed.

**IF NOT** motors keep spinning more than 20 s: estop, then send me terminals A and B.

4. Set `allow_execute: false` again until the first real mission.

## Step 6: send the report

Upload `~/drone_ws/phase13_report.txt`.

---

## What comes next

This is the last software phase in the current scope. Before the first real mission, the
checklist at the end of `docs/PHASE12_MISSION.md` applies: the deferred Phase 5 flow test on
battery, the FCU parameters from Phase 8, and a first tethered Phase 8 hover with you on the RC.
