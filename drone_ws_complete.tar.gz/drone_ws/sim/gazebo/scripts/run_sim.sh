#!/bin/bash
# Start the Gazebo simulation: Gazebo world + ArduCopter SITL + camera bridge.
# The drone stack itself is started separately (see docs/GAZEBO_SIM.md), exactly like on the Pi
# but with fcu_url:=tcp://127.0.0.1:5760 and use_camera:=false.
#
#   bash run_sim.sh            headless (no window)
#   bash run_sim.sh --gui      with the Gazebo window
#   bash run_sim.sh --stop     stop everything this script started
#
# Needs (see setup_gazebo.sh): ARDUPILOT_DIR (default ~/ardupilot, with build/sitl/bin/arducopter),
# AP_GZ_DIR (default ~/ardupilot_gazebo, with build/libArduPilotPlugin.so), ROS 2 Jazzy + ros_gz.

set -u
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ARDUPILOT_DIR="${ARDUPILOT_DIR:-$HOME/ardupilot}"
AP_GZ_DIR="${AP_GZ_DIR:-$HOME/ardupilot_gazebo}"
RUN_DIR="${SIM_RUN_DIR:-$HOME/.drone_sim}"
mkdir -p "$RUN_DIR"
cd "$RUN_DIR"

stop() {
  for f in relay bridge sitl gz; do
    [ -f "$f.pid" ] && kill "$(cat $f.pid)" 2>/dev/null
    rm -f "$f.pid"
  done
  sleep 1
  pkill -f "[a]rducopter --model JSON" 2>/dev/null
  pkill -f "[g]z sim .*indoor_search" 2>/dev/null
  echo "simulation stopped"
}
if [ "${1:-}" = "--stop" ]; then stop; exit 0; fi

for f in "$ARDUPILOT_DIR/build/sitl/bin/arducopter" "$AP_GZ_DIR/build/libArduPilotPlugin.so" \
         "$HERE/models/person/meshes/standing.glb"; do
  [ -e "$f" ] || { echo "missing $f: run setup_gazebo.sh first"; exit 1; }
done
stop > /dev/null

export GZ_SIM_SYSTEM_PLUGIN_PATH="$AP_GZ_DIR/build${GZ_SIM_SYSTEM_PLUGIN_PATH:+:$GZ_SIM_SYSTEM_PLUGIN_PATH}"
export GZ_SIM_RESOURCE_PATH="$AP_GZ_DIR/models:$HERE/models${GZ_SIM_RESOURCE_PATH:+:$GZ_SIM_RESOURCE_PATH}"

GZ_ARGS="-r"
[ "${1:-}" = "--gui" ] || GZ_ARGS="-s -r --headless-rendering"
gz sim $GZ_ARGS "$HERE/worlds/indoor_search.sdf" > gz.log 2>&1 &
echo $! > gz.pid
echo "gazebo started (log $RUN_DIR/gz.log)"
sleep 8

# ArduCopter SITL talking to the Gazebo plugin over JSON (UDP 9002). MAVLink on TCP 5760.
# Restarted automatically if it exits (a fresh SITL exits once after loading its defaults).
(
  for i in 1 2 3; do
    "$ARDUPILOT_DIR/build/sitl/bin/arducopter" --model JSON:127.0.0.1 --speedup 1 --slave 0 \
      --defaults "$ARDUPILOT_DIR/Tools/autotest/default_params/copter.parm,$HERE/params/gazebo_indoor.parm" \
      -I0 --home -35.363261,149.165230,584,90
    echo "SITL exited (run $i)"
    sleep 2
  done
) > sitl.log 2>&1 &
echo $! > sitl.pid
echo "ArduCopter SITL started (log $RUN_DIR/sitl.log), MAVLink on tcp://127.0.0.1:5760"

ros2 run ros_gz_bridge parameter_bridge \
  /sim/camera/image_raw@sensor_msgs/msg/Image[gz.msgs.Image \
  /sim/camera/camera_info@sensor_msgs/msg/CameraInfo[gz.msgs.CameraInfo > bridge.log 2>&1 &
echo $! > bridge.pid
python3 "$HERE/scripts/camera_relay.py" > relay.log 2>&1 &
echo $! > relay.pid
echo "camera bridge started: /camera/image_raw and /camera/camera_info"
echo "stop with: bash $HERE/scripts/run_sim.sh --stop"
