#!/usr/bin/env python3
"""Move the people in the Gazebo room (gz-transport Python bindings, else the `gz service` tool).

  python3 move_person.py place person_a 120 3        person_a at bearing 120 deg, 3 m away
  python3 move_person.py hide person_a               park it outside the room
  python3 move_person.py walk person_b 30 3 8        walk person_b around the drone start point:
                                                     from bearing 30 deg, radius 3 m, 8 deg/s
                                                     (Ctrl-C to stop)

Bearing = degrees to the LEFT of the drone's start heading (Gazebo +X), like the tracker's
"left". The person always faces the drone's start point.
"""

import math
import subprocess
import sys
import time

WORLD = 'indoor_search'

try:                                      # in-process: cheap enough for 10 updates a second
    from gz.msgs10.boolean_pb2 import Boolean
    from gz.msgs10.pose_pb2 import Pose
    from gz.transport13 import Node
    _NODE = Node()
except ImportError:                       # fall back to one `gz service` process per call
    _NODE = None


def set_pose(name, x, y, yaw):
    if _NODE is not None:
        p = Pose()
        p.name = name
        p.position.x, p.position.y, p.position.z = x, y, 0.0
        p.orientation.z, p.orientation.w = math.sin(yaw / 2), math.cos(yaw / 2)
        ok, rep = _NODE.request(f'/world/{WORLD}/set_pose', p, Pose, Boolean, 2000)
        return bool(ok and rep.data)
    req = (f'name: "{name}", position: {{x: {x:.3f}, y: {y:.3f}, z: 0}}, '
           f'orientation: {{x: 0, y: 0, z: {math.sin(yaw / 2):.5f}, w: {math.cos(yaw / 2):.5f}}}')
    r = subprocess.run(['gz', 'service', '-s', f'/world/{WORLD}/set_pose', '--reqtype',
                        'gz.msgs.Pose', '--reptype', 'gz.msgs.Boolean', '--timeout', '2000',
                        '--req', req], capture_output=True, text=True)
    return 'true' in r.stdout


def at(bearing_deg, dist):
    b = math.radians(bearing_deg)
    x, y = dist * math.cos(b), dist * math.sin(b)
    # The mesh looks along its -Y axis: rotate it so it faces the origin.
    return x, y, b + math.pi / 2 + math.pi


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    cmd, name = sys.argv[1], sys.argv[2]
    if cmd == 'hide':
        ok = set_pose(name, 20.0, 20.0 if name.endswith('a') else -20.0, 0.0)
    elif cmd == 'place':
        ok = set_pose(name, *at(float(sys.argv[3]), float(sys.argv[4])))
    elif cmd == 'walk':
        b, d, rate = float(sys.argv[3]), float(sys.argv[4]), float(sys.argv[5])
        t0 = time.monotonic()
        try:
            while True:
                set_pose(name, *at(b + rate * (time.monotonic() - t0), d))
                time.sleep(0.1)
        except KeyboardInterrupt:
            return 0
    else:
        print(__doc__)
        return 2
    print(f'{cmd} {name}: {"OK" if ok else "FAILED (is Gazebo running?)"}')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
