#!/usr/bin/env python3
"""Mission scenarios in the Gazebo room. Needs run_sim.sh and the drone stack running.

  python3 gz_scenarios.py G1 G2 G3 G4 G5 G6        (any subset, in that order)

  G1  person standing 120 deg left: take off, search, track 15 s, turn back, land -> COMPLETED
  G2  person walking round the drone at 8 deg/s: the drone turns with them -> COMPLETED
  G3  person hides for 3 s while tracked: LOST, REACQUIRING, TRACKING -> COMPLETED
  G4  nobody in the room: 360 deg search, turn back, land -> TARGET_NOT_FOUND
  G5  text command "look for a person and track them for 60 seconds", then "stop"
      while tracking -> CANCELLED (needs intent_bridge allow_execute: true)
  G6  cancel while tracking (Ctrl-C equivalent) -> CANCELLED

Between scenarios the flight mode is put back to STABILIZE over MAVLink (tcp 5762), which
stands in for your RC mode switch, and the safety latch is reset.
Writes ~/drone_ws/gazebo_report.txt and a camera snapshot per scenario
(~/drone_ws/gazebo_G1.jpg, ...) taken while tracking.
"""

import os
import statistics
import subprocess
import sys
import time

import numpy as np
import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import Image
from std_srvs.srv import Trigger

from drone_interfaces.action import SearchAndTrack
from drone_interfaces.msg import MissionStatus, TrackedTarget, VehicleState
from drone_interfaces.srv import SubmitCommand
from drone_perception.core.image_convert import image_to_rgb
from drone_perception.qos import IMAGE_QOS

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.expanduser('~/drone_ws')
REPORT = os.path.join(OUT_DIR, 'gazebo_report.txt')
OUTCOMES = ('COMPLETED', 'CANCELLED', 'TARGET_NOT_FOUND', 'TARGET_LOST', 'SAFETY_STOP',
            'MANUAL_OVERRIDE', 'PREFLIGHT_FAILED', 'TAKEOFF_FAILED', 'ERROR')
LATCHED = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                     durability=DurabilityPolicy.TRANSIENT_LOCAL)
END = ('MISSION_COMPLETE', 'MISSION_CANCELLED', 'SAFETY_STOP', 'MANUAL_OVERRIDE', 'ERROR')
LINES = []


def out(s=''):
    print(s, flush=True)
    LINES.append(s)


def person(*args):
    subprocess.run([sys.executable, os.path.join(HERE, 'move_person.py'), *map(str, args)],
                   stdout=subprocess.DEVNULL, check=False)


def set_mode(mode):
    from pymavlink import mavutil
    m = mavutil.mavlink_connection('tcp:127.0.0.1:5762', source_system=255)
    m.wait_heartbeat(timeout=10)
    m.set_mode(mode)
    time.sleep(1)
    m.close()


class Runner(Node):
    def __init__(self):
        super().__init__('gz_scenarios')
        self.v = self.m = self.img = None
        self.errs, self.states = [], []
        self.create_subscription(VehicleState, '/drone/vehicle_state',
                                 lambda m: setattr(self, 'v', m), 10)
        self.create_subscription(MissionStatus, '/drone/mission/status', self._m, LATCHED)
        self.create_subscription(TrackedTarget, '/drone/perception/target', self._t, 10)
        self.create_subscription(Image, '/camera/image_raw', lambda m: setattr(self, 'img', m),
                                 IMAGE_QOS)
        self.ac = ActionClient(self, SearchAndTrack, '/drone/mission/search_and_track')
        self.reset = self.create_client(Trigger, '/drone/safety/reset')
        self.cmd = self.create_client(SubmitCommand, '/drone/llm/submit_command')

    def _m(self, m):
        self.m = m
        if not self.states or self.states[-1] != m.state_name:
            self.states.append(m.state_name)

    def _t(self, t):
        if self.m is not None and self.m.state_name == 'TRACKING' and t.state == 2:
            self.errs.append(t.error_x_norm)

    def spin(self, t, until=None):
        end = time.time() + t
        while time.time() < end:
            rclpy.spin_once(self, timeout_sec=0.05)
            if until and until():
                return True
        return False

    def prepare(self):
        set_mode('STABILIZE')
        self.spin(2)
        if self.reset.wait_for_service(timeout_sec=5):
            f = self.reset.call_async(Trigger.Request())
            rclpy.spin_until_future_complete(self, f, timeout_sec=5)
        self.errs, self.states = [], []
        self.spin(2)

    def snapshot(self, name):
        if self.img is None:
            return
        try:
            import cv2
            m = self.img
            rgb = image_to_rgb(m.encoding, m.width, m.height, m.step, bytes(m.data))
            path = os.path.join(OUT_DIR, f'gazebo_{name}.jpg')
            cv2.imwrite(path, cv2.cvtColor(np.asarray(rgb), cv2.COLOR_RGB2BGR))
            out(f'  snapshot while tracking: {path}')
        except Exception as e:  # snapshots are a nice-to-have
            out(f'  (snapshot failed: {e})')

    def mission(self, track, hook=None, timeout=240):
        if not self.ac.wait_for_server(timeout_sec=5):
            out('  mission_manager not reachable: is the stack running?')
            return None
        g = SearchAndTrack.Goal(target_class='person', autonomous_takeoff=True,
                                takeoff_altitude_m=0.0, search_timeout_s=0.0,
                                track_duration_s=float(track), land_on_finish=True)
        f = self.ac.send_goal_async(g)
        rclpy.spin_until_future_complete(self, f, timeout_sec=5)
        gh = f.result()
        if gh is None or not gh.accepted:
            out('  goal rejected')
            return None
        rf = gh.get_result_async()
        t0 = time.time()
        while not rf.done() and time.time() - t0 < timeout:
            rclpy.spin_once(self, timeout_sec=0.05)
            if hook:
                hook(gh, time.time() - t0)
        return rf.result().result if rf.done() else None

    def say(self, text):
        self.cmd.wait_for_service(timeout_sec=5)
        f = self.cmd.call_async(SubmitCommand.Request(text=text, execute=True, use_llm=False))
        rclpy.spin_until_future_complete(self, f, timeout_sec=30)
        r = f.result()
        out(f'  > "{text}": {r.message}')
        return r

    def report(self, name, r, want):
        if r is None:
            out('  NO RESULT (timeout)')
            return False
        got = OUTCOMES[r.outcome]
        out(f'  result {got}: {r.message} ({r.duration_s:.0f} s)')
        out('  states: ' + ' > '.join(self.states))
        if self.errs:
            e = [abs(x) for x in self.errs]
            late = e[len(e) // 3:] if len(e) > 6 else e
            out(f'  tracking |error_x|: median {statistics.median(late):.2f}, '
                f'max {max(late):.2f} ({len(e)} samples)')
        ok = got == want and r.landed_and_disarmed
        out(f'{"PASS" if ok else "FAIL"}  {name} (want {want}, landed and disarmed)')
        return ok


def snap_hook(r, name):
    done = []

    def hook(gh, t):
        if not done and r.m is not None and r.m.state_name == 'TRACKING' and len(r.errs) > 30:
            r.snapshot(name)
            done.append(1)
    return hook


def g1(r):
    out('G1 person standing 120 deg left: search, track 15 s, turn back, land')
    person('hide', 'person_b')
    person('place', 'person_a', 120, 3)
    r.prepare()
    return r.report('G1', r.mission(15, snap_hook(r, 'G1')), 'COMPLETED')


def g2(r):
    out('G2 person walking round the drone at 8 deg/s (to the right)')
    person('hide', 'person_a')
    walker = subprocess.Popen([sys.executable, os.path.join(HERE, 'move_person.py'), 'walk',
                               'person_b', '70', '3', '-8'])
    try:
        r.prepare()
        res = r.mission(20, snap_hook(r, 'G2'))
    finally:
        walker.terminate()
        walker.wait()
    return r.report('G2', res, 'COMPLETED')


def g3(r):
    out('G3 person hides for 3 s while tracked: lost, reacquired, completes')
    person('hide', 'person_b')
    person('place', 'person_a', 40, 3)
    r.prepare()
    state = {}

    def hook(gh, t):
        if r.m is None:
            return
        if 'hid' not in state and r.m.state_name == 'TRACKING' and len(r.errs) > 40:
            r.snapshot('G3')
            person('hide', 'person_a')
            state['hid'] = time.time()
        elif 'hid' in state and 'back' not in state and time.time() - state['hid'] > 3:
            person('place', 'person_a', 40, 3)
            state['back'] = 1
    return r.report('G3', r.mission(25, hook), 'COMPLETED')


def g4(r):
    out('G4 nobody in the room: full search, turn back, land')
    person('hide', 'person_a')
    person('hide', 'person_b')
    r.prepare()
    return r.report('G4', r.mission(15), 'TARGET_NOT_FOUND')


def g5(r):
    out('G5 text command, then "stop" while tracking')
    person('hide', 'person_b')
    person('place', 'person_a', 60, 3)
    r.prepare()
    res = r.say('look for a person and track them for 60 seconds')
    if not res.executed:
        out('FAIL  G5: not started (intent_bridge allow_execute must be true for this test)')
        return False
    r.spin(120, lambda: r.m is not None and r.m.state_name == 'TRACKING' and len(r.errs) > 30)
    r.snapshot('G5')
    r.say('stop')
    r.spin(120, lambda: r.m is not None and r.m.state_name in END)
    r.spin(30, lambda: r.v is not None and not r.v.armed)
    out(f'  final: {r.m.state_name}: {r.m.detail}')
    out('  states: ' + ' > '.join(r.states))
    ok = r.m.state_name == 'MISSION_CANCELLED' and r.v is not None and not r.v.armed
    out(f'{"PASS" if ok else "FAIL"}  G5 (want CANCELLED, landed and disarmed)')
    return ok


def g6(r):
    out('G6 cancel while tracking')
    person('hide', 'person_b')
    person('place', 'person_a', 30, 3)
    r.prepare()
    sent = []

    def hook(gh, t):
        if not sent and r.m is not None and r.m.state_name == 'TRACKING' and len(r.errs) > 30:
            gh.cancel_goal_async()
            sent.append(1)
    return r.report('G6', r.mission(60, hook), 'CANCELLED')


def main():
    names = [a.upper() for a in sys.argv[1:]] or ['G1', 'G2', 'G3', 'G4', 'G5', 'G6']
    rclpy.init()
    r = Runner()
    r.spin(3)
    results = []
    for n in names:
        results.append((n, globals()[n.lower()](r)))
        out()
    person('place', 'person_a', 120, 3)
    out('GAZEBO SCENARIOS: ' + ('ALL PASSED' if all(ok for _, ok in results) else
                                'FAILED: ' + ' '.join(n for n, ok in results if not ok)))
    os.makedirs(OUT_DIR, exist_ok=True)
    with open(REPORT, 'a') as f:
        f.write(f'--- {time.strftime("%Y-%m-%d %H:%M")}\n' + '\n'.join(LINES) + '\n')
    print(f'report appended to {REPORT}')
    r.destroy_node()
    rclpy.try_shutdown()


if __name__ == '__main__':
    main()
