#!/usr/bin/env python3
"""Gazebo camera -> /camera/image_raw + /camera/camera_info, stamped with the ROS (wall) clock.

ros_gz_bridge publishes the Gazebo camera on /sim/camera/* with SIMULATION time stamps. The
drone stack runs on wall-clock time (like on the Pi, where v4l2_camera stamps frames when they
are captured), so a sim-time stamp would look minutes old and yolo_detector would drop every
frame. This relay re-stamps each frame on arrival and republishes it with the same QoS the real
camera uses. It is the only simulation-specific piece between Gazebo and the unchanged stack.
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CameraInfo, Image

from drone_perception.qos import IMAGE_QOS

FRAME = 'camera_optical_frame'


class Relay(Node):
    def __init__(self):
        super().__init__('sim_camera_relay')
        self.img = self.create_publisher(Image, '/camera/image_raw', IMAGE_QOS)
        self.info = self.create_publisher(CameraInfo, '/camera/camera_info', IMAGE_QOS)
        self.create_subscription(Image, '/sim/camera/image_raw', self._img, IMAGE_QOS)
        self.create_subscription(CameraInfo, '/sim/camera/camera_info', self._info, IMAGE_QOS)
        self.frames = 0
        self.create_timer(10.0, self._log)

    def _img(self, msg):
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = FRAME
        self.img.publish(msg)
        self.frames += 1

    def _info(self, msg):
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = FRAME
        self.info.publish(msg)

    def _log(self):
        self.get_logger().info(f'{self.frames / 10.0:.1f} frames/s relayed')
        self.frames = 0


def main():
    rclpy.init()
    node = Relay()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            node.destroy_node()
            rclpy.try_shutdown()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
