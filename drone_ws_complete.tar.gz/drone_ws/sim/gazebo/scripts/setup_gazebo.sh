#!/bin/bash
# One-time setup of the Gazebo simulation on an Ubuntu 24.04 PC with ROS 2 Jazzy (NOT the Pi:
# the Pi 5 is too slow for Gazebo's camera rendering).
#
#   bash setup_gazebo.sh
#
# Installs / builds:
#   1. Gazebo Harmonic + ros_gz (apt, the pair that goes with ROS 2 Jazzy)
#   2. ArduPilot SITL, Copter-4.6.3 (the same version as your Pixhawk), in ~/ardupilot
#   3. the ArduPilot Gazebo plugin, in ~/ardupilot_gazebo
# Takes 20 to 40 minutes, mostly the ArduPilot build. Safe to re-run: finished steps are skipped.

set -e
ARDUPILOT_DIR="${ARDUPILOT_DIR:-$HOME/ardupilot}"
AP_GZ_DIR="${AP_GZ_DIR:-$HOME/ardupilot_gazebo}"

echo "== 1. Gazebo Harmonic + ros_gz"
sudo apt-get update
sudo apt-get install -y ros-jazzy-ros-gz rapidjson-dev libopencv-dev \
  libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev gstreamer1.0-plugins-bad \
  gstreamer1.0-libav gstreamer1.0-gl git
gz sim --versions

echo "== 2. ArduPilot SITL (Copter-4.6.3)"
if [ ! -x "$ARDUPILOT_DIR/build/sitl/bin/arducopter" ]; then
  [ -d "$ARDUPILOT_DIR" ] || git clone https://github.com/ArduPilot/ardupilot.git "$ARDUPILOT_DIR"
  cd "$ARDUPILOT_DIR"
  git checkout Copter-4.6.3
  git submodule update --init --recursive
  Tools/environment_install/install-prereqs-ubuntu.sh -y
  # install-prereqs puts its tools in a venv and on PATH via ~/.profile
  . ~/.profile || true
  ./waf configure --board sitl
  ./waf copter
fi
"$ARDUPILOT_DIR/build/sitl/bin/arducopter" --help > /dev/null && echo "arducopter OK"

echo "== 3. ArduPilot Gazebo plugin"
if [ ! -f "$AP_GZ_DIR/build/libArduPilotPlugin.so" ]; then
  [ -d "$AP_GZ_DIR" ] || git clone https://github.com/ArduPilot/ardupilot_gazebo.git "$AP_GZ_DIR"
  mkdir -p "$AP_GZ_DIR/build"
  cd "$AP_GZ_DIR/build"
  GZ_VERSION=harmonic cmake .. -DCMAKE_BUILD_TYPE=RelWithDebInfo
  make -j"$(nproc)"
fi
ls "$AP_GZ_DIR/build/libArduPilotPlugin.so"

echo
echo "SETUP DONE. Next: docs/GAZEBO_SIM.md step 2."
