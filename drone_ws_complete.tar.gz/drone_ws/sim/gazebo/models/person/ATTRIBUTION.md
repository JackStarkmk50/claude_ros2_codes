# Person meshes

`standing.glb` and `walking.glb` are converted (COLLADA to glTF, textures dropped) from the
`person_standing` and `person_walking` models in https://github.com/osrf/gazebo_models,
created by Marina Kollmitz with MakeHuman.

License: Creative Commons Attribution 3.0 Unported (CC BY 3.0),
https://creativecommons.org/licenses/by/3.0/
