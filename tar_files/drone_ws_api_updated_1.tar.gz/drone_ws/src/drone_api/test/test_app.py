import numpy as np
import pytest
from fake_msgs import make

pytest.importorskip('fastapi', reason='fastapi missing: run tools/setup_venv.sh')
from fastapi.testclient import TestClient  # noqa: E402

from drone_api.app import Settings, create_app  # noqa: E402
from drone_api.core import convert, overlay  # noqa: E402
from drone_api.core.store import Store  # noqa: E402


class FakeBackend:
    def __init__(self):
        self.store = Store()
        self.calls = []
        self.viewers = 0
        rgb = np.zeros((480, 640, 3), np.uint8)
        self.jpg = overlay.encode(rgb, width=320)

    def system(self):
        return {'cpu_temp_c': 50.0}

    def camera_open(self):
        self.viewers += 1

    def camera_close(self):
        self.viewers -= 1

    def camera_jpeg(self, with_overlay=True):
        return 1, self.jpg

    def start_mission(self, goal):
        self.calls.append(('start', goal))
        return {'accepted': True}

    def cancel_mission(self):
        self.calls.append(('cancel',))
        return {'ok': True}

    def submit_command(self, text, execute, use_llm):
        self.calls.append(('command', text, execute))
        return {'understood': True, 'executed': execute}

    def preflight(self):
        self.calls.append(('preflight',))
        return {'ok': False, 'message': 'PF5'}

    def safety_reset(self):
        self.calls.append(('reset',))
        return {'ok': True}


def client(**kw):
    b = FakeBackend()
    return b, TestClient(create_app(b, Settings(**kw)))


def test_reads_open_without_token_and_sections_fill_in():
    b, c = client()
    assert c.get('/api/v1/health').json()['api'] == 'ok'
    s = c.get('/api/v1/status').json()
    assert s['vehicle'] is None and s['system'] == {'cpu_temp_c': 50.0}
    assert c.get('/api/v1/vehicle').status_code == 404
    b.store.update('vehicle', convert.vehicle(make('VehicleState', mode='LOITER', connected=True)))
    v = c.get('/api/v1/vehicle').json()
    assert v['mode'] == 'LOITER' and v['stale'] is False and 'msg_age_s' in v
    assert c.get('/api/v1/health').json()['fcu_connected'] is True
    ev = c.get('/api/v1/events').json()
    assert ev['events'][-1]['message'] == 'vehicle data received'
    assert c.get('/').status_code == 200 and 'Drone' in c.get('/').text
    assert c.get('/openapi.json').status_code == 200


def test_token_protects_reads():
    _, c = client(api_token='sec')
    assert c.get('/api/v1/status').status_code == 401
    assert c.get('/api/v1/status?token=sec').status_code == 200
    assert c.get('/api/v1/status', headers={'Authorization': 'Bearer sec'}).status_code == 200
    assert c.get('/api/v1/health').status_code == 200          # health stays open


def test_commands_off_by_default():
    b, c = client(api_token='sec')
    h = {'Authorization': 'Bearer sec'}
    assert c.post('/api/v1/mission/start', json={}, headers=h).status_code == 403
    assert c.post('/api/v1/safety/reset', headers=h).status_code == 403
    assert c.post('/api/v1/command', json={'text': 'go', 'execute': True}, headers=h).status_code == 403
    # allowed without allow_commands: dry-run text, cancel, preflight
    assert c.post('/api/v1/command', json={'text': 'go'}, headers=h).json()['executed'] is False
    assert c.post('/api/v1/mission/cancel', headers=h).json()['ok'] is True
    assert c.post('/api/v1/safety/preflight', headers=h).json()['message'] == 'PF5'
    assert ('start', ) not in [x[:1] for x in b.calls]
    assert c.get('/api/v1/config', headers=h).json()['commands_enabled'] is False


def test_no_token_means_no_cancel_or_commands():
    _, c = client(allow_commands=True)
    assert c.post('/api/v1/mission/cancel').status_code == 403
    assert c.post('/api/v1/mission/start', json={}).status_code == 403
    assert c.post('/api/v1/safety/preflight').status_code == 200


def test_commands_on_with_token():
    b, c = client(api_token='sec', allow_commands=True)
    r = c.post('/api/v1/mission/start?token=sec', json={'track_s': 15})
    assert r.json() == {'accepted': True}
    goal = b.calls[-1][1]
    assert goal['track_s'] == 15 and goal['land_on_finish'] is True and goal['approach'] is False
    assert c.post('/api/v1/mission/start?token=sec', json={'track_s': -1}).status_code == 422
    assert c.post('/api/v1/mission/start?token=sec', json={'altitude_m': 9}).status_code == 422
    assert c.get('/api/v1/config?token=sec').json()['commands_enabled'] is True


def test_websocket_pushes_status_and_events():
    b, c = client(api_token='sec')
    b.store.add_event('test', 'hello')
    with c.websocket_connect('/api/v1/ws?token=sec&rate_hz=20') as ws:
        got = [ws.receive_json() for _ in range(3)]
    types = [g['type'] for g in got]
    assert 'event' in types and 'status' in types
    assert any(g.get('message') == 'hello' for g in got)
    with pytest.raises(Exception):
        with c.websocket_connect('/api/v1/ws?token=wrong') as ws:
            ws.receive_json()


def test_camera_snapshot_and_viewer_count():
    b, c = client()
    r = c.get('/api/v1/camera.jpg')
    assert r.status_code == 200 and r.headers['content-type'] == 'image/jpeg'
    assert r.content[:2] == b'\xff\xd8' and b.viewers == 0
    _, c2 = client(camera_enabled=False)
    assert c2.get('/api/v1/camera.jpg').status_code == 403


def test_overlay_draws_and_resizes():
    rgb = np.zeros((480, 640, 3), np.uint8)
    target = convert.target(make('TrackedTarget', state=2, track_id=3, image_width=640,
                                 image_height=480, confidence=0.8))
    target['bbox_px'] = {'cx': 320, 'cy': 240, 'w': 100, 'h': 300}
    target['stale'] = False
    jpg = overlay.encode(rgb, width=320, target=target, mission={'state_name': 'TRACKING'},
                         vehicle={'mode': 'GUIDED', 'armed': True, 'battery': {'voltage_v': 15.9},
                                  'height': {'above_ground_m': 1.0}})
    import cv2
    img = cv2.imdecode(np.frombuffer(jpg, np.uint8), cv2.IMREAD_COLOR)
    assert img.shape == (240, 320, 3)
    assert img[:, :, 1].max() > 150          # green box drawn


class SleepyBackend(FakeBackend):
    """Like the ROS node: idle until touched, data arrives shortly after."""

    def __init__(self):
        super().__init__()
        self.touches = 0
        self.subscribed = False

    def touch(self):
        self.touches += 1
        was_idle = not self.subscribed
        if was_idle:
            self.subscribed = True
            self.store.update('vehicle', convert.vehicle(make('VehicleState', mode='LOITER')))
        return was_idle

    def ready(self):
        v = self.store.section('vehicle')
        return v is not None and not v['stale']


def test_requests_and_websocket_wake_the_backend():
    b = SleepyBackend()
    c = TestClient(create_app(b, Settings()))
    assert c.get('/api/v1/vehicle').json()['mode'] == 'LOITER'   # woken, data ready at once
    n = b.touches
    with c.websocket_connect('/api/v1/ws?rate_hz=20') as ws:
        for _ in range(4):
            ws.receive_json()
    assert b.touches >= n + 3                                    # an open WebSocket keeps touching
    t = b.touches
    c.get('/')                                                   # the page itself does not count
    assert b.touches == t
