"""drone_api node: subscribes to the stack's status topics and serves them over HTTP/WebSocket.

  ros2 run drone_api api_server --ros-args --params-file ~/drone_ws/src/drone_bringup/config/drone.yaml
  ros2 launch drone_api api.launch.py

It publishes nothing (no control commands) and never talks to MAVROS. The only things it can
trigger are the same ones tools/mission.py and tools/command.py use: the SearchAndTrack action (through
mission_manager -> safety_supervisor), its cancel, intent_bridge's SubmitCommand, and the safety
supervisor's preflight/reset services. Those are off unless drone_api allow_commands is true and
an api_token is set.

Runs as its own process: if it crashes or is stopped, the flight stack carries on.
"""

import os
import threading
import time

import rclpy
from action_msgs.srv import CancelGoal
from rclpy.action import ActionClient
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import ExternalShutdownException, SingleThreadedExecutor
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, HistoryPolicy, QoSProfile, ReliabilityPolicy
from rclpy.signals import SignalHandlerOptions
from sensor_msgs.msg import Image
from std_msgs.msg import String
from std_srvs.srv import Trigger

from drone_api.core import convert, overlay, system
from drone_api.core.store import Store
from drone_interfaces.action import SearchAndTrack
from drone_interfaces.msg import FlowStatus, MissionStatus, SafetyStatus, TrackedTarget, VehicleState
from drone_interfaces.srv import SubmitCommand
from drone_perception.core.image_convert import image_to_rgb

# Must be compatible with each publisher's QoS (a TRANSIENT_LOCAL subscriber gets nothing from a
# VOLATILE publisher).
VOLATILE = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                      durability=DurabilityPolicy.VOLATILE, history=HistoryPolicy.KEEP_LAST)
LATCHED = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                     durability=DurabilityPolicy.TRANSIENT_LOCAL, history=HistoryPolicy.KEEP_LAST)
IMAGE_QOS = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE)   # as drone_perception

OUTCOMES = ('COMPLETED', 'CANCELLED', 'TARGET_NOT_FOUND', 'TARGET_LOST', 'SAFETY_STOP',
            'MANUAL_OVERRIDE', 'PREFLIGHT_FAILED', 'TAKEOFF_FAILED', 'ERROR')

PARAMETERS = {
    'host': '0.0.0.0',
    'port': 8000,
    'api_token': '',                 # env DRONE_API_TOKEN overrides; empty = reads open, no commands
    'allow_commands': False,         # [SET] mission start / text execute / safety reset
    'cors_origins': ['*'],
    'ws_rate_hz': 5.0,
    'camera_enabled': True,
    'camera_topic': '/camera/image_raw',
    'camera_max_fps': 5.0,           # JPEG encodes per second, shared by all viewers
    'camera_width': 480,             # resize before JPEG (0 = full size); saves CPU and Wi-Fi
    'jpeg_quality': 70,
    'camera_idle_unsubscribe_s': 5.0,
    'system_poll_s': 2.0,
    'service_timeout_s': 5.0,
    'idle_unsubscribe_s': 30.0,      # no app/page for this long: stop listening to the busy topics
    'subscribe_when_idle': False,    # true = always listen (full event log while nobody watches;
                                     # costs about as much CPU as one more ROS node)
}

# Busy topics (10-20 Hz), only subscribed while a client uses the API. The mission status (5 Hz,
# latched) is always subscribed so mission events are logged even when nobody watches.
TELEMETRY = (
    # section, type, topic, qos, converter
    ('vehicle', VehicleState, '/drone/vehicle_state', VOLATILE, convert.vehicle),
    ('flow', FlowStatus, '/drone/flow_status', VOLATILE, convert.flow),
    ('safety', SafetyStatus, '/drone/safety_status', LATCHED, convert.safety),
    ('target', TrackedTarget, '/drone/perception/target', VOLATILE, convert.target),
    ('fcu_output', String, '/drone/fcu/output_state', VOLATILE, convert.text),
)


class ApiNode(Node):
    def __init__(self):
        super().__init__('drone_api')
        for k, v in PARAMETERS.items():
            self.declare_parameter(k, v)
        self.p = {k: self.get_parameter(k).value for k in PARAMETERS}
        env_token = os.environ.get('DRONE_API_TOKEN', '').strip()
        if env_token:
            self.p['api_token'] = env_token

        self.store = Store()
        self.cb = ReentrantCallbackGroup()
        self.create_subscription(
            MissionStatus, '/drone/mission/status',
            lambda m: self.store.update('mission', convert.mission(m)), LATCHED, callback_group=self.cb)

        # busy topics: subscribed on demand (see touch() / _activity_tick)
        self._act_lock = threading.Lock()
        self._last_touch = -1e9
        self._telemetry_subs = []
        if self.p['subscribe_when_idle']:
            self._subscribe_telemetry()
        self.create_timer(0.2, self._activity_tick, callback_group=self.cb)

        self.mission_client = ActionClient(self, SearchAndTrack, '/drone/mission/search_and_track',
                                           callback_group=self.cb)
        self.cancel_client = self.create_client(
            CancelGoal, '/drone/mission/search_and_track/_action/cancel_goal', callback_group=self.cb)
        self.command_client = self.create_client(SubmitCommand, '/drone/llm/submit_command',
                                                 callback_group=self.cb)
        self.preflight_client = self.create_client(Trigger, '/drone/safety/preflight_check',
                                                   callback_group=self.cb)
        self.reset_client = self.create_client(Trigger, '/drone/safety/reset', callback_group=self.cb)

        # camera: subscribed only while someone watches
        self._cam_lock = threading.Lock()
        self._encode_lock = threading.Lock()
        self._viewers = 0
        self._last_viewer_t = 0.0
        self._cam_sub = None
        self._frame = None            # (seq, msg)
        self._frame_seq = 0
        self._jpeg_cache = {}         # overlay flag -> (seq, jpeg, monotonic time)
        self.create_timer(0.5, self._camera_tick, callback_group=self.cb)

        self._cpu = system.CpuUsage()
        self._poll_system()
        self.create_timer(float(self.p['system_poll_s']), self._poll_system, callback_group=self.cb)
        self.create_timer(1.0, self.store.check_stale, callback_group=self.cb)

        self.store.add_event('api', 'drone_api started', 'info')
        self.get_logger().info(
            f"up: http://{self.p['host']}:{self.p['port']}/  (docs at /docs), token "
            f"{'set' if self.p['api_token'] else 'NOT set: reads open, commands refused'}, "
            f"commands {'ALLOWED' if self.p['allow_commands'] and self.p['api_token'] else 'off'}, "
            f"camera {'on' if self.p['camera_enabled'] else 'off'}")
        if self.p['allow_commands'] and not self.p['api_token']:
            self.get_logger().warn('allow_commands is true but no api_token is set: commands stay '
                                   'refused. Set DRONE_API_TOKEN or drone_api api_token.')

    # ---- on-demand telemetry -----------------------------------------------------------------
    def touch(self):
        """Called by the web side on every API request and WebSocket push. Returns True if the
        busy topics were not subscribed (the caller then waits for ready())."""
        with self._act_lock:
            self._last_touch = time.monotonic()
            return not self._telemetry_subs

    def ready(self):
        v = self.store.section('vehicle')
        return v is not None and not v['stale']

    def _subscribe_telemetry(self):
        for section, typ, topic, qos, conv in TELEMETRY:
            self._telemetry_subs.append(self.create_subscription(
                typ, topic, lambda m, s=section, c=conv: self.store.update(s, c(m)), qos,
                callback_group=self.cb))

    def _activity_tick(self):
        with self._act_lock:
            want = (self.p['subscribe_when_idle'] or
                    time.monotonic() - self._last_touch < float(self.p['idle_unsubscribe_s']))
            active = bool(self._telemetry_subs)
        if want and not active:
            with self._act_lock:
                self._subscribe_telemetry()
            self.get_logger().info('client connected: listening to the drone topics')
        elif not want and active:
            with self._act_lock:
                subs, self._telemetry_subs = self._telemetry_subs, []
            for sub in subs:
                self.destroy_subscription(sub)
            self.store.pause([t[0] for t in TELEMETRY])
            self.get_logger().info(f"no client for {self.p['idle_unsubscribe_s']:.0f} s: stopped "
                                   'listening to the busy topics (mission status still logged)')

    # ---- system ------------------------------------------------------------------------------
    def _poll_system(self):
        try:
            self.store.update('system', system.collect(self._cpu))
        except Exception as e:   # never let a /proc oddity kill the node
            self.get_logger().warn(f'system stats failed: {e}', throttle_duration_sec=60.0)

    def system(self):
        return self.store.section('system') or {}

    # ---- camera ------------------------------------------------------------------------------
    def camera_open(self):
        with self._cam_lock:
            self._viewers += 1

    def camera_close(self):
        with self._cam_lock:
            self._viewers = max(0, self._viewers - 1)
            self._last_viewer_t = time.monotonic()

    def _camera_tick(self):
        with self._cam_lock:
            want = self.p['camera_enabled'] and (
                self._viewers > 0 or
                time.monotonic() - self._last_viewer_t < self.p['camera_idle_unsubscribe_s'])
        if want and self._cam_sub is None:
            self._cam_sub = self.create_subscription(Image, self.p['camera_topic'], self._on_image,
                                                     IMAGE_QOS, callback_group=self.cb)
            self.get_logger().info(f"camera viewer connected: subscribed to {self.p['camera_topic']}")
        elif not want and self._cam_sub is not None:
            self.destroy_subscription(self._cam_sub)
            self._cam_sub = None
            with self._cam_lock:
                self._frame = None
                self._jpeg_cache.clear()
            self.get_logger().info('no camera viewers: unsubscribed')

    def _on_image(self, msg):
        with self._cam_lock:
            self._frame_seq += 1
            self._frame = (self._frame_seq, msg)

    def camera_jpeg(self, with_overlay=True):
        with self._cam_lock:
            frame = self._frame
            cached = self._jpeg_cache.get(with_overlay)
        if frame is None:
            return None, None
        seq, msg = frame
        now = time.monotonic()
        min_gap = 1.0 / max(0.5, float(self.p['camera_max_fps']))
        if cached and (cached[0] == seq or now - cached[2] < min_gap):
            return cached[0], cached[1]
        with self._encode_lock:
            try:
                rgb = image_to_rgb(msg.encoding, msg.width, msg.height, msg.step, msg.data)
                jpg = overlay.encode(rgb, self.p['jpeg_quality'], self.p['camera_width'],
                                     target=self.store.section('target'),
                                     mission=self.store.section('mission'),
                                     vehicle=self.store.section('vehicle'),
                                     overlay=with_overlay)
            except ValueError as e:
                self.get_logger().warn(f'camera frame not usable: {e}', throttle_duration_sec=10.0)
                return None, None
        with self._cam_lock:
            self._jpeg_cache[with_overlay] = (seq, jpg, now)
        return seq, jpg

    # ---- actions -----------------------------------------------------------------------------
    def _wait(self, future, timeout):
        done = threading.Event()
        future.add_done_callback(lambda _f: done.set())
        if not done.wait(timeout):
            return None
        return future.result()

    def _call(self, client, request, what):
        if not client.wait_for_service(timeout_sec=1.0):
            return None, f'{what} not available (is that node running?)'
        res = self._wait(client.call_async(request), float(self.p['service_timeout_s']))
        if res is None:
            return None, f'{what}: no answer within {self.p["service_timeout_s"]} s'
        return res, ''

    def preflight(self):
        res, err = self._call(self.preflight_client, Trigger.Request(), 'safety_supervisor')
        if res is None:
            return {'ok': False, 'available': False, 'message': err}
        return {'ok': bool(res.success), 'available': True, 'message': res.message}

    def safety_reset(self):
        res, err = self._call(self.reset_client, Trigger.Request(), 'safety_supervisor')
        if res is None:
            return {'ok': False, 'available': False, 'message': err}
        self.store.add_event('api', f'safety reset requested: {res.message}', 'info')
        return {'ok': bool(res.success), 'available': True, 'message': res.message}

    def submit_command(self, text, execute, use_llm):
        req = SubmitCommand.Request(text=text, execute=bool(execute), use_llm=bool(use_llm))
        res, err = self._call(self.command_client, req, 'intent_bridge')
        if res is None:
            return {'understood': False, 'executed': False, 'available': False, 'message': err}
        if execute:
            self.store.add_event('api', f'text command "{text}": {res.message}', 'info')
        return {'understood': bool(res.understood), 'executed': bool(res.executed),
                'available': True, 'intent_json': res.intent_json, 'message': res.message}

    def cancel_mission(self):
        res, err = self._call(self.cancel_client, CancelGoal.Request(), 'mission_manager')
        if res is None:
            return {'ok': False, 'available': False, 'message': err}
        n = len(res.goals_canceling)
        ok = res.return_code == CancelGoal.Response.ERROR_NONE and n > 0
        msg = f'cancelling {n} mission(s): the drone lands' if ok else 'no running mission'
        self.store.add_event('api', f'cancel requested: {msg}', 'warning' if ok else 'info')
        return {'ok': ok, 'available': True, 'message': msg}

    def start_mission(self, g):
        if not self.mission_client.wait_for_server(timeout_sec=1.0):
            return {'accepted': False, 'available': False,
                    'message': 'mission_manager not available (is the stack running?)'}
        goal = SearchAndTrack.Goal(
            target_class='person', autonomous_takeoff=bool(g['autonomous_takeoff']),
            takeoff_altitude_m=float(g['altitude_m']), search_timeout_s=float(g['search_s']),
            track_duration_s=float(g['track_s']), land_on_finish=bool(g['land_on_finish']),
            approach=bool(g['approach']), approach_distance_m=float(g['approach_distance_m']))
        handle = self._wait(self.mission_client.send_goal_async(goal),
                            float(self.p['service_timeout_s']))
        if handle is None:
            return {'accepted': False, 'available': True, 'message': 'mission_manager did not answer'}
        if not handle.accepted:
            mission = self.store.section('mission') or {}
            detail = mission.get('detail') or 'see the mission_manager log for the reason'
            self.store.add_event('api', f'mission refused: {detail}', 'warning')
            return {'accepted': False, 'available': True, 'message': f'refused: {detail}'}
        self.store.add_event('api', f'mission started (track {g["track_s"]:.0f} s)', 'info')
        handle.get_result_async().add_done_callback(self._on_mission_result)
        return {'accepted': True, 'available': True,
                'message': 'mission started: follow it on /api/v1/mission or the WebSocket'}

    def _on_mission_result(self, future):
        try:
            r = future.result().result
            outcome = convert.name(OUTCOMES, r.outcome)
            sev = 'info' if outcome in ('COMPLETED', 'CANCELLED') else 'warning'
            self.store.add_event('mission', f'result {outcome}: {r.message}', sev)
        except Exception as e:
            self.store.add_event('mission', f'result unknown: {e}', 'warning')


def main(args=None):
    import uvicorn

    from drone_api.app import Settings, create_app

    rclpy.init(args=args, signal_handler_options=SignalHandlerOptions.NO)
    node = ApiNode()
    executor = SingleThreadedExecutor()   # far lighter than the multi-threaded one in Python
    executor.add_node(node)
    spin = threading.Thread(target=executor.spin, daemon=True)
    spin.start()
    settings = Settings(api_token=node.p['api_token'], allow_commands=node.p['allow_commands'],
                        camera_enabled=node.p['camera_enabled'],
                        camera_max_fps=node.p['camera_max_fps'], ws_rate_hz=node.p['ws_rate_hz'],
                        cors_origins=list(node.p['cors_origins']))
    app = create_app(node, settings)
    try:
        uvicorn.run(app, host=node.p['host'], port=int(node.p['port']), log_level='warning')
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        executor.shutdown()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
