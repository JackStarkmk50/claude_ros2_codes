from drone_api.core import auth, system
from drone_api.core.store import Store


class Clock:
    def __init__(self):
        self.t = 100.0

    def __call__(self):
        return self.t


def msgs(store):
    return [e['message'] for e in store.events()]


def test_events_on_changes_only():
    c = Clock()
    s = Store(clock=c)
    s.update('vehicle', {'mode': 'STABILIZE', 'armed': False, 'connected': True})
    s.update('vehicle', {'mode': 'STABILIZE', 'armed': False, 'connected': True})
    s.update('vehicle', {'mode': 'GUIDED', 'armed': True, 'connected': True})
    m = msgs(s)
    assert m == ['vehicle data received', 'armed: yes', 'mode: STABILIZE -> GUIDED']


def test_safety_faults_and_levels():
    s = Store(clock=Clock())
    s.update('safety', {'level_name': 'OK', 'active_faults': []})
    s.update('safety', {'level_name': 'HOLD', 'active_faults': ['COMMAND_STALE']})
    ev = s.events()
    assert ev[-2]['message'] == 'safety level: OK -> HOLD' and ev[-2]['severity'] == 'warning'
    assert ev[-1]['message'] == 'fault: COMMAND_STALE' and ev[-1]['severity'] == 'error'


def test_prearm_text_reported_once_not_on_expiry():
    s = Store(clock=Clock())
    s.update('vehicle', {'last_prearm_text': ''})
    s.update('vehicle', {'last_prearm_text': 'PreArm: Check mag field'})
    s.update('vehicle', {'last_prearm_text': ''})
    assert msgs(s)[1:] == ['FCU says: PreArm: Check mag field']


def test_age_stale_and_recovery_event():
    c = Clock()
    s = Store(clock=c)
    s.update('vehicle', {'mode': 'X'})
    c.t += 0.5
    assert s.section('vehicle')['stale'] is False and s.section('vehicle')['msg_age_s'] == 0.5
    c.t += 1.0
    s.check_stale()
    s.check_stale()                                   # reported once
    assert s.section('vehicle')['stale'] is True
    assert sum('stopped arriving' in m for m in msgs(s)) == 1
    s.update('vehicle', {'mode': 'X'})
    assert 'vehicle data arriving again' in msgs(s)
    assert s.section('nothing') is None


def test_events_since_and_limit():
    s = Store(clock=Clock())
    for i in range(10):
        s.add_event('t', f'e{i}')
    assert [e['message'] for e in s.events(since=7)] == ['e7', 'e8', 'e9']
    assert len(s.events(limit=4)) == 4 and s.last_event_id() == 10


def test_auth_rules():
    R, C, A = auth.READ, auth.CANCEL, auth.ACT
    # no token configured: reads open, nothing else
    assert auth.check(R, '', '', False)[0]
    assert auth.check(C, '', '', True)[1] == 403
    assert auth.check(A, '', 'x', True)[1] == 403
    # token configured
    assert auth.check(R, 'sec', '', False)[1] == 401
    assert auth.check(R, 'sec', 'sec', False)[0]
    assert auth.check(C, 'sec', 'sec', False)[0]          # cancel without allow_commands
    assert auth.check(A, 'sec', 'sec', False)[1] == 403   # act needs allow_commands
    assert auth.check(A, 'sec', 'sec', True)[0]
    assert auth.check(A, 'sec', 'bad', True)[1] == 401
    assert auth.token_from('Bearer abc', 'zzz') == 'abc'
    assert auth.token_from(None, ' q ') == 'q'


def test_throttled_decoding():
    assert system.parse_throttled('throttled=0x50000\n') == 0x50000
    assert system.parse_throttled('garbage') is None
    d = system.decode_throttled(0x50000)
    assert d['under_voltage_since_boot'] and d['throttled_since_boot'] and d['ok_now']
    assert not d['under_voltage_now']
    d = system.decode_throttled(0x1)
    assert d['under_voltage_now'] and not d['ok_now']


def test_collect_runs_here():
    d = system.collect(system.CpuUsage(), with_throttled=False)
    assert 'cpu_temp_c' in d and 'memory' in d and d['throttled'] is None
