"""The web API (FastAPI). No ROS imports: it talks to a "backend" object, which is the ROS node on
the drone and a fake in the tests.

Backend methods (all thread-safe, the action ones may block up to a few seconds):
  store                         core.store.Store
  system()                      -> dict
  camera_open() / camera_close()  count stream viewers (the node subscribes to the camera only
                                  while someone watches)
  camera_jpeg(overlay)          -> (frame_id, jpeg bytes) or (None, None)
  start_mission(goal: dict)     -> dict
  cancel_mission()              -> dict
  submit_command(text, execute, use_llm) -> dict
  preflight()                   -> dict
  safety_reset()                -> dict

Interactive docs: http://<pi>:<port>/docs
"""

import asyncio
import os
import time
from typing import Optional

from fastapi import FastAPI, HTTPException, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.concurrency import run_in_threadpool
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response, StreamingResponse
from pydantic import BaseModel, Field

from drone_api.core import auth

API_VERSION = '1.0'
SECTIONS = ('vehicle', 'flow', 'safety', 'mission', 'target', 'fcu_output')
WEB_DIR = os.path.join(os.path.dirname(__file__), 'web')


class Settings(BaseModel):
    api_token: str = ''
    allow_commands: bool = False
    camera_enabled: bool = True
    camera_max_fps: float = 5.0
    ws_rate_hz: float = 5.0
    cors_origins: list = ['*']


class MissionStart(BaseModel):
    track_s: float = Field(60.0, ge=0, le=600, description='how long to track; 0 = until cancelled')
    search_s: float = Field(0.0, ge=0, le=600, description='0 = config default')
    altitude_m: float = Field(0.0, ge=0, le=3, description='0 = config default; safety clamps it')
    land_on_finish: bool = True
    autonomous_takeoff: bool = Field(True, description='false = start while already hovering in GUIDED')
    approach: bool = Field(False, description='fly closer; refused unless enabled in drone.yaml')
    approach_distance_m: float = Field(0.0, ge=0, le=10)


class TextCommand(BaseModel):
    text: str = Field(..., min_length=1, max_length=500)
    execute: bool = Field(False, description='false = only show what it would do')
    use_llm: bool = False


def create_app(backend, settings: Settings):
    app = FastAPI(title='Drone API', version=API_VERSION,
                  description='Telemetry and mission control for the indoor drone. Reads are '
                              'always safe. Anything that moves the drone goes through the '
                              'mission manager and the safety supervisor, never around them.')
    app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_methods=['*'],
                       allow_headers=['*'])
    store = backend.store

    def guard(kind, request_auth, query_token):
        given = auth.token_from(request_auth, query_token)
        ok, code, reason = auth.check(kind, settings.api_token, given, settings.allow_commands)
        if not ok:
            raise HTTPException(status_code=code, detail=reason)

    def read_guard(request: Request, token: Optional[str]):
        guard(auth.READ, request.headers.get('authorization'), token)

    def section_or_404(name):
        s = store.section(name)
        if s is None:
            raise HTTPException(404, f'no {name} data received yet')
        return s

    def status_doc():
        doc = {'server_time': round(time.time(), 3), 'api_version': API_VERSION}
        doc.update(store.snapshot(SECTIONS))
        doc['system'] = backend.system()
        doc['last_event_id'] = store.last_event_id()
        return doc

    # ---- pages -------------------------------------------------------------------------------
    @app.get('/', include_in_schema=False)
    def index():
        return FileResponse(os.path.join(WEB_DIR, 'index.html'))

    @app.get('/favicon.ico', include_in_schema=False)
    def favicon():
        return Response(status_code=204)

    # ---- reads -------------------------------------------------------------------------------
    @app.get('/api/v1/health', tags=['read'])
    def health():
        """Is the API up, and is data arriving from each part of the stack? No token needed."""
        topics = store.health()
        vehicle = store.section('vehicle')
        return {
            'api': 'ok',
            'api_version': API_VERSION,
            'fcu_connected': bool(vehicle and vehicle.get('connected') and not vehicle['stale']),
            'topics': topics,
            'server_time': round(time.time(), 3),
        }

    @app.get('/api/v1/config', tags=['read'])
    def config(request: Request, token: Optional[str] = None):
        """What this API allows (so an app can grey out buttons)."""
        read_guard(request, token)
        return {
            'api_version': API_VERSION,
            'commands_enabled': settings.allow_commands and bool(settings.api_token),
            'token_required_for_reads': bool(settings.api_token),
            'camera_enabled': settings.camera_enabled,
            'camera_max_fps': settings.camera_max_fps,
            'ws_rate_hz': settings.ws_rate_hz,
        }

    @app.get('/api/v1/status', tags=['read'])
    def status(request: Request, token: Optional[str] = None):
        """Everything at once: vehicle, flow, safety, mission, target, command output, Pi system.
        Each section carries msg_age_s and stale; a section is null until it first arrives."""
        read_guard(request, token)
        return status_doc()

    for _name in SECTIONS:
        def _make(name):
            def handler(request: Request, token: Optional[str] = None):
                read_guard(request, token)
                return section_or_404(name)
            handler.__name__ = f'get_{name}'
            handler.__doc__ = f'Latest {name} data (404 until the first message arrives).'
            return handler
        app.get(f'/api/v1/{_name}', tags=['read'])(_make(_name))

    @app.get('/api/v1/system', tags=['read'])
    def system(request: Request, token: Optional[str] = None):
        """Pi health: CPU temperature and load, memory, disk, undervoltage/throttling flags."""
        read_guard(request, token)
        return backend.system()

    @app.get('/api/v1/events', tags=['read'])
    def events(request: Request, since: int = 0, limit: int = Query(100, ge=1, le=300),
               token: Optional[str] = None):
        """Event log (mode changes, arming, safety level, mission state, faults...).
        Poll with since=<last id you have> to get only new ones."""
        read_guard(request, token)
        return {'events': store.events(since, limit), 'last_event_id': store.last_event_id()}

    # ---- live --------------------------------------------------------------------------------
    @app.websocket('/api/v1/ws')
    async def ws(websocket: WebSocket, token: Optional[str] = None,
                 rate_hz: Optional[float] = None):
        """Pushes {"type":"status",...} at ws_rate_hz and {"type":"event",...} for each new event."""
        given = auth.token_from(websocket.headers.get('authorization'), token)
        ok, _, reason = auth.check(auth.READ, settings.api_token, given, settings.allow_commands)
        if not ok:
            await websocket.close(code=4401, reason=reason)
            return
        await websocket.accept()
        period = 1.0 / max(0.5, min(rate_hz or settings.ws_rate_hz, 20.0))
        last_event = max(0, store.last_event_id() - 20)   # send the last 20 events on connect
        try:
            while True:
                for e in store.events(last_event, 0):
                    await websocket.send_json({'type': 'event', **e})
                    last_event = e['id']
                await websocket.send_json({'type': 'status', **status_doc()})
                await asyncio.sleep(period)
        except (WebSocketDisconnect, RuntimeError):
            return

    @app.get('/api/v1/camera.jpg', tags=['camera'])
    async def camera_jpg(request: Request, overlay: bool = True, token: Optional[str] = None):
        """One JPEG from the drone camera (with the tracked person boxed if overlay=true)."""
        read_guard(request, token)
        if not settings.camera_enabled:
            raise HTTPException(403, 'camera is switched off (drone_api camera_enabled: false)')
        backend.camera_open()
        try:
            for _ in range(30):                     # up to 3 s for the first frame after subscribing
                fid, jpg = await run_in_threadpool(backend.camera_jpeg, overlay)
                if jpg:
                    return Response(jpg, media_type='image/jpeg',
                                    headers={'Cache-Control': 'no-store'})
                await asyncio.sleep(0.1)
        finally:
            backend.camera_close()
        raise HTTPException(503, 'no camera frames: is the camera running?')

    @app.get('/api/v1/camera.mjpg', tags=['camera'])
    async def camera_mjpg(request: Request, overlay: bool = True,
                          fps: float = Query(5.0, gt=0, le=30), token: Optional[str] = None):
        """Live MJPEG stream (open in a browser or an <img> tag). fps is capped by camera_max_fps."""
        read_guard(request, token)
        if not settings.camera_enabled:
            raise HTTPException(403, 'camera is switched off (drone_api camera_enabled: false)')
        period = 1.0 / min(fps, settings.camera_max_fps)

        async def frames():
            backend.camera_open()
            last = None
            try:
                while not await request.is_disconnected():
                    t0 = time.monotonic()
                    fid, jpg = await run_in_threadpool(backend.camera_jpeg, overlay)
                    if jpg and fid != last:
                        last = fid
                        yield (b'--frame\r\nContent-Type: image/jpeg\r\nContent-Length: '
                               + str(len(jpg)).encode() + b'\r\n\r\n' + jpg + b'\r\n')
                    await asyncio.sleep(max(0.02, period - (time.monotonic() - t0)))
            finally:
                backend.camera_close()

        return StreamingResponse(frames(), media_type='multipart/x-mixed-replace; boundary=frame',
                                 headers={'Cache-Control': 'no-store'})

    # ---- actions -----------------------------------------------------------------------------
    def act_guard(kind, request: Request, token: Optional[str]):
        guard(kind, request.headers.get('authorization'), token)

    @app.post('/api/v1/safety/preflight', tags=['actions'])
    def preflight(request: Request, token: Optional[str] = None):
        """Run the pre-flight check now (changes nothing). Same access as reads."""
        act_guard(auth.READ, request, token)
        return backend.preflight()

    @app.post('/api/v1/mission/start', tags=['actions'])
    def mission_start(body: MissionStart, request: Request, token: Optional[str] = None):
        """[AIRCRAFT] Start a search-and-track mission through mission_manager (same as
        tools/mission.py start). Needs the token and allow_commands. The stack must also run with
        enable_fcu_output:=true allow_arming:=true, and every safety check still applies."""
        act_guard(auth.ACT, request, token)
        return backend.start_mission(body.model_dump())

    @app.post('/api/v1/mission/cancel', tags=['actions'])
    def mission_cancel(request: Request, token: Optional[str] = None):
        """Cancel the running mission: the drone LANDS. Needs the token (not allow_commands,
        because cancelling only ever makes things safer)."""
        act_guard(auth.CANCEL, request, token)
        return backend.cancel_mission()

    @app.post('/api/v1/command', tags=['actions'])
    def command(body: TextCommand, request: Request, token: Optional[str] = None):
        """Text command through intent_bridge ("look for a person and track them for 30 s").
        execute=false only shows what it would do (needs the token); execute=true also needs
        allow_commands, and intent_bridge's own allow_execute still applies."""
        act_guard(auth.ACT if body.execute else auth.CANCEL, request, token)
        return backend.submit_command(body.text, body.execute, body.use_llm)

    @app.post('/api/v1/safety/reset', tags=['actions'])
    def safety_reset(request: Request, token: Optional[str] = None):
        """Clear a latched safety fault (only works on the ground, disarmed)."""
        act_guard(auth.ACT, request, token)
        return backend.safety_reset()

    return app
