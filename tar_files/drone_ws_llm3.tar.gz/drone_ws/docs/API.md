# Web API: drone data for a dashboard or a phone app

**Goal:** everything the stack knows (FCU link, mode, armed, battery, height, EKF, optical flow,
safety level, pre-flight, mission state, tracked person, Pi temperature/CPU/undervoltage, camera)
available over HTTP and a WebSocket, so a dashboard or mobile app can show it live. Optionally,
start and cancel missions from the app.

**Safety:** the API is a separate node (`drone_api`). It **publishes nothing** and never talks to
MAVROS (a test enforces this). Starting a mission goes through exactly the same path as
`tools/mission.py`: mission_manager → safety_supervisor → fcu_command_node, with every check. Out of
the box it is **read-only**: commands need a token **and** `allow_commands: true`. If the API
crashes or you stop it, the flight stack does not notice.

---

## What is new

| File | What it does |
|---|---|
| `src/drone_api/drone_api/api_node.py` | ROS node + web server (FastAPI/uvicorn) on port 8000 |
| `src/drone_api/drone_api/app.py` | all endpoints (no ROS inside, tested on its own) |
| `src/drone_api/drone_api/core/` | message → JSON, latest-value store + event log, Pi health, access rules, camera overlay |
| `src/drone_api/drone_api/web/index.html` | a built-in status page at `http://<pi>:8000/` (works on a phone) |
| `src/drone_api/drone_api/demo.py` | the same API with a **simulated drone**, for building the app on a laptop |
| `src/drone_api/launch/api.launch.py` | starts it with your drone.yaml |
| `drone.yaml` → `drone_api:` | port, token, `allow_commands`, camera limits |
| `tools/setup_venv.sh` | now also installs `fastapi uvicorn websockets` |

**Tested here:** 20 drone_api tests (converters checked against the real `.msg` files, access rules,
event log, every endpoint, WebSocket, camera) + the drone_bringup config/architecture tests. The
web server ran for real (uvicorn) with the simulated drone: all endpoints, the WebSocket, 5 fps
MJPEG, and the status page in Chromium at desktop and phone width. The ROS node's logic ran against
stand-in ROS modules (subscriptions, camera subscribe/unsubscribe, every service and action call).
**Not run here: the node inside real ROS 2** (no ROS packages reachable from my side). Step 2 below
is that test.

---

## Step 1: install and build (Pi)

**COMMAND**

```bash
cp ~/drone_ws/src/drone_bringup/config/drone.yaml ~/drone.yaml.mine
tar -xzf drone_ws_api.tar.gz -C ~/drone_ws --strip-components=1
python3 ~/drone_ws/tools/carry_settings.py ~/drone.yaml.mine
bash ~/drone_ws/tools/setup_venv.sh
bash ~/drone_ws/tools/verify_workspace.sh
```

**EXPECTED** `venv ok, numpy 1.26.4 fastapi 0.x`, then `PASS fastapi/uvicorn/websockets importable`,
`drone packages (9)` (now including drone_api and drone_slam, so the two drone_slam WARN lines are
gone), `0 errors, 0 failures, 0 skipped`, `WORKSPACE CHECK: ALL PASSED`.

**IF NOT**
- `numpy` changed to 2.x: `~/drone_venv/bin/pip install "numpy==1.26.4"`, then repeat.
- test failures: send me the output of `colcon test-result --verbose | tail -40`.

## Step 2: read-only, with the stack running (Pi, props off)

**Terminal A** (the stack, bench mode as usual):

```bash
source ~/drone_ws/env.sh
ros2 launch drone_bringup bringup.launch.py
```

**Terminal B** (the API):

```bash
source ~/drone_ws/env.sh
ros2 launch drone_api api.launch.py
```

**EXPECTED** `drone_api ... up: http://0.0.0.0:8000/ (docs at /docs), token NOT set: reads open,
commands refused, commands off, camera on`.

**Terminal C** (or your laptop with the Tailscale IP):

```bash
curl -s http://localhost:8000/api/v1/health | python3 -m json.tool
```

**EXPECTED** `"fcu_connected": true` and under `topics` the entries `vehicle`, `flow`, `safety`,
`mission`, `target`, `system` with `"stale": false`.

Then open **`http://100.87.20.36:8000/`** (your Pi's Tailscale IP) in the laptop or phone
browser. EXPECTED: the status page with `live`, `FCU linked`, the mode, `disarmed`, `safety ...`,
height about 0.14 m, the battery voltage, the Pi temperature. Flip the RC mode switch: the mode pill
and the event log change within a second. Press **Show camera**: the camera with the tracked person
boxed (start the stack with perception on).

**IF NOT**
- page does not load from the phone/laptop but `curl localhost` works: use the Tailscale IP
  (`100.x.x.x`), not the hotspot IP, as with camera_view.py.
- `"vehicle"` missing in `topics`: the API and the stack do not see each other. Run
  `ros2 topic hz /drone/vehicle_state` in terminal C; send me terminal B.
- status page says `reconnecting...`: the WebSocket library is missing, `bash tools/setup_venv.sh`.

## Step 3 (only when you want app control): token and commands

1. Make a token (a long random string) and keep it out of drone.yaml and out of the workspace
   (an update overwrites `env.sh`, but never `~/.drone_secrets`, which `env.sh` reads):

   ```bash
   echo "export DRONE_API_TOKEN=$(python3 -c 'import secrets; print(secrets.token_urlsafe(24))')" >> ~/.drone_secrets
   chmod 600 ~/.drone_secrets
   source ~/drone_ws/env.sh && echo $DRONE_API_TOKEN
   ```

   Run that once. To see the token again later: `cat ~/.drone_secrets`. To make a new one, delete
   the file and run it again (then open the page with the new token).

   With a token set, **every read needs it too** (except `/api/v1/health`). Open the page as
   `http://100.87.20.36:8000/?token=<token>` (it remembers it).
2. Cancel and "check command" (dry-run) now work. To also allow mission start, text execute and
   safety reset: `allow_commands: true` in drone.yaml (`drone_api` section) and restart the API.
   The stack itself must still run with `enable_fcu_output:=true allow_arming:=true`, and
   intent_bridge's own `allow_execute` still decides for text commands.
3. Props-off check, same as Phase 12 step 4: press **Start mission** (track 15 s). EXPECTED:
   motors spin up, then `TAKEOFF_FAILED ... landed and disarmed` in the event log as
   `result TAKEOFF_FAILED: ...`. Then **Cancel** during a second run: it lands and disarms.

---

## Endpoints (all under `/api/v1`)

Interactive list with a "Try it out" button: `http://<pi>:8000/docs` (that page loads its
script from the internet; the API works without internet). Machine-readable: `/openapi.json`.

| Method | Path | What | Access |
|---|---|---|---|
| GET | `/health` | API up, FCU connected, per-topic age and message count | always open |
| GET | `/config` | what is allowed (commands, camera, token needed) so the app can grey out buttons | read |
| GET | `/status` | everything below in one document | read |
| GET | `/vehicle` | link, mode, armed, landed state, battery, attitude + compass heading, velocity, height, EKF | read |
| GET | `/flow` | optical flow quality, freshness, height band, healthy for flight/takeoff, reason | read |
| GET | `/safety` | level OK/DEGRADED/HOLD/ABORT/OVERRIDE, latched, pre-flight result + failures, faults | read |
| GET | `/mission` | mission state, elapsed, search angle, track id, detail | read |
| GET | `/target` | tracked person: state, id, confidence, box in pixels, left/right offset, last side | read |
| GET | `/fcu_output` | what the command node is doing (`SILENT: disarmed`, `SENDING ...`) | read |
| GET | `/system` | Pi CPU %, temperature, load, memory, disk, uptime, undervoltage/throttling | read |
| GET | `/events?since=<id>&limit=100` | event log (mode/armed/safety/mission changes, faults, undervoltage, data stopped) | read |
| WS | `/ws?token=&rate_hz=5` | live: `{"type":"status",...}` at 5 Hz + `{"type":"event",...}` per event | read |
| GET | `/camera.jpg?overlay=true` | one JPEG | read |
| GET | `/camera.mjpg?overlay=true&fps=5` | live MJPEG (an `<img src>` shows it) | read |
| POST | `/safety/preflight` | run the pre-flight check (changes nothing) | read |
| POST | `/mission/cancel` | cancel the mission: **the drone lands** | token |
| POST | `/command` `{"text": "...", "execute": false, "use_llm": true}` | text command or question via intent_bridge; `execute:false` = only show the plan (or answer a question in words); to confirm a plan, send its `intent_json` back with `execute:true`. See `docs/LOCAL_LLM.md` | token (execute: token + commands) |
| POST | `/mission/start` `{"track_s": 15, ...}` | [AIRCRAFT] start search-and-track | token + commands |
| POST | `/safety/reset` | clear a latched fault (on the ground, disarmed only) | token + commands |

Token: header `Authorization: Bearer <token>` or `?token=<token>` (images and the WebSocket need
the query form in a browser). Wrong token: 401. Not allowed: 403 with the reason.

`/mission/start` body (all optional): `track_s` (0-600, default 60; 0 = until cancelled),
`search_s` (0 = default), `altitude_m` (0 = default, safety clamps to 0.8-1.5), `land_on_finish`
(true), `autonomous_takeoff` (true), `approach` (false; refused unless enabled in drone.yaml),
`approach_distance_m`.

**Every data section** carries `msg_age_s` (seconds since it arrived) and `stale` (it stopped
arriving: vehicle/flow 1 s, target 1.5 s, safety/mission 2 s). A section is `null` until its
first message. An app should show stale data as stale, not as current. NaN values are `null`.

Example `vehicle` (from the simulated drone; the real one has the same shape):

```json
{"stamp": 1791807381.592, "connected": true, "heartbeat_age_s": 0.4, "armed": true,
 "mode": "GUIDED", "guided": true, "system_status": 4, "landed_state": "IN_AIR",
 "fcu_prearm_ok": true, "last_prearm_text": "", "rc_present": true,
 "battery": {"voltage_v": 15.99, "current_a": 14.0, "remaining": null},
 "attitude": {"roll_deg": -0.9, "pitch_deg": 0.5, "yaw_enu_deg": 177.3, "heading_deg": 272.7},
 "velocity_body_flu": {"valid": true, "x_mps": -0.016, "y_mps": 0.01, "z_mps": 0.0},
 "local_position_enu": {"valid": true, "x_m": 0.1, "y_m": -0.05, "z_m": 1.2},
 "height": {"valid": true, "above_ground_m": 1.191},
 "ekf": {"flags": 367, "attitude_ok": true, "velocity_horiz_ok": true, "pos_horiz_rel_ok": true,
         "const_pos_mode": false, "velocity_variance": 0.05, "pos_horiz_variance": 0.04, "age_s": 0.3},
 "msg_age_s": 0.06, "stale": false}
```

Event: `{"id": 22, "unix_time": 1791807375.35, "time": "12:16:15", "source": "mission",
"severity": "info", "message": "state: TARGET_SELECTED -> TRACKING"}` (severity: info, warning,
error).

## Chat from an app: questions and commands through the LLM

### Who talks to whom

```
 Phone app ──HTTP──► Pi :8000 drone_api ──ROS service──► Pi intent_bridge ──HTTP──► PC :11434 Ollama
   (only ever                (token check)                (guard, limits,             (gemma4:e4b:
    talks to the Pi)                                       drone state, mission)       text in, JSON out)
                                                                │
                                                                ▼
                                          Pi mission_manager → safety_supervisor → fcu_command_node → Pixhawk
```

- The **app only talks to the Pi** (`http://100.87.20.36:8000` over Tailscale). It never talks
  to the PC.
- The **PC never contacts the Pi and never controls the drone.** The Pi sends it one question
  ("this text + this live data → which form?") and the PC sends back one small JSON reply, like a
  calculator. If the PC is off, the Pi uses its own keyword parser.
- **Everything that moves the drone happens on the Pi**: intent_bridge checks the reply against
  the limits and the drone's state, mission_manager runs the mission, and safety_supervisor checks
  every command before it reaches the Pixhawk. The RC can always take over.
- Stop/cancel never go to the PC.

### The three calls the chat needs

All need the token (`Authorization: Bearer <token>`).

**1. Send what the user typed** (questions and commands alike, always `execute: false` first):

```http
POST /api/v1/command
{"text": "what's the battery?", "execute": false, "use_llm": true}
```

Reply (always this shape):

```json
{"understood": true, "executed": false, "available": true,
 "intent_json": "{\"action\": \"answer\", \"answer\": \"The battery is at 15.84 V.\", ...}",
 "message": "ANSWER: The battery is at 15.84 V. (LLM 2.4 s)"}
```

`intent_json` is a JSON string: parse it and look at `action`.

| `action` in intent_json | `message` starts with | What the app does |
|---|---|---|
| `answer` | `ANSWER:` | show the text (strip `ANSWER: `) |
| `status` | `STATUS:` | show it (questions get this when the PC is off) |
| `search_and_track` | `DRY RUN` | show the plan + a **Confirm** button (call 2) |
| `search_and_track` | `NOT POSSIBLE NOW:` | show it (the reason why, e.g. a mission is running, safety level) |
| `cancel` | `DRY RUN` | call 3 at once, no confirm |
| `refuse` / `understood: false` | `REFUSED` | show it in red |
| — | `busy ...` | show it; the previous command is still waiting for the LLM |
| — (`available: false`) | `intent_bridge not available` / `no answer within` | intent_bridge is not running, or the LLM is very slow |

Text after ` NOTE: ` is extra information, and ` (LLM x.x s)` is how long the PC took: show them
small.

**2. Confirm a plan** (needs `allow_commands: true` and the token; check `/config`
`commands_enabled` to grey the button out):

```http
POST /api/v1/command
{"text": "<the same text>", "execute": true, "use_llm": false,
 "intent_json": "<intent_json exactly as call 1 returned it>"}
```

The Pi runs exactly that plan (the PC is not asked again) after checking it again. Reply
`message` starts with `STARTED`, `NOT EXECUTED` (intent_bridge `allow_execute: false`),
`NOT POSSIBLE NOW`, `REJECTED` or `REFUSED`. `executed: true` means the mission started.
Let a Confirm button expire after ~30 s: the drone's state may have changed.

**3. Stop** (any time, no confirm, works with the PC off):

```http
POST /api/v1/mission/cancel
```

`{"ok": true, "message": "cancelling 1 mission(s): the drone lands"}` or `ok: false` with
`no running mission`. Put a Stop button next to the chat that calls this directly.

Then follow the mission live with the WebSocket (`/ws`): `status.mission.state_name` and the
`event` messages.

### Minimal app logic (JavaScript)

```js
const BASE = 'http://100.87.20.36:8000/api/v1', H = {'Content-Type': 'application/json',
             'Authorization': 'Bearer ' + TOKEN};
const post = (path, body) => fetch(BASE + path, {method: 'POST', headers: H,
                                   body: body && JSON.stringify(body)}).then(r => r.json());

async function chat(text) {
  const r = await post('/command', {text, execute: false, use_llm: true});
  const intent = JSON.parse(r.intent_json || '{}');
  if (r.understood && intent.action === 'cancel') return show((await post('/mission/cancel')).message);
  show(r.message.replace(/^ANSWER: /, ''));
  if (r.understood && intent.action === 'search_and_track' && r.message.startsWith('DRY RUN'))
    showConfirm(async () => show((await post('/command',
        {text, execute: true, use_llm: false, intent_json: r.intent_json})).message));
}
```

The status page (`http://<pi>:8000/`) has this chat built in. Its source is
`src/drone_api/drone_api/web/index.html`, and it can serve as a reference.

### Timing

Questions and commands usually take 2 to 3 s (gemma4:e4b on the PC). The first one after 30 min
idle takes up to about 50 s while the PC loads the model. Give the app request a 45 s timeout
(the API waits 45 s, `command_timeout_s`, and the LLM itself 30 s). Stop is instant.

### Try it from a laptop

```bash
T=<token>; PI=http://100.87.20.36:8000/api/v1
curl -s -X POST $PI/command -H "Authorization: Bearer $T" -H 'Content-Type: application/json' \
     -d '{"text":"what is the battery?","use_llm":true}'
curl -s -X POST $PI/command -H "Authorization: Bearer $T" -H 'Content-Type: application/json' \
     -d '{"text":"look for a person for 20 seconds","use_llm":true}'
curl -s -X POST $PI/mission/cancel -H "Authorization: Bearer $T"
```

## Building the app without the drone

On any laptop (Python 3.10+):

```bash
pip install fastapi uvicorn websockets numpy opencv-python-headless
cd drone_ws/src/drone_api
python3 -m drone_api.demo                                   # http://localhost:8000
python3 -m drone_api.demo --token sec --allow-commands      # with token and commands
```

A simulated drone flies a mission every ~70 s (take off, search, track, lose, reacquire, return,
land), with a fake camera picture. Same endpoints, same JSON, same events. Point the app at it.

## Reaching it from outside the house

Use **Tailscale** (already on the Pi): install it on the phone, same account, and use
`http://100.87.20.36:8000`. Traffic is encrypted and only your devices can reach it. Do **not**
expose port 8000 with ngrok or port forwarding: the API has a token but no HTTPS of its own.

## CPU use: listening only while someone watches

On your Pi every Python ROS node costs about 15-20 % CPU, and the API listens to about 65 messages
a second. So the API only listens to the busy topics (vehicle, flow, safety, target, command
output) **while an app or page uses it**:

- Any API request, an open WebSocket or a camera stream counts as "in use". The first request after
  an idle period waits up to 1.5 s for fresh data, so the app never gets empty values.
- After `idle_unsubscribe_s` (30 s) with nobody using it, it stops listening to those topics. The
  mission status (5 Hz) stays subscribed, so mission events and Pi undervoltage are still logged.
- While idle, mode/arming/safety changes are not logged one by one; when a client comes back, the
  first new message logs what changed (for example `mode: STABILIZE -> GUIDED`).
- `subscribe_when_idle: true` (drone.yaml, `drone_api`) listens all the time: full event log,
  costs about as much CPU as one more ROS node.

It also runs with a single-threaded ROS executor (lighter in Python) and at lower CPU priority
(`nice -n 10`, set in `api.launch.py`), so when the Pi is busy the flight stack always gets the
CPU first.

**Check on the Pi** (stack running, API running, no page open, wait 40 s):
`top` should show `api_server` at a few %. Open the page: it rises (about the cost of one ROS
node) and drops again 30 s after you close it. Terminal B logs `client connected: listening ...`
and `no client for 30 s: stopped listening ...`.

## Honest limits

- While an app is connected the API still costs about as much as one Python ROS node (about
  15-25 % on your Pi while it is throttling). Close the app/page during missions if the Pi is busy.
- Camera viewing costs Pi CPU (YUYV → JPEG, ~10-20 ms per frame at 480 px). It is capped at 5
  encodes/s shared by all viewers and only runs while someone watches, but the Pi is already ~84 %
  busy with YOLO. Close the camera view during flights if Phase 12 shows the Pi struggling.
- `local_position_enu` drifts (flow-only EKF): show it as "relative", not as a map position.
- `heading_deg` comes from the compass via the EKF; indoors, metal can bend it.
- One mission at a time (mission_manager refuses a second start; the response says `refused`).
- No HTTPS: use Tailscale for anything beyond your own Wi-Fi.
