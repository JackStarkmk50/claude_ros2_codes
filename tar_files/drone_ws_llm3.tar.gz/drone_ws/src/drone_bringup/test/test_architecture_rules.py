"""Architecture rules enforced on the source tree.

Rule 1 (one door): only drone_fcu may reference MAVROS write interfaces, and within
drone_fcu only fcu_command_node and its core modules may do so. The one exception is
fcu_state_node's MessageInterval request (telemetry rates in FCU RAM, nothing that moves).
Rule 2: only drone_safety may call the internal flight-operation action.
Rule 3: every Python package has the files ROS 2 needs to build, install and discover it.
Rule 4: drone_api (the web API) publishes nothing: it can only read, and start or cancel a
mission through the same action/services as the command-line tools.
"""

import ast
import configparser
import pathlib
import re

SRC = pathlib.Path(__file__).resolve().parents[2]
PY_PACKAGES = ['drone_fcu', 'drone_safety', 'drone_perception', 'drone_mission',
               'drone_llm', 'drone_bringup', 'drone_api']

MAVROS_WRITE = re.compile(
    r'/mavros/(setpoint_raw/local|setpoint_velocity|setpoint_position|cmd/|set_mode'
    r'|global_position/set_gp_origin)'
    r'|mavros_msgs\.srv')
EXECUTE_OP = re.compile(r'execute_operation')


def python_sources(exclude_tests=True):
    for pkg in PY_PACKAGES:
        for path in (SRC / pkg).rglob('*.py'):
            if exclude_tests and 'test' in path.relative_to(SRC / pkg).parts:
                continue
            yield pkg, path


def test_only_fcu_command_node_writes_to_mavros():
    allowed = {
        SRC / 'drone_fcu' / 'drone_fcu' / 'fcu_command_node.py',
        # checked separately below: MessageInterval only
        SRC / 'drone_fcu' / 'drone_fcu' / 'fcu_state_node.py',
    }
    allowed_dir = SRC / 'drone_fcu' / 'drone_fcu' / 'core'
    offenders = []
    for _, path in python_sources():
        if path in allowed or allowed_dir in path.parents:
            continue
        if MAVROS_WRITE.search(path.read_text()):
            offenders.append(str(path.relative_to(SRC)))
    assert not offenders, f'MAVROS write interfaces used outside fcu_command_node: {offenders}'


def test_fcu_state_node_only_requests_stream_rates():
    text = (SRC / 'drone_fcu' / 'drone_fcu' / 'fcu_state_node.py').read_text()
    srv_imports = re.findall(r'from mavros_msgs\.srv import (.+)', text)
    assert srv_imports == ['MessageInterval'], srv_imports
    services = set(re.findall(r"create_client\(\s*\w+,\s*'([^']+)'", text))
    assert services == {'/mavros/set_message_interval'}, services
    publishers = set(re.findall(r"create_publisher\(\s*\w+,\s*'([^']+)'", text))
    assert all(topic.startswith('/drone/') for topic in publishers), publishers


def test_only_safety_and_fcu_touch_execute_operation():
    offenders = []
    for pkg, path in python_sources():
        if pkg in ('drone_safety', 'drone_fcu'):
            continue
        if EXECUTE_OP.search(path.read_text()):
            offenders.append(str(path.relative_to(SRC)))
    assert not offenders, f'internal execute_operation used outside safety/fcu: {offenders}'


def test_python_packages_are_complete():
    for pkg in PY_PACKAGES:
        root = SRC / pkg
        for rel in ('package.xml', 'setup.py', 'setup.cfg', f'resource/{pkg}',
                    f'{pkg}/__init__.py', 'README.md'):
            assert (root / rel).exists(), f'{pkg}: missing {rel}'
        cfg = configparser.ConfigParser()
        cfg.read(root / 'setup.cfg')
        assert cfg['develop']['script_dir'] == f'$base/lib/{pkg}'
        assert cfg['install']['install_scripts'] == f'$base/lib/{pkg}'
        assert f'<name>{pkg}</name>' in (root / 'package.xml').read_text()


def entry_points(pkg):
    tree = ast.parse((SRC / pkg / 'setup.py').read_text())
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str) and ' = ' in node.value:
            name, target = [s.strip() for s in node.value.split('=')]
            yield name, target


def test_entry_points_point_at_real_main_functions():
    for pkg in PY_PACKAGES:
        for name, target in entry_points(pkg):
            module, func = target.split(':')
            path = SRC / pkg / (module.replace('.', '/') + '.py')
            assert path.exists(), f'{pkg}: entry point {name} -> missing {path}'
            tree = ast.parse(path.read_text())
            funcs = {n.name for n in tree.body if isinstance(n, ast.FunctionDef)}
            assert func in funcs, f'{pkg}: {name} -> {func}() not defined in {path.name}'



def test_web_api_publishes_nothing():
    for path in (SRC / 'drone_api').rglob('*.py'):
        if 'test' in path.relative_to(SRC / 'drone_api').parts:
            continue
        text = path.read_text()
        assert 'create_publisher' not in text, f'{path.name}: drone_api must not publish'
        assert 'ControlCommand' not in text, f'{path.name}: drone_api must not build commands'
        assert 'FlightOperation' not in text, f'{path.name}: drone_api must not arm/take off directly'

