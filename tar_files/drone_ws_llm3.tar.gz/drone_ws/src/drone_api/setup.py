from glob import glob

from setuptools import find_packages, setup

package_name = 'drone_api'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    package_data={'drone_api': ['web/*.html']},
    include_package_data=True,
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml', 'README.md']),
        ('share/' + package_name + '/launch', glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=False,
    maintainer='Moganesan',
    maintainer_email='ht.moganesan@gmail.com',
    description='HTTP/WebSocket API for dashboards and mobile apps (telemetry, camera, missions).',
    license='MIT',
    extras_require={'test': ['pytest']},
    entry_points={
        'console_scripts': [
            'api_server = drone_api.api_node:main',
        ],
    },
)
