import json
import math

from fake_msgs import make

from drone_api.core import convert


def test_every_converter_reads_only_real_fields_and_is_json_safe():
    for msg, fn in (('VehicleState', convert.vehicle), ('FlowStatus', convert.flow),
                    ('SafetyStatus', convert.safety), ('MissionStatus', convert.mission),
                    ('TrackedTarget', convert.target)):
        d = fn(make(msg))
        json.dumps(d, allow_nan=False)          # raises on NaN / non-serialisable


def test_nan_becomes_none():
    v = convert.vehicle(make('VehicleState', battery_current_a=float('nan'),
                             height_above_ground_m=float('inf')))
    assert v['battery']['current_a'] is None
    assert v['height']['above_ground_m'] is None
    json.dumps(v, allow_nan=False)


def test_heading_from_enu_yaw():
    # ENU yaw 0 = facing east = compass 90; yaw +90 deg (north) = compass 0
    assert convert.vehicle(make('VehicleState', yaw_rad=0.0))['attitude']['heading_deg'] == 90.0
    assert convert.vehicle(make('VehicleState', yaw_rad=math.pi / 2))['attitude']['heading_deg'] == 0.0
    assert convert.vehicle(make('VehicleState', yaw_rad=-math.pi / 2))['attitude']['heading_deg'] == 180.0


def test_names_and_stamp():
    v = convert.vehicle(make('VehicleState', landed_state=2, mode='GUIDED', armed=True))
    assert v['landed_state'] == 'IN_AIR' and v['mode'] == 'GUIDED' and v['armed'] is True
    assert v['stamp'] == 12.5
    s = convert.safety(make('SafetyStatus', level=4, active_faults=['COMMAND_STALE']))
    assert s['level_name'] == 'OVERRIDE' and s['active_faults'] == ['COMMAND_STALE']
    t = convert.target(make('TrackedTarget', state=2, last_seen_side=-1, error_x_norm=-0.4))
    assert t['state_name'] == 'TRACKING' and t['last_seen_side'] == 'left'
    assert t['error_x_norm'] == -0.4
    assert convert.safety(make('SafetyStatus', level=9))['level_name'] == 'UNKNOWN_9'
