"""Build stand-in message objects straight from drone_interfaces/msg/*.msg.

An object only has the fields the .msg file declares, so if convert.py reads a field that does not
exist (a typo, or a field renamed later) the test fails with AttributeError.
"""

import os
from types import SimpleNamespace as NS

MSG_DIR = os.path.join(os.path.dirname(__file__), '..', '..', 'drone_interfaces', 'msg')

PRIMITIVE = {'bool': False, 'string': '', 'float32': 0.0, 'float64': 0.0}
NESTED = {
    'std_msgs/Header': lambda: NS(stamp=NS(sec=12, nanosec=500000000), frame_id=''),
    'geometry_msgs/Vector3': lambda: NS(x=0.0, y=0.0, z=0.0),
    'geometry_msgs/Point': lambda: NS(x=0.0, y=0.0, z=0.0),
    'vision_msgs/BoundingBox2D': lambda: NS(center=NS(position=NS(x=0.0, y=0.0), theta=0.0),
                                            size_x=0.0, size_y=0.0),
}


def fields(name):
    out = []
    with open(os.path.join(MSG_DIR, name + '.msg')) as f:
        for line in f:
            line = line.split('#', 1)[0].strip()
            if not line:
                continue
            typ, rest = line.split(None, 1)
            if '=' in rest:          # constant
                continue
            out.append((typ, rest.split()[0]))
    return out


def make(name, **values):
    obj = NS()
    for typ, field in fields(name):
        if typ.endswith('[]'):
            v = []
        elif typ in NESTED:
            v = NESTED[typ]()
        elif typ in PRIMITIVE:
            v = PRIMITIVE[typ]
        elif typ.startswith(('uint', 'int')):
            v = 0
        else:
            raise AssertionError(f'{name}.{field}: add type {typ} to fake_msgs.NESTED')
        setattr(obj, field, v)
    for k, v in values.items():
        assert hasattr(obj, k), f'{name} has no field {k}'
        setattr(obj, k, v)
    return obj
