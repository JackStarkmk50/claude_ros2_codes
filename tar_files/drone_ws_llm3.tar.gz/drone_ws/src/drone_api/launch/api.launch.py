"""Start the web API on its own (separate from bringup, so stopping it never touches the stack).

  ros2 launch drone_api api.launch.py
  ros2 launch drone_api api.launch.py config:=$HOME/sim_drone.yaml
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    default_config = os.path.join(
        get_package_share_directory('drone_bringup'), 'config', 'drone.yaml')
    return LaunchDescription([
        DeclareLaunchArgument('config', default_value=default_config),
        # nice: lower CPU priority, so the flight stack always wins when the Pi is busy
        Node(package='drone_api', executable='api_server', name='drone_api',
             parameters=[LaunchConfiguration('config')], output='screen',
             prefix='nice -n 10'),
    ])
