# drone_api

HTTP + WebSocket API for dashboards and mobile apps: telemetry, Pi health, event log, camera, and
(off by default) mission start/cancel through mission_manager. It publishes nothing and never
talks to MAVROS. Steps and endpoint reference: `docs/API.md`.

| Executable | What it does |
|---|---|
| `api_server` | the API on port 8000 (`ros2 launch drone_api api.launch.py`) |

`python3 -m drone_api.demo` runs the same API with a simulated drone (no ROS) for app development.

Pure logic in `core/` (no ROS): `convert` (msg → JSON), `store` (latest values + events),
`system` (Pi health), `auth` (access rules), `overlay` (camera JPEG). `app.py` holds the
endpoints and talks to a backend object (the ROS node, or the demo).

Python deps from `~/drone_venv`: `fastapi uvicorn websockets` (`tools/setup_venv.sh`).

```bash
colcon test --packages-select drone_api && colcon test-result --verbose
```
