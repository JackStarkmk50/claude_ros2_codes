"""Raspberry Pi health: CPU temperature, load, memory, disk, undervoltage/throttling."""

import os
import shutil
import subprocess
import time

THROTTLE_BITS = {
    0: 'under_voltage_now',
    1: 'arm_freq_capped_now',
    2: 'throttled_now',
    3: 'soft_temp_limit_now',
    16: 'under_voltage_since_boot',
    17: 'arm_freq_capped_since_boot',
    18: 'throttled_since_boot',
    19: 'soft_temp_limit_since_boot',
}


def decode_throttled(value):
    """vcgencmd get_throttled value -> dict of flags."""
    flags = {name: bool(value >> bit & 1) for bit, name in THROTTLE_BITS.items()}
    flags['raw'] = hex(value)
    flags['ok_now'] = not any(value >> b & 1 for b in (0, 1, 2, 3))
    return flags


def parse_throttled(text):
    """'throttled=0x50000' -> 0x50000, or None."""
    text = (text or '').strip()
    if '=' not in text:
        return None
    try:
        return int(text.split('=', 1)[1], 16)
    except ValueError:
        return None


def read_throttled(timeout=1.0):
    exe = shutil.which('vcgencmd')
    if not exe:
        return None
    try:
        out = subprocess.run([exe, 'get_throttled'], capture_output=True, text=True,
                             timeout=timeout).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    v = parse_throttled(out)
    return None if v is None else decode_throttled(v)


def cpu_temp_c(path='/sys/class/thermal/thermal_zone0/temp'):
    try:
        with open(path) as f:
            return round(int(f.read().strip()) / 1000.0, 1)
    except (OSError, ValueError):
        return None


def meminfo(path='/proc/meminfo'):
    vals = {}
    try:
        with open(path) as f:
            for line in f:
                k, _, rest = line.partition(':')
                vals[k] = int(rest.split()[0])  # kB
    except (OSError, ValueError, IndexError):
        return None
    total = vals.get('MemTotal')
    avail = vals.get('MemAvailable')
    if not total or avail is None:
        return None
    return {'total_mb': round(total / 1024), 'available_mb': round(avail / 1024),
            'used_percent': round(100.0 * (total - avail) / total, 1)}


class CpuUsage:
    """CPU busy % between two calls, from /proc/stat."""

    def __init__(self, path='/proc/stat'):
        self.path = path
        self.prev = None

    def _read(self):
        try:
            with open(self.path) as f:
                parts = [int(x) for x in f.readline().split()[1:]]
        except (OSError, ValueError):
            return None
        idle = parts[3] + (parts[4] if len(parts) > 4 else 0)
        return sum(parts), idle

    def percent(self):
        cur = self._read()
        if cur is None:
            return None
        prev, self.prev = self.prev, cur
        if prev is None:
            return None
        total, idle = cur[0] - prev[0], cur[1] - prev[1]
        return round(100.0 * (total - idle) / total, 1) if total > 0 else None


def uptime_s(path='/proc/uptime'):
    try:
        with open(path) as f:
            return int(float(f.read().split()[0]))
    except (OSError, ValueError, IndexError):
        return None


def collect(cpu, with_throttled=True):
    try:
        load = [round(x, 2) for x in os.getloadavg()]
    except OSError:
        load = None
    try:
        du = shutil.disk_usage(os.path.expanduser('~'))
        disk = {'free_gb': round(du.free / 1e9, 1), 'used_percent': round(100 * du.used / du.total, 1)}
    except OSError:
        disk = None
    return {
        'hostname': os.uname().nodename,
        'unix_time': round(time.time(), 3),
        'uptime_s': uptime_s(),
        'cpu_temp_c': cpu_temp_c(),
        'cpu_percent': cpu.percent(),
        'cpu_count': os.cpu_count(),
        'load_avg': load,
        'memory': meminfo(),
        'disk': disk,
        'throttled': read_throttled() if with_throttled else None,
    }
