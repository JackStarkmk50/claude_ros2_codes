"""Access rules, kept in one place so they are easy to test.

  reads (GET, WebSocket, camera)   open if no token is configured, otherwise need the token
  preflight check                  same as reads (it only checks, never changes anything)
  mission cancel                   needs a configured token (cancel = the drone lands)
  everything else that acts        needs the token AND allow_commands: true
"""

import hmac

READ, CANCEL, ACT = 'read', 'cancel', 'act'


def token_from(headers_auth, query_token):
    """'Bearer abc' header or ?token=abc -> 'abc' (header wins)."""
    if headers_auth and headers_auth.lower().startswith('bearer '):
        return headers_auth[7:].strip()
    return (query_token or '').strip()


def check(kind, configured_token, given_token, allow_commands):
    """-> (allowed, http_status, reason)."""
    configured_token = configured_token or ''
    token_ok = bool(configured_token) and hmac.compare_digest(
        configured_token.encode(), (given_token or '').encode())
    if kind == READ:
        if not configured_token or token_ok:
            return True, 200, ''
        return False, 401, 'missing or wrong token'
    if not configured_token:
        return False, 403, 'commands need an api_token in drone.yaml (drone_api section)'
    if not token_ok:
        return False, 401, 'missing or wrong token'
    if kind == ACT and not allow_commands:
        return False, 403, 'commands are switched off (drone_api allow_commands: false)'
    return True, 200, ''
