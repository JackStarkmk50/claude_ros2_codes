"""Pure logic (no ROS): conversion, store, system stats, auth."""
