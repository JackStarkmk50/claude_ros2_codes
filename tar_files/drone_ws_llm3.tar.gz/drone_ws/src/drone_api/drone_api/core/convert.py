"""ROS message -> plain JSON-safe dict. No ROS imports: works on any object with the fields.

Every function reads only fields that exist in drone_interfaces (a test checks this against the
.msg files). NaN and infinity become None, because JSON has no NaN.
"""

import math

LANDED = ('UNDEFINED', 'ON_GROUND', 'IN_AIR', 'TAKEOFF', 'LANDING')
SAFETY_LEVELS = ('OK', 'DEGRADED', 'HOLD', 'ABORT', 'OVERRIDE')
TARGET_STATES = ('NONE', 'CANDIDATE', 'TRACKING', 'LOST')
SIDES = {-1: 'left', 0: 'centre', 1: 'right'}


def num(x, digits=3):
    """float -> rounded float, or None for NaN/inf/missing."""
    if x is None:
        return None
    try:
        f = float(x)
    except (TypeError, ValueError):
        return None
    if math.isnan(f) or math.isinf(f):
        return None
    return round(f, digits)


def name(table, i):
    try:
        return table[int(i)]
    except (IndexError, TypeError, ValueError):
        return f'UNKNOWN_{i}'


def deg(rad):
    v = num(rad, 6)
    return None if v is None else round(math.degrees(v), 1)


def stamp(header):
    """header.stamp -> seconds as float (ROS clock), or None."""
    try:
        return round(header.stamp.sec + header.stamp.nanosec * 1e-9, 3)
    except AttributeError:
        return None


def vehicle(m):
    yaw_deg = deg(m.yaw_rad)
    return {
        'stamp': stamp(m.header),
        'connected': bool(m.connected),
        'heartbeat_age_s': num(m.heartbeat_age_s, 2),
        'armed': bool(m.armed),
        'mode': m.mode,
        'guided': bool(m.guided),
        'system_status': int(m.system_status),
        'landed_state': name(LANDED, m.landed_state),
        'fcu_prearm_ok': bool(m.fcu_prearm_ok),
        'last_prearm_text': m.last_prearm_text,
        'rc_present': bool(m.rc_present),
        'battery': {
            'voltage_v': num(m.battery_voltage_v, 2),
            'current_a': num(m.battery_current_a, 2),
            'remaining': num(m.battery_remaining, 3),
        },
        'attitude': {
            'roll_deg': deg(m.roll_rad),
            'pitch_deg': deg(m.pitch_rad),
            'yaw_enu_deg': yaw_deg,
            # compass heading: 0 = north, clockwise (ENU yaw is 0 = east, counter-clockwise)
            'heading_deg': None if yaw_deg is None else round((90.0 - yaw_deg) % 360.0, 1),
        },
        'velocity_body_flu': {
            'valid': bool(m.velocity_valid),
            'x_mps': num(m.velocity_body_flu.x),
            'y_mps': num(m.velocity_body_flu.y),
            'z_mps': num(m.velocity_body_flu.z),
        },
        'local_position_enu': {
            'valid': bool(m.local_position_valid),
            'x_m': num(m.local_position_enu.x),
            'y_m': num(m.local_position_enu.y),
            'z_m': num(m.local_position_enu.z),
        },
        'height': {
            'valid': bool(m.height_valid),
            'above_ground_m': num(m.height_above_ground_m),
        },
        'ekf': {
            'flags': int(m.ekf_flags),
            'attitude_ok': bool(m.ekf_attitude_ok),
            'velocity_horiz_ok': bool(m.ekf_velocity_horiz_ok),
            'pos_horiz_rel_ok': bool(m.ekf_pos_horiz_rel_ok),
            'const_pos_mode': bool(m.ekf_const_pos_mode),
            'velocity_variance': num(m.ekf_velocity_variance),
            'pos_horiz_variance': num(m.ekf_pos_horiz_variance),
            'age_s': num(m.ekf_age_s, 2),
        },
    }


def flow(m):
    return {
        'stamp': stamp(m.header),
        'source_seen': bool(m.source_seen),
        'age_s': num(m.age_s, 2),
        'fresh': bool(m.fresh),
        'quality': int(m.quality),
        'quality_ok': bool(m.quality_ok),
        'quality_applies': bool(m.quality_applies),
        'flow_rate_x_rad_s': num(m.flow_rate_x_rad_s),
        'flow_rate_y_rad_s': num(m.flow_rate_y_rad_s),
        'ground_distance_m': num(m.ground_distance_m),
        'in_valid_height_band': bool(m.in_valid_height_band),
        'healthy_for_flight': bool(m.healthy_for_flight),
        'healthy_for_takeoff': bool(m.healthy_for_takeoff),
        'reason': m.reason,
    }


def safety(m):
    return {
        'stamp': stamp(m.header),
        'level': int(m.level),
        'level_name': name(SAFETY_LEVELS, m.level),
        'latched': bool(m.latched),
        'motion_allowed': bool(m.motion_allowed),
        'preflight_ok': bool(m.preflight_ok),
        'preflight_failures': list(m.preflight_failures),
        'active_faults': list(m.active_faults),
        'warnings': list(m.warnings),
        'commands_rejected': int(m.commands_rejected),
        'commands_clamped': int(m.commands_clamped),
    }


def mission(m):
    return {
        'stamp': stamp(m.header),
        'state': int(m.state),
        'state_name': m.state_name,
        'target_class': m.target_class,
        'target_track_id': int(m.target_track_id),
        'elapsed_s': num(m.elapsed_s, 1),
        'search_yaw_accumulated_deg': num(m.search_yaw_accumulated_deg, 1),
        'reacquire_attempts': int(m.reacquire_attempts),
        'detail': m.detail,
    }


def target(m):
    b = m.bbox
    return {
        'stamp': stamp(m.header),
        'state': int(m.state),
        'state_name': name(TARGET_STATES, m.state),
        'track_id': int(m.track_id),
        'class_id': m.class_id,
        'confidence': num(m.confidence),
        'bbox_px': {
            'cx': num(b.center.position.x, 1),
            'cy': num(b.center.position.y, 1),
            'w': num(b.size_x, 1),
            'h': num(b.size_y, 1),
        },
        'image_width': int(m.image_width),
        'image_height': int(m.image_height),
        'error_x_norm': num(m.error_x_norm),
        'error_y_norm': num(m.error_y_norm),
        'bbox_height_norm': num(m.bbox_height_norm),
        'time_since_seen_s': num(m.time_since_seen_s, 2),
        'frames_seen': int(m.frames_seen),
        'last_seen_side': SIDES.get(int(m.last_seen_side), 'unknown'),
    }


def text(m):
    return {'text': m.data}
