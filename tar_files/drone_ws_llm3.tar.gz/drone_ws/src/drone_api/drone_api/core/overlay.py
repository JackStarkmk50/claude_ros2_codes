"""Draw the tracked person and a status line on a camera frame, then JPEG-encode it."""

import cv2
import numpy as np

COLOURS = {'TRACKING': (0, 200, 0), 'CANDIDATE': (0, 200, 255), 'LOST': (0, 0, 255)}  # BGR


def draw(bgr, target=None, mission=None, vehicle=None):
    """Draw in place on a BGR image. target/mission/vehicle are the API dicts (or None)."""
    h, w = bgr.shape[:2]
    cv2.line(bgr, (w // 2, 0), (w // 2, h), (200, 200, 200), 1)
    if target and target.get('state_name') in COLOURS and not target.get('stale'):
        b = target.get('bbox_px') or {}
        iw, ih = target.get('image_width') or w, target.get('image_height') or h
        sx, sy = w / float(iw), h / float(ih)
        if None not in (b.get('cx'), b.get('cy'), b.get('w'), b.get('h')):
            x0 = int((b['cx'] - b['w'] / 2) * sx)
            y0 = int((b['cy'] - b['h'] / 2) * sy)
            x1 = int((b['cx'] + b['w'] / 2) * sx)
            y1 = int((b['cy'] + b['h'] / 2) * sy)
            col = COLOURS[target['state_name']]
            cv2.rectangle(bgr, (x0, y0), (x1, y1), col, 2)
            conf = target.get('confidence')
            label = f"{target['state_name']} id {target.get('track_id')}"
            if conf is not None:
                label += f' {conf:.2f}'
            cv2.putText(bgr, label, (x0, max(15, y0 - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, col, 1,
                        cv2.LINE_AA)
    parts = []
    if vehicle:
        parts.append(f"{vehicle.get('mode') or '?'} {'ARMED' if vehicle.get('armed') else 'disarmed'}")
        v = (vehicle.get('battery') or {}).get('voltage_v')
        if v is not None:
            parts.append(f'{v:.1f} V')
        hgt = (vehicle.get('height') or {}).get('above_ground_m')
        if hgt is not None:
            parts.append(f'h {hgt:.2f} m')
    if mission:
        parts.append(mission.get('state_name') or '')
    if parts:
        text = '  |  '.join(p for p in parts if p)
        cv2.rectangle(bgr, (0, h - 24), (w, h), (0, 0, 0), -1)
        cv2.putText(bgr, text, (6, h - 7), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1,
                    cv2.LINE_AA)
    return bgr


def encode(rgb, quality=70, width=0, target=None, mission=None, vehicle=None, overlay=True):
    """RGB array -> JPEG bytes, optionally resized to `width` px and with the overlay."""
    bgr = cv2.cvtColor(np.ascontiguousarray(rgb), cv2.COLOR_RGB2BGR)
    if width and bgr.shape[1] > width:
        hgt = int(bgr.shape[0] * width / bgr.shape[1])
        bgr = cv2.resize(bgr, (width, hgt), interpolation=cv2.INTER_AREA)
    if overlay:
        draw(bgr, target, mission, vehicle)
    ok, jpg = cv2.imencode('.jpg', bgr, [cv2.IMWRITE_JPEG_QUALITY, int(quality)])
    if not ok:
        raise ValueError('JPEG encoding failed')
    return jpg.tobytes()
