"""Thread-safe latest-value store + event log.

ROS callbacks call update(); the web side calls snapshot()/events(). Each section remembers when it
last arrived, so the API can say how old a value is and whether it has stopped arriving.
Events are generated here by comparing the new value with the previous one (mode changed, armed,
safety level changed, ...), so every client sees the same log.
"""

import collections
import threading
import time

# section -> seconds without an update before it counts as stale (None: never stale, e.g. latched)
STALE_AFTER_S = {
    'vehicle': 1.0,     # fcu_state_node publishes at 10 Hz
    'flow': 1.0,
    'safety': 2.0,      # safety_supervisor publishes at its rate_hz
    'mission': 2.0,     # mission_manager publishes at 5 Hz
    'target': 1.5,      # target_tracker publishes at 10 Hz
    'fcu_output': None,
    'system': 10.0,
}

# (section, key path, label, severity)
WATCHED = [
    ('vehicle', ('connected',), 'FCU link', 'warning'),
    ('vehicle', ('armed',), 'armed', 'info'),
    ('vehicle', ('mode',), 'mode', 'info'),
    ('vehicle', ('landed_state',), 'landed state', 'info'),
    ('vehicle', ('rc_present',), 'RC', 'warning'),
    ('vehicle', ('fcu_prearm_ok',), 'FCU pre-arm ok', 'info'),
    ('vehicle', ('last_prearm_text',), 'FCU says', 'warning'),
    ('flow', ('healthy_for_flight',), 'flow healthy for flight', 'info'),
    ('safety', ('level_name',), 'safety level', 'warning'),
    ('safety', ('latched',), 'safety latched', 'warning'),
    ('safety', ('preflight_ok',), 'pre-flight ok', 'info'),
    ('mission', ('state_name',), 'state', 'info'),
    ('target', ('state_name',), 'state', 'info'),
    ('fcu_output', ('text',), 'output', 'info'),
    ('system', ('throttled', 'under_voltage_now'), 'Pi UNDERVOLTAGE', 'error'),
    ('system', ('throttled', 'throttled_now'), 'Pi throttled', 'warning'),
]


def _get(d, path):
    for k in path:
        if not isinstance(d, dict) or k not in d:
            return None
        d = d[k]
    return d


class Store:
    def __init__(self, max_events=300, clock=time.monotonic, wall=time.time):
        self._lock = threading.Lock()
        self._data = {}          # section -> dict
        self._t = {}             # section -> monotonic time of last update
        self._count = collections.Counter()
        self._events = collections.deque(maxlen=max_events)
        self._next_id = 1
        self._clock = clock
        self._wall = wall
        self._stale_reported = set()
        self._paused = set()     # sections deliberately not subscribed (API idle): never "stale"

    # ---- writing (ROS side) -------------------------------------------------------------------
    def update(self, section, data):
        with self._lock:
            old = self._data.get(section)
            self._data[section] = data
            self._t[section] = self._clock()
            self._count[section] += 1
            if section in self._stale_reported:
                self._stale_reported.discard(section)
                self._add_event_locked(section, f'{section} data arriving again', 'info')
            self._paused.discard(section)
            self._diff_locked(section, old, data)

    def pause(self, sections):
        """The API stopped listening to these on purpose: no 'stopped arriving' warnings. The last
        values are kept, so the first new message logs what changed in the meantime."""
        with self._lock:
            self._paused.update(sections)
            self._stale_reported.difference_update(sections)

    def add_event(self, source, message, severity='info'):
        with self._lock:
            self._add_event_locked(source, message, severity)

    def check_stale(self):
        """Call periodically: logs one event when a section stops arriving."""
        now = self._clock()
        with self._lock:
            for section, t in self._t.items():
                if section in self._paused:
                    continue
                limit = STALE_AFTER_S.get(section)
                if limit is not None and now - t > limit and section not in self._stale_reported:
                    self._stale_reported.add(section)
                    self._add_event_locked(section, f'{section} data stopped arriving '
                                                    f'(last {now - t:.1f} s ago)', 'warning')

    def _diff_locked(self, section, old, new):
        if old is None:
            self._add_event_locked(section, f'{section} data received', 'info')
            return
        for sec, path, label, severity in WATCHED:
            if sec != section:
                continue
            a, b = _get(old, path), _get(new, path)
            if a == b:
                continue
            if path == ('last_prearm_text',) and not b:
                continue                         # only report new messages, not their expiry
            if isinstance(b, bool):
                msg = f'{label}: {"yes" if b else "no"}'
            else:
                msg = f'{label}: {a} -> {b}' if a not in (None, '') else f'{label}: {b}'
            sev = severity
            if section == 'safety' and path == ('level_name',) and b == 'OK':
                sev = 'info'
            if section == 'vehicle' and path == ('connected',) and b:
                sev = 'info'
            self._add_event_locked(section, msg, sev)
        if section == 'safety':
            for f in sorted(set(new.get('active_faults', [])) - set(old.get('active_faults', []))):
                self._add_event_locked('safety', f'fault: {f}', 'error')

    def _add_event_locked(self, source, message, severity):
        wall = self._wall()
        self._events.append({
            'id': self._next_id,
            'unix_time': round(wall, 3),
            'time': time.strftime('%H:%M:%S', time.localtime(wall)),
            'source': source,
            'severity': severity,
            'message': message,
        })
        self._next_id += 1

    # ---- reading (web side) -------------------------------------------------------------------
    def section(self, name):
        """One section with msg_age_s/stale added, or None if it never arrived."""
        now = self._clock()
        with self._lock:
            if name not in self._data:
                return None
            out = dict(self._data[name])
            age = now - self._t[name]
        limit = STALE_AFTER_S.get(name)
        out['msg_age_s'] = round(age, 2)
        out['stale'] = bool(limit is not None and age > limit)
        return out

    def snapshot(self, sections):
        return {name: self.section(name) for name in sections}

    def health(self):
        now = self._clock()
        with self._lock:
            items = list(self._t.items())
            counts = dict(self._count)
            paused = set(self._paused)
        topics = {}
        for name, t in items:
            limit = STALE_AFTER_S.get(name)
            age = now - t
            topics[name] = {'msg_age_s': round(age, 2), 'messages': counts.get(name, 0),
                            'stale': bool(limit is not None and age > limit),
                            'paused': name in paused}
        return topics

    def events(self, since=0, limit=100):
        with self._lock:
            ev = [e for e in self._events if e['id'] > since]
        return ev[-limit:] if limit else ev

    def last_event_id(self):
        with self._lock:
            return self._next_id - 1
