"""Run the API with a simulated drone: no ROS, no Pixhawk, no camera needed.

For building the dashboard or mobile app on a laptop:

  pip install fastapi uvicorn numpy opencv-python-headless
  cd ~/drone_ws/src/drone_api && python3 -m drone_api.demo            # http://localhost:8000
  python3 -m drone_api.demo --token sec --allow-commands --port 8000

The fake drone cycles through a mission (take off, search, track, return, land) every ~70 s, so
every field and event changes the way it will on the real drone. Mission start / cancel work.
The data has exactly the same shape as on the drone (it goes through the same converters).
"""

import argparse
import math
import threading
import time
from types import SimpleNamespace as NS

import numpy as np

from drone_api.core import convert, overlay, system
from drone_api.core.store import Store

STATES = [  # (mission state number, name, seconds)
    (1, 'PREFLIGHT', 3), (2, 'TAKING_OFF', 6), (3, 'SEARCHING', 12), (4, 'PERSON_DETECTED', 1),
    (5, 'TARGET_SELECTED', 1), (6, 'TRACKING', 20), (7, 'TARGET_LOST', 2), (8, 'REACQUIRING', 3),
    (6, 'TRACKING', 8), (9, 'RETURNING', 6), (10, 'LANDING', 6), (11, 'MISSION_COMPLETE', 5),
]


def header(t):
    return NS(stamp=NS(sec=int(t), nanosec=int((t % 1) * 1e9)), frame_id='')


class DemoBackend:
    def __init__(self):
        self.store = Store()
        self._cpu = system.CpuUsage()
        self._running = False
        self._t0 = 0.0
        self._volt = 16.4
        self._yaw = 0.0
        self._t_end = 0.0
        self.auto = True
        self._lock = threading.Lock()
        self.store.add_event('api', 'drone_api DEMO started (simulated drone)', 'info')

    # --- simulation ---------------------------------------------------------------------------
    def _mission_now(self, now):
        if not self._running:
            return 0, 'IDLE', 0.0
        el = now - self._t0
        acc = 0.0
        for num, name, dur in STATES:
            if el < acc + dur:
                return num, name, el
            acc += dur
        self._running = False
        self._t_end = now
        return 0, 'IDLE', el

    def step(self):
        now = time.time()
        with self._lock:
            state, sname, el = self._mission_now(now)
        airborne = sname in ('TAKING_OFF', 'SEARCHING', 'PERSON_DETECTED', 'TARGET_SELECTED',
                             'TRACKING', 'TARGET_LOST', 'REACQUIRING', 'RETURNING', 'LANDING')
        armed = airborne or sname == 'PREFLIGHT'
        if airborne:
            self._volt = max(14.2, self._volt - 0.0015)
        if sname in ('SEARCHING', 'REACQUIRING', 'RETURNING'):
            self._yaw += 0.26 / 10
        h = {'TAKING_OFF': min(1.2, 0.14 + 0.2 * (el - 3)), 'LANDING': 0.6}.get(
            sname, 1.2 if airborne else 0.14)
        tracking = sname in ('TRACKING', 'PERSON_DETECTED', 'TARGET_SELECTED')
        ex = 0.3 * math.sin(now / 3) if tracking else 0.0
        mode = 'GUIDED' if armed and sname not in ('LANDING',) else ('LAND' if sname == 'LANDING'
                                                                      else 'STABILIZE')
        v = NS(header=header(now), connected=True, heartbeat_age_s=0.4, armed=armed,
               guided=mode == 'GUIDED', mode=mode, system_status=4 if armed else 3,
               landed_state=2 if airborne else 1, fcu_prearm_ok=True, last_prearm_text='',
               rc_present=True, battery_voltage_v=self._volt + 0.02 * math.sin(now),
               battery_current_a=14.0 if airborne else 0.6, battery_remaining=float('nan'),
               roll_rad=0.02 * math.sin(now), pitch_rad=0.015 * math.cos(now), yaw_rad=self._yaw,
               velocity_body_flu=NS(x=0.02 * math.sin(now), y=0.01, z=0.0), velocity_valid=True,
               local_position_valid=True, local_position_enu=NS(x=0.1, y=-0.05, z=h),
               height_above_ground_m=h + 0.01 * math.sin(now * 2), height_valid=True,
               ekf_flags=0x16f, ekf_attitude_ok=True, ekf_velocity_horiz_ok=True,
               ekf_pos_horiz_rel_ok=True, ekf_const_pos_mode=False, ekf_velocity_variance=0.05,
               ekf_pos_horiz_variance=0.04, ekf_age_s=0.3)
        self.store.update('vehicle', convert.vehicle(v))
        fl = NS(header=header(now), source_seen=True, age_s=0.02, fresh=True,
                quality=150 if airborne else 72, quality_ok=airborne, quality_applies=airborne,
                flow_rate_x_rad_s=0.01, flow_rate_y_rad_s=-0.01, ground_distance_m=h,
                in_valid_height_band=airborne, healthy_for_flight=airborne,
                healthy_for_takeoff=True,
                reason='' if airborne else 'height 0.14 m below flow band')
        self.store.update('flow', convert.flow(fl))
        sf = NS(header=header(now), level=0, latched=False, motion_allowed=True,
                preflight_ok=not armed, preflight_failures=[] if not armed else ['PF8 ARMED'],
                active_faults=[], warnings=[], commands_rejected=0, commands_clamped=0)
        self.store.update('safety', convert.safety(sf))
        ms = NS(header=header(now), state=state, state_name=sname, target_class='person',
                target_track_id=7 if tracking else 0, elapsed_s=el,
                search_yaw_accumulated_deg=min(360.0, max(0.0, (el - 9) * 15)) if sname == 'SEARCHING' else 0.0,
                reacquire_attempts=1 if sname == 'REACQUIRING' else 0,
                detail={'TRACKING': 'tracking for 20 s', 'SEARCHING': 'turning left'}.get(sname, ''))
        self.store.update('mission', convert.mission(ms))
        tstate = 2 if tracking else (3 if sname in ('TARGET_LOST', 'REACQUIRING') else 0)
        cx = 320 + ex * 320
        tt = NS(header=header(now), state=tstate, track_id=7 if tstate else 0, class_id='person',
                confidence=0.81 if tstate == 2 else 0.0,
                bbox=NS(center=NS(position=NS(x=cx, y=230.0), theta=0.0), size_x=110.0, size_y=300.0),
                image_width=640, image_height=480, error_x_norm=ex, error_y_norm=-0.04,
                bbox_height_norm=0.62, time_since_seen_s=0.1 if tstate == 2 else 1.4,
                frames_seen=120, last_seen_side=1 if ex > 0.1 else (-1 if ex < -0.1 else 0))
        self.store.update('target', convert.target(tt))
        out = 'SILENT: disarmed' if not armed else ('SENDING: validated command' if mode == 'GUIDED'
                                                    else 'SILENT: mode LAND')
        self.store.update('fcu_output', {'text': out})

    def run(self):
        n = 0
        while True:
            self.step()
            if n % 20 == 0:
                self.store.update('system', system.collect(self._cpu))
            self.store.check_stale()
            if self.auto and not self._running and time.time() - self._t_end > 8:
                self.start_mission({'track_s': 20})
            n += 1
            time.sleep(0.1)

    # --- backend interface --------------------------------------------------------------------
    def system(self):
        return self.store.section('system') or {}

    def camera_open(self):
        pass

    def camera_close(self):
        pass

    def camera_jpeg(self, with_overlay=True):
        t = time.time()
        yy, xx = np.mgrid[0:480, 0:640]
        rgb = np.stack([(xx // 40 + yy // 40) % 2 * 40 + 30] * 3, axis=-1).astype(np.uint8)
        tgt = self.store.section('target')
        if tgt and tgt['state_name'] == 'TRACKING':
            b = tgt['bbox_px']
            x0, x1 = int(b['cx'] - b['w'] / 2), int(b['cx'] + b['w'] / 2)
            rgb[80:380, max(0, x0):min(640, x1)] = (150, 120, 90)
        jpg = overlay.encode(rgb, 70, 480, target=tgt, mission=self.store.section('mission'),
                             vehicle=self.store.section('vehicle'), overlay=with_overlay)
        return int(t * 10), jpg

    def start_mission(self, goal):
        with self._lock:
            if self._running:
                return {'accepted': False, 'available': True, 'message': 'refused: a mission is running'}
            self._running, self._t0 = True, time.time()
        self.store.add_event('api', f"mission started (track {goal['track_s']:.0f} s) [demo]", 'info')
        return {'accepted': True, 'available': True, 'message': 'mission started [demo]'}

    def cancel_mission(self):
        with self._lock:
            was, self._running = self._running, False
        msg = 'cancelling 1 mission(s): the drone lands' if was else 'no running mission'
        self.store.add_event('api', f'cancel requested: {msg} [demo]', 'warning' if was else 'info')
        return {'ok': was, 'available': True, 'message': msg}

    def submit_command(self, text, execute, use_llm, intent_json=''):
        """Like intent_bridge, with the real keyword parser when drone_llm is installed; questions
        get a canned answer from the demo data (no LLM in the demo)."""
        try:
            from drone_llm.core.decide import from_confirmed, interpret
            from drone_llm.core.intent import Limits
            from drone_llm.core.keyword_parser import is_question
        except ImportError:
            return {'understood': True, 'executed': False, 'available': True,
                    'intent_json': '{"action": "search_and_track", "track_duration_s": 20}',
                    'message': f'DRY RUN [demo]: would search and track 20 s ("{text}")'}
        lim = Limits()
        it = from_confirmed(intent_json, lim) if intent_json else interpret(text, lim)
        i = it.intent
        out = {'understood': it.understood, 'executed': False, 'available': True,
               'intent_json': i.to_json()}
        if use_llm and not intent_json and is_question(text) and i.action == 'status':
            v = self.store.section('vehicle') or {}
            b = (v.get('battery') or {}).get('voltage_v')
            h = (v.get('height') or {}).get('above_ground_m')
            i.action = 'answer'
            i.answer = (f'[demo answer] The battery is at {b:.2f} V and the drone is '
                        f'{h:.2f} m above the ground in {v.get("mode", "?")}.'
                        if b is not None and h is not None else '[demo answer] No data yet.')
            out.update(understood=True, intent_json=i.to_json(), message=f'ANSWER: {i.answer}')
            return out
        if not it.understood:
            out['message'] = f'REFUSED ({it.source}): ' + ('; '.join(it.fails) or i.reason)
        elif i.action == 'search_and_track' and execute:
            r = self.start_mission({'track_s': i.track_duration_s or 60.0})
            out.update(executed=r['accepted'], message=('STARTED: ' if r['accepted'] else '')
                       + r['message'] + ': ' + i.describe())
        elif i.action == 'search_and_track':
            out['message'] = f'DRY RUN ({it.source}): would {i.describe()} [demo]'
        elif i.action == 'cancel':
            out['message'] = 'DRY RUN: would cancel the running mission (the drone lands)'
        else:
            out['message'] = f'STATUS [demo]: mission {"running" if self._running else "IDLE"}'
        if it.notes:
            out['message'] += ''.join(f' NOTE: {n}.' for n in it.notes)
        return out

    def preflight(self):
        ok = not self._running
        return {'ok': ok, 'available': True,
                'message': 'PRE-FLIGHT OK [demo]' if ok else 'PF8 ARMED: vehicle is armed [demo]'}

    def safety_reset(self):
        return {'ok': True, 'available': True, 'message': 'nothing latched [demo]'}


def main():
    import uvicorn

    from drone_api.app import Settings, create_app

    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--host', default='0.0.0.0')
    ap.add_argument('--port', type=int, default=8000)
    ap.add_argument('--token', default='')
    ap.add_argument('--allow-commands', action='store_true')
    ap.add_argument('--no-auto-mission', action='store_true',
                    help='do not start a demo mission by itself')
    a = ap.parse_args()
    backend = DemoBackend()
    backend.auto = not a.no_auto_mission
    threading.Thread(target=backend.run, daemon=True).start()
    app = create_app(backend, Settings(api_token=a.token, allow_commands=a.allow_commands))
    print(f'DEMO drone API on http://{a.host}:{a.port}/  (docs: /docs)')
    uvicorn.run(app, host=a.host, port=a.port, log_level='warning')


if __name__ == '__main__':
    main()
