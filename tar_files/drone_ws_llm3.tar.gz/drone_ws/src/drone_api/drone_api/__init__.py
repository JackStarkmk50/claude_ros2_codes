"""Read-mostly HTTP/WebSocket API for dashboards and mobile apps."""
