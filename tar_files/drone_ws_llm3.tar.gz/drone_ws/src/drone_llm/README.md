# drone_llm

Intent layer: turns natural-language commands into validated structured mission requests.

See `ARCHITECTURE.md` (§3 nodes, §4 topics, §5 services, §6 actions) for the full contract of this package.

| Executable | Responsibility | Implemented in |
|---|---|---|
| `intent_bridge` | Natural language to validated structured intent to SearchAndTrack goal. | Phase 13 |

Current state: **Phase 13, real.** Service `/drone/llm/submit_command`. The logic lives in
`drone_llm/core/` (no ROS, unit-tested): `keyword_parser.py` (parser + guard), `intent.py`
(5 actions incl. read-only `answer`, + validation), `llm_client.py` (local Ollama model or the
Claude API, standard library only), `facts.py` (live data as text for questions), `decide.py`
(guard, stop bypass, parse, validate, Confirm, state check). Operator tools: `tools/command.py`,
`tools/llm_eval.py` (score models). Steps: `docs/PHASE13_LLM.md`, `docs/LOCAL_LLM.md`.

Run one node on its own:

```bash
ros2 run drone_llm intent_bridge --ros-args --params-file $(ros2 pkg prefix drone_bringup)/share/drone_bringup/config/drone.yaml
```

Test:

```bash
colcon test --packages-select drone_llm && colcon test-result --verbose
```
