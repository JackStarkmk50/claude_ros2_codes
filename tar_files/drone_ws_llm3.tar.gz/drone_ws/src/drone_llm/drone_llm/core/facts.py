"""Live data -> short plain-text facts the LLM may use to answer a question.

Pure Python, no ROS: it reads attributes, so it works on the ROS messages and on simple test
objects alike. The facts are read-only context; nothing the LLM writes back can change them.
"""

import math

LEVELS = ('OK', 'DEGRADED', 'HOLD', 'ABORT', 'OVERRIDE')
LANDED = {0: 'unknown', 1: 'on the ground', 2: 'in the air', 3: 'taking off', 4: 'landing'}
TARGET_STATES = ('no person selected', 'person seen, not confirmed yet', 'tracking a person',
                 'person lost')


def _ok(x):
    return isinstance(x, (int, float)) and not (isinstance(x, float) and math.isnan(x))


def _yn(b):
    return 'yes' if b else 'no'


def _age_note(name, ages, stale_after_s):
    a = (ages or {}).get(name)
    if a is not None and a > stale_after_s:
        return f' (this data is {a:.0f} s old: may be out of date)'
    return ''


def _vehicle(v):
    parts = [f'FCU connected: {_yn(v.connected)}', f'flight mode: {v.mode or "unknown"}',
             f'armed: {_yn(v.armed)}', f'state: {LANDED.get(int(v.landed_state), "unknown")}']
    bat = f'battery: {v.battery_voltage_v:.2f} V'
    if _ok(v.battery_remaining):
        bat += f', {v.battery_remaining * 100:.0f} % remaining'
    if _ok(v.battery_current_a):
        bat += f', drawing {v.battery_current_a:.1f} A'
    parts.append(bat)
    if v.height_valid and _ok(v.height_above_ground_m):
        parts.append(f'height above ground: {v.height_above_ground_m:.2f} m (rangefinder)')
    else:
        parts.append('height above ground: not valid right now')
    parts.append(f'heading: {(90.0 - math.degrees(v.yaw_rad)) % 360.0:.0f} deg (compass)')
    parts.append(f'RC transmitter seen: {_yn(v.rc_present)}')
    ekf = v.ekf_attitude_ok and v.ekf_velocity_horiz_ok
    parts.append('EKF (position estimate): ' + ('ok' if ekf else 'NOT ok'))
    if v.last_prearm_text:
        parts.append(f'last pre-arm message from the FCU: "{v.last_prearm_text}"')
    return 'Drone: ' + '; '.join(parts) + '.'


def _safety(s):
    parts = [f'level {LEVELS[s.level] if 0 <= s.level < len(LEVELS) else s.level}',
             f'motion allowed: {_yn(s.motion_allowed)}']
    if s.latched:
        parts.append('a fault is LATCHED (needs a reset on the ground)')
    if list(s.active_faults):
        parts.append('faults: ' + ', '.join(s.active_faults))
    if list(s.warnings):
        parts.append('warnings: ' + ', '.join(s.warnings))
    parts.append('ready for takeoff: ' + ('yes' if s.preflight_ok else
                                          'no (' + ('; '.join(s.preflight_failures) or '?') + ')'))
    return 'Safety: ' + '; '.join(parts) + '.'


def _mission(m):
    t = f'Mission: {m.state_name or "unknown"}'
    if m.detail:
        t += f' ({m.detail})'
    if m.elapsed_s and m.state_name not in ('IDLE',):
        t += f', running for {m.elapsed_s:.0f} s'
    return t + '.'


def _target(t):
    st = TARGET_STATES[t.state] if 0 <= t.state < len(TARGET_STATES) else 'unknown'
    if t.state == 0:
        return 'Camera / person detection: no person selected.'
    side = ('left of centre' if t.error_x_norm < -0.2 else
            'right of centre' if t.error_x_norm > 0.2 else 'near the centre')
    txt = f'Camera / person detection: {st}, {side} of the picture, confidence {t.confidence:.2f}'
    if t.state == 3:
        txt += f', last seen {t.time_since_seen_s:.0f} s ago'
    return txt + '.'


def _flow(f):
    if not f.source_seen:
        return 'Optical flow sensor: no data seen.'
    txt = (f'Optical flow sensor: quality {f.quality}/255, healthy for flight: '
           f'{_yn(f.healthy_for_flight)}')
    if f.reason and not f.healthy_for_flight:
        txt += f' ({f.reason})'
    return txt + '.'


def _limits(lim):
    return (f'Limits (set in drone.yaml, cannot be changed by a command): altitude '
            f'{lim.min_altitude_m:.1f} to {lim.max_altitude_m:.1f} m, search up to '
            f'{lim.max_search_timeout_s:.0f} s, tracking up to {lim.max_track_duration_s:.0f} s, '
            f'default tracking {lim.default_track_duration_s:.0f} s, flying closer to a person: '
            + ('allowed' if lim.approach_enabled else 'switched off') + '.')


SECTIONS = (('vehicle', _vehicle, 'Drone: no data (is fcu_state_node running?).'),
            ('safety', _safety, 'Safety: no data (is safety_supervisor running?).'),
            ('mission', _mission, 'Mission: no data (is mission_manager running?).'),
            ('target', _target, 'Camera / person detection: no data (is perception running?).'),
            ('flow', _flow, 'Optical flow sensor: no data.'))


def build(data, ages=None, limits=None, stale_after_s=2.0):
    """data: {'vehicle': msg or None, 'safety': ..., 'mission': ..., 'target': ..., 'flow': ...}
    ages: {'vehicle': seconds since received, ...}. Returns the facts as a few lines of text."""
    lines = []
    for name, fn, missing in SECTIONS:
        msg = (data or {}).get(name)
        if msg is None:
            lines.append(missing)
            continue
        try:
            lines.append(fn(msg) + _age_note(name, ages, stale_after_s))
        except Exception as e:                   # a bad field must not break a question
            lines.append(f'{name}: unreadable ({type(e).__name__})')
    if limits is not None:
        lines.append(_limits(limits))
    return '\n'.join(lines)
