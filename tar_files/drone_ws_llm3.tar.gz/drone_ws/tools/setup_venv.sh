#!/usr/bin/env bash
# Creates ~/drone_venv for pip-only packages. Safe to re-run.
set -euo pipefail

VENV="$HOME/drone_venv"
if [ ! -d "$VENV" ]; then
  python3 -m venv --system-site-packages "$VENV"
fi

# numpy is pinned to Ubuntu 24.04's version: apt-built cv_bridge breaks with numpy 2.x.
# setuptools is NOT upgraded here: colcon on Jazzy fails with very new setuptools.
"$VENV/bin/pip" install "numpy==1.26.4" onnxruntime pymavlink anthropic
# web API (drone_api): websockets is needed for the live WebSocket feed
"$VENV/bin/pip" install fastapi uvicorn websockets

"$VENV/bin/python" -c "import numpy, onnxruntime, pymavlink, fastapi, uvicorn, websockets; print('venv ok, numpy', numpy.__version__, 'fastapi', fastapi.__version__)"
