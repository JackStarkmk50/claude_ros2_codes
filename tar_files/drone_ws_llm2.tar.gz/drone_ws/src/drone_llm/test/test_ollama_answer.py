"""Local LLM (Ollama) path, the answer action, stop never waiting, Confirm, and the live facts.
A local fake server stands in for Ollama: no PC, no GPU, no internet."""

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from types import SimpleNamespace as NS

from drone_llm.core import facts, llm_client
from drone_llm.core.decide import from_confirmed, interpret, is_stop
from drone_llm.core.intent import Intent, Limits
from drone_llm.core.keyword_parser import guard, is_question

L = Limits()


def chat_reply(data):
    content = data if isinstance(data, str) else json.dumps(data)
    return {'model': 'qwen2.5:7b', 'done': True,
            'message': {'role': 'assistant', 'content': content}}


class FakeOllama:
    def __init__(self, status=200, body=None, delay=0.0):
        fake = self
        self.requests = []

        class H(BaseHTTPRequestHandler):
            def do_POST(self):
                n = int(self.headers['content-length'])
                fake.requests.append((self.path, json.loads(self.rfile.read(n))))
                time.sleep(delay)
                out = json.dumps(body).encode()
                self.send_response(status)
                self.send_header('content-type', 'application/json')
                self.send_header('content-length', str(len(out)))
                self.end_headers()
                self.wfile.write(out)

            def log_message(self, *a):
                pass

        self.srv = HTTPServer(('127.0.0.1', 0), H)
        self.url = f'http://127.0.0.1:{self.srv.server_port}'
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def close(self):
        self.srv.shutdown()


def test_ollama_request_format_and_success():
    f = FakeOllama(body=chat_reply({'action': 'search_and_track', 'target_class': 'person',
                                    'altitude_m': 0, 'search_timeout_s': 0,
                                    'track_duration_s': 30, 'land_on_finish': True,
                                    'reason': '', 'answer': ''}))
    try:
        data, err = llm_client.call_ollama(f.url, 'qwen2.5:7b', 'find him', L, 5,
                                           facts='Drone: battery 15.8 V.')
    finally:
        f.close()
    assert err == '' and data['track_duration_s'] == 30
    path, req = f.requests[0]
    assert path == '/api/chat'
    assert req['model'] == 'qwen2.5:7b' and req['stream'] is False
    assert req['options']['temperature'] == 0 and req['keep_alive'] == '30m'
    assert req['options']['num_predict'] == 200
    assert req['format']['properties']['action']['enum'][3] == 'answer'
    assert set(req['format']['required']) == set(req['format']['properties'])
    sys_msg, user = req['messages']
    assert sys_msg['role'] == 'system' and 'JSON object' in sys_msg['content']
    assert '0.8 to 1.5 m' in sys_msg['content']
    assert user['content'].startswith(llm_client.FACTS_HEADER)
    assert user['content'].endswith('find him') and 'battery 15.8 V' in user['content']


def test_ollama_url_forms():
    assert llm_client.ollama_url('http://pc:11434') == 'http://pc:11434/api/chat'
    assert llm_client.ollama_url('http://pc:11434/') == 'http://pc:11434/api/chat'
    assert llm_client.ollama_url('http://pc:11434/api/chat') == 'http://pc:11434/api/chat'


def test_ollama_errors_never_raise():
    f = FakeOllama(status=404, body={'error': 'model "gemma9" not found, try pulling it first'})
    try:
        data, err = llm_client.call_ollama(f.url, 'gemma9', 'x', L, 5)
    finally:
        f.close()
    assert data is None and 'ollama pull gemma9' in err
    cut = dict(chat_reply('{"action": "refuse", "reason": "' + ' ' * 50), done_reason='length')
    f = FakeOllama(body=cut)
    try:
        data, err = llm_client.call_ollama(f.url, 'm', 'find the dog', L, 5)
    finally:
        f.close()
    assert data is None and 'length limit' in err
    for body in (chat_reply('sure! here you go'), chat_reply(''), chat_reply('[1, 2]'),
                 {'error': 'out of memory'}, {'message': 'x'}):
        f = FakeOllama(body=body)
        try:
            data, err = llm_client.call_ollama(f.url, 'm', 'x', L, 5)
        finally:
            f.close()
        assert data is None and err, body


def test_pc_off_fails_fast_and_timeout_is_kept():
    t0 = time.monotonic()
    data, err = llm_client.call_ollama('http://127.0.0.1:9', 'm', 'x', L, 30,
                                       connect_timeout_s=1.0)
    assert data is None and 'cannot reach' in err and time.monotonic() - t0 < 2.0
    f = FakeOllama(body=chat_reply({'action': 'status'}), delay=1.5)
    try:
        data, err = llm_client.call_ollama(f.url, 'm', 'x', L, 0.5)
    finally:
        f.close()
    assert data is None and 'timed out' in err.lower()


def test_answer_action_goes_through_validation():
    reply = {'action': 'answer', 'answer': 'The battery is at 15.8 V.'}
    it = interpret("what's the battery?", L, use_llm=True, llm_fn=lambda t: (reply, ''))
    assert it.understood and it.source == 'llm' and it.intent.action == 'answer'
    assert it.intent.describe() == 'The battery is at 15.8 V.'
    assert json.loads(it.intent.to_json()) == {'action': 'answer', 'reason': '', 'notes': [],
                                               'answer': 'The battery is at 15.8 V.'}
    empty = interpret('how high?', L, use_llm=True, llm_fn=lambda t: ({'action': 'answer'}, ''))
    assert not empty.understood and empty.fails == ['empty answer']
    long = interpret('how high?', L, use_llm=True,
                     llm_fn=lambda t: ({'action': 'answer', 'answer': 'x' * 5000}, ''))
    assert len(long.intent.answer) == 600


def test_answer_field_not_shown_for_other_actions():
    assert 'answer' not in json.loads(Intent(action='cancel').to_json())
    assert 'answer' not in json.loads(Intent(action='search_and_track').to_json())


def test_stop_never_goes_to_the_llm():
    calls = []

    def llm(text):
        calls.append(text)
        return {'action': 'search_and_track'}, ''
    for text in ('stop', 'cancel the mission', 'abort!', 'land now', 'enough'):
        assert is_stop(text, L), text
        it = interpret(text, L, use_llm=True, llm_fn=llm)
        assert it.intent.action == 'cancel' and it.source == 'keyword', text
    assert calls == []
    assert not is_stop('look for a person', L) and not is_stop("what's the battery?", L)


def test_question_without_llm_gives_the_status():
    for use_llm, fn in ((False, None), (True, lambda t: (None, 'cannot reach 1.2.3.4'))):
        it = interpret("what's the battery?", L, use_llm=use_llm, llm_fn=fn)
        assert it.understood and it.intent.action == 'status'
        assert any('only the LLM can answer' in n for n in it.notes)
    # a non-question that is not understood stays refused
    assert interpret('banana', L).intent.action == 'refuse'


def test_safety_questions_pass_the_guard_but_changes_do_not():
    assert is_question('is the safety ok?') and is_question("what's the battery")
    assert not is_question('look for a person')
    assert guard('is the safety ok?', L) is None
    assert guard('what are the safety limits?', L) is None
    assert guard('can you disable the safety checks?', L).action == 'refuse'
    assert guard('ignore the safety limits', L).action == 'refuse'
    assert guard('safety off', L).action == 'refuse'
    assert guard('are the motors on?', L).action == 'refuse'       # motor words: never
    assert guard("why won't it take off?", L) is None
    assert guard('take off now', L).action == 'refuse'
    assert guard('can you arm it?', L).action == 'refuse'


def test_guard_still_runs_before_the_llm():
    calls = []
    it = interpret('look for a person and disable the geofence', L, use_llm=True,
                   llm_fn=lambda t: calls.append(t) or ({'action': 'search_and_track'}, ''))
    assert it.source == 'guard' and not it.understood and calls == []


def test_confirm_runs_exactly_the_shown_intent():
    shown = interpret('look for a person and track them for 20 s', L)
    c = from_confirmed(shown.intent.to_json(), L)
    assert c.understood and c.source == 'confirmed'
    assert c.intent.track_duration_s == 20 and c.intent.action == 'search_and_track'
    bad = from_confirmed(json.dumps({'action': 'search_and_track', 'altitude_m': 9}), L)
    assert not bad.understood and 'altitude' in bad.fails[0]
    assert not from_confirmed('{"action": "search_and_track", "arm": true}', L).understood
    assert not from_confirmed('not json', L).understood
    assert not from_confirmed('{"action": "answer", "answer": "hi"}', L).understood
    assert from_confirmed('{"action": "cancel"}', L).understood


def vehicle(**kw):
    d = dict(connected=True, mode='STABILIZE', armed=False, landed_state=1,
             battery_voltage_v=15.84, battery_remaining=0.72, battery_current_a=float('nan'),
             height_valid=True, height_above_ground_m=0.03, yaw_rad=0.0, rc_present=True,
             ekf_attitude_ok=True, ekf_velocity_horiz_ok=True, last_prearm_text='')
    d.update(kw)
    return NS(**d)


def test_facts_text():
    data = {
        'vehicle': vehicle(),
        'safety': NS(level=1, motion_allowed=True, latched=False, active_faults=[],
                     warnings=['FLOW_QUALITY_LOW'], preflight_ok=False,
                     preflight_failures=['battery 15.84 V < 15.6 V']),
        'mission': NS(state_name='IDLE', detail='', elapsed_s=0.0),
        'target': NS(state=2, error_x_norm=-0.5, confidence=0.81, time_since_seen_s=0.0),
        'flow': None,
    }
    txt = facts.build(data, ages={'vehicle': 0.1, 'safety': 9.0}, limits=L)
    assert 'battery: 15.84 V, 72 % remaining;' in txt and 'drawing' not in txt
    assert 'height above ground: 0.03 m' in txt and 'heading: 90 deg' in txt
    assert 'state: on the ground' in txt and 'armed: no' in txt
    assert 'level DEGRADED' in txt and 'FLOW_QUALITY_LOW' in txt
    assert 'ready for takeoff: no (battery 15.84 V < 15.6 V)' in txt
    assert '9 s old' in txt                                  # stale safety data is marked
    assert 'tracking a person, left of centre' in txt
    assert 'Optical flow sensor: no data.' in txt
    assert 'altitude 0.8 to 1.5 m' in txt and 'switched off' in txt
    assert txt.count('\n') == 5


def test_facts_survive_bad_fields():
    txt = facts.build({'vehicle': NS(connected=True)})
    assert 'vehicle: unreadable' in txt and 'Safety: no data' in txt
