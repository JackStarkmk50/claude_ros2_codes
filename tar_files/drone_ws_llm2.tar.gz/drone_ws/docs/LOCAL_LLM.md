# Local LLM: commands and questions with a model on your PC

The drone understands text in two ways. The **keyword parser** runs on the Pi and always works.
The **LLM** is Ollama on your Windows PC (RTX 3050), reached over Tailscale. No internet and no
API key are needed. If the PC is off, everything falls back to the keyword parser.

```
phone / laptop browser ──► Pi: drone_api (port 8000) ──► Pi: intent_bridge ──► PC: Ollama (11434)
     chat box                checks the token              guard, validation,      turns words into
                                                           mission, safety         a plan or an answer
```

## What the LLM can and cannot do

| You type | What happens |
|---|---|
| "what's the battery?", "is anyone in view?", "why won't it take off?" | **answer** in words, from the live data the Pi sends with the question. Read-only, never moves the drone. |
| "look for a person and watch them for 20 seconds" | a **plan** (search_and_track, track 20 s). It only starts after **Confirm**, and only if every gate below is open. |
| "stop", "cancel", "abort", "land now" | handled **on the Pi at once**. Never sent to the LLM, never waits for a busy one. |
| "arm the motors", "disable the geofence", "fly to the kitchen" | refused by the guard **before** the LLM sees it, or refused by validation. |

The LLM can only fill a fixed form (action, times, altitude, answer). It has no field for
arming, positions, speeds or safety settings. Its output is checked like any other input:
limits, then the drone's state, then mission_manager, then safety_supervisor.

**Gates for a mission to actually start** (all of them):
1. API token used, and `drone_api` → `allow_commands: true`
2. `intent_bridge` → `allow_execute: true`
3. Stack launched with `enable_fcu_output:=true allow_arming:=true`
4. Every safety check passes (preflight, battery, flow, height)

**Confirm** runs exactly the plan you saw. The Pi does not ask the LLM again, so a second
reading cannot come out different. The plan is still checked again at that moment.

## PC setup (Windows, once)

1. `OLLAMA_HOST` = `0.0.0.0` as a system environment variable. **Done.** Quit Ollama from the
   tray and start it again after any change.
2. Open port 11434 for Tailscale only. Run this in PowerShell **as administrator**:
   ```powershell
   New-NetFirewallRule -DisplayName "Ollama (Tailscale only)" -Direction Inbound -Protocol TCP -LocalPort 11434 -RemoteAddress 100.64.0.0/10 -Action Allow
   ```
3. Check the model is there and runs on the GPU:
   ```powershell
   ollama list
   ollama run gemma4:e4b "say hi"
   ollama ps
   ```
   **EXPECTED** `ollama ps` shows `gemma4:e4b` with `100% GPU`. If it says CPU, the model is
   too big for the VRAM: try a smaller one (see "Choosing a model").

The Pi asks Ollama to keep the model loaded for 30 min after the last command
(`llm_keep_alive`). The first command after that loads it again, which takes 5 to 20 s.

## Pi: install and test (props OFF)

### Step 1: update

```bash
cp ~/drone_ws/src/drone_bringup/config/drone.yaml ~/drone.yaml.mine
tar -xzf drone_ws_llm.tar.gz -C ~/drone_ws --strip-components=1
python3 ~/drone_ws/tools/carry_settings.py ~/drone.yaml.mine --keep-new intent_bridge.llm_enabled intent_bridge.llm_model
cd ~/drone_ws && colcon build --symlink-install
bash ~/drone_ws/tools/verify_workspace.sh
```

The `SubmitCommand` service gained a field, so rebuild everything (not only one package).
The tarball has no `models/` or `sim/` folders, so your YOLO model stays as it is. `--keep-new`
switches the LLM on even if your old file says `llm_enabled: false`, and takes the new
default model (gemma4:e4b) instead of your old `qwen2.5:7b`. Your `allow_execute`
is carried over: it should be `false` for these tests.
**EXPECTED** `0 errors, 0 failures` and `WORKSPACE CHECK: ALL PASSED`.

### Step 2: can the Pi reach the PC?

```bash
curl -s --max-time 5 http://100.124.153.70:11434/api/tags | head -c 300; echo
```

**EXPECTED** JSON listing your models. **If it hangs**, the firewall rule (PC step 2) is missing.
**If you get "connection refused"**, Ollama is not listening on 0.0.0.0 (PC step 1, restart Ollama).

### Step 3: score the model (no ROS needed)

```bash
python3 ~/drone_ws/tools/llm_eval.py -v
```

This sends 32 sentences (commands, hostile texts, questions) with fixed fake drone data, and
prints two scores. **LLM** means the model alone got it right. **FINAL** is what the drone would do
(guard, LLM and validation together). FINAL should be 30+ of 32. To compare models:

```bash
python3 ~/drone_ws/tools/llm_eval.py --model gemma4:e4b qwen2.5:7b
```

The result is appended to `~/drone_ws/llm_eval_report.txt`. Send me that file.

### Step 4: through the stack

Terminal A:

```bash
source ~/drone_ws/env.sh
ros2 launch drone_bringup bringup.launch.py
```

**EXPECTED** `intent_bridge ... up: LLM ollama gemma4:e4b at http://100.124.153.70:11434` and,
shortly after, `LLM server http://100.124.153.70:11434 reachable`.

Terminal B:

```bash
source ~/drone_ws/env.sh
cd ~/drone_ws/tools
python3 command.py --llm "what's the battery?"
python3 command.py --llm "is the drone ready to take off?"
python3 command.py --llm "look for a person and keep them in view for 20 seconds"
python3 command.py --llm "stop"
python3 command.py --llm --selftest
```

**EXPECTED**
- The questions print `ANSWER: ...` with the real voltage and state, and `(LLM x.x s)` at the end.
- The mission sentence prints `DRY RUN (llm): would search for a person ... track 20 s ...`.
- `stop` prints at once, with no `(LLM ...)`.
- The self-test ends with `COMMAND SELFTEST: ALL PASSED`.

### Step 5: PC off

Quit Ollama on the PC (tray icon → Quit), then:

```bash
python3 command.py --llm "what's the height?"
```

**EXPECTED** within about 3 s: `STATUS: ... height ... NOTE: LLM not used (cannot reach
100.124.153.70:11434 ...)`. Start Ollama again afterwards.

### Step 6: the chat box

Start the API (`ros2 launch drone_api api.launch.py`). Open `http://<pi>:8000/?token=<token>`
on the phone. The chat box is below the Pi card.

- Ask "what's the battery?": you get an answer in words.
- Type "look for a person for 20 seconds": you get the plan and a **Confirm** button. The
  button is grey while `allow_commands` is false. Don't press it in this test.
- Type "stop", or press the red **Stop**: you get `cancelling ...` or `no running mission`.

## Settings (`drone.yaml` → `intent_bridge`)

| Key | Value | Meaning |
|---|---|---|
| `llm_enabled` | `true` | false = keyword parser only |
| `llm_provider` | `"ollama"` | or `"anthropic"` (Claude API, needs internet and `ANTHROPIC_API_KEY`) |
| `llm_model` | `"gemma4:e4b"` | any name from `ollama list` (`"qwen2.5:7b"` = text-only option) |
| `llm_api_url` | `"http://100.124.153.70:11434"` | the PC's Tailscale IP |
| `llm_timeout_s` | `30.0` | longest wait for a reply (includes loading the model) |
| `llm_connect_timeout_s` | `3.0` | PC off: give up after this and use the keyword parser |
| `llm_keep_alive` | `"30m"` | how long the PC keeps the model on the GPU |
| `llm_num_ctx` | `4096` | context size; smaller uses less VRAM |
| `llm_num_predict` | `200` | longest reply in tokens; a model stuck inside its JSON stops here instead of at the timeout |
| `llm_send_facts` | `true` | send live data with each command, so questions can be answered |

`drone_api` → `command_timeout_s: 45.0` is how long the API waits for intent_bridge.

## Choosing a model (8 GB VRAM)

Use **one** model for everything, so Ollama doesn't swap models in and out of the GPU (several
seconds per swap). `llm_eval.py` results from 2026-10-16 (RTX 3050 8 GB, before the reply cap):

| Model | Model alone | Drone (FINAL) | Hostile texts refused by the model | Typical / slowest | Images |
|---|---|---|---|---|---|
| **`gemma4:e4b`** (default) | **31/32** | **31/32** | **11/11** | 2.7 s / 10 s | yes |
| `qwen2.5:7b` | 29/32 | 31/32 | 9/11 (2 hung 60 s) | 2.0 s / 60 s | no |
| `gemma3:4b` | 27/32 | 27/32 | 7/11, lost the numbers | 2.0 s / 7 s | yes |

- gemma4:e4b: best, and it reads text and images with the same loaded model. First load about
  50 s from disk, then 2 to 3 s per reply. `ollama ps` showed 100% GPU.
- qwen2.5:7b: good text model, kept as the one-line fallback. Its two 60 s hangs are fixed by
  `llm_num_predict`.
- gemma3:4b: do not use. It accepted "look for a person at 10 m", "track for 2 hours" and
  "chase that guy" as normal missions by dropping the numbers.
- `gemma4:e4b-it-qat` (about 6 GB instead of about 10 GB to download) is worth one eval run if GPU
  memory gets tight once images are added.

`embeddinggemma` is not usable here. It only makes text vectors for search; it cannot reply.

## Troubleshooting

| Symptom | Cause |
|---|---|
| `cannot reach 100.124.153.70:11434 (timeout)` | PC asleep, Tailscale down on the PC, or the firewall rule is missing |
| `connection refused` | Ollama not running, or not listening on 0.0.0.0 |
| `reply cut off at the length limit` | The model got stuck inside its reply; the keyword parser was used. Rare; if frequent, try the other model |
| `model "x" is not installed on the PC` | `ollama pull x` on the PC, or fix `llm_model` |
| First command slow (10 to 20 s), then fast | The model was loading. Normal after 30 min idle |
| Every command slow (> 5 s) | Model partly on the CPU (`ollama ps`): use a smaller model |
| `busy with the previous command` | A slow LLM call is still running. `stop` still works |
| `intent_bridge: no answer within 45 s` (API) | The LLM is slower than that: raise `drone_api` `command_timeout_s`, or use a smaller model |
