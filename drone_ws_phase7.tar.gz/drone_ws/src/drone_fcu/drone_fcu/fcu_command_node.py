"""fcu_command_node: the single output from the Pi to the flight controller.

Phase 6: the setpoint path. Every tick (10 Hz) it decides what the FCU should get
(drone_fcu/core/setpoint.py): nothing, HOLD (zero velocity) or the command safety_supervisor
validated. Setpoints go only to /mavros/setpoint_raw/local, only while armed in GUIDED, and
only if output_enabled is true. With output_enabled false (bench mode, the default) the
publisher to MAVROS is never even created; the node reports what it WOULD send on
/drone/fcu/output_state.

Flight operations (arm, takeoff, land) arrive in Phase 8. allow_arming has no effect yet.
"""

import time

import rclpy
from mavros_msgs.msg import PositionTarget
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from rclpy.time import Time
from std_msgs.msg import String

from drone_fcu.core.setpoint import COMMAND, SILENT, SetpointConfig, decide
from drone_interfaces.msg import ControlCommand, SafetyStatus, VehicleState

# Parameter defaults. drone_bringup/config/drone.yaml overrides them.
PARAMETERS = {
    'output_enabled': False,          # [AIRCRAFT] launch arg enable_fcu_output
    'allow_arming': False,            # [AIRCRAFT] launch arg allow_arming (used from Phase 8)
    'rate_hz': 10.0,
    'cmd_timeout_s': 0.3,
    'safety_stale_s': 0.5,
    'safety_stale_land_s': 1.0,
    'vehicle_timeout_s': 1.0,
    # flight operations (Phase 8)
    'set_mode_timeout_s': 3.0,
    'arm_timeout_s': 3.0,
    'takeoff_start_timeout_s': 3.0,
    'max_arm_to_takeoff_s': 2.0,
    'min_climb_rate_mps': 0.2,
    'alt_tol_m': 0.15,
    'stable_window_s': 2.0,
    'stable_timeout_s': 8.0,
    'stable_max_vz_mps': 0.15,
    'stable_max_vxy_mps': 0.2,
    'min_descent_rate_mps': 0.1,
    'disarm_wait_s': 5.0,
    'ground_height_max_m': 0.25,
}

# velocity + yaw rate only: ignore position, acceleration and yaw angle
TYPE_MASK = (PositionTarget.IGNORE_PX | PositionTarget.IGNORE_PY | PositionTarget.IGNORE_PZ
             | PositionTarget.IGNORE_AFX | PositionTarget.IGNORE_AFY | PositionTarget.IGNORE_AFZ
             | PositionTarget.IGNORE_YAW)

STATE_QOS = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                       durability=DurabilityPolicy.VOLATILE)
SAFETY_QOS = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                        durability=DurabilityPolicy.TRANSIENT_LOCAL)
SETPOINT_QOS = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                          durability=DurabilityPolicy.VOLATILE)


class Latest:

    def __init__(self):
        self.msg = None
        self.time = None

    def set(self, msg):
        self.msg = msg
        self.time = time.monotonic()

    def age(self, now):
        return now - self.time if self.time is not None else float('inf')


class FcuCommandNode(Node):

    def __init__(self):
        super().__init__('fcu_command_node')
        for name, default in PARAMETERS.items():
            self.declare_parameter(name, default)
        p = {name: self.get_parameter(name).value for name in PARAMETERS}
        self.p = p
        self.cfg = SetpointConfig(
            cmd_timeout_s=p['cmd_timeout_s'], safety_stale_s=p['safety_stale_s'],
            safety_stale_land_s=p['safety_stale_land_s'],
            vehicle_timeout_s=p['vehicle_timeout_s'])

        self.vehicle = Latest()
        self.safety = Latest()
        self.command = Latest()
        self.create_subscription(VehicleState, '/drone/vehicle_state', self.vehicle.set,
                                 STATE_QOS)
        self.create_subscription(SafetyStatus, '/drone/safety_status', self._on_safety,
                                 SAFETY_QOS)
        self.create_subscription(ControlCommand, '/drone/control/validated_command',
                                 self.command.set, STATE_QOS)
        self.state_pub = self.create_publisher(String, '/drone/fcu/output_state', 10)

        self.setpoint_pub = None
        if p['output_enabled']:
            self.setpoint_pub = self.create_publisher(
                PositionTarget, '/mavros/setpoint_raw/local', SETPOINT_QOS)
            self.get_logger().warn(
                '[AIRCRAFT] output_enabled=true: setpoints WILL be sent to the FCU while it is '
                'armed in GUIDED. Props off unless the phase says otherwise.')
        else:
            self.get_logger().info('bench mode: output_enabled=false, nothing is sent to MAVROS')
        if p['allow_arming']:
            self.get_logger().warn('[AIRCRAFT] allow_arming=true (no effect before Phase 8)')

        self._last_report = None
        self._land_reported = False
        self.create_timer(1.0 / p['rate_hz'], self._tick)

    def _on_safety(self, msg):
        # TRANSIENT_LOCAL hands us the last status even if it is old: judge age by its stamp
        age = (self.get_clock().now() - Time.from_msg(msg.header.stamp)).nanoseconds
        if age * 1e-9 < self.cfg.safety_stale_s:
            self.safety.set(msg)

    def _tick(self):
        now = time.monotonic()
        d = decide(self.cfg, self.vehicle.msg, self.vehicle.age(now), self.safety.msg,
                   self.safety.age(now), self.command.msg, self.command.age(now))

        if d.action != SILENT and self.setpoint_pub is not None:
            sp = PositionTarget()
            sp.header.stamp = self.get_clock().now().to_msg()
            sp.coordinate_frame = PositionTarget.FRAME_BODY_NED   # MAVROS: body FLU in
            sp.type_mask = TYPE_MASK
            sp.velocity.x, sp.velocity.y, sp.velocity.z = d.vx, d.vy, d.vz
            sp.yaw_rate = d.yaw_rate
            self.setpoint_pub.publish(sp)

        prefix = '' if self.setpoint_pub is not None or d.action == SILENT else 'WOULD SEND '
        text = f'{prefix}{d.action}: {d.reason}'
        if d.action == COMMAND:
            text += (f' (vx {d.vx:.2f} vy {d.vy:.2f} vz {d.vz:.2f} m/s, '
                     f'yaw_rate {d.yaw_rate:.3f} rad/s FLU)')
        if d.request_land:
            text += ' | LAND needed: safety_supervisor lost while airborne (LAND arrives in ' \
                    'Phase 8; the pilot must land)'
            if not self._land_reported:
                self.get_logger().error(text)
                self._land_reported = True
        else:
            self._land_reported = False
        self.state_pub.publish(String(data=text))

        # log when the kind of decision changes (numbers in the reason don't count)
        key = (d.action, d.reason.split('(')[0], d.request_land)
        if key != self._last_report:
            self.get_logger().info(text)
            self._last_report = key


def main(args=None):
    rclpy.init(args=args)
    node = FcuCommandNode()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        # A second Ctrl-C during cleanup (terminal + launch both send SIGINT) must not
        # print a traceback.
        try:
            node.destroy_node()
            rclpy.try_shutdown()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
