import math

from helpers import CFG, flow, flying_vehicle, ground_vehicle
from drone_safety.core.config import (LEVEL_ABORT, LEVEL_DEGRADED, LEVEL_HOLD, LEVEL_OK,
                                      LEVEL_OVERRIDE)
from drone_safety.core.supervisor import Inputs, SafetyCore


def inputs(v, fl=None, **kw):
    base = dict(vehicle=v, vehicle_age=0.1, flow=fl or flow(), flow_age=0.1,
                fcu_output=(True, True))
    base.update(kw)
    return Inputs(**base)


def test_ground_ok_and_preflight():
    core = SafetyCore(CFG)
    vd = core.update(0.0, inputs(ground_vehicle()))
    assert vd.level == LEVEL_OK and vd.preflight_ok and not vd.latched


def test_stale_telemetry_on_ground_holds_but_does_not_latch():
    core = SafetyCore(CFG)
    vd = core.update(0.0, inputs(ground_vehicle(), vehicle_age=3.0))
    assert vd.level == LEVEL_HOLD and not vd.latched
    assert core.update(1.0, inputs(ground_vehicle())).level == LEVEL_OK


def test_disconnect_in_flight_latches():
    core = SafetyCore(CFG)
    core.update(0.0, inputs(flying_vehicle()))
    vd = core.update(0.1, inputs(flying_vehicle(connected=False)))
    assert vd.level == LEVEL_HOLD and vd.latched
    vd = core.update(0.2, inputs(flying_vehicle()))
    assert vd.latched and not vd.motion_allowed


def test_flow_dip_degrades_then_aborts():
    core = SafetyCore(CFG)
    bad = flow(healthy_flight=False, reason='quality 40 < 100')
    assert core.update(0.0, inputs(flying_vehicle(), bad)).level == LEVEL_DEGRADED
    assert core.update(0.5, inputs(flying_vehicle(), bad)).level == LEVEL_DEGRADED
    vd = core.update(1.2, inputs(flying_vehicle(), bad))
    assert vd.level == LEVEL_ABORT and vd.request_land


def test_short_flow_dip_recovers():
    core = SafetyCore(CFG)
    core.update(0.0, inputs(flying_vehicle(), flow(healthy_flight=False)))
    assert core.update(0.5, inputs(flying_vehicle())).level == LEVEL_OK


def test_ekf_tilt_ceiling_battery_abort():
    for v in (flying_vehicle(ekf_velocity_horiz_ok=False),
              flying_vehicle(roll_rad=math.radians(40)),
              flying_vehicle(height_above_ground_m=2.5),
              flying_vehicle(battery_voltage_v=13.8)):
        vd = SafetyCore(CFG).update(0.0, inputs(v))
        assert vd.level == LEVEL_ABORT and vd.latched, v


def test_battery_warning_degrades():
    vd = SafetyCore(CFG).update(0.0, inputs(flying_vehicle(battery_voltage_v=14.2)))
    assert vd.level == LEVEL_DEGRADED and vd.motion_allowed


def test_height_band_hold_then_land_after_timeout():
    core = SafetyCore(CFG)
    low = flying_vehicle(height_above_ground_m=0.35)
    assert core.update(0.0, inputs(low)).level == LEVEL_HOLD
    assert core.update(4.0, inputs(low)).level == LEVEL_HOLD
    vd = core.update(5.5, inputs(low))
    assert vd.level == LEVEL_ABORT and vd.request_land


def test_mission_command_stream_stops():
    core = SafetyCore(CFG)
    vd = core.update(0.0, inputs(flying_vehicle(), stream_active=True, cmd_age=0.5))
    assert vd.level == LEVEL_HOLD and 'COMMAND_STALE' in vd.active_faults[0]


def test_override_latches_until_reset_on_ground():
    core = SafetyCore(CFG)
    core.update(0.0, inputs(flying_vehicle()))
    vd = core.update(0.1, inputs(flying_vehicle(mode='LOITER')))
    assert vd.level == LEVEL_OVERRIDE and vd.latched and not vd.motion_allowed
    ok, msg = core.reset(0.2, inputs(flying_vehicle(mode='LOITER')))
    assert not ok and 'armed' in msg
    vd = core.update(10.0, inputs(ground_vehicle(mode='LOITER')))
    assert vd.level == LEVEL_OVERRIDE and not vd.preflight_ok
    ok, msg = core.reset(10.1, inputs(ground_vehicle(mode='LOITER')))
    assert ok and 'OVERRIDE' in msg
    assert core.update(10.2, inputs(ground_vehicle())).level == LEVEL_OK


def test_reset_refused_while_something_is_still_wrong():
    core = SafetyCore(CFG)
    core.update(0.0, inputs(flying_vehicle()))
    core.update(0.1, inputs(flying_vehicle(connected=False)))
    ok, msg = core.reset(1.0, inputs(ground_vehicle(connected=False)))
    assert not ok and 'FCU_DISCONNECTED' in msg


def test_pi_temperature():
    assert SafetyCore(CFG).update(0.0, inputs(ground_vehicle(), cpu_temp_c=78.0)).level \
        == LEVEL_DEGRADED
    vd = SafetyCore(CFG).update(0.0, inputs(flying_vehicle(), cpu_temp_c=85.0))
    assert vd.level == LEVEL_ABORT
