"""The safety verdict: in-flight health (ARCHITECTURE §11.2), latching, override, reset.

`SafetyCore.update()` is called at the supervisor rate with the newest inputs and returns the
fields of SafetyStatus. Time `now` is a steady-clock time in s.
"""

import math
from dataclasses import dataclass, field

from drone_safety.core.config import (LANDED_IN_AIR, LANDED_ON_GROUND, LEVEL_ABORT,
                                      LEVEL_DEGRADED, LEVEL_HOLD, LEVEL_NAMES, LEVEL_OK,
                                      LEVEL_OVERRIDE, finite)
from drone_safety.core.override import OverrideDetector
from drone_safety.core.preflight import preflight_failures


@dataclass
class Inputs:
    vehicle: object = None
    vehicle_age: float = math.inf
    flow: object = None
    flow_age: float = math.inf
    cmd_age: float = math.inf          # since the last command from an allowed source
    stream_active: bool = False        # a mission command stream has started while airborne
    cpu_temp_c: float = math.nan
    fcu_output: tuple = None           # (output_enabled, allow_arming) or None


@dataclass
class Verdict:
    level: int = LEVEL_OK
    latched: bool = False
    motion_allowed: bool = False
    preflight_ok: bool = False
    preflight_failures: list = field(default_factory=list)
    active_faults: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    request_land: bool = False        # ABORT while airborne and armed (executed in Phase 8)

    @property
    def level_name(self):
        return LEVEL_NAMES[self.level]


class SafetyCore:

    def __init__(self, cfg):
        self.cfg = cfg
        self.override = OverrideDetector(cfg.autonomy_modes)
        self.latched_faults = {}       # name -> level
        self.override_reason = None
        self._flow_bad_since = None
        self._hold_since = None

    # ------------------------------------------------------------------ checks

    def _conditions(self, now, i):
        """[(level, name, latch_if_armed)] for everything wrong right now."""
        cfg = self.cfg
        out = []
        v = i.vehicle
        if v is None or i.vehicle_age > cfg.telemetry_timeout_s:
            return [(LEVEL_HOLD, 'TELEMETRY_STALE: no fresh vehicle state', True)]
        if not v.connected:
            out.append((LEVEL_HOLD, 'FCU_DISCONNECTED', True))
        elif v.heartbeat_age_s > cfg.heartbeat_timeout_s:
            out.append((LEVEL_HOLD, f'HEARTBEAT_STALE: {v.heartbeat_age_s:.1f} s', True))

        airborne = v.armed and v.landed_state != LANDED_ON_GROUND
        flying = v.armed and v.landed_state == LANDED_IN_AIR

        if finite(v.battery_voltage_v) and v.armed:
            if cfg.battery_land_v > 0 and v.battery_voltage_v < cfg.battery_land_v:
                out.append((LEVEL_ABORT, f'BATTERY_LAND: {v.battery_voltage_v:.2f} V', True))
            elif cfg.battery_warn_v > 0 and v.battery_voltage_v < cfg.battery_warn_v:
                out.append((LEVEL_DEGRADED, f'BATTERY_LOW: {v.battery_voltage_v:.2f} V', False))

        if airborne:
            ekf_ok = (v.ekf_attitude_ok and v.ekf_velocity_horiz_ok and v.ekf_pos_horiz_rel_ok
                      and not v.ekf_const_pos_mode and v.ekf_age_s < cfg.ekf_timeout_s)
            if not ekf_ok:
                out.append((LEVEL_ABORT, f'EKF_UNHEALTHY: flags 0x{v.ekf_flags:x}, age '
                                         f'{v.ekf_age_s:.1f} s', True))
            if finite(v.roll_rad, v.pitch_rad):
                tilt = max(abs(v.roll_rad), abs(v.pitch_rad))
                if tilt > math.radians(cfg.max_tilt_deg):
                    out.append((LEVEL_ABORT, f'TILT: {math.degrees(tilt):.0f} deg', True))

        if flying:
            flow_ok = (i.flow is not None and i.flow_age <= cfg.telemetry_timeout_s
                       and i.flow.healthy_for_flight)
            if flow_ok:
                self._flow_bad_since = None
            else:
                if self._flow_bad_since is None:
                    self._flow_bad_since = now
                reason = i.flow.reason if i.flow is not None else 'no flow status'
                if now - self._flow_bad_since > cfg.flow_bad_timeout_s:
                    out.append((LEVEL_ABORT, f'FLOW_BAD: {reason}', True))
                else:
                    out.append((LEVEL_DEGRADED, f'FLOW_DEGRADED: {reason}', False))
            if not v.height_valid:
                out.append((LEVEL_HOLD, 'HEIGHT_INVALID', False))
            elif v.height_above_ground_m > cfg.hard_ceiling_m:
                out.append((LEVEL_ABORT, f'CEILING: {v.height_above_ground_m:.2f} m', True))
            elif not cfg.min_height_m <= v.height_above_ground_m <= cfg.max_height_m:
                out.append((LEVEL_HOLD, f'HEIGHT_BAND: {v.height_above_ground_m:.2f} m', False))
            if i.stream_active and i.cmd_age > cfg.max_cmd_age_s:
                out.append((LEVEL_HOLD, f'COMMAND_STALE: {i.cmd_age:.1f} s', False))
        else:
            self._flow_bad_since = None

        if finite(i.cpu_temp_c):
            if i.cpu_temp_c >= cfg.cpu_temp_fault_c:
                out.append((LEVEL_ABORT, f'PI_OVERHEAT: {i.cpu_temp_c:.0f} C', True))
            elif i.cpu_temp_c >= cfg.cpu_temp_warn_c:
                out.append((LEVEL_DEGRADED, f'PI_HOT: {i.cpu_temp_c:.0f} C', False))
        return out

    # ------------------------------------------------------------------ verdict

    def update(self, now, i):
        cfg = self.cfg
        v = i.vehicle
        armed = bool(v is not None and v.armed)
        airborne = armed and v.landed_state != LANDED_ON_GROUND

        if v is not None and i.vehicle_age <= cfg.telemetry_timeout_s:
            reason = self.override.update(v.armed, v.mode, v.landed_state)
            if reason and self.override_reason is None:
                self.override_reason = reason

        conditions = self._conditions(now, i)
        for level, name, latch in conditions:
            if latch and armed:
                key = name.split(':')[0]
                self.latched_faults[key] = max(level, self.latched_faults.get(key, 0))

        level = max([c[0] for c in conditions] + list(self.latched_faults.values())
                    + [LEVEL_OK])
        # a HOLD that lasts too long in the air becomes a landing
        if level == LEVEL_HOLD and airborne:
            if self._hold_since is None:
                self._hold_since = now
            elif now - self._hold_since > cfg.hold_to_land_s:
                self.latched_faults['HOLD_TIMEOUT'] = LEVEL_ABORT
                level = LEVEL_ABORT
        else:
            self._hold_since = None

        faults = [c[1] for c in conditions if c[0] >= LEVEL_HOLD]
        warnings = [c[1] for c in conditions if c[0] == LEVEL_DEGRADED]
        faults += [f'{k} (latched)' for k in self.latched_faults
                   if not any(f.startswith(k) for f in faults)]
        if self.override_reason:
            level = LEVEL_OVERRIDE
            faults.insert(0, f'OVERRIDE: {self.override_reason}')
        latched = bool(self.latched_faults) or self.override_reason is not None

        pre = preflight_failures(cfg, v, i.vehicle_age, i.flow, i.flow_age, level, latched,
                                 i.fcu_output)
        return Verdict(
            level=level,
            latched=latched,
            motion_allowed=level <= LEVEL_DEGRADED and not latched,
            preflight_ok=not pre,
            preflight_failures=pre,
            active_faults=faults,
            warnings=warnings,
            request_land=(level == LEVEL_ABORT and airborne and cfg.allow_auto_land),
        )

    def reset(self, now, i):
        """(ok, message). Only on the ground, disarmed, with nothing currently wrong."""
        v = i.vehicle
        if v is None or i.vehicle_age > self.cfg.telemetry_timeout_s:
            return False, 'no fresh vehicle state'
        if v.armed:
            return False, 'vehicle is armed: reset only on the ground, disarmed'
        if v.landed_state not in (LANDED_ON_GROUND,) and not (
                v.height_valid and v.height_above_ground_m < self.cfg.ground_height_max_m):
            return False, 'vehicle not confirmed on the ground'
        current = [c for c in self._conditions(now, i) if c[0] >= LEVEL_HOLD]
        if current:
            return False, 'still failing: ' + '; '.join(c[1] for c in current)
        cleared = list(self.latched_faults) + (['OVERRIDE'] if self.override_reason else [])
        self.latched_faults.clear()
        self.override_reason = None
        self.override.engaged = False
        return True, ('cleared: ' + ', '.join(cleared)) if cleared else 'nothing to clear'
