# drone_safety

Safety supervisor: health checks, pre-flight validation, command gate, flight-operation gate and override handling.

See `ARCHITECTURE.md` (§3 nodes, §4 topics, §5 services, §6 actions) for the full contract of this package.

| Executable | Responsibility | Implemented in |
|---|---|---|
| `safety_supervisor` | Health checks, pre-flight validation, command gate, override handling. | Phase 6 (done); flight-operation gate in Phase 8 |

Publishes `/drone/safety_status` (20 Hz, TRANSIENT_LOCAL) and `/drone/control/validated_command`;
serves `/drone/safety/preflight_check` and `/drone/safety/reset` (std_srvs/Trigger).
The logic lives in `drone_safety/core/` (no ROS imports, unit-tested): `preflight.py`,
`supervisor.py`, `override.py`, `gate.py`, `config.py`. Limits are read once at startup.

Run one node on its own:

```bash
ros2 run drone_safety safety_supervisor --ros-args --params-file $(ros2 pkg prefix drone_bringup)/share/drone_bringup/config/drone.yaml
```

Test:

```bash
colcon test --packages-select drone_safety && colcon test-result --verbose
```
