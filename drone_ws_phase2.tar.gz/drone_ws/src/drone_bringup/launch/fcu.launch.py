"""FCU layer: fcu_state_node and fcu_command_node.

MAVROS itself is added to this file in Phase 3, once the serial device on your Pi is confirmed.
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    default_config = os.path.join(
        get_package_share_directory('drone_bringup'), 'config', 'drone.yaml')
    config = LaunchConfiguration('config')

    return LaunchDescription([
        DeclareLaunchArgument('config', default_value=default_config),
        DeclareLaunchArgument('enable_fcu_output', default_value='false',
                              description='[AIRCRAFT] allow setpoints to be sent'),
        DeclareLaunchArgument('allow_arming', default_value='false',
                              description='[AIRCRAFT] allow arm and takeoff'),
        Node(
            package='drone_fcu', executable='fcu_state_node', name='fcu_state_node',
            parameters=[config], output='screen',
        ),
        Node(
            package='drone_fcu', executable='fcu_command_node', name='fcu_command_node',
            parameters=[config, {
                'output_enabled': ParameterValue(
                    LaunchConfiguration('enable_fcu_output'), value_type=bool),
                'allow_arming': ParameterValue(
                    LaunchConfiguration('allow_arming'), value_type=bool),
            }],
            output='screen',
        ),
    ])
