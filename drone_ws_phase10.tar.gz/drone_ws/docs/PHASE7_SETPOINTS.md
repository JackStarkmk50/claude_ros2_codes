# Phase 7: first real setpoints to the Pixhawk (props off)

**Goal:** prove the command path on the real Pixhawk before anything flies:
- the Pi sends nothing unless the Pixhawk is armed in GUIDED;
- the yaw direction arrives at the Pixhawk with the right sign;
- a stopped mission, a dead safety node and a dead command node each end in a safe state;
- a mode switch on the RC takes the Pi out of control immediately, and it stays out;
- the motor emergency stop switch works.

**Safety: [AIRCRAFT] ALL PROPELLERS OFF.** In this phase the Pixhawk is really armed and the motors
really spin at idle. You arm and switch modes on the RC. The Pi never arms, never changes a mode
and never takes off (`allow_arming` stays false). The only thing the Pi sends is velocity/yaw
setpoints, and the safety gate forces the velocity to zero.

---

## What is new

| File | What it does |
|---|---|
| `safety_supervisor` parameter `bench_ground_test` (launch argument, default `false`) | **[AIRCRAFT]** Props-off only. Normally the gate turns every command into HOLD while the drone is on the ground. With this on, yaw commands pass while armed ON THE GROUND, and all translation is forced to zero (ArduCopter GUIDED would take off on any climb request). While it is on, the pre-flight check always fails (`PF13 ... bench_ground_test is on`), so it can never be used for a takeoff. |
| `fcu_state_node` | also asks the Pixhawk for `POSITION_TARGET_LOCAL_NED` (5 Hz): the target the Pixhawk says it is following |
| `tools/setpoint_test.py` | guided test (11 steps). It reads what MAVROS really puts on the wire to the Pixhawk (`/uas1/mavlink_sink`), not just what our node meant to send |

**Honest limits of this test**
- On the ground ArduCopter ignores yaw (the motors stay at idle and don't react). So this test
  proves what the Pixhawk **receives**, not that the drone physically turns the right way. The
  physical direction is checked in Phase 8 with a small yaw at the first hover.
- The Pixhawk's echo (`POSITION_TARGET_LOCAL_NED`) as far as I know only contains the velocity
  target, not the yaw rate. It shows that the Pixhawk follows our velocity stream.

Tested before sending: 101 unit tests pass. The whole stack ran against a simulated Pixhawk
(it arms, switches modes and logs every setpoint it receives), and all 13 checks passed. The
simulator's own log confirmed the yaw sign independently: +0.2 rad/s "turn left" from the Pi
arrived as -0.2 rad/s (MAVLink counts clockwise as positive). The real MAVROS on your Pi does the
same conversion; this test checks it on your installation.

---

## Before you start

| # | What | Why |
|---|---|---|
| B1 | **Props off.** Check all four. | the motors really spin |
| B2 | **4S battery connected** (not just USB) | on USB the battery reads 0.03 V, safety goes ABORT as soon as you arm, and nothing can be tested |
| B3 | **[AIRCRAFT]** `RC6_OPTION = 31` (motor emergency stop) in Mission Planner, then reboot | tested in the `estop` step. Without it, answer `n` there; it is required before Phase 8 |
| B4 | **[AIRCRAFT]** Recommended for this test only: `DISARM_DELAY = 60`, and back to `10` afterwards | ArduCopter disarms by itself about 10 s after arming when it stays on the ground with the throttle low. You can also leave it: the tool tells you when that happened and you re-arm |
| B5 | Know how to arm on your RC (usually throttle down + rudder right for 2 s) | the tool asks you to arm |

You arm in **LOITER**, not in GUIDED: ArduCopter does not accept RC arming in GUIDED (unless
`GUID_OPTIONS` bit 0 is set, which we don't need). You then flip the switch to GUIDED.

## Step 1: update the workspace and run the check

**COMMAND**

```bash
tar -xzf drone_ws_phase7.tar.gz -C ~/drone_ws --strip-components=1
bash ~/drone_ws/tools/verify_workspace.sh
```

**EXPECTED** `Summary: 101 tests, 0 errors, 0 failures, 0 skipped` and `WORKSPACE CHECK: ALL PASSED`.
**IF NOT** paste the FAIL lines.

## Step 2: start the stack with output on (terminal A) [AIRCRAFT]

Props off, battery connected, TELEM1 connected, RC transmitter on.

**COMMAND**

```bash
source ~/drone_ws/env.sh
ros2 launch drone_bringup bringup.launch.py enable_fcu_output:=true bench_ground_test:=true use_perception:=false
```

**EXPECTED**
- `drone bringup: enable_fcu_output=true allow_arming=false bench_ground_test=true`
- a WARN from `fcu_command_node`: `[AIRCRAFT] output_enabled=true: setpoints WILL be sent ...`
- a WARN from `safety_supervisor`: `[AIRCRAFT] bench_ground_test=true ... PROPS OFF ...`
- `FCU link up`

**IF NOT** if either WARN is missing, stop (Ctrl-C) and check the command line.

## Step 3: guided test (terminal B)

**COMMAND**

```bash
source ~/drone_ws/env.sh
python3 ~/drone_ws/tools/setpoint_test.py
```

The tool tells you what to do on the RC (lines starting with `>>>`) and waits for it. It first
asks you to type `props off`. About 5 minutes.

| Step | You do | What it checks | Expected |
|---|---|---|---|
| check | type `props off` | stack is up with output and ground test on | PASS |
| idle | nothing (disarmed) | the Pi sends nothing while disarmed | 0 setpoints, `SILENT: disarmed` |
| arm | arm in LOITER | the Pi sends nothing outside GUIDED | 0 setpoints, `SILENT: mode LOITER, not GUIDED` |
| guided | flip to GUIDED | with no mission the Pi holds: zero velocity at 10 Hz; the Pixhawk echoes a zero velocity target | 10 setpoints/s, all zero; echo PASS or CHECK |
| yaw | nothing (motors stay at idle) | yaw sign on the wire | we send +0.20 → Pixhawk receives -0.20, and the other way round; translation zero |
| stop | nothing | mission commands stop → HOLD | HOLD within about 0.4 s |
| override | flip to LOITER, then back to GUIDED | the Pi goes silent at once and stays silent | level 4 (OVERRIDE), 0 setpoints, also after GUIDED again |
| reset | disarm | the override is cleared only on the ground, disarmed | `cleared: OVERRIDE`, level 0 |
| estop | answer `y`, arm in LOITER, flip the emergency stop switch, answer whether the motors stopped, switch back, disarm | the kill switch works | you answer `y` |
| safety_lost | arm in LOITER, flip to GUIDED; the tool stops `safety_supervisor` | without the veto layer the command node holds | HOLD within about 0.6 s, zero setpoints |
| command_lost | nothing; the tool stops `fcu_command_node`; then disarm | nothing is sent any more | 0 setpoints |

After the last step: **disarm**, then Ctrl-C terminal A. Two nodes were stopped on purpose, so
start the launch fresh before doing anything else, and from now on **without**
`enable_fcu_output:=true bench_ground_test:=true`.

**IF NOT**

| What you see | WHY | CHECK / FIX |
|---|---|---|
| `check: output_enabled=False ...` | terminal A was started without the flags | Step 2 command exactly |
| `not armed after 90 s` | ArduCopter refused to arm | Mission Planner HUD shows the reason. `Need Position Estimate`: arm in STABILIZE or ALT_HOLD if your switch has one. `Hardware safety switch`: press the Pixhawk safety button until it is solid red. Send me the message |
| `safety does not allow motion ... BATTERY_LAND` | battery below 14.0 V or not connected (B2) | connect the charged 4S pack, disarm, run again |
| `safety does not allow motion ...` other fault | shown in the line | paste the report |
| `the Pixhawk disarmed during the step` | auto-disarm (B4) | re-run from that step: `--steps yaw,stop,...` |
| yaw FAIL with the wrong sign (+0.20 arrives as +0.20) | MAVROS on the Pi converts differently than expected | **stop here and paste the report.** Do not fly until it is resolved |
| override FAIL | the Pi did not notice the mode switch | paste the report and the terminal A lines |
| any step you want to repeat | | `python3 ~/drone_ws/tools/setpoint_test.py --steps override,reset` (the `check` step always runs first) |

## Step 4: send me

1. `~/drone_ws/phase7_report.txt`
2. anything unusual in terminal A (WARN/ERROR lines)
3. from before: the receiver failsafe answer (bars **drop** or **freeze** with the transmitter
   off) and the `PreArm:` text behind PF4, if you have them

**[AIRCRAFT]** After the test, set `DISARM_DELAY` back to `10` if you changed it.

Phase 8 is the first autonomous operation: the Pi requests GUIDED, arms, takes off to a low
height, holds, lands and confirms the disarm. Before that: `ARMING_CHECK = 1`, the FCU battery
failsafe, and the deferred flow test on battery (Phase 5).
