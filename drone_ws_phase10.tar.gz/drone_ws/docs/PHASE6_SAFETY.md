# Phase 6: safety supervisor and command path (bench mode)

**Goal:** the veto layer exists and is proven before anything can move the aircraft.
`safety_supervisor` judges the drone's health, runs the pre-flight checks, detects a pilot
override and filters every motion command. `fcu_command_node` decides what the flight controller
should receive each tick: nothing, HOLD (zero velocity) or the validated command.

**Safety:** bench mode. `fcu_command_node` starts with `output_enabled=false`, and in that mode it
never even creates the publisher to MAVROS; it only reports what it WOULD send. Nothing arms,
changes mode or moves. Props off anyway.

---

## What is new

| File | What it does |
|---|---|
| `src/drone_safety/drone_safety/core/preflight.py` | PF1–PF14 pre-flight checks. Every failure is listed, not just the first. |
| `src/drone_safety/drone_safety/core/supervisor.py` | In-flight health → level OK / DEGRADED / HOLD / ABORT / OVERRIDE, latching, reset rules |
| `src/drone_safety/drone_safety/core/override.py` | pilot or FCU took authority (mode switch, disarm in the air) |
| `src/drone_safety/drone_safety/core/gate.py` | command gate: source, sequence, age, numbers, mode, level, vehicle state, limits, yaw acceleration |
| `src/drone_safety/drone_safety/safety_supervisor.py` | the node: `/drone/safety_status` at 20 Hz, gate, `/drone/safety/preflight_check`, `/drone/safety/reset` |
| `src/drone_fcu/drone_fcu/core/setpoint.py` | SILENT / HOLD / COMMAND decision |
| `src/drone_fcu/drone_fcu/fcu_command_node.py` | the node: 10 Hz; reports its decision on `/drone/fcu/output_state` |
| `tools/bench_test.py` | 8 automatic scenarios against a fake vehicle (no Pixhawk needed) |
| `src/drone_bringup/config/drone.yaml` | new timeouts; a test checks that every node's yaml matches its parameters |

What the levels do:

| Level | When (examples) | Motion |
|---|---|---|
| OK | all healthy | allowed within limits |
| DEGRADED | battery below 14.4 V, short flow dip, Pi at 75 °C | allowed within limits |
| HOLD | no fresh telemetry, outside the height band, mission commands stopped | zero velocity |
| ABORT | EKF bad, tilt over 25°, above the ceiling, battery below 14.0 V, flow bad for more than 1 s, HOLD for more than 5 s in the air | zero velocity + LAND (see below) |
| OVERRIDE | the pilot switched out of GUIDED, or the drone was disarmed in the air | the Pi sends nothing at all |

Faults that happen while armed are **latched**: they stay until `/drone/safety/reset`, which only
works disarmed on the ground with nothing currently wrong.

**Honest limit of this phase:** automatic LAND is part of the flight operations in Phase 8. Until
then an ABORT in the air holds position (zero velocity) and logs `LAND must be requested ... the
PILOT must land`. Nothing flies before Phase 8, so this is only visible on the bench.

Two changes against the architecture document, both stricter:
- The gate checks the command's validity (source, sequence, age, numbers) **before** the safety
  level. Otherwise a foreign or broken command during a HOLD would count as a live mission stream.
- Override detection runs in `safety_supervisor` (it will also run every flight operation, so it
  knows which modes the Pi requested). `fcu_command_node` goes silent as soon as it hears
  OVERRIDE and stays silent even if `safety_supervisor` then dies.

Tested before sending: 96 unit tests pass. The 8 bench scenarios all pass. The full bringup runs
against a simulated Pixhawk, with pre-flight reporting only the simulator's battery and bench
mode. The bench test found two real bugs, which are fixed:
- a logging call that crashed `safety_supervisor` on its first level change;
- the gate ordering described above.

---

## Step 1: update the workspace and run the check

**COMMAND**

```bash
tar -xzf drone_ws_phase6.tar.gz -C ~/drone_ws --strip-components=1
bash ~/drone_ws/tools/verify_workspace.sh
```

**EXPECTED** `Summary: 96 tests, 0 errors, 0 failures, 0 skipped` and `WORKSPACE CHECK: ALL PASSED`.
**IF NOT** paste the FAIL lines.

## Step 2: automatic bench scenarios (no Pixhawk needed)

Stop any running `fcu.launch.py` / `bringup.launch.py` first (the script refuses otherwise).

**COMMAND**

```bash
source ~/drone_ws/env.sh
python3 ~/drone_ws/tools/bench_test.py
```

**EXPECTED** (about 40 s)

```text
PASS  S0 nodes start
PASS  S1 pre-flight on the ground: ... only PF13 bench mode
PASS  S2 validated yaw command: validated yaw 0.200 rad/s (sent 0.2)
PASS  S3 yaw clamp: sent 3.0 rad/s, validated 0.524 (limit 0.524)
PASS  S4 bad commands rejected: 3/3 rejected ... 0 forwarded
PASS  S5 mission stops: command node HOLD after ~0.3 s ..., safety ABORT after ~5.3 s
PASS  S6 reset: refused in the air, accepted on the ground
PASS  S7 pilot override: safety OVERRIDE, command node "SILENT: override ..."
PASS  S8 safety_supervisor killed: command node HOLD after ~0.2 s, LAND flagged after ~0.7 s
BENCH TEST: ALL PASSED
```

**IF NOT**

| What you see | WHY | CHECK / FIX |
|---|---|---|
| `STOP: another node publishes /drone/vehicle_state` | the real stack is running | Ctrl-C it, wait 5 s, run again |
| `S0 ... not up after 20 s` | a node crashed at start | `cat /tmp/phase6_bench_nodes.log` and paste the traceback |
| any other FAIL | timing on a busy Pi, or a real bug | paste the report; `/tmp/phase6_bench_nodes.log` has the node output |

## Step 3: the whole stack with the real Pixhawk (props off)

**COMMAND** (terminal A)

```bash
source ~/drone_ws/env.sh
ros2 launch drone_bringup bringup.launch.py
```

(terminal B)

```bash
source ~/drone_ws/env.sh
ros2 service call /drone/safety/preflight_check std_srvs/srv/Trigger
ros2 topic echo --once /drone/safety_status
ros2 topic echo --once /drone/fcu/output_state
```

**EXPECTED**
- `preflight_check`: `success=False` with a list of what is not ready yet. On your setup today
  that should be about:
  - `PF5 BATTERY` (USB power)
  - `PF4` only if ArduPilot reports a pre-arm problem
  - `PF14 RC` if the transmitter is off
  - `PF13 OUTPUT: bench mode`

  Each failure explains itself.
- `safety_status`: `level: 0` (OK) or `1` (DEGRADED) on the bench.
- `output_state`: `SILENT: disarmed`.

Flip the RC mode switch while watching terminal A: nothing happens, because you are disarmed and
the Pi is not driving (override only counts once the Pi has had the vehicle armed in GUIDED).

## Step 4: send me

1. `~/drone_ws/phase6_report.txt` (from Step 2)
2. the `preflight_check` message from Step 3

Phase 7 is the first test with `enable_fcu_output:=true` (**[AIRCRAFT]**, props off). You arm on
the RC in GUIDED, and we check the yaw direction through the FCU's echo of the setpoint and the
pilot override. Before Phase 7 I will ask for the motor emergency stop switch (`RC6_OPTION = 31`),
and the receiver failsafe answer (R1 in Phase 5).
