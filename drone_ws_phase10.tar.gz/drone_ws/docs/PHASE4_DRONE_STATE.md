# Phase 4: drone state (fcu_state_node)

**Goal:** one ROS node turns the Pixhawk's telemetry into two clean messages that the rest of the
stack will trust: `/drone/vehicle_state` and `/drone/flow_status`, both at 10 Hz. Every value has
an age; anything too old is reported as invalid, never as its last value.

**Safety:** PROPS OFF for the whole phase. Nothing in this phase arms, changes a mode, or writes an
FCU parameter. The one request the Pi makes is "please send these messages at these rates"
(MAV_CMD_SET_MESSAGE_INTERVAL); it lives in FCU RAM and resets when the Pixhawk reboots.
The FCU settings in Part A are recommendations only. **You** decide whether to change them, and you
change them yourself in Mission Planner.

---

## Part A: what your Phase 3 report showed

| # | Finding | What it means | Recommendation (your decision) |
|---|---|---|---|
| A1 | Only `OPTICAL_FLOW` and `DISTANCE_SENSOR` arrived, each at **100 Hz**, using **49 %** of the 115200 link. | These are almost certainly the MTF-01's own messages, which ArduPilot forwards to every MAVLink port, including TELEM1. The EKF does not need them on TELEM1. Phase 4 adds its own streams, so the link will reach about 65 % (measured with a simulated 100 Hz sensor). | **[AIRCRAFT]** On the serial port the MTF-01 is wired to (the `SERIALn` with `SERIALn_PROTOCOL = 2` that is not SERIAL1), add **1024** to `SERIALn_OPTIONS`. That is bit 10, "Don't forward mavlink to/from"; check the label in Mission Planner's parameter list before you write it. The FCU still reads the sensor, it just stops copying it to TELEM1. Another option is to lower the MTF-01 output rate in MicoAir's tool. Moving to 921600 later also solves it. |
| A2 | `SR1_*` are all 0. | Without a request, ArduPilot sends almost nothing on TELEM1: no attitude, battery, EKF or landed state. | Nothing to change: `fcu_state_node` now requests the streams itself on every (re)connect. `request_streams.sh` is no longer needed. |
| A3 | Rangefinder arrives as `DISTANCE_SENSOR` (`RNGFND1_TYPE = 10`), so `/mavros/rangefinder` stays empty. | Expected with a MAVLink rangefinder. | Nothing to change: height is now read from the FCU's `DISTANCE_SENSOR` (downward-facing only). |
| A4 | **`ARMING_CHECK = 0`**: all ArduPilot pre-arm checks are disabled. | ArduPilot will arm with a bad compass, uncalibrated accelerometers, low board voltage, and so on. It also makes our pre-flight check PF4 ("FCU pre-arm ok") meaningless, because it is always true. | **[AIRCRAFT]** Set `ARMING_CHECK = 1` before Phase 7 (first powered test). If it then reports PreArm problems, `state_monitor` shows them and we fix them one by one. |
| A5 | `BATT_FS_LOW_ACT = 0`, `BATT_FS_CRT_ACT = 0`, `BATT_LOW_VOLT = 6.0`, `BATT_CRT_VOLT = 4.0` | The FCU does nothing on a low battery, and 6.0 V / 4.0 V look like placeholders. | **[AIRCRAFT]** Tell me the pack (for example 3S or 4S LiPo). Then set real voltages and `*_ACT = 1` (Land). Our own battery limits in `drone.yaml` stay at 0 until then, so pre-flight fails on purpose. |
| A6 | `RC6_OPTION = 17` | 17 is AutoTune, if I read the table right (check it in Mission Planner). Flipping it by accident in ALT_HOLD or LOITER starts an autotune. | **[AIRCRAFT]** If you don't use AutoTune, make that switch the motor emergency stop instead: `RC6_OPTION = 31`. That also closes the missing kill switch item (ARCHITECTURE §11.6). |
| A7 | `FLTMODE4 = GUIDED`, `FLTMODE6 = LOITER`, `EK3_SRC1_POSZ = 2` (rangefinder), `EK3_SRC1_VELXY = 5` (flow), `GUID_TIMEOUT = 3` | These match the design. | Nothing to change. |

The hands-on checks from Phase 3 Step 7 are replaced by the Phase 4 checks in Step 4.

---

## Part B: what changed in the workspace

| File | Change |
|---|---|
| `src/drone_fcu/drone_fcu/fcu_state_node.py` | real node: VehicleState + FlowStatus at 10 Hz, stream requests, `/diagnostics` |
| `src/drone_fcu/drone_fcu/core/` | pure-Python logic with unit tests: `mavlink_decode.py`, `ekf_flags.py`, `fcu_status.py`, `flow_health.py`, `frames.py`, `link_monitor.py` |
| `src/drone_fcu/test/` | 30 tests (MAVLink layouts are checked against pymavlink) |
| `src/drone_bringup/config/drone.yaml` | `fcu_state_node` parameters (timeouts, flow thresholds, stream rates) |
| `src/drone_bringup/launch/fcu.launch.py` | passes `fcu_baud` to the node so the link-load number uses the right baud |
| `src/drone_bringup/test/` | new rules: fcu_state_node may only request stream rates; yaml matches the node |
| `tools/state_monitor.py` | read-only live view, and `--check` writes `~/drone_ws/phase4_report.txt` |
| `tools/verify_workspace.sh` | also checks pymavlink and fails if any test was skipped |

How the node gets its data:

| Field | Source |
|---|---|
| connected, heartbeat age | FCU `HEARTBEAT` (raw) + `/mavros/state`. Lost within 2 s of the last heartbeat. |
| mode, armed | `/mavros/state` |
| landed_state | `/mavros/extended_state` (`EXTENDED_SYS_STATE`) |
| fcu_prearm_ok | `/mavros/sys_status` pre-arm bit |
| last_prearm_text | `/mavros/statustext/recv`, "PreArm: ..." within the last 5 s |
| roll, pitch, yaw | `/mavros/imu/data` (ROS convention: nose down = +pitch, right side down = +roll, yaw 0 = East) |
| velocity, local position | `/mavros/local_position/*` (from `LOCAL_POSITION_NED`) |
| height | FCU `DISTANCE_SENSOR`, downward, cm → m (raw) |
| EKF flags | FCU `EKF_STATUS_REPORT` (raw) |
| flow | FCU `OPTICAL_FLOW` (raw). The MTF-01's own forwarded copies are counted as link load, not used. |
| battery | `/mavros/battery` |
| rc_present | `/mavros/rc/in` has channels in 900–2100 µs, and SYS_STATUS does not flag the RC receiver unhealthy (radio failsafe) |

Tested before sending, against a simulated ArduPilot that sends nothing until asked and forwards a
100 Hz "MTF-01" at sysid 42:
- all 50 workspace tests pass;
- the node requests the 8 streams, and every field fills in;
- a PreArm text and a mode change show up;
- when the heartbeat is cut, the link is reported LOST within 1.6 s;
- on reconnect, the streams are requested again and the data comes back.

A real Pixhawk is the one thing I could not test.

---

## Step 1: update the workspace and run the check

**COMMAND** (from the folder where you downloaded `drone_ws_phase4.tar.gz`)

```bash
tar -xzf drone_ws_phase4.tar.gz -C ~/drone_ws --strip-components=1
bash ~/drone_ws/tools/verify_workspace.sh
```

**EXPECTED** (last lines)

```text
PASS  pymavlink importable
Summary: 53 tests, 0 errors, 0 failures, 0 skipped
WORKSPACE CHECK: ALL PASSED
```

**IF NOT**

| What you see | WHY | CHECK / FIX |
|---|---|---|
| `FAIL  pymavlink not importable` | the venv from Phase 2 is missing | `bash ~/drone_ws/tools/setup_venv.sh`, then run the check again |
| `FAIL  N tests skipped` | same cause (the decode tests need pymavlink) | as above |
| a test failure | paste the failing test name and message | `colcon test-result --verbose` |

## Step 2: start the FCU layer (terminal A)

Pixhawk powered, **props off**, TELEM1 connected.

**COMMAND**

```bash
source ~/drone_ws/env.sh
ros2 launch drone_bringup fcu.launch.py
```

**EXPECTED** within about 10 s, from `fcu_state_node`:

```text
up: publishing /drone/vehicle_state and /drone/flow_status at 10 Hz; ...
FCU link up
stream requested: ATTITUDE at 10 Hz
... (8 "stream requested" lines)
FCU forwards OPTICAL_FLOW from another device (sysid X compid Y); not used, ...
FCU forwards DISTANCE_SENSOR from another device (sysid X compid Y); ...
FCU mode: - -> STABILIZE
```

The two "forwards" lines are the MTF-01 traffic from A1. They disappear if you apply A1.

**IF NOT**

| What you see | WHY | CHECK / FIX |
|---|---|---|
| no `FCU link up` | MAVROS not connected | the Phase 3 table (Step 4 of PHASE3_MAVROS_LINK.md) still applies |
| `stream request refused by FCU: X` | ArduPilot rejected that rate | paste the line |
| `FCU does not send X after 3 requests` | accepted but not sent | paste the line. For `LOCAL_POSITION_NED` this is expected without an EKF origin (see Step 3). |

## Step 3: automatic state check (terminal B)

**COMMAND**

```bash
source ~/drone_ws/env.sh
python3 ~/drone_ws/tools/state_monitor.py --check 15
```

**EXPECTED** `STATE CHECK: ALL REQUIRED PASSED`, and `report saved to ~/drone_ws/phase4_report.txt`.

These are normal on the bench and are not failures:
- `flow ... healthy_for_flight=False reason: height 0.0x m below flow band`: the MTF-01 is below
  its working height on the floor, so flow quality is only judged in the air.
- `WARN RC present` if your transmitter is off.
- `FCU pre-arm bit: True`: with `ARMING_CHECK = 0` it is always true (A4).
- `WARN EKF velocity (LOCAL_POSITION_NED) missing`: ArduPilot may not publish local position
  indoors until it has an EKF origin (ARCHITECTURE P4). It doesn't block this phase; we deal with
  it before any takeoff.

**IF NOT**

| FAIL line | WHY | CHECK / FIX |
|---|---|---|
| `no /drone/vehicle_state` | node not running | terminal A shows why |
| `connected` | no heartbeat | terminal A: MAVROS lines |
| `landed_state ... UNDEFINED` | `EXTENDED_SYS_STATE` not arriving | terminal A for "refused" / "does not send" |
| `attitude: none` | `ATTITUDE` not arriving | same |
| `rangefinder height` | no downward `DISTANCE_SENSOR` from the FCU | check `RNGFND1_ORIENT` is 25 (down); paste the diagnostics section |
| `optical flow from FCU` | FCU's own `OPTICAL_FLOW` not arriving | paste the diagnostics section |
| `EKF_STATUS_REPORT` | not arriving | same |
| `battery` | no battery data | `BATT_MONITOR` is 4; is the battery or power module connected? |

## Step 4: hands-on checks (props off, read-only)

**COMMAND** (terminal B, live view, one line per second, Ctrl-C to stop)

```bash
python3 ~/drone_ws/tools/state_monitor.py
```

| # | Do this | Watch | Expected |
|---|---|---|---|
| a | lift the drone slowly from the floor to about 1 m and back | `h` | follows the height (a few cm on the floor, about 1.00 m at 1 m) |
| b | hold it at about 1 m over your floor, then cover the MTF-01 lens | `flow q`, `flight` | at 1 m, q is high and `flight ok` if the EKF agrees; covered, q drops and `flight NO [quality ...]` |
| c | flip the RC mode switch LOITER ↔ GUIDED (disarmed) | mode, and terminal A | the mode follows the switch; terminal A logs `FCU mode: LOITER -> GUIDED` |
| d | tilt nose down, then right side down, then point the nose North | `pitch`, `roll`, `hdg` | nose down: pitch **positive**; right side down: roll **positive**; nose North: hdg near 0 (indoors the compass can be off by 10–20°) |
| e | switch the RC transmitter off, then on | `RC` | `RC NO` within about 2 s, then `RC yes` again. Tell me what you see: this ArduPilot behaviour is not verified yet. |
| f | unplug TELEM1, wait 5 s, plug it back | `LINK`, terminal A | `LINK DOWN` within about 2 s, with `FCU link LOST` in A; then `FCU link up` and 8 `stream requested` lines again |

Only if you set `ARMING_CHECK = 1` (A4): the monitor should show `prearm NO (PreArm: ...)` whenever
ArduPilot has a reason to refuse arming. That is the Phase 4 pre-arm test from the architecture.

## Step 5: send me

1. `~/drone_ws/phase4_report.txt`
2. a line per check a–f: OK, or what you saw instead
3. your decision on A1, A4, A5 (and the battery type) and A6: changed, not changed, or later

Next is Phase 5, optical flow on your floor: tune `flow_min_quality` from real readings, check the
flow direction signs by moving the drone by hand, and record which EKF flags ArduPilot sets with
flow on the ground and in hand. It is still read-only, and nothing arms. Phase 6 is the safety
supervisor.
