# Phase 3: MAVROS link to the Pixhawk (read-only)

**Goal:** the Pi talks to the Pixhawk through MAVROS on TELEM1, and we can see exactly what
telemetry arrives, at what rate, and how busy the 115200 link is. We also record the FCU
parameters the later phases depend on.

**Safety:** PROPS OFF for the whole phase. Nothing in this phase arms, changes a mode, or
writes an FCU parameter. MAVROS only reads telemetry and sends a companion heartbeat.
`request_streams.sh` asks the FCU for message rates; that lives in FCU RAM and resets on reboot.

What changed in the workspace:

| File | Change |
|---|---|
| `src/drone_bringup/launch/fcu.launch.py` | starts MAVROS: `serial:///dev/ttyAMA0:115200`, MAVLink 2, no respawn |
| `src/drone_bringup/config/mavros_pluginlists.yaml` | only 12 MAVROS plugins load (everything else is blocked) |
| `src/drone_bringup/launch/bringup.launch.py` | new args `use_mavros`, `fcu_device`, `fcu_baud`, `gcs_url` |
| `tools/phase3_precheck.sh` | is the serial port ready? |
| `tools/phase3_link_check.sh` | connection, firmware, topic rates, samples, link load, FCU parameter report |
| `tools/mavlink_link_stats.py` | per-message rate and bytes/s actually on the wire, % of 115200 |
| `tools/request_streams.sh` | ask ArduPilot for the messages the stack needs |

Tested before sending: MAVROS starts with this config, loads exactly the 12 plugins, publishes
`/mavros/state`, `/mavros/optical_flow/raw/optical_flow`, `/mavros/rangefinder/rangefinder` etc.,
and every tool ran end to end against a simulated ArduPilot link. A real Pixhawk is the one thing
I could not test, which is what this phase is for.

---

## Step 1: install MAVROS and its geoid data

**COMMAND**

```bash
sudo apt update
sudo apt install -y ros-jazzy-mavros ros-jazzy-mavros-extras geographiclib-tools
sudo /opt/ros/jazzy/lib/mavros/install_geographiclib_datasets.sh
```

**EXPECTED** the script downloads `egm96-5` and ends without an error.
**IF NOT** "OS not supported" means `geographiclib-tools` is missing (install it and re-run).
Without this data MAVROS aborts at startup with `GeographicLib exception: File not readable`.

## Step 2: update the workspace

**COMMAND** (from the folder where you downloaded `drone_ws_phase3.tar.gz`)

```bash
tar -xzf drone_ws_phase3.tar.gz -C ~/drone_ws --strip-components=1
cd ~/drone_ws && source /opt/ros/jazzy/setup.bash
rm -rf build install log && colcon build --symlink-install
source ~/drone_ws/env.sh
```

**EXPECTED** `Summary: 7 packages finished`.
**IF NOT** paste the first error line.

## Step 3: precheck the serial port

Pixhawk powered (USB or battery), **props off**, TELEM1 cable to the Pi.
Close anything else that used the port before (old Flask server, mavproxy, a test script).

**COMMAND**

```bash
bash ~/drone_ws/tools/phase3_precheck.sh
```

**EXPECTED** `PRECHECK: ALL PASSED`.
**IF NOT** each FAIL line prints its fix.

## Step 4: start MAVROS (terminal A)

**COMMAND**

```bash
source ~/drone_ws/env.sh
ros2 launch drone_bringup fcu.launch.py
```

**EXPECTED** within a few seconds:

```text
[mavros.mavros_node]: FCU URL: serial:///dev/ttyAMA0:115200
[mavros]: CON: Got HEARTBEAT, connected. FCU: ArduPilot
[mavros.sys]: VER: ... Flight software: ...   <- firmware version lines
[mavros.param]: PR: parameters list received      <- can take a minute at 115200
```

plus the two drone_fcu skeleton lines and `BENCH SKELETON: output_enabled=False allow_arming=False`.

**IF NOT**

| What you see | WHY | CHECK / FIX |
|---|---|---|
| no `Got HEARTBEAT` after 15 s | wrong device, baud, protocol, or TX/RX | Mission Planner (USB): `SERIAL1_PROTOCOL = 2`, `SERIAL1_BAUD = 115`. Pi TX (GPIO14) → Pixhawk TELEM1 RX, Pi RX (GPIO15) ← TELEM1 TX, GND shared. |
| `Permission denied` on /dev/ttyAMA0 | user not in dialout | `sudo usermod -aG dialout $USER`, log out and in |
| `Device or resource busy` | another program has the port | `sudo fuser -v /dev/ttyAMA0`, stop it |
| `GeographicLib exception` | Step 1 not done | run Step 1 |
| connects then `Lost connection` repeatedly | noisy link or baud mismatch | check wiring and ground; `mavlink_link_stats.py` shows `Bad CRC frames` |
| after Ctrl-C, the next launch says busy | an old mavros_node is still alive | `pkill -f mavros_node`, then launch again |

## Step 5: baseline link check (terminal B)

**COMMAND**

```bash
source ~/drone_ws/env.sh
bash ~/drone_ws/tools/phase3_link_check.sh
```

**EXPECTED** `PASS /mavros/state connected: True`, mode and armed state, `12` plugin nodes,
`PASS local_position tf.send = False`, a rate per topic, a link-load table, and a parameter list.
Some topics may say `NONE` and the link-load section may list `MISSING` messages: that is the
baseline before Step 6 and exactly what we want to see.
The report is saved to `~/drone_ws/phase3_report.txt`.

## Step 6: request the streams the stack needs, then measure again

**COMMAND**

```bash
bash ~/drone_ws/tools/request_streams.sh
python3 ~/drone_ws/tools/mavlink_link_stats.py 15
```

**EXPECTED** ten `PASS` lines, then a table with OPTICAL_FLOW, ATTITUDE, RANGEFINDER (or
DISTANCE_SENSOR), LOCAL_POSITION_NED around 10 Hz, EKF_STATUS_REPORT, SYS_STATUS and
EXTENDED_SYS_STATE around 2 Hz, and finally `PASS every message the stack needs is arriving`.
The total load line tells us how much of the 115200 link is used.

**IF NOT**

| What you see | WHY | CHECK / FIX |
|---|---|---|
| `FAIL OPTICAL_FLOW` / no OPTICAL_FLOW in the table | FCU has no flow sensor configured, or the MTF-01 isn't detected | report shows `FLOW_TYPE`; in Mission Planner's status tab, `opt_qua` should change |
| no RANGEFINDER and no DISTANCE_SENSOR | rangefinder not configured | report shows `RNGFND1_TYPE` |
| a `FAIL` with `success=False` | FCU refused that message id | paste the line; the stack can live without some of them |
| load above 60% | too many default streams on SERIAL1 | paste the table; we lower `SR1_*` rates or move to 921600 |

## Step 7: hands-on checks (props off, read-only)

Run each in terminal B, and Ctrl-C when done.

| # | Do this | Command | Expected |
|---|---|---|---|
| a | lift the drone slowly from the floor to about 1 m and back | `ros2 topic echo /mavros/rangefinder/rangefinder --field range` | value follows the height (about 0.05 on the floor) |
| b | cover the MTF-01 lens with your hand, then uncover | `ros2 topic echo /mavros/optical_flow/raw/optical_flow --field quality` | drops toward 0 when covered, recovers when uncovered |
| c | flip the RC mode switch LOITER ↔ GUIDED (disarmed) | `ros2 topic echo /mavros/state --field mode` | mode text follows the switch. This is the data the override detection will use. |
| d | tilt the drone nose down by hand | `ros2 topic echo /mavros/imu/data --field orientation` | values change smoothly (we check the sign conventions in Phase 4) |
| e | unplug the TELEM1 cable, wait 15 s, plug it back | watch terminal A | `Lost connection, HEARTBEAT timed out`, then `Got HEARTBEAT, connected` again |

## Step 8: send me

1. `~/drone_ws/phase3_report.txt`
2. the output of Step 6 (the link table)
3. a line per hands-on check a–e: OK, or what you saw instead

With those I write Phase 4 (fcu_state_node: VehicleState and FlowStatus from real data).

---

## Findings from building this phase (for reference)

- MAVROS 2 in a `mavros` namespace publishes `/mavros/mavros/state`. We start it without a
  namespace so topics are `/mavros/state`, matching the architecture.
- MAVROS plugin settings (for example `conn_timeout`, `tf.send`) are not reliably loaded from
  YAML files in this MAVROS 2 build. We rely only on defaults that we verified (`tf.send`
  is `False` by default) and on the plugin allow-list, which does load. The link check verifies
  `tf.send` on your Pi.
- `/mavros/state` and `/mavros/extended_state` are published RELIABLE + TRANSIENT_LOCAL: a node
  that starts late receives the last state immediately, even if it is old. Phase 4 judges
  freshness by message timestamps, not only by "a message arrived".
- `/mavros/sys_status` exists and carries `sensors_health`, which includes ArduPilot's pre-arm bit.
  This settles ARCHITECTURE P6 unless your firmware does not set it (the report will show).
- The MTF-01 flow arrives on `/mavros/optical_flow/raw/optical_flow` (`quality`,
  `ground_distance`, `flow_rate`). ArduPilot's own RANGEFINDER message arrives on
  `/mavros/rangefinder/rangefinder`.
