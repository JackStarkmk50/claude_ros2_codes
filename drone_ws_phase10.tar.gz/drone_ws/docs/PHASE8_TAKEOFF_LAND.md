# Phase 8: the Pi arms, takes off, hovers, lands and disarms (props off first)

**Goal:** the complete autonomous sequence, commanded from the Pi through the safety layer:

`pre-flight check → GUIDED → ARM → TAKEOFF → climb verified → stable hover verified → LAND → touchdown → DISARM confirmed`

The RC stays the manual override and emergency stop. The Pi never fights the pilot.

**Safety: [AIRCRAFT] ALL PROPELLERS OFF for every step in this document.** In this phase the Pi
really arms the Pixhawk and really commands a takeoff. With props off the motors spin up towards
takeoff thrust for up to 5 s, the drone does not rise, and the Pi must turn that into
LAND → disarm by itself. That is the expected result of the props-off test, and it proves the most
important failure path on the real Pixhawk.

This document does **not** include a real flight. The first real lift-off comes after the checks in
"Before the first real flight" at the end, and only as a separate, explicit step.

---

## What is new

| File | What it does |
|---|---|
| `drone_fcu/core/operations.py` | The TAKEOFF and LAND step machines (pure Python, 17 unit tests). Every step is verified from telemetry, with a timeout, and every failure has a defined safe end (see the table below). |
| `fcu_command_node` | Executes approved operations against MAVROS (`set_mode`, `cmd/arming`, `cmd/takeoff`). **Sets the EKF origin itself** once the link is up, so ArduPilot can arm in GUIDED without GPS. LANDS by itself if `safety_supervisor` goes silent while airborne. |
| `safety_supervisor` | Public action `/drone/flight/operation`: runs the pre-flight check (PF1 to PF14) and checks source and altitude, then forwards to `fcu_command_node`. Requests LAND by itself on any ABORT in the air (battery, flow lost, tilt, ...). New fault `COMMAND_NODE_LOST` (see honest limits). |
| `tools/flight_op.py` | Operator command: `preflight`, `takeoff <m>`, `land`. Prints every stage. Ctrl-C cancels a TAKEOFF (the drone lands if armed). |
| `drone.yaml` | `link_baud` 921600; new `fcu_command_node` settings incl. `ekf_origin_lat_deg` / `ekf_origin_lon_deg` **[SET]**; takeoff altitude limits 0.8 to 1.5 m |
| launch files | `fcu_baud` now defaults to **921600**, you no longer need `fcu_baud:=921600` |

**What happens when something goes wrong during a TAKEOFF**

| When | What the Pi does | End state |
|---|---|---|
| GUIDED not reached / arming refused | stops, disarms if armed | on the ground, disarmed |
| takeoff command rejected, or no climb within 5 s (props off!) | LAND | landed, disarmed |
| safety ABORT, Ctrl-C (cancel), unstable hover | LAND | landed, disarmed |
| you move the RC mode switch | OVERRIDE: the Pi goes silent immediately and stays silent | you fly |
| `safety_supervisor` dies | `fcu_command_node` LANDS by itself | landed, disarmed |
| telemetry lost while armed | LAND requested blind, never reports success | check the drone |
| LAND not accepted by the FCU (asked twice) | reports "LAND NOT ACCEPTED: take manual control" | **you land** |
| `fcu_command_node` dies in the air | nothing can command the FCU any more. Safety raises ABORT `COMMAND_NODE_LOST ... the PILOT must land`. ArduCopter keeps hovering in GUIDED. | **you land** |

**Honest limits**
- Everything above was tested in software only: 121 unit tests, plus the whole stack against the
  real ArduCopter 4.6.3 firmware in the simulator (SITL) with an indoor setup like yours (no GPS,
  optical flow, downward rangefinder with a 0.14 m ground reading, Pi-set EKF origin). Results:
  takeoff to 0.8 m → hover at 0.83 m → LAND → "landed and disarmed (confirmed by the FCU)";
  low battery in the hover → automatic LAND; RC mode switch during the climb → Pi silent;
  cancel during the climb → LAND; safety node killed while hovering and while climbing → LAND;
  command node killed → COMMAND_NODE_LOST, pilot lands. A no-climb run in SITL also ended in
  LAND → disarmed.
- The simulator is not your Pixhawk, your MTF-01 or your floor. The props-off test below checks the
  sequence on your hardware. How the real drone climbs and hovers is only known at the first flight.
- If `fcu_command_node` dies in the air, only you can land it (last row above). This is why the
  pilot must stay on the RC for every flight.

---

## Before you start

| # | What | Why |
|---|---|---|
| B1 | **Props off.** Check all four. | the Pi will arm and command a takeoff |
| B2 | **4S battery connected** | on USB power PF5 BATTERY fails (0.03 V) and nothing is approved |
| B3 | RC transmitter on, mode switch in **STABILIZE**, emergency stop switch (RC6) tested and **within reach** | PF9 needs an allowed mode; the estop is your fastest way to stop the motors |
| B4 | Drone secured on the table (it may twitch when the motors spin up) | props off, but still |
| B5 | `DISARM_DELAY` can stay at 60 for this phase | the Pi disarms by itself anyway |

---

## Step 1: update the workspace and run the check

**WHAT** install Phase 8 and run the full build and test check.

**COMMAND**

```bash
tar -xzf drone_ws_phase8.tar.gz -C ~/drone_ws --strip-components=1
bash ~/drone_ws/tools/verify_workspace.sh
```

**EXPECTED** `Summary: 121 tests, 0 errors, 0 failures, 0 skipped` and `WORKSPACE CHECK: ALL PASSED`.

**IF NOT** paste the FAIL lines. If the build says `geographic_msgs` is missing:
`sudo apt install ros-jazzy-geographic-msgs` (normally already installed with MAVROS).

## Step 2: set the EKF origin coordinates [SET]

**WHAT** tell `fcu_command_node` where on Earth the drone roughly is.

**WHY** Without GPS, ArduPilot has no "home" and refuses to arm in GUIDED (the
`PreArm: AHRS: waiting for home` you saw in LOITER). The Pi now sends a fixed origin at startup.
It only needs to be roughly right (a city is enough, 2 decimals): ArduPilot uses it to anchor
its local position, and to compute the magnetic declination, so a point on the other side of the
world would be wrong, but your city is fine. Nothing flies to these coordinates.

**COMMAND** open `~/drone_ws/src/drone_bringup/config/drone.yaml`, find `fcu_command_node` and
replace the two `0.0` values with your latitude and longitude (from any map app), for example:

```yaml
    ekf_origin_lat_deg: 13.08               # [SET] your latitude
    ekf_origin_lon_deg: 80.27               # [SET] your longitude
```

then rebuild:

```bash
cd ~/drone_ws && colcon build --symlink-install
```

**EXPECTED** the build finishes without errors.

**IF NOT** if you leave them at 0.0, `fcu_command_node` warns at startup
`ekf_origin_lat_deg/lon_deg not set in drone.yaml: no EKF origin is sent`, and PF4 will keep
failing with `waiting for home`.

## Step 3: start the stack with output and arming on (terminal A) [AIRCRAFT]

**WHAT** start everything, with the Pi allowed to arm and take off.

**COMMAND**

```bash
source ~/drone_ws/env.sh
ros2 launch drone_bringup bringup.launch.py enable_fcu_output:=true allow_arming:=true use_perception:=false
```

(`bench_ground_test` stays at its default, false. `fcu_baud` is 921600 by default now.)

**EXPECTED** within about 15 s:
- `drone bringup: enable_fcu_output=true allow_arming=true bench_ground_test=false`
- WARN `[AIRCRAFT] output_enabled=true: setpoints and LAND WILL be sent to the FCU ...`
- WARN `[AIRCRAFT] allow_arming=true: this node may ARM and TAKE OFF when safety_supervisor approves a TAKEOFF.`
- `FCU link up`
- `EKF origin sent (13.0800, 80.2700)` (your values), 3 times over about 12 s
- In Mission Planner's Messages tab (if connected): `EKF3 IMU0 origin set`

**IF NOT**
- no `FCU link up`: same checks as Phase 3 (cable, `/dev/ttyAMA0`, `SERIAL1_BAUD` 921600).
- `EKF origin sent ...: ArduPilot still waits for home/origin` keeps repeating for more than 30 s:
  paste terminal A from the start and tell me what Mission Planner shows under Messages.

## Step 4: pre-flight check (terminal B)

**WHAT** ask the safety layer whether a takeoff would be approved right now. Nothing is sent to
the FCU.

**COMMAND**

```bash
source ~/drone_ws/env.sh
python3 ~/drone_ws/tools/flight_op.py preflight | tee ~/phase8_report.txt
```

**EXPECTED** `PRE-FLIGHT OK`. Compared with Phase 6, PF4 (FCU pre-arm), PF5 (battery) and PF13
(bench mode) now pass.

**IF NOT** each line says which check failed:

| Line | Meaning / fix |
|---|---|
| `PF4 FCU_PREARM: PreArm: AHRS: waiting for home` | origin not accepted yet: wait 20 s after `FCU link up` and repeat; check step 2 |
| `PF4 FCU_PREARM: <other text>` | an ArduPilot pre-arm check; paste it to me |
| `PF5 BATTERY: xx V < 15.60 V` | battery not connected or not charged (needs 3.9 V/cell at rest) |
| `PF7 FLOW: ...` | flow quality or rangefinder on the table; paste it |
| `PF9 MODE: LAND is not an allowed pre-takeoff mode` | flip the mode switch to STABILIZE (see step 8) |
| `PF14 RC: ...` | transmitter off |

Do not continue until you see `PRE-FLIGHT OK`.

## Step 5: refusal checks (nothing moves)

**WHAT** check that bad requests are refused before anything is sent.

**COMMAND**

```bash
python3 ~/drone_ws/tools/flight_op.py takeoff 3.0 | tee -a ~/phase8_report.txt
python3 ~/drone_ws/tools/flight_op.py land | tee -a ~/phase8_report.txt
```

**EXPECTED**
- first: `RESULT: FAILED at PREFLIGHT: TAKEOFF REFUSED: PF12 ALTITUDE: 3.0 m outside 0.80-1.50 m`
- second: `RESULT: FAILED at PREFLIGHT: LAND REFUSED: vehicle is disarmed: nothing to land`
- the motors do not move, the Pixhawk stays disarmed, the mode stays STABILIZE.

**IF NOT** if anything arms or the mode changes: flip the estop, stop terminal A (Ctrl-C) and send
me terminal A and B.

## Step 6: PROPS-OFF takeoff: the Pi arms, commands takeoff, detects "no climb", lands, disarms [AIRCRAFT]

**WHAT** the full takeoff sequence on the real Pixhawk. Without props the drone cannot rise, so the
Pi must detect that and land.

**WHY** this proves on your hardware: mode change to GUIDED from the Pi, arming from the Pi without
GPS, the takeoff command, climb detection, and the LAND → disarm fallback.

**PROPS OFF. Hand on the estop switch.** The motors will spin up and get **loud** (towards takeoff
thrust) for up to 5 s. That is expected. Flip the estop if anything else happens.

**COMMAND**

```bash
python3 ~/drone_ws/tools/flight_op.py takeoff 0.8 | tee -a ~/phase8_report.txt
```

**EXPECTED** (times approximate)

```
SET_GUIDED     0.0 s  height  0.14 m  ...
ARM            0.x s  height  0.14 m  ...
TAKEOFF_CMD    0.x s  height  0.14 m  takeoff sent, waiting for the climb to start
TAKEOFF_CMD    5.x s  ...             no climb within 5 s of the takeoff command: LAND
...
RESULT: FAILED at TAKEOFF_CMD: no climb within 5 s of the takeoff command; landed and disarmed
  after ~10-20 s: armed False, landed_state 1, height 0.14 m
```

What you see and hear: mode goes STABILIZE → GUIDED, the motors arm and spin up, after about 5 s
the mode goes to LAND, the motors slow down and the Pixhawk disarms (by itself or when the Pi asks,
at most 5 s after touchdown).

**IF NOT**
- `FAILED at SET_GUIDED` / `FAILED at ARM`: the result line includes the FCU's own message (for
  example a PreArm reason). Paste it. The Pixhawk stays disarmed.
- the motors keep spinning for more than 20 s: **estop**, then paste terminal A and B.
- `RESULT: OK` with props off: this must not happen, **estop** and send me everything.

## Step 7: cancel test (Ctrl-C) [AIRCRAFT]

**WHAT** a TAKEOFF interrupted by the operator must end in LAND → disarm.

First flip the mode switch **LAND → STABILIZE** (see step 8), then run `preflight` again and check
`PRE-FLIGHT OK`.

**COMMAND** (props off, hand on the estop)

```bash
python3 ~/drone_ws/tools/flight_op.py takeoff 0.8 | tee -ia ~/phase8_report.txt
```

press **Ctrl-C once** as soon as the `TAKEOFF_CMD` line appears.

**EXPECTED** `Cancelling the TAKEOFF: the drone LANDS if it is armed...` then
`RESULT: FAILED at TAKEOFF_CMD: cancelled; landed and disarmed`.

(`tee -i` keeps writing the report when you press Ctrl-C.)

**IF NOT** paste terminal A and B.

## Step 8: after every landing, flip the mode switch to STABILIZE

After a LAND the Pixhawk stays in LAND mode. On purpose, the pre-flight check refuses the next
takeoff (`PF9 MODE: LAND ...`) until you move the mode switch to STABILIZE. This means a new takeoff
always needs a human action on the RC, and a LAND can never be followed by an automatic re-takeoff.

(The mode switch only sets a new mode when it *moves*: if it is already in STABILIZE, flip it to
another position and back.)

## Step 9: pilot override test [AIRCRAFT]

**WHAT** you take control during a takeoff; the Pi must go silent and stay silent.

After step 8, `preflight` shows `PRE-FLIGHT OK`.

**COMMAND** (props off, hand on the estop)

```bash
python3 ~/drone_ws/tools/flight_op.py takeoff 0.8 | tee -a ~/phase8_report.txt
```

as soon as `TAKEOFF_CMD` appears, flip the mode switch to **STABILIZE**.

**EXPECTED**
- `RESULT: FAILED at TAKEOFF_CMD: mode changed to STABILIZE during takeoff`
- the mode stays STABILIZE (the Pi does not switch back), the motors keep idling: **you disarm**
  (throttle down + rudder left, or the estop).
- then clear the override:

```bash
ros2 service call /drone/safety/reset std_srvs/srv/Trigger | tee -a ~/phase8_report.txt
python3 ~/drone_ws/tools/flight_op.py preflight | tee -a ~/phase8_report.txt
```

  `reset` answers `cleared: OVERRIDE`, and `preflight` answers `PRE-FLIGHT OK`.

**IF NOT** if the mode goes back to GUIDED or LAND by itself: estop, and send me everything.

## Step 10: send the report

Stop terminal A with Ctrl-C and upload `~/phase8_report.txt` here, plus terminal A's output if
anything failed.

---

## Before the first real flight (not in this phase)

Nothing in this document makes the drone fly. Before the first real, props-on takeoff (tethered,
with you on the RC) we need:

1. **The deferred Phase 5 hand-held flow test**, on the 4S battery and without the Pi cable,
   including the flow direction signs, and tuning `flow_min_quality` (still the placeholder 100) on
   your floor/mat. Hovering without GPS depends entirely on the flow sensor.
2. **[AIRCRAFT] FCU parameters, your decision in Mission Planner:**

| Parameter | Recommended | Why |
|---|---|---|
| `RNGFND1_GNDCLEAR` | 14 (cm) | the MTF-01 reads 0.14 m on the ground (landing gear). This tells ArduPilot, so heights mean "above the floor" and landing detection is cleaner |
| `DISARM_DELAY` | back to 10 | 60 was only for the Phase 7 test |
| `BATT_LOW_VOLT` / `BATT_FS_LOW_ACT` | 13.6 / 1 (Land) | the FCU's own backup if the Pi is gone. The Pi already lands at 14.0 V (`battery_land_v`) |
| `BATT_CRT_VOLT` / `BATT_FS_CRT_ACT` | 13.2 / 1 (Land) | last resort |

   Check that the battery monitor (`BATT_MONITOR`, voltage calibration) reads the same voltage as
   a meter on the battery before relying on these.
3. **A written first-flight plan** (tethered, 0.8 m, short hover, LAND): I will send it as its own
   step after the above, with the checks to do after the first hover (yaw direction, drift, height).
