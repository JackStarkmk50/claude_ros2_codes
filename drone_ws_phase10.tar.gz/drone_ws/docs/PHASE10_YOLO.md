# Phase 10: YOLO person detection on the Pi 5

**Goal:** `yolo_detector` finds people in the camera picture and publishes their boxes on
`/drone/perception/detections`, fast enough and fresh enough to steer by. This phase **measures**
on your Pi 5: frames per second, how old a picture is when its detection comes out, CPU load and
temperature.

**Safety:** nothing here talks to the Pixhawk. Detections only reach the drone later, through the
tracker, the mission and the safety gate.

---

## What is new

| File | What it does |
|---|---|
| `yolo_detector` (real now) | newest frame only → letterbox to 320 px → ONNX Runtime on the CPU → boxes back in original pixels → only `person`, confidence ≥ 0.5. One message per processed frame, empty when nobody is seen, stamped with the **capture time** of the picture. Inference runs in its own thread; frames that arrive meanwhile are dropped, never queued. Frames older than 0.5 s are skipped. Stats on `/diagnostics` and in the log every 10 s. |
| `drone_perception/core/yolo_postprocess.py` | pre/post-processing (letterbox, decode, class filter, NMS), 9 unit tests |
| `tools/yolo_check.py` | `--image photo.jpg`: run the model on a photo without ROS (boxes, ms per frame, CPU temperature, annotated copy). `--live 30`: measure the running detector (Y1 to Y5), append to `~/drone_ws/phase10_report.txt` |
| `drone.yaml` → `yolo_detector` | `model_path` **[SET]** (default `/home/virtua/drone_ws/models/yolo11n_320.onnx`), `num_threads` 3, `max_frame_age_s` 0.5, `publish_debug_image` false |
| `yolo11n_320.onnx` (separate download, 10 MB) | YOLO11n exported at 320 px |

**About the model file:** I exported it from Ultralytics' YOLO11n (`yolo export model=yolo11n.pt
format=onnx imgsz=320`), so you don't need a PC with PyTorch. YOLO11 weights are licensed
AGPL-3.0 by Ultralytics. That is fine for your own project. It matters only if you ever ship the
drone's software as a product. SHA-256:
`e02f23d8d9bcf0655bb731359b08212f7c693c36a7d12f691de2fa5b6be05843`.

**Tested here (not on a Pi):**
- My pre/post-processing gives **exactly** the same boxes as Ultralytics' own code on their two
  sample photos (5 people, every coordinate equal to 0.1 px).
- The whole node ran against `fake_camera.py` (a person cut from a photo, disappearing for 4 s):
  30 fps in, 30 fps out, image age at publish 22 ms, no errors, person found in 72% of frames
  (the other 28% the person was hidden, as intended).
- That machine is much faster than a Pi 5. **I don't know your Pi's numbers yet.** My estimate is
  about 60 to 120 ms per frame (8 to 15 fps) with 3 threads. That is enough: the tracker only
  needs a few updates per second to turn slowly towards a person. Step 3 measures it.

---

## Step 1: update, keep your settings, check onnxruntime

**COMMAND**

```bash
cp ~/drone_ws/src/drone_bringup/config/drone.yaml ~/drone.yaml.mine
tar -xzf drone_ws_phase10.tar.gz -C ~/drone_ws --strip-components=1
python3 ~/drone_ws/tools/carry_settings.py ~/drone.yaml.mine
~/drone_venv/bin/python -c "import onnxruntime, numpy; print('onnxruntime', onnxruntime.__version__, 'numpy', numpy.__version__)"
bash ~/drone_ws/tools/verify_workspace.sh
```

**EXPECTED** `onnxruntime 1.x numpy 1.26.4`, then `Summary: 152 tests, 0 errors, 0 failures, 0 skipped`
and `WORKSPACE CHECK: ALL PASSED`.

**IF NOT**
- `No module named 'onnxruntime'`: `bash ~/drone_ws/tools/setup_venv.sh` (installs it into
  `~/drone_venv`), then repeat.
- numpy 2.x: `~/drone_venv/bin/pip install "numpy==1.26.4"`.

## Step 2: put the model on the Pi

**WHAT** copy `yolo11n_320.onnx` (attached with this phase) to `~/drone_ws/models/`.

**COMMAND** (after copying the file to the Pi's home folder, e.g. with `scp`)

```bash
mkdir -p ~/drone_ws/models
mv ~/yolo11n_320.onnx ~/drone_ws/models/
sha256sum ~/drone_ws/models/yolo11n_320.onnx
grep model_path ~/drone_ws/src/drone_bringup/config/drone.yaml
```

**EXPECTED** the checksum above, and `model_path: "/home/virtua/drone_ws/models/yolo11n_320.onnx"`.

**IF NOT** different checksum: the copy is damaged, copy it again. Different home folder: edit
`model_path` to the full path, then `colcon build --symlink-install`.

## Step 3: the model on a photo from your own camera (timing on the Pi)

**WHAT** take a picture with you in it, then run the model on it without ROS. This gives the pure
model speed on your Pi.

**COMMAND**

Terminal A (camera only):

```bash
source ~/drone_ws/env.sh
ros2 launch drone_bringup perception.launch.py use_detector:=false use_tracker:=false
```

Terminal B: stand 2 to 4 m in front of the camera, run this, and stay still for 10 s:

```bash
source ~/drone_ws/env.sh
python3 ~/drone_ws/tools/camera_check.py
python3 ~/drone_ws/tools/yolo_check.py --image ~/drone_ws/camera_snapshot.jpg | tee ~/drone_ws/phase10_report.txt
```

Stop terminal A (Ctrl-C).

**EXPECTED**
- `1 detection(s): person 0.7..0.9 box ...`
- `time per frame over 30 runs: median NN ms`. Anything under 150 ms is fine.
- `~/drone_ws/camera_snapshot_detections.jpg` shows a green box around you.

**IF NOT**
- `0 detection(s)`: check the snapshot. Are you in it, and well lit? Stand fully in the picture,
  2 to 4 m away.
- median above 200 ms: send me the output. I will try 2 or 4 threads, or a 256 px model.

## Step 4: live detection

**WHAT** camera and detector together, measured while you walk in and out of the picture.

**COMMAND**

Terminal A:

```bash
ros2 launch drone_bringup perception.launch.py use_tracker:=false
```

**EXPECTED** from `yolo_detector`: `up: /home/virtua/drone_ws/models/yolo11n_320.onnx at 320 px,
classes person ...`, then every 10 s a line like
`camera 30.0 fps, detector 11.2 fps, model 85 ms, image age at publish 120 ms (max 180), CPU 58 C`.

Terminal B, then walk in front of the camera, out of the picture, and back, for 30 s:

```bash
python3 ~/drone_ws/tools/yolo_check.py --live 30
```

**EXPECTED** `YOLO CHECK: ALL PASSED`:

| Check | Meaning |
|---|---|
| Y1 | detections arrive (one message per processed frame, also when empty) |
| Y2 ≥ 5 fps | enough updates to steer by |
| Y3 image age ≤ 300 ms | how old the picture is when its detection comes out |
| Y4 (info) | in what share of frames a person was found. It should roughly match how long you were in the picture |
| Y5 CPU < 80 C | the Pi 5 starts slowing itself down around 80 to 85 C |

**IF NOT**
- `ERROR ... no detection: model file not found`: step 2.
- Y2 below 5 fps: send me the log lines. Other programs may be using the CPU (`top`).
- Y4 at 0% although you were in the picture: send me the snapshot from step 3.

## Step 5: heat check (5 minutes)

**WHAT** leave terminal A running for 5 minutes with someone in the picture, then:

```bash
python3 ~/drone_ws/tools/yolo_check.py --live 20
```

**EXPECTED** Y5 still PASS, and the detector fps about the same as in step 4.

**IF NOT** above 80 C: check that the active cooler spins. We can also limit the detector with
`max_rate_hz: 8.0` in `drone.yaml`.

## Step 6: send the report

Upload `~/drone_ws/phase10_report.txt` (it collects steps 3 to 5), and a line from terminal A's
log.
