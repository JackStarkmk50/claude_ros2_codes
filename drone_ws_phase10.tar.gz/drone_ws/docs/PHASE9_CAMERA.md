# Phase 9: USB camera

**Goal:** the Zebronics USB camera publishes frames the rest of the stack can trust:
- `/camera/image_raw` at a steady rate, in the size and encoding the detector expects;
- each frame stamped with its **capture time** on the Pi's clock (the tracker uses it to know how
  old a detection is);
- a TF chain `base_link → camera_link → camera_optical_frame` describing where the camera sits.

**Safety:** nothing here talks to the Pixhawk. The drone can stay powered off or on USB. Run the
FCU part or not, it does not matter for this phase.

---

## What is new

| File | What it does |
|---|---|
| `perception.launch.py` | starts `v4l2_camera_node` (as `/camera/camera`, topics `/camera/image_raw` and `/camera/camera_info`) and two static transforms from the `camera_mount` values. New launch arguments: `use_camera`, `camera_device`, `use_detector`, `use_tracker` |
| `drone.yaml` | new sections `/camera/camera` (device, `pixel_format` **[SET]**, `image_size` **[SET]**, `output_encoding` rgb8, frame `camera_optical_frame`) and `camera_mount` (where the camera sits, **[TUNE: measure]**) |
| `tools/camera_check.py` | listens 10 s and prints PASS/FAIL for C1 to C10 (rate, size, encoding, frame, stamp, gaps, camera_info, TF). Saves `~/drone_ws/camera_snapshot.jpg` and `~/drone_ws/phase9_report.txt` |
| `tools/fake_camera.py` | publishes frames without a camera (test pattern, a photo, or a virtual room that turns with the drone's heading). Used in later phases and in my simulator tests |
| `tools/carry_settings.py` | after an update, copies your own `[SET]` values (for example the EKF origin from Phase 8) from your old `drone.yaml` into the new one |
| `drone_perception/core/` | image conversion (rgb8, bgr8, mono8, YUYV) without cv_bridge, frame statistics, virtual room. 142 tests in total now |

**Honest limits**
- I have no USB camera here. `camera_check.py`, the TF chain and the launch file were tested
  against `fake_camera.py` (C1 to C10 all PASS, 30 fps). `v4l2_camera_node` itself was only
  checked for reading its settings from `drone.yaml`; how it behaves with your camera is what this
  phase tests.
- The camera is **not calibrated** and does not need to be: the tracker only uses where the person
  is in the picture (left/right), not distances.
- One thing I found while testing: full-size images sent "best effort" arrive at only about 7 of
  30 frames per second in ROS 2. Everything in this stack receives images "reliable, newest frame
  only", which arrives at the full rate.

---

## Step 1: update the workspace, keep your settings

**WHAT** install Phase 9 without losing the values you set in `drone.yaml` (EKF origin).

**COMMAND**

```bash
cp ~/drone_ws/src/drone_bringup/config/drone.yaml ~/drone.yaml.mine
tar -xzf drone_ws_phase9.tar.gz -C ~/drone_ws --strip-components=1
python3 ~/drone_ws/tools/carry_settings.py ~/drone.yaml.mine
sudo apt install -y ros-jazzy-v4l2-camera v4l-utils python3-opencv
bash ~/drone_ws/tools/verify_workspace.sh
```

**EXPECTED**
- `carried  fcu_command_node.ekf_origin_lat_deg: 0.0 -> <yours>` (and lon), if you had set them
- apt says the packages are installed or already the newest version
- `Summary: 142 tests, 0 errors, 0 failures, 0 skipped` and `WORKSPACE CHECK: ALL PASSED`

**IF NOT** paste the output. `check ... [TUNE]` lines are not errors: they list tuning values that
differ from mine, which I left as they are in the new file. Tell me if you had tuned one of them.

## Step 2: find what your camera can do

**WHAT** list the formats and sizes the camera supports.

**COMMAND**

```bash
groups | grep -q video && echo "video group OK" || echo "NOT in video group"
v4l2-ctl -d /dev/video0 --list-formats-ext
```

**EXPECTED** `video group OK`, then a list like:

```
[0]: 'MJPG' (Motion-JPEG, compressed)
        Size: Discrete 1280x720 ...
[1]: 'YUYV' (YUYV 4:2:2)
        Size: Discrete 640x480
                Interval: Discrete 0.033s (30.000 fps)
```

**Why it matters:** `drone.yaml` uses `pixel_format: "YUYV"` and `image_size: [640, 480]`. The
detector shrinks every frame to 320 px anyway, so 640x480 is plenty and keeps the Pi 5 CPU for
YOLO.

**IF NOT**
- `NOT in video group`: `sudo usermod -aG video $USER`, then log out and back in.
- YUYV is not listed at 640x480: send me the list and I will pick the setting.
- nothing on `/dev/video0`: `v4l2-ctl --list-devices`, then use `camera_device:=/dev/videoN`
  below.

## Step 3: start the camera (terminal A)

**COMMAND**

```bash
source ~/drone_ws/env.sh
ros2 launch drone_bringup perception.launch.py use_detector:=false use_tracker:=false
```

**EXPECTED** no ERROR lines from `camera` (it may print what format and size it set), and
both `static_transform_publisher` nodes running. Leave it running.

**IF NOT**
- `Failed opening device /dev/video0: Permission denied`: the video group (step 2).
- `... Device or resource busy`: another program uses the camera (close it, or reboot).
- a format or size error: send me the output of step 2 and terminal A.

## Step 4: run the camera check (terminal B)

**COMMAND**

```bash
source ~/drone_ws/env.sh
python3 ~/drone_ws/tools/camera_check.py
```

**EXPECTED** all ten lines `PASS`, then `CAMERA CHECK: ALL PASSED`:

| Check | Meaning |
|---|---|
| C1 frames arrive | the driver publishes |
| C2 frame rate ≥ 15 fps | enough for detection (YOLO will run slower than this anyway) |
| C3 / C4 / C5 | 640x480, `rgb8`, frame `camera_optical_frame` |
| C6 stamp = capture time | the stamp is 0 to 150 ms behind the Pi's clock, never ahead |
| C7 / C8 | stamps increase, no gap longer than 0.5 s |
| C9 camera_info | same size and frame. "not calibrated" is fine |
| C10 TF | the camera transform exists |

**IF NOT**
- C2 low (for example 7 to 15 fps): often low light (the camera slows its exposure). Turn the
  room light on and repeat. Then check the USB cable/port (use a USB 3 port on the Pi).
- C6 fails with a very large number: the driver's stamps are not on the Pi's clock. Send me the
  line.
- anything else: send me `~/drone_ws/phase9_report.txt` and terminal A.

## Step 5: look at the snapshot

**WHAT** check that the picture is the right way round.

Open `~/drone_ws/camera_snapshot.jpg` (copy it to your laptop, for example with
`scp virtua@viruta:~/drone_ws/camera_snapshot.jpg .`).

**EXPECTED** the picture is upright, and something on the drone's **left** is on the **left** of
the picture (not mirrored). This matters: the tracker turns the drone towards where the person is
in the picture. A mirrored picture would make it turn the wrong way.

**IF NOT** mounted upside down or mirrored: tell me, and I will add a flip before the detector
(easier than remounting).

## Step 6: measure the camera mount [TUNE]

**WHAT** tell the stack where the camera sits. It is only used for the TF tree (visualisation
and later work). Tracking works without exact values.

Measure from the centre of the frame (between the motors) to the lens:

```yaml
camera_mount:
  ros__parameters:
    x_m: 0.08          # forward
    y_m: 0.0           # left
    z_m: 0.02          # up
    tilt_down_deg: 0.0 # 0 = looking straight ahead, 20 = looking 20 degrees down
    yaw_left_deg: 0.0
```

Edit `~/drone_ws/src/drone_bringup/config/drone.yaml`, then `colcon build --symlink-install`
in `~/drone_ws`.

## Step 7: send the report

Upload `~/drone_ws/phase9_report.txt`, tell me what step 5 showed (upright? mirrored?), and your
mount measurements.
