# Phase 5: optical flow on your floor (hand-held, props off)

**Goal:** measure how the MTF-01 behaves over your real floor, so the flow thresholds in
`drone.yaml` come from data instead of guesses. Also check that the sign conventions are right
(tilt, heading, direction of movement) and see what the EKF does with flow.

**Safety:** **PROPS OFF**, disarmed, battery connected. You hold the drone in your hands. Nothing
in this phase arms, changes a mode, or writes an FCU parameter; `flow_test.py` only listens.

No node code changes in this phase. New: `tools/flow_test.py` (a guided recorder).

---

## Before you start (from Phase 4)

These are not needed for the test itself, but please tell me in your Step 4 message:

| # | Question |
|---|---|
| R1 | RC receiver: with the transmitter on, open Mission Planner → Radio Calibration and switch the transmitter off. Do the bars **drop** or **freeze**? If they freeze, the receiver holds the last sticks and neither ArduPilot nor the Pi can see the RC loss. Set the receiver's failsafe to "no pulses" (see its manual). |
| R2 | Battery: with the 4S pack connected, what does `state_monitor.py` show for `batt`? It should match a multimeter on the pack to within about 0.2 V. |
| R3 | `ARMING_CHECK`: did you set it to 1? If so, what `FCU says: PreArm: ...` lines appear in terminal A? |

## Step 1: update the workspace

**COMMAND**

```bash
tar -xzf drone_ws_phase5.tar.gz -C ~/drone_ws --strip-components=1
bash ~/drone_ws/tools/verify_workspace.sh
```

**EXPECTED** `Summary: 53 tests, 0 errors, 0 failures, 0 skipped` and `WORKSPACE CHECK: ALL PASSED`.
**IF NOT** paste the FAIL lines.

## Step 2: start the FCU layer (terminal A)

Props off, battery connected, TELEM1 connected.

```bash
source ~/drone_ws/env.sh
ros2 launch drone_bringup fcu.launch.py
```

**EXPECTED** `FCU link up` and the 8 `stream requested` lines, as in Phase 4.

## Step 3: guided flow test (terminal B)

Use the floor the drone will actually fly over. Good light helps; a plain glossy floor is the
worst case for any flow sensor.

**COMMAND**

```bash
source ~/drone_ws/env.sh
python3 ~/drone_ws/tools/flow_test.py
```

The script tells you what to do for each step. Get in position, press Enter, and hold until it
prints the result (5–10 s per step, about 3 minutes in total).

| Step | You do | What it checks | Expected |
|---|---|---|---|
| floor | drone flat on the floor | height sitting on the landing gear | about 0.14 m, below the 0.25 m on-ground limit → PASS |
| pitch | tilt nose down ~20° | pitch sign | positive → PASS |
| roll | right side down ~20° | roll sign | positive → PASS |
| north | nose to North (phone compass) | heading | near 0° (±30° indoors) → PASS or CHECK |
| h50 / h100 / h150 | hold level and still at 0.5 / 1.0 / 1.5 m | height accuracy and flow quality per height | INFO: the numbers I use to set `flow_min_quality` and the height band |
| rotate | at 1 m, rock it in place (don't move the sensor over the floor) | flow vs. gyro: rotation compensation | INFO: I interpret it. Large compensated flow while only rotating points at `FLOW_FXSCALER` / `FLOW_FYSCALER` / `FLOW_ORIENT_YAW` |
| forward | at 1 m, walk forward ~1 m | EKF velocity direction | x positive → PASS. CHECK means the EKF didn't produce velocity while disarmed (possible; then this check moves to the props-off armed test in Phase 7) |
| left | at 1 m, move left ~1 m | same, y axis | y positive → PASS (or CHECK as above) |
| cover | at 1 m, cover the lens | quality drop is detected | quality below 100 and `flight False` → PASS |

**IF NOT**

| What you see | WHY | CHECK / FIX |
|---|---|---|
| `FAIL ... no /drone/vehicle_state` | terminal A isn't running or has stopped | restart Step 2 |
| pitch or roll FAIL (negative) | would mean a frame error on our side | paste the report; stop here |
| forward/left FAIL (negative velocity) | the EKF believes the drone moves the opposite way: flow orientation wrong. **This must be fixed before any flight.** | paste the report. Do not change `FLOW_ORIENT_YAW` until we have looked at the numbers together |
| height far from what you hold | sensor mounting, or a reflective/dark floor | paste the report |
| `KeyboardInterrupt` / stopped early | Ctrl-C | the report still saves the steps done so far |

You can re-run single steps, for example:

```bash
python3 ~/drone_ws/tools/flow_test.py --steps h100,forward,left
```

## Step 4: send me

1. `~/drone_ws/phase5_report.txt`
2. answers to R1, R2, R3
3. what the floor is (tiles, wood, carpet, mat...) and whether the room lighting was normal

From that I will:
- set `flow_min_quality` and the flow height band from your numbers;
- decide whether any FCU flow calibration is needed (your decision to apply);
- write down which EKF flags your setup shows on the ground and in hand, for the pre-flight check.

After that comes Phase 6: the safety supervisor and the command gate, still in bench mode, with
nothing sent to the aircraft.
