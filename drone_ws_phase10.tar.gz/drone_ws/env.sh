# Source this in every terminal:  source ~/drone_ws/env.sh
# Order matters: ROS, then the workspace, then the pip-only packages from the venv.

source /opt/ros/jazzy/setup.bash

WS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "$WS_DIR/install/setup.bash" ]; then
  source "$WS_DIR/install/setup.bash"
else
  echo "[env.sh] $WS_DIR/install not found yet: run colcon build first"
fi

# pip-only packages (onnxruntime, pymavlink, anthropic) live in ~/drone_venv.
# ROS executables run with /usr/bin/python3, so the venv is added via PYTHONPATH
# instead of relying on 'activate'.
VENV_SITE="$HOME/drone_venv/lib/python3.12/site-packages"
if [ -d "$VENV_SITE" ]; then
  export PYTHONPATH="$PYTHONPATH:$VENV_SITE"
fi

export ROS_DOMAIN_ID="${ROS_DOMAIN_ID:-42}"   # keep the drone on its own DDS domain
