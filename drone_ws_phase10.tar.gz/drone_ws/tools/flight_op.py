#!/usr/bin/env python3
"""Operator command for one flight operation, through the safety gate. [AIRCRAFT]

  python3 flight_op.py preflight        ask safety_supervisor for the pre-flight check only
  python3 flight_op.py takeoff 0.8      TAKEOFF to 0.8 m above the takeoff point
  python3 flight_op.py land             LAND now

Sends a FlightOperation goal to /drone/flight/operation (safety_supervisor) as source
"operator" and prints every stage until the result. Ctrl-C during a TAKEOFF cancels it: if
already armed, the drone LANDS. A LAND cannot be cancelled from here (only by the pilot with
the RC mode switch). Nothing is sent unless the stack runs with enable_fcu_output:=true, and a
TAKEOFF also needs allow_arming:=true.
"""

import argparse
import math
import sys
import time

import rclpy
from rclpy.action import ActionClient
from rclpy.signals import SignalHandlerOptions
from rclpy.node import Node
from std_srvs.srv import Trigger

from drone_interfaces.action import FlightOperation

STAGES = ['NONE', 'PREFLIGHT', 'SET_GUIDED', 'ARM', 'TAKEOFF_CMD', 'CLIMB', 'STABILIZE',
          'SET_LAND', 'DESCEND', 'TOUCHDOWN', 'DISARM']


def preflight(node):
    client = node.create_client(Trigger, '/drone/safety/preflight_check')
    if not client.wait_for_service(timeout_sec=5.0):
        print('safety_supervisor not reachable: is the stack running?')
        return 2
    future = client.call_async(Trigger.Request())
    rclpy.spin_until_future_complete(node, future, timeout_sec=5.0)
    r = future.result()
    print(r.message.replace(' | ', '\n  ') if r else 'no answer')
    return 0 if r and r.success else 1


def run_op(node, op, altitude):
    client = ActionClient(node, FlightOperation, '/drone/flight/operation')
    if not client.wait_for_server(timeout_sec=5.0):
        print('safety_supervisor not reachable: is the stack running?')
        return 2
    goal = FlightOperation.Goal(op=op, altitude_m=float(altitude), source='operator',
                                reason='flight_op.py')
    last = [None]

    def on_feedback(msg):
        f = msg.feedback
        line = (f'{STAGES[f.stage]:12} {f.elapsed_in_stage_s:5.1f} s  height '
                f'{f.height_m:5.2f} m  {f.detail}')
        key = (f.stage, f.detail.split(':')[0])
        if key != last[0]:
            print(line, flush=True)
            last[0] = key

    t0 = time.monotonic()
    future = client.send_goal_async(goal, feedback_callback=on_feedback)
    rclpy.spin_until_future_complete(node, future, timeout_sec=5.0)
    gh = future.result()
    if gh is None or not gh.accepted:
        print('goal not accepted')
        return 1
    result_future = gh.get_result_async()
    cancel_sent = False
    while not result_future.done():
        try:
            rclpy.spin_once(node, timeout_sec=0.1)
        except KeyboardInterrupt:
            if op == FlightOperation.Goal.OP_LAND:
                print('\nA LAND cannot be cancelled from here. Take over with the RC mode '
                      'switch if needed. Waiting for the result...')
            elif not cancel_sent:
                print('\nCancelling the TAKEOFF: the drone LANDS if it is armed...')
                gh.cancel_goal_async()
                cancel_sent = True
    r = result_future.result().result
    status = 'OK' if r.success else f'FAILED at {STAGES[r.failed_stage]}'
    height = 'n/a' if math.isnan(r.height_at_end_m) else f'{r.height_at_end_m:.2f} m'
    print(f'\nRESULT: {status}: {r.message}')
    if r.failed_stage == FlightOperation.Result.STAGE_PREFLIGHT:
        return 1   # refused before anything was sent: no end state to report
    print(f'  after {time.monotonic() - t0:.1f} s: armed {r.armed_at_end}, landed_state '
          f'{r.landed_state_at_end}, height {height}')
    return 0 if r.success else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('op', choices=['preflight', 'takeoff', 'land'])
    parser.add_argument('altitude', nargs='?', type=float, default=math.nan,
                        help='TAKEOFF height above the takeoff point, m')
    args = parser.parse_args()
    if args.op == 'takeoff' and math.isnan(args.altitude):
        parser.error('takeoff needs an altitude, e.g. takeoff 0.8')
    # No rclpy SIGINT handler: it would shut ROS down on Ctrl-C before the cancel is sent.
    rclpy.init(signal_handler_options=SignalHandlerOptions.NO)
    node = Node('flight_op')
    try:
        if args.op == 'preflight':
            code = preflight(node)
        elif args.op == 'takeoff':
            code = run_op(node, FlightOperation.Goal.OP_TAKEOFF, args.altitude)
        else:
            code = run_op(node, FlightOperation.Goal.OP_LAND, 0.0)
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
    sys.exit(code)


if __name__ == '__main__':
    main()
