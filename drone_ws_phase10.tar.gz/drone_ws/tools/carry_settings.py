#!/usr/bin/env python3
"""Carry your own [SET] values from an old drone.yaml into a new one (after an update).

  cp ~/drone_ws/src/drone_bringup/config/drone.yaml ~/drone.yaml.mine     # BEFORE extracting
  tar -xzf drone_ws_phaseN.tar.gz -C ~/drone_ws --strip-components=1
  python3 ~/drone_ws/tools/carry_settings.py ~/drone.yaml.mine

Every line marked [SET] in the new file gets the value from the same node + key in your old
file, if it exists there. Comments and everything else in the new file stay as they are. It
prints each value it carried. Nothing else is changed; [TUNE] values are listed so you can
compare them by hand.
"""

import argparse
import os
import re
import sys

NEW_DEFAULT = os.path.expanduser('~/drone_ws/src/drone_bringup/config/drone.yaml')
KEY = re.compile(r'^(\s+)([A-Za-z0-9_]+):\s*([^#]*?)(\s*#.*)?$')
NODE = re.compile(r'^([^\s#][^:]*):')


def index(lines):
    """{(node, key): (line_no, indent, value, comment)} for 'key: value' lines."""
    out, node = {}, None
    for i, line in enumerate(lines):
        m = NODE.match(line)
        if m:
            node = m.group(1).strip()
            continue
        k = KEY.match(line.rstrip('\n'))
        if k and node and k.group(2) != 'ros__parameters':
            out[(node, k.group(2))] = (i, k.group(1), k.group(3).strip(), k.group(4) or '')
    return out


def carry(old_lines, new_lines):
    old, new = index(old_lines), index(new_lines)
    carried, differ = [], []
    for (node, key), (i, indent, value, comment) in sorted(new.items(), key=lambda x: x[1][0]):
        if (node, key) not in old:
            continue
        old_value = old[(node, key)][2]
        if '[SET]' in comment and old_value != value:
            head = f'{indent}{key}: {old_value}'
            column = new_lines[i].find('#')                  # keep the comment where it was
            pad = ' ' * max(1, column - len(head)) if comment else ''
            new_lines[i] = f'{head}{pad}{comment.strip()}\n'
            carried.append(f'{node}.{key}: {value} -> {old_value}')
        elif '[TUNE' in comment and old_value != value:
            differ.append(f'{node}.{key}: new {value}, yours {old_value}')
    return new_lines, carried, differ


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('old', help='your previous drone.yaml')
    p.add_argument('new', nargs='?', default=NEW_DEFAULT)
    a = p.parse_args()
    with open(a.old) as f:
        old_lines = f.readlines()
    with open(a.new) as f:
        new_lines = f.readlines()
    new_lines, carried, differ = carry(old_lines, new_lines)
    with open(a.new, 'w') as f:
        f.writelines(new_lines)
    for line in carried:
        print(f'carried  {line}')
    if not carried:
        print('nothing to carry (no [SET] value differs)')
    for line in differ:
        print(f'check    {line}  (not changed; [TUNE] values are yours to compare)')
    print(f'written: {a.new}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
