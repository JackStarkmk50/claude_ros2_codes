#!/usr/bin/env bash
# Phase 3, with MAVROS running: verify the link, list what arrives, record key FCU parameters.
# Read-only: it arms nothing, changes no mode and writes no FCU parameter.
set -u
OUT="$HOME/drone_ws/phase3_report.txt"
exec > >(tee "$OUT") 2>&1
fail=0

echo "== 1. connection"
if [ "$(timeout 20 ros2 topic echo --once --field connected /mavros/state 2>/dev/null | head -1)" = "True" ]; then
  echo "PASS  /mavros/state connected: True"
else
  echo "FAIL  not connected within 20 s (see README Phase 3 'IF NOT')"; exit 1
fi
timeout 5 ros2 topic echo --once /mavros/state 2>/dev/null | grep -E "armed|guided|mode|system_status"

echo "== 2. firmware"
timeout 10 ros2 service call /mavros/vehicle_info_get mavros_msgs/srv/VehicleInfoGet "{get_all: false}" 2>/dev/null \
  | grep -oE "flight_sw_version=[0-9]+|autopilot=[0-9]+|type=[0-9]+" | head -3

echo "== 3. MAVROS setup"
n=$(ros2 node list 2>/dev/null | grep -cE "^/mavros/")
echo "INFO  MAVROS plugin nodes loaded: $n (expected 12)"
[ "$(ros2 param get /mavros/local_position tf.send 2>/dev/null)" = "Boolean value is: False" ] \
  && echo "PASS  local_position tf.send = False (no map/odom TF)" \
  || { echo "FAIL  local_position tf.send is not False"; fail=1; }

echo "== 4. topic rates (6 s each)"
for t in /mavros/state /mavros/imu/data /mavros/local_position/pose /mavros/local_position/velocity_body \
         /mavros/battery /mavros/sys_status /mavros/extended_state /mavros/rc/in \
         /mavros/optical_flow/raw/optical_flow /mavros/rangefinder/rangefinder; do
  r=$(timeout 7 ros2 topic hz --window 50 "$t" 2>/dev/null | grep "average rate" | tail -1 | awk '{print $3}')
  printf '%-45s %s Hz\n' "$t" "${r:-NONE}"
done

echo "== 5. one optical-flow and rangefinder sample"
timeout 5 ros2 topic echo --once /mavros/optical_flow/raw/optical_flow 2>/dev/null | grep -E "quality|ground_distance" \
  || echo "NONE  no OPTICAL_FLOW yet (normal before request_streams.sh)"
timeout 5 ros2 topic echo --once --field range /mavros/rangefinder/rangefinder 2>/dev/null | head -1 | sed 's/^/range_m: /' \
  || echo "NONE  no RANGEFINDER yet"

echo "== 6. raw MAVLink on the wire (10 s)"
python3 "$HOME/drone_ws/tools/mavlink_link_stats.py" 10 115200

echo "== 7. FCU parameters (read-only pull; can take ~1 min at 115200)"
timeout 180 ros2 service call /mavros/param/pull mavros_msgs/srv/ParamPull "{force_pull: false}" 2>/dev/null \
  | grep -oE "success=[A-Za-z]+|param_received=[0-9]+"
ros2 param dump /mavros/param 2>/dev/null > /tmp/fcu_params_dump.yaml
python3 - /tmp/fcu_params_dump.yaml <<'PYEOF'
import sys
import yaml
with open(sys.argv[1]) as f:
    doc = yaml.safe_load(f) or {}
params = next(iter(doc.values()), {}).get('ros__parameters', {})
WANT = """SERIAL1_PROTOCOL SERIAL1_BAUD FLOW_TYPE FLOW_ORIENT_YAW RNGFND1_TYPE RNGFND1_MIN RNGFND1_MAX
RNGFND1_MIN_CM RNGFND1_MAX_CM EK3_SRC1_POSXY EK3_SRC1_VELXY EK3_SRC1_POSZ EK3_SRC1_YAW GUID_TIMEOUT
GUID_OPTIONS DISARM_DELAY LAND_SPEED PILOT_SPEED_UP WPNAV_SPEED_UP ARMING_CHECK FS_THR_ENABLE
FS_EKF_ACTION FS_EKF_THRESH FS_GCS_ENABLE BATT_MONITOR BATT_LOW_VOLT BATT_CRT_VOLT BATT_FS_LOW_ACT
BATT_FS_CRT_ACT FENCE_ENABLE FENCE_TYPE FENCE_ALT_MAX FLTMODE_CH FLTMODE1 FLTMODE2 FLTMODE3
FLTMODE4 FLTMODE5 FLTMODE6 SYSID_MYGCS SR1_RAW_SENS SR1_EXT_STAT SR1_RC_CHAN SR1_POSITION
SR1_EXTRA1 SR1_EXTRA2 SR1_EXTRA3""".split()
print(f'INFO  {len(params)} FCU parameters available')
for name in WANT:
    print(f'{name:<18} {params.get(name, "(not on this firmware)")}')
for name in sorted(k for k in params if k.startswith('RC') and k.endswith('_OPTION')):
    if params[name]:
        print(f'{name:<18} {params[name]}')
PYEOF

echo "== done. Report saved to $OUT"
[ $fail = 0 ] || exit 1
