#!/usr/bin/env python3
"""Watch /drone/vehicle_state and /drone/flow_status (read-only; sends nothing).

  python3 state_monitor.py            one summary line per second until Ctrl-C
  python3 state_monitor.py --check 15 listen 15 s, print PASS/WARN/FAIL checks and write
                                      ~/drone_ws/phase4_report.txt
"""

import argparse
import math
import os
import sys
import time

import rclpy
from diagnostic_msgs.msg import DiagnosticArray
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data

from drone_interfaces.msg import FlowStatus, VehicleState

LANDED = {0: 'UNDEFINED', 1: 'ON_GROUND', 2: 'IN_AIR', 3: 'TAKEOFF', 4: 'LANDING'}
REPORT = os.path.expanduser('~/drone_ws/phase4_report.txt')


def fmt(x, spec='.2f', unit=''):
    return 'n/a' if x is None or (isinstance(x, float) and math.isnan(x)) else f'{x:{spec}}{unit}'


def summary(v, f):
    hdg = 'n/a' if math.isnan(v.yaw_rad) else f'{round(90.0 - math.degrees(v.yaw_rad)) % 360}'
    link = f'LINK {"up" if v.connected else "DOWN"} hb {fmt(v.heartbeat_age_s, ".1f", "s")}'
    fcu = f'{v.mode or "?"} {"ARMED" if v.armed else "disarmed"} {LANDED.get(v.landed_state)}'
    pre = f'prearm {"ok" if v.fcu_prearm_ok else "NO"}'
    if v.last_prearm_text:
        pre += f' ({v.last_prearm_text})'
    att = (f'roll {fmt(math.degrees(v.roll_rad), ".1f")} pitch '
           f'{fmt(math.degrees(v.pitch_rad), ".1f")} hdg {hdg}')
    height = f'h {fmt(v.height_above_ground_m, ".2f", "m")}{"" if v.height_valid else " INVALID"}'
    flow = f'flow q{f.quality} {"fresh" if f.fresh else "STALE"}'
    ekf = (f'EKF 0x{v.ekf_flags:x} att {int(v.ekf_attitude_ok)} vel {int(v.ekf_velocity_horiz_ok)}'
           f' pos {int(v.ekf_pos_horiz_rel_ok)}')
    ready = (f'takeoff {"ok" if f.healthy_for_takeoff else "NO"} '
             f'flight {"ok" if f.healthy_for_flight else "NO"}')
    return ' | '.join([link, fcu, pre, f'RC {"yes" if v.rc_present else "NO"}',
                       f'batt {fmt(v.battery_voltage_v, ".2f", "V")}', att, height, flow, ekf,
                       ready]) + (f' [{f.reason}]' if f.reason else '')


class Monitor(Node):

    def __init__(self):
        super().__init__('state_monitor')
        self.vehicle = []
        self.flow = []
        self.diag = {}
        self.create_subscription(VehicleState, '/drone/vehicle_state',
                                 lambda m: self.vehicle.append((time.monotonic(), m)), 10)
        self.create_subscription(FlowStatus, '/drone/flow_status',
                                 lambda m: self.flow.append((time.monotonic(), m)), 10)
        self.create_subscription(DiagnosticArray, '/diagnostics', self._on_diag,
                                 qos_profile_sensor_data)

    def _on_diag(self, msg):
        for status in msg.status:
            if 'fcu_state:' in status.name:
                self.diag[status.name] = status


def run_live(node):
    last = 0.0
    while rclpy.ok():
        rclpy.spin_once(node, timeout_sec=0.1)
        if time.monotonic() - last >= 1.0 and node.vehicle and node.flow:
            last = time.monotonic()
            print(time.strftime('%H:%M:%S'), summary(node.vehicle[-1][1], node.flow[-1][1]),
                  flush=True)
            node.vehicle.clear()
            node.flow.clear()


def run_check(node, seconds):
    lines = []

    def out(text):
        print(text, flush=True)
        lines.append(text)

    out(f'== Phase 4 state check ({seconds} s)')
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        rclpy.spin_once(node, timeout_sec=0.1)
    if not node.vehicle or not node.flow:
        out('FAIL  no /drone/vehicle_state or /drone/flow_status: is fcu.launch.py running?')
        return lines, False
    v_hz = len(node.vehicle) / seconds
    f_hz = len(node.flow) / seconds
    v = node.vehicle[-1][1]
    f = node.flow[-1][1]
    ok = True

    def check(level, passed, text):
        nonlocal ok
        tag = 'PASS' if passed else level
        if tag == 'FAIL':
            ok = False
        out(f'{tag:<5} {text}')

    check('FAIL', v_hz >= 8.0 and f_hz >= 8.0,
          f'publish rate: vehicle_state {v_hz:.1f} Hz, flow_status {f_hz:.1f} Hz (want 10)')
    check('FAIL', v.connected, f'connected (heartbeat age {v.heartbeat_age_s:.2f} s)')
    check('FAIL', bool(v.mode), f'mode reported: {v.mode or "none"}, armed: {v.armed}')
    check('FAIL', v.landed_state != 0,
          f'landed_state from EXTENDED_SYS_STATE: {LANDED.get(v.landed_state)}')
    check('FAIL', not math.isnan(v.roll_rad),
          'attitude: ' + (f'roll {math.degrees(v.roll_rad):.1f} pitch '
                          f'{math.degrees(v.pitch_rad):.1f} deg' if not math.isnan(v.roll_rad)
                          else 'none (ATTITUDE missing)'))
    check('FAIL', v.height_valid,
          f'rangefinder height: {fmt(v.height_above_ground_m, ".2f", " m")} (DISTANCE_SENSOR)')
    check('FAIL', f.source_seen and f.fresh, f'optical flow from FCU: quality {f.quality}, '
          f'age {fmt(f.age_s, ".2f", " s")}')
    check('FAIL', v.ekf_age_s < 2.0, f'EKF_STATUS_REPORT: flags 0x{v.ekf_flags:x}, att '
          f'{v.ekf_attitude_ok} vel {v.ekf_velocity_horiz_ok} pos {v.ekf_pos_horiz_rel_ok} '
          f'const_pos {v.ekf_const_pos_mode}, age {fmt(v.ekf_age_s, ".2f", " s")}')
    check('FAIL', not math.isnan(v.battery_voltage_v),
          f'battery reported: {fmt(v.battery_voltage_v, ".2f", " V")}')
    check('WARN', v.battery_voltage_v >= 5.0,
          'battery voltage plausible (WARN below 5 V: pack not connected, or the power '
          'module / BATT_VOLT_PIN / BATT_VOLT_MULT is wrong)')
    check('WARN', v.rc_present, 'RC present (WARN if your transmitter is off)')
    velocity_note = ('present' if v.velocity_valid else 'missing: ArduPilot may need an EKF '
                     'origin indoors (ARCHITECTURE P4), handled in a later phase')
    check('WARN', v.velocity_valid, f'EKF velocity (LOCAL_POSITION_NED) {velocity_note}')
    prearm_texts = sorted({m.last_prearm_text for _, m in node.vehicle if m.last_prearm_text})
    check('WARN', v.fcu_prearm_ok, f'FCU pre-arm bit: {v.fcu_prearm_ok}')
    for text in prearm_texts:
        out(f'INFO  FCU said: {text}')
    if not v.fcu_prearm_ok and not prearm_texts:
        out('INFO  no PreArm text in this window: ArduPilot repeats it every 30 s, so use '
            '--check 35, or read it in Mission Planner\'s Messages tab')
    out(f'INFO  flow healthy_for_takeoff={f.healthy_for_takeoff} '
        f'healthy_for_flight={f.healthy_for_flight} reason: {f.reason or "-"}')
    out('== diagnostics')
    if not node.diag:
        out('WARN  no fcu_state diagnostics received')
    for name, status in sorted(node.diag.items()):
        out(f'{name}: {status.message}')
        for kv in status.values:
            out(f'    {kv.key:<36} {kv.value}')
    out('== last summary line')
    out(summary(v, f))
    out('STATE CHECK: ' + ('ALL REQUIRED PASSED' if ok else 'FAILURES ABOVE'))
    return lines, ok


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', type=float, metavar='SECONDS')
    args = parser.parse_args()
    rclpy.init()
    node = Monitor()
    ok = True
    try:
        if args.check:
            lines, ok = run_check(node, args.check)
            os.makedirs(os.path.dirname(REPORT), exist_ok=True)
            with open(REPORT, 'w') as fh:
                fh.write('\n'.join(lines) + '\n')
            print(f'report saved to {REPORT}')
        else:
            run_live(node)
    except (KeyboardInterrupt, ExternalShutdownException, BrokenPipeError):
        pass
    finally:
        try:
            node.destroy_node()
            rclpy.try_shutdown()
        except KeyboardInterrupt:
            pass
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
