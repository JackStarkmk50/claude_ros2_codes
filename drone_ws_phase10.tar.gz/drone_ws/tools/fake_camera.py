#!/usr/bin/env python3
"""Publish camera frames without a camera, for testing perception and the mission (sends
nothing to the drone).

  python3 fake_camera.py --pattern                     moving test pattern
  python3 fake_camera.py --image photo.jpg             the same photo over and over
  python3 fake_camera.py --world --person-image p.jpg  a virtual room around the drone

World mode: the drone sits in a 360 degree room. The picture it "sees" depends on its heading
(yaw from /drone/vehicle_state, e.g. from SITL), so turning the drone turns the view. A person
cut out of --person-image stands at --person-bearing-deg (degrees LEFT of the heading the drone
had when this tool started). That lets YOLO, the tracker and the mission run closed-loop in SITL.

Publishes /camera/image_raw (rgb8, stamp = now) and /camera/camera_info, frame
camera_optical_frame, like the real camera. Run with use_camera:=false so both don't publish.
"""

import argparse
import math
import time

import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CameraInfo, Image

from drone_interfaces.msg import VehicleState
from drone_perception.qos import IMAGE_QOS
from drone_perception.core.image_convert import rgb_to_image_fields
from drone_perception.core.virtual_world import World, wrap_deg



def load_rgb(path, crop=None):
    import cv2
    bgr = cv2.imread(path)
    if bgr is None:
        raise SystemExit(f'cannot read image {path}')
    if crop:
        x1, y1, x2, y2 = crop
        bgr = bgr[y1:y2, x1:x2]
    return np.ascontiguousarray(bgr[:, :, ::-1])


def resize(rgb, w, h):
    import cv2
    return cv2.resize(rgb, (max(1, int(w)), max(1, int(h))), interpolation=cv2.INTER_AREA)


class FakeCamera(Node):
    def __init__(self, args):
        super().__init__('fake_camera')
        self.args = args
        self.w, self.h = (int(v) for v in args.size.lower().split('x'))
        self.pub = self.create_publisher(Image, '/camera/image_raw', IMAGE_QOS)
        self.info_pub = self.create_publisher(CameraInfo, '/camera/camera_info',
                                              IMAGE_QOS)
        self.yaw0 = None
        self.yaw = 0.0
        self.t0 = time.monotonic()
        self.n = 0
        self.world = None
        self.still = None
        crop = [int(v) for v in args.crop.split(',')] if args.crop else None
        if args.world:
            sprite = load_rgb(args.person_image, crop) if args.person_image else None
            if sprite is not None:
                sh = int(self.h * args.person_height_frac)
                sprite = resize(sprite, sprite.shape[1] * sh / sprite.shape[0], sh)
            self.world = World(self.w, self.h, args.hfov_deg, sprite, args.person_bearing_deg)
            self.create_subscription(VehicleState, '/drone/vehicle_state', self._state, 10)
        elif args.image:
            self.still = resize(load_rgb(args.image, crop), self.w, self.h)
        self.create_timer(1.0 / args.rate, self._tick)
        self.get_logger().info(f'publishing {self.w}x{self.h} rgb8 at {args.rate:.0f} Hz '
                               f'({"world" if args.world else "image" if args.image else "pattern"})')

    def _state(self, msg):
        if not math.isfinite(msg.yaw_rad) or not msg.connected:
            return
        yaw = math.degrees(msg.yaw_rad)
        if self.yaw0 is None:
            self.yaw0 = yaw
        self.yaw = wrap_deg(yaw - self.yaw0)

    def _frame(self):
        t = time.monotonic() - self.t0
        if self.world is not None:
            a = self.args
            self.world.visible = (t >= a.person_appear_after_s
                                  and not (a.person_hide_after_s > 0
                                           and a.person_hide_after_s <= t
                                           < a.person_hide_after_s + a.person_hide_for_s))
            self.world.bearing = a.person_bearing_deg + a.person_walk_deg_s * t
            return self.world.render(self.yaw)
        if self.still is not None:
            return self.still
        frame = np.zeros((self.h, self.w, 3), np.uint8)
        x = int(t * 100) % self.w
        frame[:, x:x + 20] = 255
        frame[:, :, 1] = (np.arange(self.w) * 255 // self.w).astype(np.uint8)
        return frame

    def _tick(self):
        now = self.get_clock().now().to_msg()
        enc, w, h, step, data = rgb_to_image_fields(self._frame())
        msg = Image(encoding=enc, width=w, height=h, step=step, data=data, is_bigendian=0)
        msg.header.stamp = now
        msg.header.frame_id = 'camera_optical_frame'
        self.pub.publish(msg)
        info = CameraInfo(width=w, height=h)
        info.header = msg.header
        self.info_pub.publish(info)
        self.n += 1


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    src = p.add_mutually_exclusive_group()
    src.add_argument('--pattern', action='store_true', help='moving test pattern (default)')
    src.add_argument('--image', help='publish this photo')
    src.add_argument('--world', action='store_true', help='virtual 360 degree room')
    p.add_argument('--size', default='640x480')
    p.add_argument('--rate', type=float, default=30.0)
    p.add_argument('--crop', help='x1,y1,x2,y2 crop of the input image (e.g. one person)')
    p.add_argument('--hfov-deg', type=float, default=60.0, help='world mode: camera view width')
    p.add_argument('--person-image', help='world mode: photo containing the person')
    p.add_argument('--person-bearing-deg', type=float, default=90.0,
                   help='world mode: degrees LEFT of the start heading (negative = right)')
    p.add_argument('--person-height-frac', type=float, default=0.7)
    p.add_argument('--person-appear-after-s', type=float, default=0.0)
    p.add_argument('--person-hide-after-s', type=float, default=0.0,
                   help='world mode: hide the person at this time (0 = never)')
    p.add_argument('--person-hide-for-s', type=float, default=1e9)
    p.add_argument('--person-walk-deg-s', type=float, default=0.0,
                   help='world mode: the person walks around the drone (+ = to the left)')
    args = p.parse_args()
    rclpy.init()
    node = FakeCamera(args)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == '__main__':
    main()
