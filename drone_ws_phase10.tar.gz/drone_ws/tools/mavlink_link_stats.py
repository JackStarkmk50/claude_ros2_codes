#!/usr/bin/env python3
"""Measure what the Pixhawk actually sends over the MAVLink link (read-only).

Listens to MAVROS's raw stream /uas1/mavlink_source for N seconds and prints, per message:
rate (Hz) and bytes/s on the wire, plus the total link load against the serial capacity.
It sends nothing to the FCU.

Usage (MAVROS must be running):
  python3 ~/drone_ws/tools/mavlink_link_stats.py            # 10 s, 115200 baud
  python3 ~/drone_ws/tools/mavlink_link_stats.py 20 921600
"""

import collections
import sys
import time

import rclpy
from mavros_msgs.msg import Mavlink
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data

# Messages this stack cares about (id -> name). Others are shown by id.
NAMES = {
    0: 'HEARTBEAT', 1: 'SYS_STATUS', 2: 'SYSTEM_TIME', 22: 'PARAM_VALUE', 24: 'GPS_RAW_INT',
    27: 'RAW_IMU', 29: 'SCALED_PRESSURE', 30: 'ATTITUDE', 32: 'LOCAL_POSITION_NED',
    33: 'GLOBAL_POSITION_INT', 35: 'RC_CHANNELS_RAW', 36: 'SERVO_OUTPUT_RAW',
    42: 'MISSION_CURRENT',
    62: 'NAV_CONTROLLER_OUTPUT', 65: 'RC_CHANNELS', 74: 'VFR_HUD', 77: 'COMMAND_ACK',
    85: 'POSITION_TARGET_LOCAL_NED', 100: 'OPTICAL_FLOW', 111: 'TIMESYNC',
    116: 'SCALED_IMU2', 125: 'POWER_STATUS', 129: 'SCALED_IMU3', 132: 'DISTANCE_SENSOR',
    136: 'TERRAIN_REPORT', 147: 'BATTERY_STATUS', 148: 'AUTOPILOT_VERSION', 150: 'SENSOR_OFFSETS',
    152: 'MEMINFO', 163: 'AHRS', 164: 'SIMSTATE', 165: 'HWSTATUS', 168: 'WIND', 173: 'RANGEFINDER',
    178: 'AHRS2', 193: 'EKF_STATUS_REPORT', 241: 'VIBRATION', 242: 'HOME_POSITION',
    245: 'EXTENDED_SYS_STATE', 253: 'STATUSTEXT',
}
# Needed by later phases; flagged if missing.
REQUIRED = [0, 1, 30, 32, 100, 147, 193, 245]
RANGE_ANY = [132, 173]          # rangefinder may arrive as either message
MAVLINK2_OVERHEAD = 12          # 10-byte header + 2-byte CRC (no signing)


class LinkStats(Node):

    def __init__(self):
        super().__init__('mavlink_link_stats')
        self.count = collections.Counter()
        self.nbytes = collections.Counter()
        self.bad_crc = 0
        self.create_subscription(Mavlink, '/uas1/mavlink_source', self.on_msg,
                                 qos_profile_sensor_data)

    def on_msg(self, msg):
        if msg.framing_status != Mavlink.FRAMING_OK:
            self.bad_crc += 1
            return
        overhead = MAVLINK2_OVERHEAD if msg.magic == Mavlink.MAVLINK_V20 else 8
        self.count[msg.msgid] += 1
        self.nbytes[msg.msgid] += msg.len + overhead


def main():
    seconds = float(sys.argv[1]) if len(sys.argv) > 1 else 10.0
    baud = int(sys.argv[2]) if len(sys.argv) > 2 else 115200
    rclpy.init()
    node = LinkStats()
    print(f'listening to /uas1/mavlink_source for {seconds:.0f} s ...')
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        rclpy.spin_once(node, timeout_sec=0.1)

    if not node.count:
        print('FAIL  no MAVLink received. Is MAVROS running and /mavros/state connected?')
        sys.exit(1)

    print(f'\n{"id":>4}  {"message":<26}{"Hz":>7}{"bytes/s":>10}')
    total = 0.0
    for msgid, n in sorted(node.count.items(), key=lambda kv: -node.nbytes[kv[0]]):
        bps = node.nbytes[msgid] / seconds
        total += bps
        print(f'{msgid:>4}  {NAMES.get(msgid, "?"):<26}{n / seconds:>7.1f}{bps:>10.0f}')

    capacity = baud / 10.0      # 8N1: 10 bits per byte
    print(f'\nFCU -> Pi total: {total:.0f} bytes/s = {100 * total / capacity:.0f}% '
          f'of {baud} baud ({capacity:.0f} bytes/s). Bad CRC frames: {node.bad_crc}')
    if total > 0.6 * capacity:
        print('WARN  link above 60% busy: command replies may be delayed')

    missing = [f'{i} {NAMES[i]}' for i in REQUIRED if i not in node.count]
    if not any(i in node.count for i in RANGE_ANY):
        missing.append('132 DISTANCE_SENSOR or 173 RANGEFINDER')
    if missing:
        print('MISSING (needed later; request with tools/request_streams.sh): '
              + ', '.join(missing))
    else:
        print('PASS  every message the stack needs is arriving')
    node.destroy_node()
    rclpy.try_shutdown()


if __name__ == '__main__':
    main()
