#!/usr/bin/env python3
"""Phase 7 guided test: the first real setpoints to the Pixhawk. [AIRCRAFT] PROPS OFF.

Needs the whole stack running with output on and the ground test switch:
  ros2 launch drone_bringup bringup.launch.py enable_fcu_output:=true bench_ground_test:=true

You arm and switch modes on the RC. This tool never arms, never changes a mode and never
talks to MAVROS directly. It only:
  - publishes operator yaw commands to /drone/control/command (through the safety gate),
  - reads back what MAVROS really sends to the Pixhawk (/uas1/mavlink_sink),
  - reads the Pixhawk's echo of the target it follows (POSITION_TARGET_LOCAL_NED),
  - at the end, stops safety_supervisor and then fcu_command_node to prove the fallbacks.

Writes ~/drone_ws/phase7_report.txt.

  python3 setpoint_test.py                        all steps
  python3 setpoint_test.py --steps idle,arm,guided,yaw
"""

import argparse
import os
import signal
import subprocess
import sys
import time

import rclpy
from mavros_msgs.msg import Mavlink
from rcl_interfaces.srv import GetParameters
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy, qos_profile_sensor_data
from std_msgs.msg import String
from std_srvs.srv import Trigger

from drone_fcu.core import mavlink_decode as mav
from drone_interfaces.msg import ControlCommand, SafetyStatus, VehicleState

REPORT = os.path.expanduser('~/drone_ws/phase7_report.txt')
YAW_TEST = 0.2              # rad/s FLU (+ = turn left), well below the 30 deg/s gate limit
FRAME_BODY_NED = 8
TYPE_MASK = 1479            # ignore position, acceleration and yaw: velocity + yaw rate
LEVEL_OVERRIDE = 4
WAIT_USER_S = 90.0

RELIABLE = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                      durability=DurabilityPolicy.VOLATILE)
LATCHED = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                     durability=DurabilityPolicy.TRANSIENT_LOCAL)

STEPS = ['check', 'idle', 'arm', 'guided', 'yaw', 'stop', 'override', 'reset', 'estop',
         'safety_lost', 'command_lost']


class Tester(Node):

    def __init__(self):
        super().__init__('setpoint_test')
        self.vehicle = None
        self.vehicle_t = 0.0
        self.safety = None
        self.output = ''
        self.output_t = 0.0
        self.sent = []          # (t, SetPositionTargetLocalNed) MAVROS -> Pixhawk
        self.echo = []          # (t, PositionTargetLocalNed)    Pixhawk -> MAVROS
        self.send_yaw = None    # rad/s FLU while streaming, else None
        # a time-based seq survives a restart of this tool (the gate drops a repeated seq)
        self.seq = int(time.time() * 10) % 2**31
        self.cmd_pub = self.create_publisher(ControlCommand, '/drone/control/command', 10)
        self.create_subscription(VehicleState, '/drone/vehicle_state', self._on_vehicle,
                                 RELIABLE)
        self.create_subscription(SafetyStatus, '/drone/safety_status', self._on_safety, LATCHED)
        self.create_subscription(String, '/drone/fcu/output_state', self._on_output, 10)
        self.create_subscription(Mavlink, '/uas1/mavlink_sink', self._on_sink,
                                 qos_profile_sensor_data)
        self.create_subscription(Mavlink, '/uas1/mavlink_source', self._on_source,
                                 qos_profile_sensor_data)
        self.reset_client = self.create_client(Trigger, '/drone/safety/reset')
        self.create_timer(0.1, self._tick)

    # ---- inputs
    def _on_vehicle(self, msg):
        self.vehicle, self.vehicle_t = msg, time.monotonic()

    def _on_safety(self, msg):
        self.safety = msg

    def _on_output(self, msg):
        self.output, self.output_t = msg.data, time.monotonic()

    def _on_sink(self, msg):
        if msg.msgid == mav.SET_POSITION_TARGET_LOCAL_NED:
            self.sent.append((time.monotonic(),
                              mav.decode(msg.msgid, msg.payload64, msg.len)))

    def _on_source(self, msg):
        if msg.msgid == mav.POSITION_TARGET_LOCAL_NED and msg.sysid == 1 and msg.compid == 1:
            self.echo.append((time.monotonic(), mav.decode(msg.msgid, msg.payload64, msg.len)))

    # ---- output: operator yaw commands through the gate
    def _tick(self):
        if self.send_yaw is None:
            return
        c = ControlCommand()
        c.header.stamp = self.get_clock().now().to_msg()
        c.mode = ControlCommand.MODE_BODY_VELOCITY
        c.source = 'operator'
        self.seq += 1
        c.seq = self.seq
        c.yaw_rate_rad_s = float(self.send_yaw)
        c.max_age_s = 0.3
        self.cmd_pub.publish(c)

    # ---- helpers
    def spin_for(self, seconds):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            rclpy.spin_once(self, timeout_sec=0.02)

    def wait_for(self, predicate, timeout):
        """Seconds until predicate() is true, or None."""
        start = time.monotonic()
        while time.monotonic() - start < timeout:
            rclpy.spin_once(self, timeout_sec=0.02)
            if predicate():
                return time.monotonic() - start
        return None

    def fresh(self):
        return self.vehicle is not None and time.monotonic() - self.vehicle_t < 1.0

    def armed(self):
        return self.fresh() and self.vehicle.armed

    def mode(self):
        return self.vehicle.mode if self.fresh() else '?'

    def level(self):
        return None if self.safety is None else self.safety.level

    def sent_since(self, t0):
        return [m for t, m in self.sent if t >= t0]

    def echo_since(self, t0):
        return [m for t, m in self.echo if t >= t0]

    def get_param(self, node, name):
        client = self.create_client(GetParameters, f'/{node}/get_parameters')
        try:
            if not client.wait_for_service(timeout_sec=3.0):
                return None
            req = GetParameters.Request()
            req.names = [name]
            future = client.call_async(req)
            rclpy.spin_until_future_complete(self, future, timeout_sec=3.0)
            if future.result() is None or not future.result().values:
                return None
            return future.result().values[0].bool_value
        finally:
            self.destroy_client(client)

    def call_reset(self):
        if not self.reset_client.wait_for_service(timeout_sec=3.0):
            return None
        future = self.reset_client.call_async(Trigger.Request())
        rclpy.spin_until_future_complete(self, future, timeout_sec=3.0)
        return future.result()


def say(text):
    print(f'\n>>> {text}', flush=True)


def ask(text):
    try:
        return input(f'\n>>> {text} ').strip().lower()
    except EOFError:
        return ''


def fmt_sp(m):
    return (f'frame {m.coordinate_frame} mask {m.type_mask} v ({m.vx:+.2f} {m.vy:+.2f} '
            f'{m.vz:+.2f}) m/s yaw_rate {m.yaw_rate:+.3f} rad/s')


def zero_translation(msgs):
    return all(abs(m.vx) < 1e-3 and abs(m.vy) < 1e-3 and abs(m.vz) < 1e-3 for m in msgs)


def need_armed_guided(t, verdicts):
    if t.armed() and t.mode() == 'GUIDED':
        return True
    say('Arm on the RC in LOITER (throttle low), then flip the mode switch to GUIDED.')
    if t.wait_for(lambda: t.armed() and t.mode() == 'GUIDED', WAIT_USER_S) is None:
        verdicts.append(('FAIL', f'not armed in GUIDED after {WAIT_USER_S:.0f} s '
                                 f'(armed {t.armed()}, mode {t.mode()})'))
        return False
    t.spin_for(1.0)
    return True


def safety_allows(t, verdicts):
    s = t.safety
    if s is not None and s.level <= 1 and not s.latched:
        return True
    detail = 'no safety_status' if s is None else (
        f'safety level {s.level}{" (latched)" if s.latched else ""}: '
        f'{", ".join(s.active_faults) or "-"}')
    verdicts.append(('FAIL', f'safety does not allow motion, so nothing can be tested: '
                             f'{detail}. Fix that first (disarm, then /drone/safety/reset)'))
    return False


def start_stream(t, verdicts):
    """Stream yaw commands until the command node reports COMMAND."""
    t.send_yaw = YAW_TEST
    if t.wait_for(lambda: t.output.startswith('COMMAND'), 3.0) is None:
        t.send_yaw = None
        verdicts.append(('FAIL', f'yaw commands never reached the Pixhawk: output '
                                 f'"{t.output}"'))
        return False
    t.spin_for(1.0)
    return True


def disarmed_during(t, verdicts):
    if not t.armed():
        verdicts.append(('FAIL', 'the Pixhawk disarmed during the step. ArduCopter disarms by '
                                 'itself after DISARM_DELAY seconds on the ground (see the doc)'))
        return True
    return False


# ---------------------------------------------------------------- steps
def step_check(t, v):
    if t.wait_for(t.fresh, 5.0) is None:
        v.append(('FAIL', 'no /drone/vehicle_state: is bringup.launch.py running?'))
        return
    if t.wait_for(lambda: t.safety is not None and t.output, 5.0) is None:
        v.append(('FAIL', 'no safety_status or output_state: is the whole stack running?'))
        return
    out = t.get_param('fcu_command_node', 'output_enabled')
    ground = t.get_param('safety_supervisor', 'bench_ground_test')
    if out is not True or ground is not True:
        v.append(('FAIL', f'output_enabled={out}, bench_ground_test={ground}; start with '
                          'enable_fcu_output:=true bench_ground_test:=true'))
        return
    if not t.vehicle.connected:
        v.append(('FAIL', 'FCU not connected'))
        return
    answer = ask('Are ALL PROPELLERS REMOVED? Type "props off" to continue:')
    if answer != 'props off':
        v.append(('FAIL', 'props not confirmed off: stopped'))
        return
    v.append(('PASS', f'stack up, output on, ground test on, FCU mode {t.mode()}, '
                      f'armed {t.armed()}, safety level {t.level()}'))


def step_idle(t, v):
    if t.armed():
        say('Disarm on the RC.')
        if t.wait_for(lambda: t.fresh() and not t.armed(), WAIT_USER_S) is None:
            v.append(('FAIL', 'still armed'))
            return
    t0 = time.monotonic()
    t.spin_for(2.0)
    n = len(t.sent_since(t0))
    ok = n == 0 and t.output.startswith('SILENT')
    v.append(('PASS' if ok else 'FAIL',
              f'disarmed: {n} setpoints on the wire (expected 0), output "{t.output}"'))


def step_arm(t, v):
    if not t.armed():
        say('Arm on the RC in LOITER (throttle low, props off). Do NOT switch to GUIDED yet.')
        if t.wait_for(t.armed, WAIT_USER_S) is None:
            v.append(('FAIL', f'not armed after {WAIT_USER_S:.0f} s. If Mission Planner shows '
                              'a PreArm message, send it to me'))
            return
    if t.mode() == 'GUIDED':
        v.append(('CHECK', 'already in GUIDED: switch to LOITER and run --steps arm again'))
        return
    t0 = time.monotonic()
    t.spin_for(2.0)
    n = len(t.sent_since(t0))
    ok = n == 0 and t.output.startswith('SILENT')
    v.append(('PASS' if ok else 'FAIL',
              f'armed in {t.mode()}: {n} setpoints on the wire (expected 0), '
              f'output "{t.output}"'))


def step_guided(t, v):
    if not t.armed():
        v.append(('FAIL', 'not armed: run the arm step first'))
        return
    say('Flip the mode switch to GUIDED.')
    if t.wait_for(lambda: t.mode() == 'GUIDED', WAIT_USER_S) is None:
        v.append(('FAIL', f'mode is {t.mode()}, not GUIDED'))
        return
    t.spin_for(1.0)
    t0 = time.monotonic()
    t.spin_for(3.0)
    if disarmed_during(t, v):
        return
    sent = t.sent_since(t0)
    rate = len(sent) / 3.0
    ok = (t.output.startswith('HOLD') and 7.0 <= rate <= 13.0 and zero_translation(sent)
          and all(abs(m.yaw_rate) < 1e-3 for m in sent)
          and all(m.coordinate_frame == FRAME_BODY_NED and m.type_mask == TYPE_MASK
                  for m in sent))
    v.append(('PASS' if ok else 'FAIL',
              f'GUIDED with no mission: output "{t.output}", {rate:.1f} setpoints/s on the wire '
              f'(expected 10, all zero)' + (f', e.g. {fmt_sp(sent[-1])}' if sent else '')))
    echo = t.echo_since(t0)
    if echo:
        e = echo[-1]
        still = abs(e.vx) < 0.05 and abs(e.vy) < 0.05 and abs(e.vz) < 0.05
        v.append(('PASS' if still else 'CHECK',
                  f'Pixhawk echo: {len(echo)} targets, mask {e.type_mask} frame '
                  f'{e.coordinate_frame}, v ({e.vx:+.2f} {e.vy:+.2f} {e.vz:+.2f}) m/s'))
    else:
        v.append(('CHECK', 'no POSITION_TARGET_LOCAL_NED echo from the Pixhawk (not required; '
                           'tells me whether it follows the velocity target)'))
    safety_allows(t, v)


def step_yaw(t, v):
    if not need_armed_guided(t, v) or not safety_allows(t, v):
        return
    say(f'Sending yaw commands: {YAW_TEST:+.1f} rad/s (turn LEFT) for 3 s, then '
        f'{-YAW_TEST:+.1f} rad/s (turn RIGHT) for 3 s. Motors stay at idle: '
        'ArduCopter ignores yaw while landed.')
    results = []
    for flu in (YAW_TEST, -YAW_TEST):
        t.send_yaw = flu
        t.spin_for(2.0)             # the gate ramps yaw at 60 deg/s^2
        t0 = time.monotonic()
        t.spin_for(1.0)
        sent = t.sent_since(t0)
        results.append((flu, sent, t.output))
    t.send_yaw = None
    if disarmed_during(t, v):
        return
    for flu, sent, output in results:
        if not sent:
            v.append(('FAIL', f'FLU {flu:+.2f}: nothing on the wire, output "{output}"'))
            continue
        wire = sum(m.yaw_rate for m in sent) / len(sent)
        ok = (output.startswith('COMMAND') and abs(wire + flu) < 0.02 and zero_translation(sent))
        direction = 'LEFT (counter-clockwise)' if flu > 0 else 'RIGHT (clockwise)'
        v.append(('PASS' if ok else 'FAIL',
                  f'turn {direction}: we send {flu:+.2f} rad/s FLU, the Pixhawk receives '
                  f'{wire:+.3f} rad/s NED (expected {-flu:+.2f}: MAVLink yaw rate is + '
                  f'clockwise), translation {"zero" if zero_translation(sent) else "NOT ZERO"}'
                  + ('' if ok else f', output "{output}"')))


def step_stop(t, v):
    if not need_armed_guided(t, v) or not safety_allows(t, v) or not start_stream(t, v):
        return
    t.send_yaw = None
    dt = t.wait_for(lambda: t.output.startswith('HOLD'), 2.0)
    t0 = time.monotonic()
    t.spin_for(1.0)
    sent = t.sent_since(t0)
    zero = sent and all(abs(m.yaw_rate) < 1e-3 for m in sent) and zero_translation(sent)
    ok = dt is not None and dt <= 0.5 and zero
    v.append(('PASS' if ok else 'FAIL',
              f'commands stopped: HOLD after {"never" if dt is None else f"{dt:.2f} s"} '
              f'(limit 0.3 s + one 10 Hz tick), then {len(sent)} zero setpoints/s'))


def step_override(t, v):
    if not need_armed_guided(t, v):
        return
    say('PILOT OVERRIDE: flip the mode switch to LOITER now.')
    if t.wait_for(lambda: t.mode() not in ('GUIDED', '?'), WAIT_USER_S) is None:
        v.append(('FAIL', 'mode did not leave GUIDED'))
        return
    dt = t.wait_for(lambda: t.level() == LEVEL_OVERRIDE and t.output.startswith('SILENT'), 2.0)
    t.spin_for(0.5)
    t0 = time.monotonic()
    t.spin_for(1.5)
    n = len(t.sent_since(t0))
    ok = dt is not None and n == 0
    v.append(('PASS' if ok else 'FAIL',
              f'switched to {t.mode()}: safety level {t.level()} (OVERRIDE is 4) after '
              f'{"never" if dt is None else f"{dt:.2f} s"}, output "{t.output}", '
              f'{n} setpoints on the wire afterwards (expected 0)'))
    if not ok:
        return
    say('Now flip back to GUIDED. The Pi must stay silent until a reset.')
    if t.wait_for(lambda: t.mode() == 'GUIDED', WAIT_USER_S) is None:
        v.append(('CHECK', 'did not see GUIDED again; latch not tested'))
        return
    t0 = time.monotonic()
    t.spin_for(2.0)
    n = len(t.sent_since(t0))
    ok = n == 0 and t.level() == LEVEL_OVERRIDE and t.output.startswith('SILENT')
    v.append(('PASS' if ok else 'FAIL',
              f'back in GUIDED: level {t.level()}, output "{t.output}", {n} setpoints '
              '(expected 0: override stays latched)'))


def step_reset(t, v):
    if t.armed():
        say('Disarm on the RC.')
        if t.wait_for(lambda: t.fresh() and not t.armed(), WAIT_USER_S) is None:
            v.append(('FAIL', 'still armed'))
            return
    t.spin_for(1.0)
    res = t.call_reset()
    if res is None:
        v.append(('FAIL', '/drone/safety/reset not available'))
        return
    t.spin_for(1.0)
    ok = res.success and t.level() is not None and t.level() < 2
    v.append(('PASS' if ok else 'FAIL',
              f'reset: "{res.message}", level now {t.level()}'))


def step_estop(t, v):
    answer = ask('Is the motor emergency stop on an RC switch (RC6_OPTION = 31)? [y/n]')
    if answer != 'y':
        v.append(('CHECK', 'skipped: set RC6_OPTION = 31 before Phase 8'))
        return
    if not t.armed():
        say('Arm on the RC in LOITER (props off). Motors spin at idle.')
        if t.wait_for(t.armed, WAIT_USER_S) is None:
            v.append(('FAIL', 'not armed'))
            return
    say('Flip the EMERGENCY STOP switch now and listen to the motors.')
    t.spin_for(3.0)
    answer = ask('Did all motors stop? [y/n]')
    armed_after = t.armed()
    say('Put the emergency stop switch back, and disarm if still armed.')
    t.wait_for(lambda: t.fresh() and not t.armed(), WAIT_USER_S)
    v.append(('PASS' if answer == 'y' else 'FAIL',
              f'emergency stop: motors stopped = {answer or "no answer"}; FCU armed right '
              f'after = {armed_after}'))


def kill(pattern):
    """SIGINT the processes whose command line contains pattern. Returns the pids."""
    out = subprocess.run(['pgrep', '-f', pattern], capture_output=True, text=True).stdout
    pids = [int(p) for p in out.split() if int(p) != os.getpid()]
    for pid in pids:
        os.kill(pid, signal.SIGINT)
    return pids


def step_safety_lost(t, v):
    if not need_armed_guided(t, v) or not safety_allows(t, v) or not start_stream(t, v):
        return
    say('Stopping safety_supervisor (the veto layer) while yaw commands are streaming.')
    pids = kill('lib/drone_safety/safety_supervisor')
    if not pids:
        t.send_yaw = None
        v.append(('FAIL', 'safety_supervisor process not found'))
        return
    dt = t.wait_for(lambda: t.output.startswith('HOLD') and 'safety' in t.output, 3.0)
    t0 = time.monotonic()
    t.spin_for(1.0)
    t.send_yaw = None
    sent = t.sent_since(t0)
    zero = sent and all(abs(m.yaw_rate) < 1e-3 for m in sent) and zero_translation(sent)
    ok = dt is not None and dt <= 1.0 and zero
    v.append(('PASS' if ok else 'FAIL',
              f'safety_supervisor stopped: command node HOLD after '
              f'{"never" if dt is None else f"{dt:.2f} s"} (limit 0.5 s + one 10 Hz tick), '
              f'output "{t.output}", '
              f'{len(sent)} zero setpoints/s on the wire'))


def step_command_lost(t, v):
    if not need_armed_guided(t, v):
        return
    say('Stopping fcu_command_node (the only node that talks to the Pixhawk).')
    pids = kill('lib/drone_fcu/fcu_command_node')
    if not pids:
        v.append(('FAIL', 'fcu_command_node process not found'))
        return
    t.spin_for(0.5)
    t0 = time.monotonic()
    t.spin_for(2.0)
    n = len(t.sent_since(t0))
    v.append(('PASS' if n == 0 else 'FAIL',
              f'fcu_command_node stopped: {n} setpoints on the wire afterwards (expected 0). '
              'In the air the Pixhawk stops by itself after GUID_TIMEOUT (default 3 s)'))
    say('Disarm on the RC, then stop terminal A with Ctrl-C. Two nodes are gone now, so '
        'restart the launch before anything else.')
    t.wait_for(lambda: t.fresh() and not t.armed(), WAIT_USER_S)


RUN = {'check': step_check, 'idle': step_idle, 'arm': step_arm, 'guided': step_guided,
       'yaw': step_yaw, 'stop': step_stop, 'override': step_override, 'reset': step_reset,
       'estop': step_estop, 'safety_lost': step_safety_lost,
       'command_lost': step_command_lost}


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--steps', default=','.join(STEPS),
                        help=f'comma list from: {",".join(STEPS)}')
    args = parser.parse_args()
    steps = [s.strip() for s in args.steps.split(',') if s.strip()]
    unknown = [s for s in steps if s not in RUN]
    if unknown:
        sys.exit(f'unknown steps: {unknown}')
    if 'check' not in steps:
        steps.insert(0, 'check')

    rclpy.init()
    t = Tester()
    lines = ['== Phase 7 setpoint test (props off)']
    failed = False
    try:
        for name in steps:
            print(f'\n---- {name}', flush=True)
            verdicts = []
            RUN[name](t, verdicts)
            for verdict, text in verdicts:
                line = f'{verdict:5} {name}: {text}'
                print(line, flush=True)
                lines.append(line)
                failed |= verdict == 'FAIL'
            if name == 'check' and any(vd == 'FAIL' for vd, _ in verdicts):
                break
    except (KeyboardInterrupt, ExternalShutdownException):
        lines.append('stopped early (Ctrl-C)')
    finally:
        t.send_yaw = None
        lines.append('SETPOINT TEST: ' + ('FAILED' if failed else 'no FAIL'))
        os.makedirs(os.path.dirname(REPORT), exist_ok=True)
        with open(REPORT, 'w') as fh:
            fh.write('\n'.join(lines) + '\n')
        print(f'\n{lines[-1]}\nreport: {REPORT}')
        t.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
