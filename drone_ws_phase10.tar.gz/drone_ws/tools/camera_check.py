#!/usr/bin/env python3
"""Phase 9 camera check (read-only; sends nothing to the drone).

  python3 camera_check.py                listen 10 s, print PASS/FAIL, save a snapshot
  python3 camera_check.py --size 640x480 --seconds 20

Checks /camera/image_raw and /camera/camera_info: frame rate, size, encoding, frame_id, that
the stamp is the capture time on the Pi's clock, stamps increasing, no long gaps, and that the
TF base_link -> camera_optical_frame exists. Writes ~/drone_ws/phase9_report.txt and
~/drone_ws/camera_snapshot.jpg (open it to see what the drone sees).
"""

import argparse
import os
import sys
import time

import rclpy
from rclpy.node import Node
from rclpy.time import Time
from sensor_msgs.msg import CameraInfo, Image
from tf2_ros import Buffer, TransformListener

from drone_perception.core.camera_stats import CameraExpect, FrameStats, camera_checks
from drone_perception.qos import IMAGE_QOS
from drone_perception.core.image_convert import image_to_rgb

REPORT = os.path.expanduser('~/drone_ws/phase9_report.txt')
SNAPSHOT = os.path.expanduser('~/drone_ws/camera_snapshot.jpg')


class Check(Node):
    def __init__(self):
        super().__init__('camera_check')
        self.stats = FrameStats()
        self.info = None
        self.last = None
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self.create_subscription(Image, '/camera/image_raw', self._image, IMAGE_QOS)
        self.create_subscription(CameraInfo, '/camera/camera_info', self._info,
                                 IMAGE_QOS)

    def _now(self):
        return self.get_clock().now().nanoseconds * 1e-9

    def _image(self, msg):
        stamp = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        self.stats.add(stamp, self._now(), msg.width, msg.height, msg.encoding,
                       msg.header.frame_id)
        self.last = msg

    def _info(self, msg):
        calibrated = any(abs(k) > 1e-9 for k in msg.k)
        self.info = (msg.width, msg.height, msg.header.frame_id, calibrated)



def save_snapshot(msg):
    try:
        import cv2
        rgb = image_to_rgb(msg.encoding, msg.width, msg.height, msg.step, msg.data)
        cv2.imwrite(SNAPSHOT, rgb[:, :, ::-1])
        return f'snapshot saved: {SNAPSHOT}'
    except Exception as e:   # the check itself must still report
        return f'snapshot not saved: {e}'


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--seconds', type=float, default=10.0)
    parser.add_argument('--size', default='640x480', help='expected WIDTHxHEIGHT')
    parser.add_argument('--min-fps', type=float, default=15.0)
    parser.add_argument('--encoding', default='rgb8')
    args = parser.parse_args()
    w, h = (int(v) for v in args.size.lower().split('x'))
    exp = CameraExpect(min_fps=args.min_fps, width=w, height=h, encoding=args.encoding)

    rclpy.init()
    node = Check()
    print(f'listening {args.seconds:.0f} s on /camera/image_raw ...', flush=True)
    end = time.monotonic() + args.seconds
    while time.monotonic() < end:
        rclpy.spin_once(node, timeout_sec=0.05)
    checks = camera_checks(node.stats, exp, node.info)
    try:
        node.tf_buffer.lookup_transform('base_link', 'camera_optical_frame', Time())
        checks.append(('C10 TF base_link -> camera_optical_frame', True, 'found'))
    except Exception as e:
        checks.append(('C10 TF base_link -> camera_optical_frame', False, str(e).split('\n')[0]))
    lines = [f'{"PASS" if ok else "FAIL"}  {name}: {detail}' for name, ok, detail in checks]
    lines.append(save_snapshot(node.last) if node.last is not None else 'no frame to save')
    ok = all(c[1] for c in checks)
    lines.append('CAMERA CHECK: ' + ('ALL PASSED' if ok else 'FAILURES ABOVE'))
    text = '\n'.join(lines)
    print(text)
    os.makedirs(os.path.dirname(REPORT), exist_ok=True)
    with open(REPORT, 'w') as f:
        f.write(text + '\n')
    print(f'report written: {REPORT}')
    node.destroy_node()
    rclpy.try_shutdown()
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
