#!/usr/bin/env bash
# Phase 3, before starting MAVROS: is the serial port ready? Read-only.
DEV="${1:-/dev/ttyAMA0}"
fail=0
pass() { echo "PASS  $1"; }
bad()  { echo "FAIL  $1"; echo "      -> $2"; fail=1; }

[ -c "$DEV" ] && pass "$DEV exists" || bad "$DEV missing" "check dtparam=uart0=on / enable_uart=1 in the boot config"
id -nG | grep -qw dialout && pass "user $(whoami) is in dialout" \
  || bad "user not in dialout" "sudo usermod -aG dialout $USER, then log out and in"
if command -v fuser >/dev/null && fuser "$DEV" >/dev/null 2>&1; then
  bad "$DEV is already open by another process" "close it: $(fuser -v "$DEV" 2>&1 | tail -1)"
else
  pass "$DEV not in use by another program of this user (run 'sudo fuser -v $DEV' to check all users)"
fi
grep -qE "console=(serial0|ttyAMA0)" /proc/cmdline \
  && bad "a Linux serial console is on the UART" "remove console=serial0,115200 from the kernel cmdline" \
  || pass "no Linux serial console on the UART"
if systemctl is-active --quiet ModemManager 2>/dev/null; then
  bad "ModemManager is running" "sudo systemctl disable --now ModemManager"
else
  pass "ModemManager not running"
fi
[ -f /usr/share/GeographicLib/geoids/egm96-5.pgm ] || [ -f /usr/local/share/GeographicLib/geoids/egm96-5.pgm ] \
  && pass "GeographicLib geoid dataset present" \
  || bad "GeographicLib dataset missing (MAVROS will abort)" "see README Phase 3 step 1"
ros2 pkg prefix mavros >/dev/null 2>&1 && pass "mavros installed" \
  || bad "mavros not found" "sudo apt install ros-jazzy-mavros ros-jazzy-mavros-extras; source env.sh"

[ $fail = 0 ] && echo "PRECHECK: ALL PASSED" || { echo "PRECHECK: FIX THE FAILS ABOVE"; exit 1; }
