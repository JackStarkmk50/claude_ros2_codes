#!/usr/bin/env python3
"""Phase 10 YOLO check (sends nothing to the drone).

  python3 yolo_check.py --image photo.jpg        run the model on a photo, no ROS needed:
                                                 detections + timing + CPU temperature
  python3 yolo_check.py --live 30                listen 30 s to the running yolo_detector:
                                                 fps, image age, CPU, temperature; writes
                                                 ~/drone_ws/phase10_report.txt

The model path and settings come from drone.yaml (yolo_detector section) unless --model is given.
"""

import argparse
import math
import os
import statistics
import sys
import time

import yaml

CONFIG = os.path.expanduser('~/drone_ws/src/drone_bringup/config/drone.yaml')
REPORT = os.path.expanduser('~/drone_ws/phase10_report.txt')
TEMP = '/sys/class/thermal/thermal_zone0/temp'


def cpu_temp():
    try:
        with open(TEMP) as f:
            return int(f.read()) / 1000.0
    except (OSError, ValueError):
        return math.nan


def cpu_busy(seconds):
    """Whole-CPU busy fraction over `seconds` from /proc/stat (nan if unavailable)."""
    def read():
        with open('/proc/stat') as f:
            v = [int(x) for x in f.readline().split()[1:]]
        return sum(v), v[3] + v[4]
    try:
        t0, i0 = read()
        time.sleep(seconds)
        t1, i1 = read()
        return 1.0 - (i1 - i0) / max(1, t1 - t0)
    except OSError:
        return math.nan


def settings(args):
    p = {}
    try:
        with open(args.config) as f:
            p = yaml.safe_load(f)['yolo_detector']['ros__parameters']
    except (OSError, KeyError, TypeError):
        pass
    return {
        'model': args.model or p.get('model_path', ''),
        'size': int(p.get('input_size', 320)),
        'conf': float(p.get('confidence_threshold', 0.5)),
        'iou': float(p.get('nms_iou_threshold', 0.45)),
        'classes': p.get('allowed_classes', ['person']),
        'threads': int(p.get('num_threads', 3)),
    }


def offline(args):
    import cv2
    from drone_perception.core.yolo_model import YoloModel
    from drone_perception.core.yolo_postprocess import COCO_CLASSES, class_ids
    s = settings(args)
    bgr = cv2.imread(args.image)
    if bgr is None:
        print(f'cannot read {args.image}')
        return 2
    rgb = bgr[:, :, ::-1].copy()
    model = YoloModel(s['model'], s['size'], s['threads'])
    ids = class_ids(s['classes'])
    dets, _ = model.detect(rgb, s['conf'], s['iou'], ids)          # warm-up
    times = []
    t_start = cpu_temp()
    for _ in range(args.runs):
        dets, t = model.detect(rgb, s['conf'], s['iou'], ids)
        times.append(t['pre'] + t['infer'] + t['post'])
    times.sort()
    print(f'model {s["model"]} ({s["size"]} px, {s["threads"]} threads), image '
          f'{rgb.shape[1]}x{rgb.shape[0]}')
    print(f'{len(dets)} detection(s):')
    for d in dets:
        print(f'  {COCO_CLASSES[d.class_id]:8} {d.score:.2f}  box x {d.x1:.0f}-{d.x2:.0f}, '
              f'y {d.y1:.0f}-{d.y2:.0f}')
        cv2.rectangle(bgr, (int(d.x1), int(d.y1)), (int(d.x2), int(d.y2)), (0, 255, 0), 2)
    print(f'time per frame over {args.runs} runs: median {times[len(times) // 2]:.1f} ms, '
          f'worst {times[-1]:.1f} ms  (= up to {1000 / times[len(times) // 2]:.1f} fps)')
    print(f'CPU temperature: {t_start:.1f} C before, {cpu_temp():.1f} C after')
    out = os.path.splitext(args.image)[0] + '_detections.jpg'
    cv2.imwrite(out, bgr)
    print(f'annotated image: {out}')
    return 0


def live(args):
    import rclpy
    from diagnostic_msgs.msg import DiagnosticArray
    from rclpy.node import Node
    from vision_msgs.msg import Detection2DArray

    rclpy.init()
    node = Node('yolo_check')
    ages, counts, recv = [], [], []
    diag = {}

    def on_det(msg):
        now = node.get_clock().now().nanoseconds * 1e-9
        stamp = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        ages.append(now - stamp)
        counts.append(len(msg.detections))
        recv.append(time.monotonic())

    def on_diag(msg):
        for st in msg.status:
            if st.name.endswith('yolo_detector'):
                diag.update({kv.key: kv.value for kv in st.values})
                diag['summary'] = st.message

    node.create_subscription(Detection2DArray, '/drone/perception/detections', on_det, 10)
    node.create_subscription(DiagnosticArray, '/diagnostics', on_diag, 10)
    print(f'listening {args.live:.0f} s; stand in front of the camera for part of it ...',
          flush=True)
    busy = []
    end = time.monotonic() + args.live
    while time.monotonic() < end:
        t0 = time.monotonic()
        while time.monotonic() - t0 < 1.0:
            rclpy.spin_once(node, timeout_sec=0.05)
        busy.append(cpu_busy(0.05))
    node.destroy_node()
    rclpy.try_shutdown()

    lines = []

    def check(name, ok, detail):
        lines.append(f'{"PASS" if ok else "FAIL"}  {name}: {detail}')
        return ok

    n = len(recv)
    ok = check('Y1 detections arrive', n >= 2, f'{n} messages')
    if n >= 2:
        fps = (n - 1) / (recv[-1] - recv[0])
        ok &= check('Y2 detector rate >= 5 fps', fps >= 5.0, f'{fps:.1f} fps')
        med = statistics.median(ages)
        ok &= check('Y3 image age at detection <= 300 ms', med <= 0.3,
                    f'median {med * 1000:.0f} ms, worst {max(ages) * 1000:.0f} ms')
        seen = sum(1 for c in counts if c > 0)
        check('Y4 person seen (info)', True, f'in {seen} of {n} frames ({seen / n:.0%}), '
                                              f'most at once {max(counts)}')
    temp = cpu_temp()
    ok &= check('Y5 CPU temperature < 80 C', not temp >= 80.0, f'{temp:.1f} C')
    if busy:
        lines.append(f'INFO  CPU busy: average {statistics.mean(busy):.0%}')
    if diag:
        lines.append('INFO  detector diagnostics: ' + ', '.join(f'{k} {v}' for k, v in
                                                                 sorted(diag.items())))
    lines.append('YOLO CHECK: ' + ('ALL PASSED' if ok else 'FAILURES ABOVE'))
    text = '\n'.join(lines)
    print(text)
    os.makedirs(os.path.dirname(REPORT), exist_ok=True)
    with open(REPORT, 'a') as f:
        f.write(text + '\n')
    print(f'report appended: {REPORT}')
    return 0 if ok else 1


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument('--image', help='photo to run the model on (offline)')
    g.add_argument('--live', type=float, help='seconds to listen to yolo_detector')
    p.add_argument('--model', help='override the model path from drone.yaml')
    p.add_argument('--config', default=CONFIG)
    p.add_argument('--runs', type=int, default=30)
    args = p.parse_args()
    return offline(args) if args.image else live(args)


if __name__ == '__main__':
    sys.exit(main())
