#!/usr/bin/env python3
"""Phase 5 guided optical-flow test, hand-held, PROPS OFF, disarmed. Read-only: sends nothing.

Needs fcu.launch.py running (MAVROS + fcu_state_node). Walks you through a few short steps,
records what the FCU reports during each, and writes ~/drone_ws/phase5_report.txt.

  python3 flow_test.py            all steps, press Enter before each
  python3 flow_test.py --steps heights,move   only some steps
"""

import argparse
import math
import os
import statistics
import sys
import time

import rclpy
from mavros_msgs.msg import Mavlink
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Imu

from drone_fcu.core import ekf_flags
from drone_fcu.core import mavlink_decode as mav
from drone_interfaces.msg import FlowStatus, VehicleState

REPORT = os.path.expanduser('~/drone_ws/phase5_report.txt')
MIN_QUALITY = 100   # drone.yaml flow_min_quality, the value this test helps to tune

STEPS = [
    ('floor', 8, 'Put the drone flat on your usual floor and let go.'),
    ('pitch', 5, 'Hold it in the air and tilt the NOSE DOWN about 20 degrees. Hold still.'),
    ('roll', 5, 'Tilt the RIGHT side DOWN about 20 degrees. Hold still.'),
    ('north', 5, 'Hold it level with the nose pointing NORTH (use a phone compass).'),
    ('h50', 8, 'Hold it level and still, sensor about 0.5 m above the floor.'),
    ('h100', 8, 'Hold it level and still at about 1.0 m.'),
    ('h150', 8, 'Hold it level and still at about 1.5 m.'),
    ('rotate', 10, 'At about 1 m, rock it nose up / nose down, then left / right, around its '
                   'own centre. Keep the sensor over the same spot (rotate, do not move).'),
    ('forward', 6, 'At about 1 m and level, walk FORWARD slowly (nose direction) about 1 m, '
                   'then stop.'),
    ('left', 6, 'At about 1 m and level, move it to its LEFT slowly about 1 m, then stop.'),
    ('cover', 5, 'At about 1 m, cover the flow sensor lens with your hand.'),
]


class Recorder(Node):

    def __init__(self):
        super().__init__('flow_test')
        self.bucket = None
        self.create_subscription(VehicleState, '/drone/vehicle_state',
                                 lambda m: self._add('vehicle', m), 10)
        self.create_subscription(FlowStatus, '/drone/flow_status',
                                 lambda m: self._add('flow', m), 10)
        self.create_subscription(Imu, '/mavros/imu/data', lambda m: self._add('imu', m),
                                 qos_profile_sensor_data)
        self.create_subscription(Mavlink, '/uas1/mavlink_source', self._on_raw,
                                 qos_profile_sensor_data)

    def _add(self, key, msg):
        if self.bucket is not None:
            self.bucket[key].append(msg)

    def _on_raw(self, msg):
        # the autopilot's own OPTICAL_FLOW (sysid 1, compid 1), not the sensor's forwarded copy
        if msg.msgid == mav.OPTICAL_FLOW and msg.sysid == 1 and msg.compid == 1:
            self._add('of', mav.decode(msg.msgid, msg.payload64, msg.len))

    def record(self, seconds):
        self.bucket = {'vehicle': [], 'flow': [], 'imu': [], 'of': []}
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            rclpy.spin_once(self, timeout_sec=0.05)
        data, self.bucket = self.bucket, None
        return data


def finite(values):
    return [v for v in values if not math.isnan(v)]


def mean(values):
    values = finite(values)
    return statistics.fmean(values) if values else math.nan


def rms(values):
    values = finite(values)
    return math.sqrt(statistics.fmean(v * v for v in values)) if values else math.nan


def f(x, spec='.2f'):
    return 'n/a' if x is None or (isinstance(x, float) and math.isnan(x)) else f'{x:{spec}}'


def height_summary(d):
    v = d['vehicle']
    heights = [m.height_above_ground_m for m in v if m.height_valid]
    q = [m.quality for m in d['flow']]
    good = sum(1 for x in q if x >= MIN_QUALITY)
    spread = f(max(heights) - min(heights)) if heights else 'n/a'
    out = [f'height mean {f(mean(heights))} m, spread {spread} m, valid {len(heights)}/{len(v)}',
           f'flow quality median {f(statistics.median(q), ".0f") if q else "n/a"}, '
           f'min {min(q) if q else "n/a"}, >= {MIN_QUALITY} in {good}/{len(q)} samples']
    if v:
        last = v[-1]
        out.append(f'EKF flags 0x{last.ekf_flags:x} ({ekf_flags.describe(last.ekf_flags)})')
    if d['flow']:
        out.append(f'flow_status: takeoff {d["flow"][-1].healthy_for_takeoff}, flight '
                   f'{d["flow"][-1].healthy_for_flight}, reason: {d["flow"][-1].reason or "-"}')
    return out


def analyse(step, d):
    """(lines, verdict) where verdict is PASS / CHECK / INFO / FAIL."""
    v = d['vehicle']
    if not v or not d['flow']:
        return ['no /drone/vehicle_state: is fcu.launch.py running?'], 'FAIL'
    if step == 'floor':
        lines = height_summary(d)
        heights = finite([m.height_above_ground_m for m in v])
        ok = heights and mean(heights) < 0.25
        lines.append('on-ground limit ground_height_max_m is 0.25 m')
        return lines, 'PASS' if ok else 'CHECK'
    if step in ('pitch', 'roll'):
        vals = [math.degrees(getattr(m, f'{step}_rad')) for m in v]
        avg = mean(vals)
        return [f'{step} mean {f(avg, ".1f")} deg (expected positive, about +20)'], \
            'PASS' if avg > 5 else 'FAIL'
    if step == 'north':
        yaw = mean([m.yaw_rad for m in v])
        hdg = (90.0 - math.degrees(yaw)) % 360 if not math.isnan(yaw) else math.nan
        err = min(hdg, 360 - hdg) if not math.isnan(hdg) else math.nan
        return [f'compass heading {f(hdg, ".0f")} deg (expected near 0; indoors 10-20 deg off '
                'is common)'], 'PASS' if err < 30 else 'CHECK'
    if step.startswith('h'):
        return height_summary(d), 'INFO'
    if step == 'rotate':
        of = [o for o in d['of'] if o is not None]
        raw = rms([o.flow_rate_x for o in of] + [o.flow_rate_y for o in of])
        comp = rms([o.flow_comp_m_x for o in of] + [o.flow_comp_m_y for o in of])
        gyro = rms([m.angular_velocity.x for m in d['imu']] + [m.angular_velocity.y
                                                               for m in d['imu']])
        return [f'body rotation rate (gyro) RMS {f(gyro)} rad/s',
                f'FCU flow rate RMS {f(raw)} rad/s, FCU compensated flow RMS {f(comp)} '
                f'({len(of)} samples)',
                'I interpret these: flow should follow the rotation, and the compensated '
                'value should stay much smaller than the raw one'], 'INFO'
    if step in ('forward', 'left'):
        axis = 'x' if step == 'forward' else 'y'
        vel = [getattr(m.velocity_body_flu, axis) for m in v if m.velocity_valid]
        valid = len(vel)
        if not vel:
            return ['no EKF velocity while moving (velocity_valid false)'], 'CHECK'
        peak = max(vel, key=abs)
        of = [o for o in d['of'] if o is not None]
        lines = [f'EKF body velocity {axis}: peak {f(peak)} m/s, mean {f(mean(vel))} m/s '
                 f'({valid}/{len(v)} valid); expected POSITIVE (ROS: x forward, y left)',
                 f'FCU flow rate x/y mean {f(mean([o.flow_rate_x for o in of]), ".3f")} / '
                 f'{f(mean([o.flow_rate_y for o in of]), ".3f")} rad/s']
        if abs(peak) < 0.05:
            return lines + ['velocity barely moved: the EKF may not use flow while disarmed '
                            'on the bench'], 'CHECK'
        return lines, 'PASS' if peak > 0 else 'FAIL'
    if step == 'cover':
        q = [m.quality for m in d['flow']]
        lines = [f'quality min {min(q)}, last {q[-1]}; reason: {d["flow"][-1].reason or "-"}']
        return lines, 'PASS' if min(q) < MIN_QUALITY and not d['flow'][-1].healthy_for_flight \
            else 'FAIL'
    return [], 'INFO'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--steps', default=','.join(s[0] for s in STEPS))
    parser.add_argument('--auto', action='store_true', help='do not wait for Enter (testing)')
    args = parser.parse_args()
    chosen = args.steps.split(',')
    rclpy.init()
    node = Recorder()
    lines = ['== Phase 5 flow test (props off, disarmed, hand-held)']
    print('PROPS OFF. Disarmed. Keep the drone level unless a step says otherwise.\n')
    try:
        for name, seconds, text in STEPS:
            if name not in chosen:
                continue
            print(f'--- {name}: {text}')
            if not args.auto:
                input(f'    Get in position, then press Enter (records {seconds} s) ')
            else:
                print(f'    recording {seconds} s')
            result, verdict = analyse(name, node.record(seconds))
            lines.append(f'{verdict:<5} {name}: {text}')
            for line in result:
                lines.append(f'      {line}')
                print(f'    {line}')
            print(f'    => {verdict}\n')
    except (KeyboardInterrupt, ExternalShutdownException, EOFError):
        lines.append('(stopped early)')
    finally:
        os.makedirs(os.path.dirname(REPORT), exist_ok=True)
        with open(REPORT, 'w') as fh:
            fh.write('\n'.join(lines) + '\n')
        print(f'report saved to {REPORT}')
        try:
            node.destroy_node()
            rclpy.try_shutdown()
        except KeyboardInterrupt:
            pass
    sys.exit(0)


if __name__ == '__main__':
    main()
