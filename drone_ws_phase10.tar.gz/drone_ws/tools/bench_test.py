#!/usr/bin/env python3
"""Phase 6 bench scenarios: safety_supervisor + fcu_command_node against a FAKE vehicle.

No MAVROS, no Pixhawk needed, nothing is sent to any aircraft: this script starts its own
safety_supervisor and fcu_command_node (bench mode) and feeds them invented vehicle states.
Do NOT run it while fcu.launch.py / bringup.launch.py is running (it refuses if it sees another
/drone/vehicle_state publisher).

  python3 bench_test.py        runs every scenario, writes ~/drone_ws/phase6_report.txt
"""

import math
import os
import signal
import subprocess
import sys
import time

import rclpy
from ament_index_python.packages import get_package_share_directory
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from std_msgs.msg import String
from std_srvs.srv import Trigger

from drone_interfaces.msg import ControlCommand, FlowStatus, SafetyStatus, VehicleState

REPORT = os.path.expanduser('~/drone_ws/phase6_report.txt')
NODE_LOG = '/tmp/phase6_bench_nodes.log'
RELIABLE = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                      durability=DurabilityPolicy.VOLATILE)
LATCHED = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                     durability=DurabilityPolicy.TRANSIENT_LOCAL)
LEVELS = ['OK', 'DEGRADED', 'HOLD', 'ABORT', 'OVERRIDE']


def fake_vehicle(flying):
    v = VehicleState()
    v.connected = True
    v.heartbeat_age_s = 0.3
    v.armed = flying
    v.guided = flying
    v.mode = 'GUIDED' if flying else 'STABILIZE'
    v.system_status = 4 if flying else 3
    v.landed_state = 2 if flying else 1
    v.fcu_prearm_ok = True
    v.rc_present = True
    v.battery_voltage_v = 15.8 if flying else 16.4
    v.battery_current_a = 8.0
    v.battery_remaining = math.nan
    v.roll_rad, v.pitch_rad, v.yaw_rad = 0.01, -0.01, 0.0
    v.velocity_valid = v.local_position_valid = True
    v.height_above_ground_m = 1.2 if flying else 0.14
    v.height_valid = True
    v.ekf_flags = 0x16f
    v.ekf_attitude_ok = v.ekf_velocity_horiz_ok = v.ekf_pos_horiz_rel_ok = True
    v.ekf_velocity_variance = v.ekf_pos_horiz_variance = 0.1
    v.ekf_age_s = 0.3
    return v


def fake_flow(flying):
    f = FlowStatus()
    f.source_seen = f.fresh = True
    f.quality = 180 if flying else 70
    f.quality_ok = flying
    f.quality_applies = flying
    f.in_valid_height_band = flying
    f.healthy_for_flight = flying
    f.healthy_for_takeoff = True
    f.ground_distance_m = math.nan
    f.flow_rate_x_rad_s = f.flow_rate_y_rad_s = 0.0
    f.reason = '' if flying else 'height 0.14 m below flow band'
    return f


class Bench(Node):

    def __init__(self):
        super().__init__('phase6_bench')
        self.vehicle = fake_vehicle(False)
        self.flying = False
        self.send_commands = False
        self.cmd_source = 'mission_manager'
        self.cmd_yaw = 0.2
        self.seq = 0
        self.safety = None
        self.validated = []
        self.output = ''
        self.v_pub = self.create_publisher(VehicleState, '/drone/vehicle_state', RELIABLE)
        self.f_pub = self.create_publisher(FlowStatus, '/drone/flow_status', RELIABLE)
        self.c_pub = self.create_publisher(ControlCommand, '/drone/control/command', 10)
        self.create_subscription(SafetyStatus, '/drone/safety_status', self._on_safety, LATCHED)
        self.create_subscription(ControlCommand, '/drone/control/validated_command',
                                 self.validated.append, RELIABLE)
        self.create_subscription(String, '/drone/fcu/output_state', self._on_output, 10)
        self.reset_client = self.create_client(Trigger, '/drone/safety/reset')
        self.preflight_client = self.create_client(Trigger, '/drone/safety/preflight_check')
        self.create_timer(0.1, self._tick)

    def _on_safety(self, msg):
        self.safety = msg

    def _on_output(self, msg):
        self.output = msg.data

    def set_flying(self, flying, **overrides):
        self.flying = flying
        self.vehicle = fake_vehicle(flying)
        for k, val in overrides.items():
            setattr(self.vehicle, k, val)

    def land(self):
        """Touch down (armed, on the ground), then disarm, like a real landing."""
        self.vehicle.landed_state = 1
        self.vehicle.height_above_ground_m = 0.14
        self.spin_for(0.5)
        self.set_flying(False)

    def command(self, source=None, seq=None, yaw=None):
        c = ControlCommand()
        c.header.stamp = self.get_clock().now().to_msg()
        c.mode = ControlCommand.MODE_BODY_VELOCITY
        c.source = source or self.cmd_source
        if seq is None:
            self.seq += 1
            seq = self.seq
        c.seq = seq
        c.yaw_rate_rad_s = self.cmd_yaw if yaw is None else yaw
        c.max_age_s = 0.3
        self.c_pub.publish(c)

    def _tick(self):
        stamp = self.get_clock().now().to_msg()
        self.vehicle.header.stamp = stamp
        f = fake_flow(self.flying)
        f.header.stamp = stamp
        self.v_pub.publish(self.vehicle)
        self.f_pub.publish(f)
        if self.send_commands:
            self.command()

    def spin_for(self, seconds):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            rclpy.spin_once(self, timeout_sec=0.02)

    def wait_for(self, predicate, timeout):
        """Seconds until predicate() is true, or None."""
        start = time.monotonic()
        while time.monotonic() - start < timeout:
            rclpy.spin_once(self, timeout_sec=0.02)
            if predicate():
                return time.monotonic() - start
        return None

    def call(self, client, timeout=3.0):
        if not client.wait_for_service(timeout_sec=timeout):
            return None
        future = client.call_async(Trigger.Request())
        end = time.monotonic() + timeout
        while not future.done() and time.monotonic() < end:
            rclpy.spin_once(self, timeout_sec=0.02)
        return future.result()

    def level(self):
        return LEVELS[self.safety.level] if self.safety else 'none'


def start_nodes(config, log):
    procs = {}
    for pkg, exe in (('drone_safety', 'safety_supervisor'), ('drone_fcu', 'fcu_command_node')):
        procs[exe] = subprocess.Popen(
            ['ros2', 'run', pkg, exe, '--ros-args', '--params-file', config],
            stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    return procs


def stop(proc):
    if proc.poll() is None:
        os.killpg(proc.pid, signal.SIGINT)
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)


def main():
    rclpy.init()
    bench = Bench()
    lines = ['== Phase 6 bench scenarios (fake vehicle, bench mode, nothing sent to MAVROS)']
    ok_all = True

    def result(passed, name, detail):
        nonlocal ok_all
        ok_all &= passed
        line = f'{"PASS" if passed else "FAIL":<5} {name}: {detail}'
        print(line, flush=True)
        lines.append(line)

    bench.spin_for(1.0)
    others = [i for i in bench.get_publishers_info_by_topic('/drone/vehicle_state')
              if i.node_name != 'phase6_bench']
    if others:
        print('STOP: another node publishes /drone/vehicle_state '
              f'({others[0].node_name}). Stop fcu.launch.py / bringup first.')
        sys.exit(2)

    config = os.path.join(get_package_share_directory('drone_bringup'), 'config', 'drone.yaml')
    log = open(NODE_LOG, 'w')
    procs = start_nodes(config, log)
    try:
        up = bench.wait_for(lambda: bench.safety is not None and 'bench mode' in bench.output
                            or (bench.safety is not None and bench.output), 20.0)
        result(up is not None, 'S0 nodes start', 'safety_supervisor and fcu_command_node up'
               if up is not None else f'not up after 20 s, see {NODE_LOG}')
        if up is None:
            return

        # S1: on the ground, everything healthy except bench mode
        bench.set_flying(False)
        bench.spin_for(3.0)
        fails = list(bench.safety.preflight_failures)
        pf = bench.call(bench.preflight_client)
        result(bench.safety.level == 0 and len(fails) == 1 and fails[0].startswith('PF13')
               and pf is not None and not pf.success,
               'S1 pre-flight on the ground',
               f'level {bench.level()}, failures {fails} (expected only PF13 bench mode)')

        # S2: flying in GUIDED, mission streams a left turn
        bench.set_flying(True)
        bench.send_commands = True
        bench.cmd_yaw = 0.2
        t = bench.wait_for(lambda: bench.output.startswith('WOULD SEND COMMAND'), 3.0)
        bench.spin_for(1.0)
        yaw = bench.validated[-1].yaw_rate_rad_s if bench.validated else math.nan
        result(t is not None and math.isclose(yaw, 0.2, abs_tol=0.01),
               'S2 validated yaw command', f'validated yaw {yaw:.3f} rad/s (sent 0.2); '
               f'command node: "{bench.output}"')

        # S3: over-limit yaw is clamped to 30 deg/s
        bench.cmd_yaw = 3.0
        bench.spin_for(1.5)
        yaw = bench.validated[-1].yaw_rate_rad_s
        clamped = math.isclose(yaw, math.radians(30), abs_tol=0.01)
        result(clamped and bench.safety.commands_clamped > 0,
               'S3 yaw clamp', f'sent 3.0 rad/s, validated {yaw:.3f} (limit '
               f'{math.radians(30):.3f}), clamped count {bench.safety.commands_clamped}')
        bench.cmd_yaw = 0.2
        bench.spin_for(1.0)

        # S4: bad commands are rejected and never forwarded
        before = bench.safety.commands_rejected
        bench.send_commands = False
        bench.spin_for(0.5)
        n_valid = len(bench.validated)
        bench.command(source='someone_else')
        bench.command(seq=1)                  # replay of an old sequence number
        bench.command(yaw=math.nan)
        bench.spin_for(0.5)
        rejected = bench.safety.commands_rejected - before
        result(rejected == 3 and len(bench.validated) == n_valid,
               'S4 bad commands rejected', f'{rejected}/3 rejected (unknown source, replayed '
               f'seq, NaN), {len(bench.validated) - n_valid} forwarded')

        # S5: the mission stops sending -> HOLD fast, safety HOLD, then ABORT after 5 s
        bench.send_commands = True
        bench.spin_for(1.0)
        bench.send_commands = False
        t_hold = bench.wait_for(lambda: bench.output.startswith('WOULD SEND HOLD'), 2.0)
        t_abort = bench.wait_for(lambda: bench.safety.level == 3, 8.0)
        result(t_hold is not None and t_hold < 0.6 and t_abort is not None,
               'S5 mission stops', f'command node HOLD after {t_hold and round(t_hold, 2)} s '
               f'(limit 0.3 s + 10 Hz tick), safety ABORT after '
               f'{t_abort and round(t_hold + t_abort, 1)} s (hold_to_land_s 5)')

        # reset is refused in the air, accepted on the ground
        r_air = bench.call(bench.reset_client)
        bench.land()
        bench.spin_for(1.0)
        r_ground = bench.call(bench.reset_client)
        bench.spin_for(0.5)
        result(r_air is not None and not r_air.success and r_ground is not None
               and r_ground.success and bench.safety.level == 0,
               'S6 reset', f'in the air: "{r_air and r_air.message}"; on the ground: '
               f'"{r_ground and r_ground.message}"')

        # S7: pilot flips the mode switch to LOITER -> OVERRIDE, command node silent
        bench.set_flying(True)
        bench.send_commands = True
        bench.spin_for(1.0)
        bench.vehicle.mode = 'LOITER'
        t = bench.wait_for(lambda: bench.safety.level == 4
                           and bench.output.startswith('SILENT: override'), 2.0)
        result(t is not None, 'S7 pilot override',
               f'safety {bench.level()}, command node "{bench.output}"')
        bench.send_commands = False
        bench.land()
        bench.spin_for(0.5)
        bench.call(bench.reset_client)
        bench.spin_for(0.5)

        # S8: safety_supervisor dies in the air -> HOLD, then LAND needed
        bench.set_flying(True)
        bench.send_commands = True
        bench.spin_for(1.5)
        stop(procs['safety_supervisor'])
        t_hold = bench.wait_for(lambda: 'safety status stale' in bench.output, 2.0)
        t_land = bench.wait_for(lambda: 'LAND needed' in bench.output, 3.0)
        result(t_hold is not None and t_land is not None,
               'S8 safety_supervisor killed', f'command node HOLD after '
               f'{t_hold and round(t_hold, 2)} s, LAND flagged after '
               f'{t_land and round(t_hold + t_land, 2)} s; last: "{bench.output}"')
        bench.send_commands = False
    finally:
        for proc in procs.values():
            stop(proc)
        log.close()
        lines.append('BENCH TEST: ' + ('ALL PASSED' if ok_all else 'FAILURES ABOVE'))
        print(lines[-1])
        os.makedirs(os.path.dirname(REPORT), exist_ok=True)
        with open(REPORT, 'w') as fh:
            fh.write('\n'.join(lines) + '\n')
        print(f'report saved to {REPORT} (node output: {NODE_LOG})')
        bench.destroy_node()
        rclpy.try_shutdown()
    sys.exit(0 if ok_all else 1)


if __name__ == '__main__':
    main()
