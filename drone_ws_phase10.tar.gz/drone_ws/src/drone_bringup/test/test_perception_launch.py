"""perception.launch.py reads the camera mount from drone.yaml and builds the TF chain."""

import importlib.util
import pathlib

import yaml

ROOT = pathlib.Path(__file__).resolve().parents[1]


def module():
    path = ROOT / 'launch' / 'perception.launch.py'
    spec = importlib.util.spec_from_file_location('perception_launch', path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def test_mount_comes_from_the_config():
    m = module()
    mount = m.camera_mount(str(ROOT / 'config' / 'drone.yaml'))
    cfg = yaml.safe_load(open(ROOT / 'config' / 'drone.yaml'))['camera_mount']['ros__parameters']
    assert mount == {**m.MOUNT_DEFAULTS, **cfg}


def test_missing_config_gives_defaults(tmp_path):
    m = module()
    assert m.camera_mount(str(tmp_path / 'nope.yaml')) == m.MOUNT_DEFAULTS


def test_camera_frames_match_the_detector_and_tracker():
    cfg = yaml.safe_load(open(ROOT / 'config' / 'drone.yaml'))
    cam = cfg['/camera/camera']['ros__parameters']
    assert cam['camera_frame_id'] == 'camera_optical_frame'
    assert cam['output_encoding'] in ('rgb8', 'bgr8', 'mono8', 'yuv422_yuy2')


def test_two_static_transforms():
    m = module()
    nodes = m.static_tf_nodes(dict(m.MOUNT_DEFAULTS, tilt_down_deg=90.0))
    assert len(nodes) == 2
