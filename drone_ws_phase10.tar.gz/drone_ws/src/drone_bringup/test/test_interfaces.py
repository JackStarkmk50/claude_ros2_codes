"""All custom interfaces are generated, installed and importable from Python."""

from drone_interfaces.action import FlightOperation, SearchAndTrack
from drone_interfaces.msg import (
    ControlCommand, FlowStatus, MissionStatus, SafetyStatus, TrackedTarget, VehicleState,
)
from drone_interfaces.srv import SubmitCommand


def test_messages_construct():
    for cls in (VehicleState, FlowStatus, TrackedTarget, ControlCommand, SafetyStatus,
                MissionStatus):
        cls()


def test_service_and_actions_construct():
    SubmitCommand.Request()
    SubmitCommand.Response()
    for action in (SearchAndTrack, FlightOperation):
        action.Goal()
        action.Result()
        action.Feedback()


def test_key_constants():
    assert ControlCommand.MODE_HOLD == 0
    assert SafetyStatus.LEVEL_OVERRIDE == 4
    assert FlightOperation.Goal.OP_TAKEOFF == 0
    assert FlightOperation.Goal.OP_LAND == 1
    assert FlightOperation.Result.STAGE_DISARM == 10
    assert MissionStatus.MANUAL_OVERRIDE == 14
    assert SearchAndTrack.Result.OUTCOME_MANUAL_OVERRIDE == 5
    assert VehicleState.LANDED_ON_GROUND == 1


def test_mission_feedback_carries_status():
    fb = SearchAndTrack.Feedback()
    assert isinstance(fb.status, MissionStatus)
