"""Every launch file loads and builds a LaunchDescription without errors."""

import importlib.util
import pathlib

import pytest
from launch import LaunchDescription

LAUNCH_DIR = pathlib.Path(__file__).resolve().parents[1] / 'launch'


@pytest.mark.parametrize('path', sorted(LAUNCH_DIR.glob('*.launch.py')), ids=lambda p: p.name)
def test_launch_file_builds(path):
    spec = importlib.util.spec_from_file_location(path.stem.replace('.', '_'), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    assert isinstance(module.generate_launch_description(), LaunchDescription)
