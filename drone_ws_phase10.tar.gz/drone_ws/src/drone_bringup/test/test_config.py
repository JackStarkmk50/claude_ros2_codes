"""drone.yaml is valid, has a section for every node, and keeps the bench-mode defaults."""

import pathlib

import yaml

CONFIG = pathlib.Path(__file__).resolve().parents[1] / 'config' / 'drone.yaml'
NODES = [
    'fcu_state_node', 'fcu_command_node', 'safety_supervisor', 'yolo_detector',
    'target_tracker', 'mission_manager', 'intent_bridge',
]


def load():
    with open(CONFIG) as f:
        return yaml.safe_load(f)


def test_every_node_has_parameters():
    cfg = load()
    for node in NODES:
        assert 'ros__parameters' in cfg[node], node


def test_bench_mode_defaults():
    p = load()['fcu_command_node']['ros__parameters']
    assert p['output_enabled'] is False
    assert p['allow_arming'] is False


def test_translation_locked_in_current_scope():
    p = load()['safety_supervisor']['ros__parameters']
    assert p['max_horizontal_speed_mps'] == 0.0
    assert p['max_vertical_speed_mps'] == 0.0


def test_takeoff_altitudes_are_consistent():
    s = load()['safety_supervisor']['ros__parameters']
    m = load()['mission_manager']['ros__parameters']
    assert s['min_takeoff_alt_m'] <= m['default_takeoff_altitude_m'] <= s['max_takeoff_alt_m']
    assert s['max_takeoff_alt_m'] <= s['hard_ceiling_m'] - s['ceiling_margin_m']


def test_llm_off_until_phase_13():
    assert load()['intent_bridge']['ros__parameters']['llm_enabled'] is False


NODE_SOURCES = {
    'fcu_state_node': ('drone_fcu', 'fcu_state_node.py'),
    'fcu_command_node': ('drone_fcu', 'fcu_command_node.py'),
    'safety_supervisor': ('drone_safety', 'safety_supervisor.py'),
    'yolo_detector': ('drone_perception', 'yolo_detector.py'),
}


def declared_parameters(pkg, filename):
    import ast
    src = pathlib.Path(__file__).resolve().parents[2] / pkg / pkg / filename
    for node in ast.parse(src.read_text()).body:
        if isinstance(node, ast.Assign) and getattr(node.targets[0], 'id', '') == 'PARAMETERS':
            return ast.literal_eval(node.value)
    raise AssertionError(f'no PARAMETERS dict in {filename}')


def test_implemented_nodes_config_matches_declared_parameters():
    cfg = load()
    for node, (pkg, filename) in NODE_SOURCES.items():
        declared = declared_parameters(pkg, filename)
        configured = cfg[node]['ros__parameters']
        assert set(configured) == set(declared), node
        for name, value in configured.items():
            assert type(value) is type(declared[name]), f'{node}.{name}'


def test_on_ground_limit_is_the_same_everywhere():
    cfg = load()
    a = cfg['fcu_command_node']['ros__parameters']['ground_height_max_m']
    b = cfg['safety_supervisor']['ros__parameters']['ground_height_max_m']
    flow_min = cfg['fcu_state_node']['ros__parameters']['flow_min_height_m']
    assert a == b < flow_min
