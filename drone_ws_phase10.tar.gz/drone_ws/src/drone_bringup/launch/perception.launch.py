"""Perception layer: USB camera (v4l2_camera), static camera transforms, yolo_detector and
target_tracker.

Camera settings come from the `camera` section of the config file, the camera mount (position
and tilt on the frame) from `camera_mount`. The TF tree is
base_link -> camera_link -> camera_optical_frame; nothing else in the stack publishes TF.
"""

import math
import os

import yaml
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

MOUNT_DEFAULTS = {'x_m': 0.0, 'y_m': 0.0, 'z_m': 0.0, 'tilt_down_deg': 0.0, 'yaw_left_deg': 0.0}


def camera_mount(config_path):
    """camera_mount parameters from the config file (defaults for anything missing)."""
    try:
        with open(config_path) as f:
            section = (yaml.safe_load(f) or {}).get('camera_mount', {})
    except OSError:
        section = {}
    mount = dict(MOUNT_DEFAULTS)
    mount.update(section.get('ros__parameters', {}))
    return mount


def static_tf_nodes(mount):
    """base_link -> camera_link from the mount, camera_link -> camera_optical_frame fixed.

    In FLU a positive pitch turns the nose DOWN, so pitch = +tilt_down. The optical frame is
    the REP-103 camera convention: z forward, x right, y down.
    """
    body = Node(
        package='tf2_ros', executable='static_transform_publisher', name='tf_base_to_camera',
        arguments=['--x', str(mount['x_m']), '--y', str(mount['y_m']), '--z', str(mount['z_m']),
                   '--roll', '0', '--pitch', str(math.radians(mount['tilt_down_deg'])),
                   '--yaw', str(math.radians(mount['yaw_left_deg'])),
                   '--frame-id', 'base_link', '--child-frame-id', 'camera_link'],
    )
    optical = Node(
        package='tf2_ros', executable='static_transform_publisher', name='tf_camera_to_optical',
        arguments=['--roll', str(-math.pi / 2), '--pitch', '0', '--yaw', str(-math.pi / 2),
                   '--frame-id', 'camera_link', '--child-frame-id', 'camera_optical_frame'],
    )
    return [body, optical]


def generate_launch_description():
    default_config = os.path.join(
        get_package_share_directory('drone_bringup'), 'config', 'drone.yaml')
    config = LaunchConfiguration('config')

    def tf_from_config(context):
        return static_tf_nodes(camera_mount(context.perform_substitution(config)))

    return LaunchDescription([
        DeclareLaunchArgument('config', default_value=default_config),
        DeclareLaunchArgument('use_camera', default_value='true',
                              description='Start the USB camera driver (false: frames come '
                                          'from elsewhere, e.g. tools/fake_camera.py)'),
        DeclareLaunchArgument('use_detector', default_value='true',
                              description='Start yolo_detector'),
        DeclareLaunchArgument('use_tracker', default_value='true',
                              description='Start target_tracker'),
        DeclareLaunchArgument('camera_device', default_value='/dev/video0',
                              description='USB camera device'),
        OpaqueFunction(function=tf_from_config),
        Node(
            package='v4l2_camera', executable='v4l2_camera_node', name='camera',
            namespace='camera',
            parameters=[config, {'video_device': LaunchConfiguration('camera_device')}],
            output='screen', respawn=True, respawn_delay=2.0,
            condition=IfCondition(LaunchConfiguration('use_camera')),
        ),
        Node(
            package='drone_perception', executable='yolo_detector', name='yolo_detector',
            parameters=[config], output='screen', respawn=True, respawn_delay=2.0,
            condition=IfCondition(LaunchConfiguration('use_detector')),
        ),
        Node(
            package='drone_perception', executable='target_tracker', name='target_tracker',
            parameters=[config], output='screen',
            condition=IfCondition(LaunchConfiguration('use_tracker')),
        ),
    ])
