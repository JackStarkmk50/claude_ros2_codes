# drone_bringup

Launch files and the single YAML parameter file for the whole stack.

| File | Starts |
|---|---|
| `launch/bringup.launch.py` | everything below, each stage switchable |
| `launch/fcu.launch.py` | `fcu_state_node`, `fcu_command_node` (MAVROS added in Phase 3) |
| `launch/autonomy.launch.py` | `safety_supervisor`, `mission_manager`, `intent_bridge` |
| `launch/perception.launch.py` | `yolo_detector`, `target_tracker` (USB camera + static TF added in Phase 9) |
| `config/drone.yaml` | parameters for every node; `[TUNE]` marks values to tune experimentally |

Launch arguments of `bringup.launch.py`:

| Argument | Default | Meaning |
|---|---|---|
| `config` | installed `drone.yaml` | parameter file |
| `use_fcu`, `use_autonomy`, `use_perception`, `use_llm` | `true` | start that stage |
| `enable_fcu_output` | `false` | **[AIRCRAFT]** allow setpoints to reach MAVROS |
| `allow_arming` | `false` | **[AIRCRAFT]** allow autonomous arm and takeoff |

Tests in `test/` check: every launch file builds, the YAML is valid and keeps bench-mode
defaults, all custom interfaces import, and the architecture rules (only `fcu_command_node`
writes to MAVROS; every Python package is complete; every entry point has a `main()`).
