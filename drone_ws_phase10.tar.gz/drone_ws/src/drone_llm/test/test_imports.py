"""Every executable module imports cleanly and exposes main()."""


def test_node_modules_import():
    from drone_llm import intent_bridge  # noqa: F401
    assert callable(intent_bridge.main)
