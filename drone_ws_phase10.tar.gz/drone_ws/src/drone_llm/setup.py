from setuptools import find_packages, setup

package_name = 'drone_llm'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml', 'README.md']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Moganesan',
    maintainer_email='ht.moganesan@gmail.com',
    description=(
        'Intent layer: turns natural-language commands into validated structured mission requests.'
    ),
    license='MIT',
    extras_require={'test': ['pytest']},
    entry_points={
        'console_scripts': [
            'intent_bridge = drone_llm.intent_bridge:main',
        ],
    },
)
