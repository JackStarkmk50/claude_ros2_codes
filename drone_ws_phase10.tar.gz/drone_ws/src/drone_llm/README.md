# drone_llm

Intent layer: turns natural-language commands into validated structured mission requests.

See `ARCHITECTURE.md` (§3 nodes, §4 topics, §5 services, §6 actions) for the full contract of this package.

| Executable | Responsibility | Implemented in |
|---|---|---|
| `intent_bridge` | Natural language to validated structured intent to SearchAndTrack goal. | Phase 13 |

Current state: **Phase 2 skeleton.** Each node starts, loads its parameters from
`drone_bringup/config/drone.yaml`, logs them, and spins. It publishes and commands nothing.

Run one node on its own:

```bash
ros2 run drone_llm intent_bridge --ros-args --params-file $(ros2 pkg prefix drone_bringup)/share/drone_bringup/config/drone.yaml
```

Test:

```bash
colcon test --packages-select drone_llm && colcon test-result --verbose
```
