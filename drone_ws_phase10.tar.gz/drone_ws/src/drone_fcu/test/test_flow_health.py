import math

from drone_fcu.core.flow_health import FlowConfig, FlowHealth

CFG = FlowConfig(timeout_s=0.5, min_quality=100, quality_samples=5,
                 min_height_m=0.3, max_height_m=3.0)


def feed(flow, quality, n, t0=0.0, dt=0.1):
    for i in range(n):
        flow.add_sample(quality, 0.01, -0.01, -1.0, t0 + i * dt)
    return t0 + (n - 1) * dt


def test_nothing_received():
    v = FlowHealth(CFG).evaluate(1.0, 1.0, True, True, True)
    assert not v.source_seen and not v.fresh
    assert not v.healthy_for_flight and not v.healthy_for_takeoff
    assert 'no OPTICAL_FLOW' in v.reason


def test_healthy_in_band():
    flow = FlowHealth(CFG)
    t = feed(flow, 150, 5)
    v = flow.evaluate(t, 1.0, True, True, True)
    assert v.healthy_for_flight and v.healthy_for_takeoff
    assert v.quality_applies and v.in_valid_height_band
    assert v.reason == ''
    assert math.isnan(v.ground_distance_m)   # -1 = not provided


def test_quality_needs_consecutive_samples():
    flow = FlowHealth(CFG)
    t = feed(flow, 150, 4)
    v = flow.evaluate(t, 1.0, True, True, True)
    assert not v.quality_ok and 'recovering (4/5)' in v.reason
    t = feed(flow, 50, 1, t0=t + 0.1)
    t = feed(flow, 150, 4, t0=t + 0.1)
    assert not flow.evaluate(t, 1.0, True, True, True).quality_ok
    t = feed(flow, 150, 1, t0=t + 0.1)
    assert flow.evaluate(t, 1.0, True, True, True).quality_ok


def test_on_the_ground_takeoff_ok_but_not_flight():
    flow = FlowHealth(CFG)
    t = feed(flow, 40, 5)       # low quality: normal below the sensor's minimum height
    v = flow.evaluate(t, 0.05, True, True, False)
    assert v.healthy_for_takeoff
    assert not v.healthy_for_flight
    assert not v.quality_applies and not v.in_valid_height_band


def test_stale_flow_fails_both():
    flow = FlowHealth(CFG)
    t = feed(flow, 150, 5)
    v = flow.evaluate(t + 0.6, 1.0, True, True, True)
    assert not v.fresh
    assert not v.healthy_for_flight and not v.healthy_for_takeoff
    assert 'stale' in v.reason


def test_invalid_rangefinder_fails_both():
    flow = FlowHealth(CFG)
    t = feed(flow, 150, 5)
    v = flow.evaluate(t, math.nan, False, True, True)
    assert not v.healthy_for_flight and not v.healthy_for_takeoff
    assert 'rangefinder invalid' in v.reason


def test_ekf_gates():
    flow = FlowHealth(CFG)
    t = feed(flow, 150, 5)
    assert not flow.evaluate(t, 1.0, True, True, False).healthy_for_flight
    assert not flow.evaluate(t, 1.0, True, False, True).healthy_for_takeoff


def test_above_band():
    flow = FlowHealth(CFG)
    t = feed(flow, 150, 5)
    v = flow.evaluate(t, 3.5, True, True, True)
    assert not v.healthy_for_flight and 'above flow band' in v.reason
