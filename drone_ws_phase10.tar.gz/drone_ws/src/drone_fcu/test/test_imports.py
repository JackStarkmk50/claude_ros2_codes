"""Every executable module imports cleanly and exposes main()."""


def test_node_modules_import():
    from drone_fcu import fcu_state_node  # noqa: F401
    from drone_fcu import fcu_command_node  # noqa: F401
    assert callable(fcu_state_node.main)
    assert callable(fcu_command_node.main)


def test_core_modules_have_no_ros_imports():
    import ast
    import pathlib
    core = pathlib.Path(__file__).resolve().parents[1] / 'drone_fcu' / 'core'
    for path in core.glob('*.py'):
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node, ast.Import):
                names = [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom):
                names = [node.module or '']
            else:
                continue
            for name in names:
                assert not name.startswith('rclpy') and '_msgs' not in name, (path.name, name)
