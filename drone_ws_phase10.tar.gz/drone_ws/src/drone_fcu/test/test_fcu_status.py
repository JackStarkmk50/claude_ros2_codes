from drone_fcu.core.fcu_status import (MAV_SYS_STATUS_PREARM_CHECK as PREARM,
                                       MAV_SYS_STATUS_SENSOR_RC_RECEIVER as RC, prearm_ok,
                                       rc_present)

STICKS = [1500, 1500, 1000, 1500, 1165, 1500, 1500, 1500]


def test_prearm_bit():
    assert prearm_ok(PREARM, PREARM)
    assert not prearm_ok(PREARM, 0)
    assert not prearm_ok(0, 0)          # not reported = not ok


def test_rc_needs_plausible_channels():
    assert rc_present(STICKS)
    assert not rc_present([])
    assert not rc_present([0] * 8)


def test_rc_radio_failsafe_from_sys_status():
    assert rc_present(STICKS, (RC, RC))
    assert not rc_present(STICKS, (RC, 0))    # ArduPilot flags the receiver unhealthy
    assert rc_present(STICKS, (0, 0))         # receiver bit not reported: channels decide
