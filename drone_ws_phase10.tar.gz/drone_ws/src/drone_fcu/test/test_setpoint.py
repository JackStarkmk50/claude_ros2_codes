import math
from types import SimpleNamespace as NS

from drone_fcu.core.setpoint import COMMAND, HOLD, SILENT, SetpointConfig, decide

CFG = SetpointConfig()


def vehicle(**kw):
    base = dict(connected=True, armed=True, mode='GUIDED', landed_state=2)
    base.update(kw)
    return NS(**base)


def safety(level=0, motion_allowed=True):
    return NS(level=level, motion_allowed=motion_allowed)


def cmd(yaw=0.2, mode=1):
    return NS(mode=mode, vx_mps=0.0, vy_mps=0.0, vz_mps=0.0, yaw_rate_rad_s=yaw)


def test_streams_validated_command():
    d = decide(CFG, vehicle(), 0.1, safety(), 0.05, cmd(), 0.1)
    assert d.action == COMMAND and d.yaw_rate == 0.2


def test_silent_when_not_our_turn():
    assert decide(CFG, vehicle(armed=False), 0.1, safety(), 0.05, cmd(), 0.1).action == SILENT
    assert decide(CFG, vehicle(mode='LOITER'), 0.1, safety(), 0.05, cmd(), 0.1).action == SILENT
    assert decide(CFG, vehicle(), 2.0, safety(), 0.05, cmd(), 0.1).action == SILENT
    assert decide(CFG, None, 0.0, safety(), 0.05, cmd(), 0.1).action == SILENT


def test_override_silences_everything():
    d = decide(CFG, vehicle(), 0.1, safety(level=4, motion_allowed=False), 0.05, cmd(), 0.1)
    assert d.action == SILENT


def test_stale_command_holds():
    d = decide(CFG, vehicle(), 0.1, safety(), 0.05, cmd(), 0.31)
    assert d.action == HOLD and d.yaw_rate == 0.0
    assert decide(CFG, vehicle(), 0.1, safety(), 0.05, None, math.inf).action == HOLD


def test_safety_levels_hold():
    for level in (2, 3):
        d = decide(CFG, vehicle(), 0.1, safety(level, False), 0.05, cmd(), 0.1)
        assert d.action == HOLD


def test_dead_safety_holds_then_requests_land_when_airborne():
    d = decide(CFG, vehicle(), 0.1, safety(), 0.7, cmd(), 0.1)
    assert d.action == HOLD and not d.request_land
    d = decide(CFG, vehicle(), 0.1, safety(), 1.5, cmd(), 0.1)
    assert d.action == HOLD and d.request_land
    d = decide(CFG, vehicle(landed_state=1), 0.1, None, math.inf, cmd(), 0.1)
    assert d.action == HOLD and not d.request_land


def test_non_finite_or_hold_command_holds():
    assert decide(CFG, vehicle(), 0.1, safety(), 0.05, cmd(yaw=math.nan), 0.1).action == HOLD
    assert decide(CFG, vehicle(), 0.1, safety(), 0.05, cmd(mode=0), 0.1).action == HOLD
