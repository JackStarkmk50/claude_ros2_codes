import math

from drone_fcu.core import operations as ops
from drone_fcu.core.operations import (ARM, HOLD, OP_LAND, OP_TAKEOFF, SET_MODE, SILENT,
                                       TAKEOFF, Obs, OpConfig, Operation)

CFG = OpConfig()
GROUND_H = 0.14


class Sim:
    """A tiny fake vehicle that does what an accepted request asks, next tick."""

    def __init__(self, mode='STABILIZE', climbs=True, arms=True, lands=True, auto_disarm=True):
        self.o = Obs(fresh=True, mode=mode, landed_state=ops.LANDED_ON_GROUND,
                     height_m=GROUND_H, vz_mps=0.0, vxy_mps=0.0, flow_ok=True, ekf_ok=True)
        self.climbs, self.arms, self.lands, self.auto_disarm = climbs, arms, lands, auto_disarm
        self.target = None
        self.sent = []
        self.touchdown_at = None

    def handle(self, op, step, now):
        if step.request is None:
            return
        kind, arg = step.request
        self.sent.append(step.request)
        ok = True
        if kind == SET_MODE:
            if arg == 'LAND' and not self.lands:
                ok = False
            else:
                self.o.mode = arg
        elif kind == ARM:
            if arg and not self.arms:
                ok = False
            elif arg:
                self.o.armed = True
            elif self.o.landed_state == ops.LANDED_ON_GROUND:
                self.o.armed = False
            else:
                ok = False
        elif kind == TAKEOFF:
            self.target = GROUND_H + arg
        op.ack(kind, ok, '' if ok else 'denied')

    def physics(self, now, dt):
        o = self.o
        if o.mode == 'GUIDED' and o.armed and self.target and self.climbs:
            o.landed_state = ops.LANDED_TAKEOFF if o.height_m < self.target - 0.05 \
                else ops.LANDED_IN_AIR
            o.height_m = min(self.target, o.height_m + 0.5 * dt)
        if o.mode == 'LAND' and o.armed:
            self.target = None
            if o.height_m > GROUND_H + 0.01:
                o.landed_state = ops.LANDED_LANDING
                o.height_m = max(GROUND_H, o.height_m - 0.5 * dt)
            else:
                o.landed_state = ops.LANDED_ON_GROUND
                if self.touchdown_at is None:
                    self.touchdown_at = now
                if self.auto_disarm and now - self.touchdown_at > 1.0:
                    o.armed = False


def run(op, sim, until=60.0, dt=0.1, hook=None):
    now = 0.0
    streams = []
    while now < until:
        if hook:
            hook(now, sim, op)
        step = op.step(now, sim.o)
        streams.append((op.stage, step.stream))
        if step.result is not None:
            sim.handle(op, step, now)
            return step.result, streams, now
        sim.handle(op, step, now)
        sim.physics(now, dt)
        now += dt
    raise AssertionError(f'operation did not finish: stage {op.stage_name}')


def takeoff(alt=0.8):
    return Operation(CFG, OP_TAKEOFF, 0.0, altitude_m=alt, start_height_m=GROUND_H)


def test_takeoff_happy_path():
    sim = Sim()
    op = takeoff()
    result, streams, _ = run(op, sim)
    assert result.success, result.message
    assert [r[0] for r in sim.sent] == [SET_MODE, ARM, TAKEOFF]
    assert sim.sent[2] == (TAKEOFF, 0.8)
    # no setpoints before the stabilize stage, HOLD during it
    assert all(s == SILENT for st, s in streams if st < ops.STAGE_STABILIZE)
    assert any(s == HOLD for st, s in streams if st == ops.STAGE_STABILIZE)
    assert abs(sim.o.height_m - (0.8 + GROUND_H)) < 0.01


def test_arm_refused_sends_nothing_else():
    sim = Sim(arms=False)
    result, _, _ = run(takeoff(), sim)
    assert not result.success and result.failed_stage == ops.STAGE_ARM
    assert 'ARM refused' in result.message
    assert [r[0] for r in sim.sent] == [SET_MODE, ARM]


def test_guided_not_reached():
    sim = Sim()
    op = takeoff()
    sim.handle = lambda op, step, now: op.ack(step.request[0], True) if step.request else None
    result, _, now = run(op, sim)
    assert result.failed_stage == ops.STAGE_SET_GUIDED and now >= CFG.set_mode_timeout_s


def test_no_climb_props_off_lands_and_disarms():
    sim = Sim(climbs=False)
    result, _, _ = run(takeoff(), sim)
    assert not result.success and result.failed_stage == ops.STAGE_TAKEOFF_CMD
    assert 'no climb' in result.message
    assert (SET_MODE, 'LAND') in sim.sent
    assert result.landed_and_disarmed


def test_takeoff_rejected_disarms_on_the_ground():
    sim = Sim()
    original = sim.handle

    def handle(op, step, now):
        if step.request and step.request[0] == TAKEOFF:
            sim.sent.append(step.request)
            op.ack(TAKEOFF, False, 'Takeoff rejected')
            return
        original(op, step, now)
    sim.handle = handle
    result, _, _ = run(takeoff(), sim)
    assert result.failed_stage == ops.STAGE_TAKEOFF_CMD and not result.armed_at_end
    assert (ARM, False) in sim.sent and (SET_MODE, 'LAND') not in sim.sent


def test_safety_abort_during_climb_lands():
    sim = Sim()

    def hook(now, sim, op):
        if op.stage == ops.STAGE_CLIMB and sim.o.height_m > 0.5:
            sim.o.safety_abort, sim.o.abort_reason = True, 'BATTERY_LAND'
    result, _, _ = run(takeoff(), sim, hook=hook)
    assert result.failed_stage == ops.STAGE_CLIMB and 'BATTERY_LAND' in result.message
    assert result.landed_and_disarmed


def test_pilot_mode_change_ends_at_once():
    sim = Sim()

    def hook(now, sim, op):
        if op.stage == ops.STAGE_CLIMB:
            sim.o.mode = 'LOITER'
    n_before = []
    result, _, _ = run(takeoff(), sim, hook=lambda n, s, o: (hook(n, s, o),
                                                             n_before.append(len(s.sent))))
    assert not result.success and 'LOITER' in result.message
    assert (SET_MODE, 'LAND') not in sim.sent        # the pilot has authority


def test_override_flag_ends_silently():
    sim = Sim()

    def hook(now, sim, op):
        if op.stage == ops.STAGE_STABILIZE:
            sim.o.override = True
    result, _, _ = run(takeoff(), sim, hook=hook)
    assert 'override' in result.message and (SET_MODE, 'LAND') not in sim.sent


def test_unstable_hover_lands():
    sim = Sim()

    def hook(now, sim, op):
        sim.o.flow_ok = op.stage != ops.STAGE_STABILIZE
    result, _, _ = run(takeoff(), sim, hook=hook)
    assert result.failed_stage == ops.STAGE_STABILIZE and 'flow' in result.message


def test_cancel_before_and_after_arming():
    sim = Sim()
    op = takeoff()
    op.cancel()
    result, _, _ = run(op, sim)
    assert 'cancelled' in result.message and sim.sent == []

    sim = Sim()
    op = takeoff()
    result, _, _ = run(op, sim, hook=lambda n, s, o: o.cancel() if o.stage == ops.STAGE_CLIMB
                       else None)
    assert 'cancelled' in result.message and result.landed_and_disarmed
    assert (SET_MODE, 'LAND') in sim.sent


def test_land_cannot_be_cancelled():
    sim = Sim(mode='GUIDED')
    sim.o.armed, sim.o.landed_state, sim.o.height_m = True, ops.LANDED_IN_AIR, 0.9
    op = Operation(CFG, OP_LAND, 0.0)
    assert op.cancel() is False
    result, _, _ = run(op, sim)
    assert result.success and result.landed_and_disarmed
    assert sim.sent == [(SET_MODE, 'LAND')]


def test_land_mode_refused_twice_asks_for_pilot():
    sim = Sim(mode='GUIDED', lands=False)
    sim.o.armed, sim.o.landed_state, sim.o.height_m = True, ops.LANDED_IN_AIR, 0.9
    result, _, _ = run(Operation(CFG, OP_LAND, 0.0), sim)
    assert 'LAND NOT ACCEPTED' in result.message
    assert sim.sent == [(SET_MODE, 'LAND'), (SET_MODE, 'LAND')]


def test_no_auto_disarm_then_disarm_request_on_ground():
    sim = Sim(mode='GUIDED', auto_disarm=False)
    sim.o.armed, sim.o.landed_state, sim.o.height_m = True, ops.LANDED_IN_AIR, 0.5
    result, _, _ = run(Operation(CFG, OP_LAND, 0.0), sim)
    assert result.success and sim.sent[-1] == (ARM, False)


def test_telemetry_lost_during_land_never_success():
    sim = Sim(mode='GUIDED')
    sim.o.armed, sim.o.landed_state, sim.o.height_m = True, ops.LANDED_IN_AIR, 1.0

    def hook(now, sim, op):
        if op.stage == ops.STAGE_DESCEND:
            sim.o.fresh = False
    result, _, _ = run(Operation(CFG, OP_LAND, 0.0), sim, hook=hook)
    assert not result.success and 'telemetry lost' in result.message


def test_telemetry_lost_while_climbing_requests_land_blind():
    sim = Sim()

    def hook(now, sim, op):
        if op.stage == ops.STAGE_CLIMB:
            sim.o.fresh = False
    result, _, _ = run(takeoff(), sim, hook=hook)
    assert not result.success and 'blind' in result.message
    assert sim.sent[-1] == (SET_MODE, 'LAND')


def test_target_height_includes_landing_gear():
    op = Operation(CFG, OP_TAKEOFF, 0.0, altitude_m=1.0, start_height_m=0.14)
    assert math.isclose(op.target_height, 1.14)
    assert math.isclose(op.band[0], 0.85) and math.isclose(op.band[1], 1.29)
    op = Operation(CFG, OP_TAKEOFF, 0.0, altitude_m=1.0, start_height_m=math.nan)
    assert math.isclose(op.target_height, 1.0)


def test_slow_spool_up_still_counts():
    """ArduCopter 4.6 needs 2-3 s after the takeoff command before it leaves the ground."""
    sim = Sim()
    original = sim.physics
    t_takeoff = []

    def physics(now, dt):
        if sim.target and not t_takeoff:
            t_takeoff.append(now)
        if t_takeoff and now - t_takeoff[0] < 3.5:
            return
        original(now, dt)
    sim.physics = physics
    result, _, _ = run(takeoff(), sim)
    assert result.success, result.message
