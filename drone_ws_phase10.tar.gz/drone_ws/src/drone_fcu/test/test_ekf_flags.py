from drone_fcu.core import ekf_flags as e

GOOD_AIRBORNE = e.ATTITUDE | e.VELOCITY_HORIZ | e.VELOCITY_VERT | e.POS_HORIZ_REL


def test_healthy_in_air():
    h = e.evaluate(GOOD_AIRBORNE, on_ground=False)
    assert h.attitude_ok and h.velocity_horiz_ok and h.pos_horiz_rel_ok
    assert not h.const_pos_mode


def test_predicted_position_counts_only_on_ground():
    flags = e.ATTITUDE | e.VELOCITY_HORIZ | e.PRED_POS_HORIZ_REL
    assert e.evaluate(flags, on_ground=True).pos_horiz_rel_ok
    assert not e.evaluate(flags, on_ground=False).pos_horiz_rel_ok


def test_uninitialized_overrides_everything():
    h = e.evaluate(GOOD_AIRBORNE | e.UNINITIALIZED, on_ground=False)
    assert not (h.attitude_ok or h.velocity_horiz_ok or h.pos_horiz_rel_ok)


def test_const_pos_mode_reported():
    assert e.evaluate(e.ATTITUDE | e.CONST_POS_MODE, on_ground=True).const_pos_mode


def test_describe():
    assert e.describe(0) == 'none'
    assert e.describe(e.ATTITUDE | e.CONST_POS_MODE) == 'attitude|const_pos_mode'
