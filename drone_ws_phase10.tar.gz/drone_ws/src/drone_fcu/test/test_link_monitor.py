from drone_fcu.core.link_monitor import LinkMonitor, StreamRequester


def test_rates_per_source():
    m = LinkMonitor(window_s=5.0)
    for i in range(50):
        m.record(1, 1, 30, 28, i * 0.1)
        m.record(42, 158, 100, 26, i * 0.1)
        m.record(42, 158, 100, 26, i * 0.1 + 0.05)
    r = m.rates(4.95)
    assert r[(1, 1, 30)][0] == 10.0
    assert r[(42, 158, 100)][0] == 20.0
    assert r[(1, 1, 30)][1] == 10 * 40   # 28 payload + 12 overhead, 10 Hz
    assert m.last_seen(1, 1, 30) == 4.9
    assert m.last_seen(1, 1, 99) is None
    assert m.rates(20.0) == {}


def test_requests_all_after_connect_then_only_missing():
    seen = {}
    req = StreamRequester({30: 10.0, 193: 2.0, 65: 0.0}, check_period_s=5.0,
                          missing_after_s=3.0, max_attempts=3)
    assert req.due(0.0, seen.get) == []            # not connected yet
    req.reset(0.0)
    assert sorted(req.due(0.0, seen.get)) == [(30, 10.0), (193, 2.0)]   # rate 0 = off
    assert req.due(1.0, seen.get) == []            # waits for the check period
    seen[30] = 4.9
    assert req.due(5.0, seen.get) == [(193, 2.0)]  # 30 arrives, 193 still missing


def test_gives_up_after_max_attempts_and_resets_on_reconnect():
    seen = {}
    req = StreamRequester({193: 2.0}, check_period_s=5.0, missing_after_s=3.0, max_attempts=3)
    req.reset(0.0)
    for t in (0.0, 5.0, 10.0):
        assert req.due(t, seen.get) == [(193, 2.0)]
    assert req.given_up(12.0, seen.get) == []      # just asked, give it time
    assert req.given_up(13.5, seen.get) == [193]
    assert req.due(15.0, seen.get) == []
    req.reset(20.0)
    assert req.due(20.0, seen.get) == [(193, 2.0)]


def test_once_streams_are_not_chased():
    r = StreamRequester({1: 2.0, 85: 5.0}, check_period_s=1.0, missing_after_s=1.0,
                        max_attempts=2, once={85})
    r.reset(0.0)
    assert sorted(m for m, _ in r.due(0.0, lambda m: None)) == [1, 85]
    assert [m for m, _ in r.due(2.0, lambda m: None)] == [1]
    r.due(4.0, lambda m: None)
    assert r.given_up(6.0, lambda m: None) == [1]
