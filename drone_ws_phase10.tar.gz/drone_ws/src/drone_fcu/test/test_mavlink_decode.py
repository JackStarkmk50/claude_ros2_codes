"""Our struct layouts match real MAVLink 2 frames built by pymavlink."""

import struct

import pytest

from drone_fcu.core import mavlink_decode as mav

mavlink = pytest.importorskip('pymavlink.dialects.v20.ardupilotmega')


def as_mavros(msg):
    """(payload64, len) the way MAVROS puts a frame into mavros_msgs/Mavlink."""
    link = mavlink.MAVLink(None, srcSystem=1, srcComponent=1)
    frame = msg.pack(link)
    length = frame[1]
    payload = frame[10:10 + length]
    padded = payload + b'\0' * (-len(payload) % 8)
    words = list(struct.unpack(f'<{len(padded) // 8}Q', padded))
    return words, length


def test_ekf_status_report():
    words, length = as_mavros(mavlink.MAVLink_ekf_status_report_message(
        flags=0x10F, velocity_variance=0.25, pos_horiz_variance=0.5,
        pos_vert_variance=0.75, compass_variance=0.125, terrain_alt_variance=0.0,
        airspeed_variance=0.0))
    d = mav.decode(mav.EKF_STATUS_REPORT, words, length)
    assert d.flags == 0x10F
    assert d.velocity_variance == 0.25
    assert d.pos_horiz_variance == 0.5
    assert d.pos_vert_variance == 0.75
    assert d.compass_variance == 0.125


def test_distance_sensor():
    words, length = as_mavros(mavlink.MAVLink_distance_sensor_message(
        time_boot_ms=123456, min_distance=1, max_distance=800, current_distance=57,
        type=0, id=0, orientation=25, covariance=255, horizontal_fov=0.0, vertical_fov=0.0,
        quaternion=[0.0] * 4, signal_quality=0))
    d = mav.decode(mav.DISTANCE_SENSOR, words, length)
    assert (d.min_distance, d.max_distance, d.current_distance) == (1, 800, 57)
    assert d.orientation == mav.ORIENTATION_DOWN
    assert d.time_boot_ms == 123456


def test_optical_flow_with_extensions():
    words, length = as_mavros(mavlink.MAVLink_optical_flow_message(
        time_usec=99, sensor_id=3, flow_x=-12, flow_y=34, flow_comp_m_x=0.5,
        flow_comp_m_y=-0.5, quality=180, ground_distance=-1.0,
        flow_rate_x=0.25, flow_rate_y=-0.125))
    d = mav.decode(mav.OPTICAL_FLOW, words, length)
    assert d.quality == 180
    assert (d.flow_x, d.flow_y) == (-12, 34)
    assert d.ground_distance == -1.0
    assert (d.flow_rate_x, d.flow_rate_y) == (0.25, -0.125)


def test_truncated_payload_is_zero_padded():
    # MAVLink 2 drops trailing zeros: here the extension fields are 0 and get cut off
    words, length = as_mavros(mavlink.MAVLink_optical_flow_message(
        time_usec=1, sensor_id=0, flow_x=0, flow_y=0, flow_comp_m_x=0.0, flow_comp_m_y=0.0,
        quality=50, ground_distance=0.0, flow_rate_x=0.0, flow_rate_y=0.0))
    assert length < 34
    d = mav.decode(mav.OPTICAL_FLOW, words, length)
    assert d.quality == 50
    assert d.flow_rate_x == 0.0


def test_unknown_message_is_none():
    assert mav.decode(9999, [0], 8) is None


def test_position_target_local_ned():
    words, length = as_mavros(mavlink.MAVLink_position_target_local_ned_message(
        time_boot_ms=42, coordinate_frame=8, type_mask=1479, x=0.0, y=0.0, z=0.0, vx=0.0,
        vy=0.0, vz=0.0, afx=0.0, afy=0.0, afz=0.0, yaw=0.0, yaw_rate=-0.2))
    d = mav.decode(mav.POSITION_TARGET_LOCAL_NED, words, length)
    assert d.time_boot_ms == 42 and d.type_mask == 1479 and d.coordinate_frame == 8
    assert abs(d.yaw_rate + 0.2) < 1e-6


def test_set_position_target_local_ned():
    words, length = as_mavros(mavlink.MAVLink_set_position_target_local_ned_message(
        time_boot_ms=0, target_system=1, target_component=1, coordinate_frame=8,
        type_mask=3527, x=0.0, y=0.0, z=0.0, vx=0.0, vy=0.0, vz=0.0, afx=0.0, afy=0.0,
        afz=0.0, yaw=0.0, yaw_rate=-0.2))
    d = mav.decode(mav.SET_POSITION_TARGET_LOCAL_NED, words, length)
    assert (d.target_system, d.target_component, d.coordinate_frame) == (1, 1, 8)
    assert d.type_mask == 3527 and abs(d.yaw_rate + 0.2) < 1e-6 and d.vx == 0.0
