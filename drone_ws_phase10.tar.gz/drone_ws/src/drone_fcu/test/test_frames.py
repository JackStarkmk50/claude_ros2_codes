import math

from drone_fcu.core.frames import (enu_yaw_to_compass_deg, quaternion_to_euler, tilt_rad,
                                   wrap_pi)


def quat_from_euler(roll, pitch, yaw):
    cr, sr = math.cos(roll / 2), math.sin(roll / 2)
    cp, sp = math.cos(pitch / 2), math.sin(pitch / 2)
    cy, sy = math.cos(yaw / 2), math.sin(yaw / 2)
    return (sr * cp * cy - cr * sp * sy, cr * sp * cy + sr * cp * sy,
            cr * cp * sy - sr * sp * cy, cr * cp * cy + sr * sp * sy)


def test_identity_is_level_facing_east():
    assert quaternion_to_euler(0, 0, 0, 1) == (0.0, 0.0, 0.0)
    assert enu_yaw_to_compass_deg(0.0) == 90.0


def test_round_trip():
    for r, p, y in [(0.1, -0.2, 1.0), (-0.3, 0.25, -2.5), (0.0, 0.0, math.pi / 2)]:
        out = quaternion_to_euler(*quat_from_euler(r, p, y))
        assert all(math.isclose(a, b, abs_tol=1e-9) for a, b in zip(out, (r, p, y)))


def test_facing_north_is_compass_zero():
    # ENU yaw +90 deg (counter-clockwise from East) = North
    yaw = quaternion_to_euler(*quat_from_euler(0, 0, math.pi / 2))[2]
    assert math.isclose(enu_yaw_to_compass_deg(yaw), 0.0, abs_tol=1e-9)
    # ENU yaw -90 deg = South
    assert math.isclose(enu_yaw_to_compass_deg(-math.pi / 2), 180.0)


def test_wrap_and_tilt():
    assert math.isclose(wrap_pi(3 * math.pi / 2), -math.pi / 2)
    assert math.isclose(tilt_rad(0.0, 0.0), 0.0)
    assert math.isclose(tilt_rad(math.radians(10), 0.0), math.radians(10))
