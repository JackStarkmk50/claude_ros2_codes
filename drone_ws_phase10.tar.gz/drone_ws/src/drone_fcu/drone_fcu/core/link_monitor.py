"""Bookkeeping for the raw MAVLink stream: rates per source and message, and stream requests.

Pure logic; `now` is a steady-clock time in s.
"""

from collections import defaultdict, deque

MAVLINK2_OVERHEAD_BYTES = 12   # header 10 + checksum 2, unsigned


class LinkMonitor:
    """Counts frames and bytes per (sysid, compid, msgid) over a sliding window."""

    def __init__(self, window_s=5.0):
        self.window_s = window_s
        self._frames = defaultdict(deque)   # key -> deque[(time, bytes)]
        self._last = {}

    def record(self, sysid, compid, msgid, payload_len, now):
        key = (sysid, compid, msgid)
        frames = self._frames[key]
        frames.append((now, payload_len + MAVLINK2_OVERHEAD_BYTES))
        self._last[key] = now
        self._trim(frames, now)

    def last_seen(self, sysid, compid, msgid):
        return self._last.get((sysid, compid, msgid))

    def rates(self, now):
        """{(sysid, compid, msgid): (hz, bytes_per_s)} over the window."""
        out = {}
        for key, frames in self._frames.items():
            self._trim(frames, now)
            if frames:
                out[key] = (len(frames) / self.window_s,
                            sum(b for _, b in frames) / self.window_s)
        return out

    def _trim(self, frames, now):
        while frames and now - frames[0][0] > self.window_s:
            frames.popleft()


class StreamRequester:
    """Decides when to ask the FCU (MAV_CMD_SET_MESSAGE_INTERVAL) for each stream.

    After every (re)connect all streams are requested once. After that a stream is requested
    again only if it has not been seen for `missing_after_s`, at most `max_attempts` times
    per connection; then it is reported as not sent by the FCU. Streams in `once` are requested
    once per connection and never reported missing (the FCU sends them only in some modes).
    """

    def __init__(self, rates_hz, check_period_s=5.0, missing_after_s=3.0, max_attempts=3,
                 once=()):
        self.rates_hz = {mid: hz for mid, hz in rates_hz.items() if hz > 0.0}
        self.once = set(once)
        self.check_period_s = check_period_s
        self.missing_after_s = missing_after_s
        self.max_attempts = max_attempts
        self.attempts = {}
        self._last_request = {}
        self._next_check = None

    def reset(self, now):
        """Call on every (re)connect: the FCU may have rebooted and forgotten the rates."""
        self.attempts = {mid: 0 for mid in self.rates_hz}
        self._last_request = {}
        self._next_check = now

    def due(self, now, last_seen):
        """[(msgid, hz)] to request now. last_seen(msgid) -> time or None."""
        if self._next_check is None or now < self._next_check:
            return []
        self._next_check = now + self.check_period_s
        out = []
        for mid, hz in self.rates_hz.items():
            if self.attempts[mid] >= self.max_attempts or (mid in self.once
                                                            and self.attempts[mid] > 0):
                continue
            seen = last_seen(mid)
            missing = seen is None or now - seen > self.missing_after_s
            if self.attempts[mid] == 0 or missing:
                self.attempts[mid] += 1
                self._last_request[mid] = now
                out.append((mid, hz))
        return out

    def given_up(self, now, last_seen):
        """Streams requested max_attempts times that still do not arrive."""
        out = []
        for mid, tries in self.attempts.items():
            seen = last_seen(mid)
            if tries < self.max_attempts or mid in self.once:
                continue
            waited = now - self._last_request.get(mid, now) > self.missing_after_s
            if waited and (seen is None or now - seen > self.missing_after_s):
                out.append(mid)
        return out
