"""Flight operations executed by fcu_command_node (ARCHITECTURE §11.5).

TAKEOFF: GUIDED -> arm -> takeoff command -> climb -> stable hover (then the node streams HOLD)
LAND:    LAND mode -> descend -> touchdown -> ArduPilot disarms (the Pi only confirms)

`Operation.step(now, obs)` is called every tick with a fresh `Obs`. It returns a `Step`: what
to ask MAVROS for (at most one request at a time), what the setpoint stream must do, the stage
and, when finished, the result. Every step waits for the state the FCU REPORTS, never only for
an acknowledgement. The node answers requests with `ack(kind, ok, text)`.

Rules that matter for safety:
- No setpoints while GUIDED is climbing on its own (a velocity setpoint would end ArduPilot's
  takeoff and hold the drone where it is). HOLD is streamed only from the STABILIZE stage on.
- Once the drone may have left the ground, every failure ends in LAND, never in a disarm.
  A disarm is requested only on the ground: before the takeoff command, or after touchdown.
- A pilot/FCU mode change ends the operation at once and the Pi sends nothing more.
- A LAND that can no longer be confirmed (telemetry lost) is never reported as a success.
"""

import math
from dataclasses import dataclass

# FlightOperation goal/result constants (kept here so this module needs no ROS imports)
OP_TAKEOFF, OP_LAND = 0, 1
(STAGE_NONE, STAGE_PREFLIGHT, STAGE_SET_GUIDED, STAGE_ARM, STAGE_TAKEOFF_CMD, STAGE_CLIMB,
 STAGE_STABILIZE, STAGE_SET_LAND, STAGE_DESCEND, STAGE_TOUCHDOWN, STAGE_DISARM) = range(11)
STAGE_NAMES = ['NONE', 'PREFLIGHT', 'SET_GUIDED', 'ARM', 'TAKEOFF_CMD', 'CLIMB', 'STABILIZE',
               'SET_LAND', 'DESCEND', 'TOUCHDOWN', 'DISARM']

LANDED_UNDEFINED, LANDED_ON_GROUND, LANDED_IN_AIR, LANDED_TAKEOFF, LANDED_LANDING = range(5)

# requests to MAVROS
SET_MODE = 'SET_MODE'     # arg: mode name
ARM = 'ARM'               # arg: True = arm, False = disarm
TAKEOFF = 'TAKEOFF'       # arg: metres above home

# what the setpoint stream does during a stage
SILENT = 'SILENT'
HOLD = 'HOLD'


@dataclass(frozen=True)
class OpConfig:
    set_mode_timeout_s: float = 3.0
    land_mode_timeout_s: float = 2.0
    arm_timeout_s: float = 3.0
    takeoff_start_timeout_s: float = 5.0   # ArduCopter 4.6 spools up and slews ~2-3 s first
    max_arm_to_takeoff_s: float = 2.0
    min_climb_rate_mps: float = 0.2
    climb_start_m: float = 0.10           # height gain that counts as "climbing"
    alt_tol_m: float = 0.15
    stable_window_s: float = 2.0
    stable_timeout_s: float = 8.0
    stable_max_vz_mps: float = 0.15
    stable_max_vxy_mps: float = 0.2
    min_descent_rate_mps: float = 0.1
    disarm_wait_s: float = 5.0
    ground_height_max_m: float = 0.25
    telemetry_lost_s: float = 3.0


@dataclass
class Obs:
    """What the FCU reports right now (from /drone/vehicle_state etc.)."""
    fresh: bool = False               # vehicle state younger than the timeout
    armed: bool = False
    mode: str = ''
    landed_state: int = LANDED_UNDEFINED
    height_m: float = math.nan        # rangefinder, NaN if invalid
    vz_mps: float = math.nan          # + up
    vxy_mps: float = math.nan         # horizontal speed
    flow_ok: bool = False             # FlowStatus.healthy_for_flight
    ekf_ok: bool = False
    safety_abort: bool = False        # safety ABORT, or safety_supervisor lost
    override: bool = False            # safety says OVERRIDE
    abort_reason: str = ''


@dataclass
class Result:
    success: bool
    failed_stage: int
    message: str
    armed_at_end: bool
    landed_state_at_end: int
    height_at_end_m: float

    @property
    def landed_and_disarmed(self):
        return not self.armed_at_end and self.landed_state_at_end in (LANDED_ON_GROUND,
                                                                      LANDED_UNDEFINED)


@dataclass
class Step:
    request: tuple = None             # (kind, arg) to send now, or None
    stream: str = SILENT              # SILENT / HOLD / None = normal setpoint path
    stage: int = STAGE_NONE
    detail: str = ''
    result: Result = None


def _on_ground(cfg, o):
    return o.landed_state == LANDED_ON_GROUND and (
        not math.isfinite(o.height_m) or o.height_m < cfg.ground_height_max_m)


class Operation:

    def __init__(self, cfg, op, now, altitude_m=0.0, start_height_m=math.nan, source=''):
        self.cfg = cfg
        self.op = op
        self.source = source
        self.h = altitude_m
        # ArduPilot's takeoff altitude is above home (the arming point), while the rangefinder
        # measures from the sensor to the floor, which is already ~0.14 m on the landing gear.
        # How ArduPilot's EKF treats that offset depends on RNGFND1_GNDCLEAR, so the rangefinder
        # height of the hover is accepted anywhere in [h - tol, h + ground offset + tol].
        ground = start_height_m if math.isfinite(start_height_m) else 0.0
        self.ground_offset = min(max(ground, 0.0), cfg.ground_height_max_m)
        self.target_height = self.h + self.ground_offset
        self.band = (self.h - cfg.alt_tol_m, self.target_height + cfg.alt_tol_m)
        self.failed_stage = STAGE_NONE
        self.fail_msg = ''
        self.result = None
        self.pending = None           # request kind waiting for its ack
        self.nack = None              # (kind, text) of a refused request
        self.land_attempts = 0
        self.max_height = self.target_height
        self.t_armed = None
        self.t_last_fresh = now
        self.stable_since = None
        self.descent_alerted = False
        self.cancel_requested = False
        self.op_phase = 'takeoff' if op == OP_TAKEOFF else 'land'   # 'ground': disarm cleanup
        self._enter(STAGE_SET_GUIDED if op == OP_TAKEOFF else STAGE_SET_LAND, now)

    # ------------------------------------------------------------------ API

    @property
    def stage_name(self):
        return STAGE_NAMES[self.stage]

    @property
    def done(self):
        return self.result is not None

    @property
    def landing(self):
        return self.op_phase == 'land'

    def ack(self, kind, ok, text=''):
        if self.pending != kind:
            return
        self.pending = None
        if not ok:
            self.nack = (kind, text)

    def cancel(self):
        """True if accepted. A landing cannot be cancelled from ROS (only by the pilot)."""
        if self.done:
            return False
        if self.landing:
            return False
        self.cancel_requested = True
        return True

    def step(self, now, o):
        if self.done:
            return Step(stream=None, stage=self.stage, result=self.result)
        if o.fresh:
            self.t_last_fresh = now
            if math.isfinite(o.height_m):
                self.max_height = max(self.max_height, o.height_m)
        s = self._step(now, o)
        s.stage = self.stage
        if self.result is not None:
            s.result = self.result
        return s

    # ------------------------------------------------------------------ internals

    def _enter(self, stage, now):
        self.stage = stage
        self.t_stage = now
        self.sent = False
        self.nack = None
        self.pending = None

    def _elapsed(self, now):
        return now - self.t_stage

    def _send(self, kind, arg):
        self.sent = True
        self.pending = kind
        return Step(request=(kind, arg))

    def _finish(self, o, success, message, failed_stage=None):
        if not success and self.failed_stage == STAGE_NONE:
            self.failed_stage = self.stage if failed_stage is None else failed_stage
        if not success and self.fail_msg and message != self.fail_msg:
            message = f'{self.fail_msg}; {message}'
        self.result = Result(success, STAGE_NONE if success else self.failed_stage, message,
                             bool(o.armed), int(o.landed_state), float(o.height_m))
        return Step(stream=None, detail=message)

    def _fail_to_land(self, now, o, message):
        """Takeoff failed after arming: land (the drone may have left the ground)."""
        if self.failed_stage == STAGE_NONE:
            self.failed_stage = self.stage
            self.fail_msg = message
        self.op_phase = 'land'
        self._enter(STAGE_SET_LAND, now)
        return Step(detail=f'{message}: LAND')

    def _fail_to_disarm(self, now, o, message):
        """Failure while still on the ground before the takeoff command: disarm."""
        if self.failed_stage == STAGE_NONE:
            self.failed_stage = self.stage
            self.fail_msg = message
        if not o.armed:
            return self._finish(o, False, message)
        self.op_phase = 'ground'
        self._enter(STAGE_DISARM, now)
        return Step(detail=f'{message}: disarming on the ground')

    def _nack_text(self):
        kind, text = self.nack
        return f'{kind} refused by the FCU' + (f': {text}' if text else '')

    def _step(self, now, o):
        cfg = self.cfg
        if o.override:
            return self._finish(o, False, 'override: the pilot/FCU took control, the Pi sends '
                                          'nothing')
        if not o.fresh:
            if now - self.t_last_fresh > cfg.telemetry_lost_s:
                if self.stage in (STAGE_SET_GUIDED, STAGE_ARM) and not self.t_armed:
                    return self._finish(o, False, 'telemetry lost before arming')
                if self.landing:
                    return self._finish(o, False, 'LAND in progress, telemetry lost: cannot '
                                                  'confirm touchdown or disarm')
                # armed and blind: ask for LAND once (an FCU mode, it completes on its own)
                self.failed_stage = self.stage if self.failed_stage == STAGE_NONE \
                    else self.failed_stage
                self.result = Result(False, self.failed_stage,
                                     'telemetry lost while armed: LAND requested blind, the '
                                     'pilot must confirm', True, LANDED_UNDEFINED, math.nan)
                return Step(request=(SET_MODE, 'LAND'), stream=None)
            return Step(stream=SILENT if self.stage != STAGE_STABILIZE else HOLD,
                        detail='waiting for telemetry')
        return getattr(self, f'_stage_{self.stage_name.lower()}')(now, o)

    # ---- takeoff

    def _stage_set_guided(self, now, o):
        if o.armed:
            return self._finish(o, False, 'vehicle already armed: TAKEOFF only starts disarmed '
                                          'on the ground')
        if self.cancel_requested:
            return self._finish(o, False, 'cancelled before arming')
        if o.mode == 'GUIDED':
            self._enter(STAGE_ARM, now)
            return self._stage_arm(now, o)
        if self.nack:
            return self._finish(o, False, self._nack_text())
        if not self.sent:
            return self._send(SET_MODE, 'GUIDED')
        if self._elapsed(now) > self.cfg.set_mode_timeout_s:
            return self._finish(o, False, f'mode is still {o.mode} after '
                                          f'{self.cfg.set_mode_timeout_s:.0f} s, not GUIDED')
        return Step(detail=f'waiting for GUIDED (mode {o.mode})')

    def _stage_arm(self, now, o):
        if o.mode != 'GUIDED':
            if o.armed:
                return self._fail_to_disarm(now, o, f'mode changed to {o.mode} while arming')
            return self._finish(o, False, f'mode changed to {o.mode} before arming')
        if o.armed:
            self.t_armed = now
            if self.cancel_requested:
                return self._fail_to_disarm(now, o, 'cancelled')
            self._enter(STAGE_TAKEOFF_CMD, now)
            return self._stage_takeoff_cmd(now, o)
        if self.cancel_requested:
            return self._finish(o, False, 'cancelled before arming')
        if self.nack:
            return self._finish(o, False, self._nack_text())
        if not self.sent:
            return self._send(ARM, True)
        if self._elapsed(now) > self.cfg.arm_timeout_s:
            # no retry loop; if the arm shows up late, the next op (or the pilot) disarms
            return self._finish(o, False, f'not armed after {self.cfg.arm_timeout_s:.0f} s')
        return Step(detail='waiting for the FCU to arm')

    def _stage_takeoff_cmd(self, now, o):
        cfg = self.cfg
        if o.mode != 'GUIDED' or not o.armed:
            return self._finish(o, False, f'vehicle left GUIDED/armed before takeoff (mode '
                                          f'{o.mode}, armed {o.armed})')
        if self.cancel_requested and not self.sent:
            return self._fail_to_disarm(now, o, 'cancelled')
        if not self.sent:
            if now - self.t_armed > cfg.max_arm_to_takeoff_s:
                return self._fail_to_disarm(now, o, 'takeoff could not be sent within '
                                                    f'{cfg.max_arm_to_takeoff_s:.0f} s of arming')
            return self._send(TAKEOFF, self.h)
        if self.nack:
            return self._fail_to_disarm(now, o, self._nack_text())
        climbing = o.landed_state in (LANDED_TAKEOFF, LANDED_IN_AIR) or (
            math.isfinite(o.height_m)
            and o.height_m > self.ground_offset + cfg.climb_start_m)
        if climbing:
            self._enter(STAGE_CLIMB, now)
            return self._stage_climb(now, o)
        if self.cancel_requested or o.safety_abort:
            return self._fail_to_land(now, o, 'cancelled' if self.cancel_requested
                                      else f'safety abort: {o.abort_reason}')
        if self._elapsed(now) > cfg.takeoff_start_timeout_s:
            return self._fail_to_land(now, o, f'no climb within '
                                              f'{cfg.takeoff_start_timeout_s:.0f} s of the '
                                              'takeoff command')
        return Step(detail='takeoff sent, waiting for the climb to start')

    def _airborne_checks(self, now, o):
        if o.mode != 'GUIDED':
            return self._finish(o, False, f'mode changed to {o.mode} during takeoff')
        if not o.armed:
            return self._finish(o, False, 'disarmed during takeoff')
        if o.safety_abort:
            return self._fail_to_land(now, o, f'safety abort: {o.abort_reason}')
        if self.cancel_requested:
            return self._fail_to_land(now, o, 'cancelled')
        return None

    def _stage_climb(self, now, o):
        cfg = self.cfg
        bad = self._airborne_checks(now, o)
        if bad:
            return bad
        if math.isfinite(o.height_m) and o.height_m >= self.band[0]:
            self._enter(STAGE_STABILIZE, now)
            return self._stage_stabilize(now, o)
        limit = self.h / cfg.min_climb_rate_mps + 5.0
        if self._elapsed(now) > limit:
            return self._fail_to_land(now, o, f'climb timeout: height {o.height_m:.2f} m '
                                              f'after {limit:.0f} s (needs '
                                              f'{self.band[0]:.2f} m)')
        return Step(detail=f'climbing: {o.height_m:.2f} / {self.band[0]:.2f} m')

    def _stage_stabilize(self, now, o):
        cfg = self.cfg
        bad = self._airborne_checks(now, o)
        if bad:
            return bad
        problems = []
        if not math.isfinite(o.height_m) or not self.band[0] <= o.height_m <= self.band[1]:
            problems.append(f'height {o.height_m:.2f} m (expected {self.band[0]:.2f}-'
                            f'{self.band[1]:.2f})')
        if not math.isfinite(o.vz_mps) or abs(o.vz_mps) >= cfg.stable_max_vz_mps:
            problems.append(f'vz {o.vz_mps:.2f} m/s')
        if not math.isfinite(o.vxy_mps) or o.vxy_mps >= cfg.stable_max_vxy_mps:
            problems.append(f'horizontal {o.vxy_mps:.2f} m/s')
        if not o.flow_ok:
            problems.append('flow not healthy for flight')
        if not o.ekf_ok:
            problems.append('EKF not healthy')
        if problems:
            self.stable_since = None
        elif self.stable_since is None:
            self.stable_since = now
        if self.stable_since is not None and now - self.stable_since >= cfg.stable_window_s:
            return self._finish(o, True, f'hovering at {o.height_m:.2f} m '
                                         f'({self.h:.2f} m above the takeoff point)')
        if self._elapsed(now) > cfg.stable_timeout_s:
            return self._fail_to_land(now, o, 'not stable after '
                                              f'{cfg.stable_timeout_s:.0f} s: '
                                              + ', '.join(problems))
        return Step(stream=HOLD, detail='stabilizing: ' + (', '.join(problems) or 'stable'))

    # ---- land

    def _stage_set_land(self, now, o):
        cfg = self.cfg
        if not o.armed:
            if _on_ground(cfg, o) or o.landed_state == LANDED_UNDEFINED:
                return self._land_done(o)
            return self._finish(o, False, 'disarmed but not confirmed on the ground')
        if o.mode == 'LAND':
            self._enter(STAGE_DESCEND, now)
            return self._stage_descend(now, o)
        if self.nack or (self.sent and self._elapsed(now) > cfg.land_mode_timeout_s):
            self.land_attempts += 1
            if self.land_attempts >= 2:
                return self._finish(o, False, 'LAND NOT ACCEPTED: take manual control')
            self._enter(STAGE_SET_LAND, now)
        if not self.sent:
            return self._send(SET_MODE, 'LAND')
        return Step(detail=f'waiting for LAND (mode {o.mode})')

    def _stage_descend(self, now, o):
        cfg = self.cfg
        if o.mode != 'LAND' and o.armed:
            return self._finish(o, False, f'mode changed to {o.mode} during LAND')
        if not o.armed:
            if _on_ground(cfg, o) or o.landed_state == LANDED_UNDEFINED:
                return self._land_done(o)
            return self._finish(o, False, 'disarmed before touchdown was confirmed')
        if _on_ground(cfg, o):
            self._enter(STAGE_TOUCHDOWN, now)
            return Step(detail='touchdown: waiting for ArduPilot to disarm')
        limit = self.max_height / cfg.min_descent_rate_mps + 10.0
        detail = f'descending: {o.height_m:.2f} m'
        if self._elapsed(now) > limit:
            detail = (f'LAND slower than expected ({self._elapsed(now):.0f} s): still in LAND, '
                      f'{o.height_m:.2f} m. Watch it; take over if needed')
        return Step(detail=detail)

    def _stage_touchdown(self, now, o):
        cfg = self.cfg
        if not o.armed:
            return self._land_done(o)
        if o.mode != 'LAND':
            return self._finish(o, False, f'mode changed to {o.mode} after touchdown')
        if not _on_ground(cfg, o):
            self._enter(STAGE_DESCEND, now)
            return Step(detail='bounced: back to descending')
        if self._elapsed(now) > cfg.disarm_wait_s:
            self._enter(STAGE_DISARM, now)
            return self._stage_disarm(now, o)
        return Step(detail='touchdown: waiting for ArduPilot to disarm')

    def _stage_disarm(self, now, o):
        cfg = self.cfg
        ground_phase = self.op_phase == 'ground'
        if not o.armed:
            if ground_phase:
                return self._finish(o, False, 'disarmed on the ground')
            return self._land_done(o)
        if not _on_ground(cfg, o) and not ground_phase:
            self._enter(STAGE_DESCEND, now)
            return Step(detail='not on the ground any more: back to descending')
        if self.nack:
            return self._finish(o, False, f'{self._nack_text()}: the operator must disarm')
        if not self.sent:
            return self._send(ARM, False)
        if self._elapsed(now) > cfg.disarm_wait_s:
            return self._finish(o, False, 'still armed after the disarm request: the operator '
                                          'must disarm')
        return Step(detail='disarm requested (on the ground)')

    def _land_done(self, o):
        if self.failed_stage != STAGE_NONE:
            return self._finish(o, False, 'landed and disarmed')
        return self._finish(o, True, 'landed and disarmed (confirmed by the FCU)')
