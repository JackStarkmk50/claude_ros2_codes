"""Optical-flow health, judged from what the FCU reports (fusion itself runs in EKF3).

Pure logic: the node feeds samples and asks for a verdict; `now` is a steady-clock time in s.
"""

import math
from dataclasses import dataclass


@dataclass(frozen=True)
class FlowConfig:
    timeout_s: float = 0.5
    min_quality: int = 100
    quality_samples: int = 5
    min_height_m: float = 0.3
    max_height_m: float = 3.0


@dataclass(frozen=True)
class FlowVerdict:
    source_seen: bool
    age_s: float
    fresh: bool
    quality: int
    quality_ok: bool
    quality_applies: bool
    flow_rate_x_rad_s: float
    flow_rate_y_rad_s: float
    ground_distance_m: float
    in_valid_height_band: bool
    healthy_for_flight: bool
    healthy_for_takeoff: bool
    reason: str


class FlowHealth:

    def __init__(self, config):
        self.cfg = config
        self._last_time = None
        self._quality = 0
        self._rate = (math.nan, math.nan)
        self._ground_distance = math.nan
        self._good_run = 0

    def add_sample(self, quality, rate_x, rate_y, ground_distance, now):
        """One OPTICAL_FLOW message. ground_distance < 0 means 'not provided'."""
        self._last_time = now
        self._quality = int(quality)
        self._rate = (float(rate_x), float(rate_y))
        self._ground_distance = float(ground_distance) if ground_distance >= 0.0 else math.nan
        # quality must hold for N consecutive samples; one bad sample restarts the count
        self._good_run = self._good_run + 1 if quality >= self.cfg.min_quality else 0

    def evaluate(self, now, height_m, height_valid, ekf_attitude_ok, ekf_velocity_ok):
        """Verdict. height_* is the rangefinder; ekf_* already include EKF freshness."""
        cfg = self.cfg
        seen = self._last_time is not None
        age = now - self._last_time if seen else math.inf
        fresh = age < cfg.timeout_s
        quality_ok = seen and self._good_run >= cfg.quality_samples
        quality_applies = height_valid and height_m >= cfg.min_height_m
        in_band = height_valid and cfg.min_height_m <= height_m <= cfg.max_height_m

        flight_causes = []
        takeoff_causes = []
        if not seen:
            flight_causes.append('no OPTICAL_FLOW from the FCU')
        elif not fresh:
            flight_causes.append(f'flow stale ({age:.1f} s)')
        takeoff_causes.extend(flight_causes)
        if not height_valid:
            flight_causes.append('rangefinder invalid')
            takeoff_causes.append('rangefinder invalid')
        elif height_m < cfg.min_height_m:
            flight_causes.append(f'height {height_m:.2f} m below flow band')
        elif height_m > cfg.max_height_m:
            flight_causes.append(f'height {height_m:.2f} m above flow band')
        if seen and not quality_ok:
            if self._quality < cfg.min_quality:
                flight_causes.append(f'quality {self._quality} < {cfg.min_quality}')
            else:
                flight_causes.append(
                    f'quality recovering ({self._good_run}/{cfg.quality_samples})')
        if not ekf_velocity_ok:
            flight_causes.append('EKF horizontal velocity not ok')
        if not ekf_attitude_ok:
            takeoff_causes.append('EKF attitude not ok')

        causes = list(dict.fromkeys(flight_causes + takeoff_causes))
        return FlowVerdict(
            source_seen=seen,
            age_s=age,
            fresh=fresh,
            quality=self._quality,
            quality_ok=quality_ok,
            quality_applies=quality_applies,
            flow_rate_x_rad_s=self._rate[0],
            flow_rate_y_rad_s=self._rate[1],
            ground_distance_m=self._ground_distance,
            in_valid_height_band=in_band,
            healthy_for_flight=not flight_causes,
            healthy_for_takeoff=not takeoff_causes,
            reason='; '.join(causes),
        )
