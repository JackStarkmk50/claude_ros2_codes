"""Frame helpers. ROS REP-103: ENU world (yaw 0 = East, counter-clockwise positive), FLU body.

MAVROS already converts ArduPilot's NED/FRD to ENU/FLU on its standard topics, so our code
never converts between NED and ENU; it only reads angles out of ENU quaternions.
"""

import math


def quaternion_to_euler(x, y, z, w):
    """(roll, pitch, yaw) in rad, ZYX order, from an ENU/FLU orientation quaternion."""
    sinr_cosp = 2.0 * (w * x + y * z)
    cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(sinr_cosp, cosr_cosp)
    sinp = 2.0 * (w * y - z * x)
    pitch = math.copysign(math.pi / 2.0, sinp) if abs(sinp) >= 1.0 else math.asin(sinp)
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    yaw = math.atan2(siny_cosp, cosy_cosp)
    return roll, pitch, yaw


def wrap_pi(angle):
    """Angle wrapped to [-pi, pi)."""
    return (angle + math.pi) % (2.0 * math.pi) - math.pi


def enu_yaw_to_compass_deg(yaw_enu):
    """ENU yaw (0 = East, CCW +) to a compass heading in degrees (0 = North, CW +), [0, 360)."""
    return (90.0 - math.degrees(yaw_enu)) % 360.0


def tilt_rad(roll, pitch):
    """Angle between body up-axis and world up-axis."""
    return math.acos(max(-1.0, min(1.0, math.cos(roll) * math.cos(pitch))))
