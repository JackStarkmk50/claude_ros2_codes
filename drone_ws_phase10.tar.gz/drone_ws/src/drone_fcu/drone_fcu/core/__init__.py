"""Pure-Python logic for drone_fcu (no ROS imports), unit-tested in drone_fcu/test."""
