"""Pre-arm and RC-link verdicts from SYS_STATUS sensor bits and RC_CHANNELS."""

MAV_SYS_STATUS_SENSOR_RC_RECEIVER = 0x10000
MAV_SYS_STATUS_PREARM_CHECK = 0x10000000


def prearm_ok(sensors_present, sensors_health):
    """ArduPilot's own pre-arm result. False if the FCU does not report the bit."""
    bit = MAV_SYS_STATUS_PREARM_CHECK
    return bool(sensors_present & bit and sensors_health & bit)


def rc_present(channels, sys_status_bits=None):
    """RC link usable: channel values in a plausible PWM range, and, when SYS_STATUS is
    fresh and reports an RC receiver, ArduPilot does not flag it unhealthy (radio failsafe).

    sys_status_bits: (sensors_present, sensors_health), or None if SYS_STATUS is stale.
    A receiver whose own failsafe holds the last values looks present to ArduPilot too;
    only the receiver's failsafe setting ("no pulses") can fix that.
    """
    if not any(900 <= ch <= 2100 for ch in channels):
        return False
    if sys_status_bits is not None:
        present, health = sys_status_bits
        bit = MAV_SYS_STATUS_SENSOR_RC_RECEIVER
        if present & bit and not health & bit:
            return False
    return True
