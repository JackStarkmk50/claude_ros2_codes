"""What fcu_command_node streams to the FCU each tick (ARCHITECTURE §11.1 L3, §11.6).

SILENT  = send nothing (not our turn: disarmed, not GUIDED, override, link lost)
HOLD    = zero velocity, zero yaw rate
COMMAND = the validated command from safety_supervisor

The node then publishes the decision to MAVROS only if output_enabled; in bench mode it only
reports what it WOULD send. `now` values are ages in seconds.
"""

import math
from dataclasses import dataclass

SILENT = 'SILENT'
HOLD = 'HOLD'
COMMAND = 'COMMAND'

LEVEL_HOLD = 2
LEVEL_OVERRIDE = 4
LANDED_ON_GROUND = 1
MODE_BODY_VELOCITY = 1


@dataclass(frozen=True)
class SetpointConfig:
    cmd_timeout_s: float = 0.3
    safety_stale_s: float = 0.5
    safety_stale_land_s: float = 1.0
    vehicle_timeout_s: float = 1.0


@dataclass(frozen=True)
class Decision:
    action: str
    reason: str
    vx: float = 0.0
    vy: float = 0.0
    vz: float = 0.0
    yaw_rate: float = 0.0
    request_land: bool = False   # safety lost while airborne (LAND is executed from Phase 8)


def decide(cfg, vehicle, vehicle_age, safety, safety_age, cmd, cmd_age):
    # the last OVERRIDE we heard stays in force even if safety_supervisor then dies
    if safety is not None and safety.level == LEVEL_OVERRIDE:
        return Decision(SILENT, 'override: pilot/FCU has authority')
    if vehicle is None or vehicle_age > cfg.vehicle_timeout_s or not vehicle.connected:
        return Decision(SILENT, 'no fresh vehicle state (the FCU GUIDED timeout covers this)')
    if not vehicle.armed:
        return Decision(SILENT, 'disarmed')
    if vehicle.mode != 'GUIDED':
        return Decision(SILENT, f'mode {vehicle.mode}, not GUIDED')

    airborne = vehicle.landed_state != LANDED_ON_GROUND
    if safety is None or safety_age > cfg.safety_stale_s:
        land = airborne and safety_age > cfg.safety_stale_land_s
        return Decision(HOLD, f'safety status stale ({safety_age:.1f} s)', request_land=land)
    if safety.level >= LEVEL_HOLD or not safety.motion_allowed:
        return Decision(HOLD, f'safety level {safety.level}')
    if cmd is None or cmd_age > cfg.cmd_timeout_s:
        return Decision(HOLD, 'no fresh validated command')
    values = (cmd.vx_mps, cmd.vy_mps, cmd.vz_mps, cmd.yaw_rate_rad_s)
    if cmd.mode != MODE_BODY_VELOCITY or not all(math.isfinite(x) for x in values):
        return Decision(HOLD, 'validated command is HOLD')
    return Decision(COMMAND, 'validated command', *values)
