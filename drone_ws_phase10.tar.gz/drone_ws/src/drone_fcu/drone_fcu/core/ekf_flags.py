"""Interpretation of ArduPilot's EKF_STATUS_REPORT flags (EKF_STATUS_FLAGS enum)."""

from dataclasses import dataclass

ATTITUDE = 1
VELOCITY_HORIZ = 2
VELOCITY_VERT = 4
POS_HORIZ_REL = 8
POS_HORIZ_ABS = 16
POS_VERT_ABS = 32
POS_VERT_AGL = 64
CONST_POS_MODE = 128
PRED_POS_HORIZ_REL = 256
PRED_POS_HORIZ_ABS = 512
UNINITIALIZED = 1024
GPS_GLITCHING = 32768

FLAG_NAMES = [
    (ATTITUDE, 'attitude'), (VELOCITY_HORIZ, 'vel_horiz'), (VELOCITY_VERT, 'vel_vert'),
    (POS_HORIZ_REL, 'pos_horiz_rel'), (POS_HORIZ_ABS, 'pos_horiz_abs'),
    (POS_VERT_ABS, 'pos_vert_abs'), (POS_VERT_AGL, 'pos_vert_agl'),
    (CONST_POS_MODE, 'const_pos_mode'), (PRED_POS_HORIZ_REL, 'pred_pos_horiz_rel'),
    (PRED_POS_HORIZ_ABS, 'pred_pos_horiz_abs'), (UNINITIALIZED, 'uninitialized'),
    (GPS_GLITCHING, 'gps_glitching'),
]


@dataclass(frozen=True)
class EkfHealth:
    attitude_ok: bool
    velocity_horiz_ok: bool
    pos_horiz_rel_ok: bool
    const_pos_mode: bool


def evaluate(flags, on_ground):
    """Health from raw flags.

    On the ground ArduPilot may only report a *predicted* relative position
    (PRED_POS_HORIZ_REL) until it has moved; that counts as ok while on the ground.
    """
    initialized = not flags & UNINITIALIZED
    pos_rel = bool(flags & POS_HORIZ_REL) or (on_ground and bool(flags & PRED_POS_HORIZ_REL))
    return EkfHealth(
        attitude_ok=initialized and bool(flags & ATTITUDE),
        velocity_horiz_ok=initialized and bool(flags & VELOCITY_HORIZ),
        pos_horiz_rel_ok=initialized and pos_rel,
        const_pos_mode=bool(flags & CONST_POS_MODE),
    )


def describe(flags):
    """'attitude|vel_horiz|...' for logs and diagnostics."""
    return '|'.join(name for bit, name in FLAG_NAMES if flags & bit) or 'none'
