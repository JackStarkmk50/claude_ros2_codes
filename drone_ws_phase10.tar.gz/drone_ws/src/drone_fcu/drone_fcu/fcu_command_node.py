"""fcu_command_node: the single output from the Pi to the flight controller.

1. Setpoints (Phase 6/7). Every tick (10 Hz) it decides what the FCU should get
   (drone_fcu/core/setpoint.py): nothing, HOLD (zero velocity) or the command safety_supervisor
   validated. Setpoints go only to /mavros/setpoint_raw/local, only while armed in GUIDED, and
   only if output_enabled. With output_enabled false (bench mode, the default) the publisher to
   MAVROS is never created; the node reports what it WOULD send on /drone/fcu/output_state.

2. Flight operations (Phase 8), internal action /drone/fcu/execute_operation. Only
   safety_supervisor calls it, after its own checks. TAKEOFF: GUIDED -> arm -> takeoff ->
   climb -> stable hover. LAND: LAND mode -> touchdown -> ArduPilot disarms. Each step is
   confirmed from the state the FCU reports (drone_fcu/core/operations.py). TAKEOFF also needs
   allow_arming. While an operation runs, the operation decides the setpoint stream (silent
   during ArduPilot's own climb, HOLD while it checks the hover, silent during LAND).

3. If safety_supervisor goes silent while airborne and nothing else is running, this node
   starts a LAND by itself.

4. Indoor, without GPS, ArduPilot has no EKF origin and refuses to arm in GUIDED ("waiting for
   home"). With output enabled, this node sets a fixed origin once the FCU link is up
   (ekf_origin_* parameters). ArduPilot ignores it if an origin already exists.
"""

import math
import threading
import time

import rclpy
from geographic_msgs.msg import GeoPointStamped
from mavros_msgs.msg import PositionTarget, StatusText
from mavros_msgs.srv import CommandBool, CommandTOL, SetMode
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup, ReentrantCallbackGroup
from rclpy.executors import ExternalShutdownException, MultiThreadedExecutor
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy, qos_profile_sensor_data
from rclpy.time import Time
from std_msgs.msg import String

from drone_fcu.core import operations as ops
from drone_fcu.core.setpoint import COMMAND, HOLD, SILENT, Decision, SetpointConfig, decide
from drone_interfaces.action import FlightOperation
from drone_interfaces.msg import ControlCommand, FlowStatus, SafetyStatus, VehicleState

# Parameter defaults. drone_bringup/config/drone.yaml overrides them.
PARAMETERS = {
    'output_enabled': False,          # [AIRCRAFT] launch arg enable_fcu_output
    'allow_arming': False,            # [AIRCRAFT] launch arg allow_arming: TAKEOFF allowed
    'rate_hz': 10.0,
    'cmd_timeout_s': 0.3,
    'safety_stale_s': 0.5,
    'safety_stale_land_s': 1.0,
    'vehicle_timeout_s': 1.0,
    # flight operations
    'set_mode_timeout_s': 3.0,
    'land_mode_timeout_s': 2.0,
    'arm_timeout_s': 3.0,
    'takeoff_start_timeout_s': 5.0,
    'max_arm_to_takeoff_s': 2.0,
    'min_climb_rate_mps': 0.2,
    'alt_tol_m': 0.15,
    'stable_window_s': 2.0,
    'stable_timeout_s': 8.0,
    'stable_max_vz_mps': 0.15,
    'stable_max_vxy_mps': 0.2,
    'min_descent_rate_mps': 0.1,
    'disarm_wait_s': 5.0,
    'ground_height_max_m': 0.25,
    # EKF origin for GPS-less GUIDED (0/0 = not configured: nothing is sent)
    'set_ekf_origin': True,
    'ekf_origin_lat_deg': 0.0,
    'ekf_origin_lon_deg': 0.0,
    'ekf_origin_alt_m': 0.0,
}
OP_FIELDS = set(ops.OpConfig.__dataclass_fields__)

# velocity + yaw rate only: ignore position, acceleration and yaw angle
TYPE_MASK = (PositionTarget.IGNORE_PX | PositionTarget.IGNORE_PY | PositionTarget.IGNORE_PZ
             | PositionTarget.IGNORE_AFX | PositionTarget.IGNORE_AFY | PositionTarget.IGNORE_AFZ
             | PositionTarget.IGNORE_YAW)

STATE_QOS = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                       durability=DurabilityPolicy.VOLATILE)
SAFETY_QOS = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                        durability=DurabilityPolicy.TRANSIENT_LOCAL)
SETPOINT_QOS = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                          durability=DurabilityPolicy.VOLATILE)

LEVEL_ABORT = 3
LEVEL_OVERRIDE = 4
STATUSTEXT_KEEP_S = 5.0


class Latest:

    def __init__(self):
        self.msg = None
        self.time = None

    def set(self, msg):
        self.msg = msg
        self.time = time.monotonic()

    def age(self, now):
        return now - self.time if self.time is not None else float('inf')


class FcuCommandNode(Node):

    def __init__(self):
        super().__init__('fcu_command_node')
        for name, default in PARAMETERS.items():
            self.declare_parameter(name, default)
        p = {name: self.get_parameter(name).value for name in PARAMETERS}
        self.p = p
        self.cfg = SetpointConfig(
            cmd_timeout_s=p['cmd_timeout_s'], safety_stale_s=p['safety_stale_s'],
            safety_stale_land_s=p['safety_stale_land_s'],
            vehicle_timeout_s=p['vehicle_timeout_s'])
        self.op_cfg = ops.OpConfig(**{k: v for k, v in p.items() if k in OP_FIELDS})

        self.lock = threading.RLock()
        self.op = None                # running ops.Operation
        self.op_goal = None           # its goal handle (None when started by this node)
        self.op_step = None           # last ops.Step
        self.statustexts = []         # (monotonic time, text)
        self.origin_sent = 0
        self.origin_last = None
        self.link_up_time = None

        self.vehicle = Latest()
        self.safety = Latest()
        self.command = Latest()
        self.flow = Latest()
        tick_group = MutuallyExclusiveCallbackGroup()
        self.cb_group = ReentrantCallbackGroup()
        self.create_subscription(VehicleState, '/drone/vehicle_state', self._on_vehicle,
                                 STATE_QOS, callback_group=tick_group)
        self.create_subscription(FlowStatus, '/drone/flow_status', self.flow.set, STATE_QOS,
                                 callback_group=tick_group)
        self.create_subscription(SafetyStatus, '/drone/safety_status', self._on_safety,
                                 SAFETY_QOS, callback_group=tick_group)
        self.create_subscription(ControlCommand, '/drone/control/validated_command',
                                 self.command.set, STATE_QOS, callback_group=tick_group)
        self.create_subscription(StatusText, '/mavros/statustext/recv', self._on_statustext,
                                 qos_profile_sensor_data, callback_group=tick_group)
        self.state_pub = self.create_publisher(String, '/drone/fcu/output_state', 10)

        self.setpoint_pub = None
        self.origin_pub = None
        if p['output_enabled']:
            self.setpoint_pub = self.create_publisher(
                PositionTarget, '/mavros/setpoint_raw/local', SETPOINT_QOS)
            self.get_logger().warn(
                '[AIRCRAFT] output_enabled=true: setpoints and LAND WILL be sent to the FCU. '
                'Props off unless the phase says otherwise.')
            if p['set_ekf_origin']:
                if self._origin_configured():
                    self.origin_pub = self.create_publisher(
                        GeoPointStamped, '/mavros/global_position/set_gp_origin', 10)
                else:
                    self.get_logger().warn(
                        'ekf_origin_lat_deg/lon_deg not set in drone.yaml: no EKF origin is '
                        'sent. Without GPS, ArduPilot will not arm in GUIDED.')
        else:
            self.get_logger().info('bench mode: output_enabled=false, nothing is sent to MAVROS')
        if p['allow_arming']:
            if p['output_enabled']:
                self.get_logger().warn(
                    '[AIRCRAFT] allow_arming=true: this node may ARM and TAKE OFF when '
                    'safety_supervisor approves a TAKEOFF.')
            else:
                self.get_logger().warn('allow_arming=true has no effect without output_enabled')

        self.mode_client = self.create_client(SetMode, '/mavros/set_mode',
                                              callback_group=self.cb_group)
        self.arm_client = self.create_client(CommandBool, '/mavros/cmd/arming',
                                             callback_group=self.cb_group)
        self.takeoff_client = self.create_client(CommandTOL, '/mavros/cmd/takeoff',
                                                 callback_group=self.cb_group)
        self.action_server = ActionServer(
            self, FlightOperation, '/drone/fcu/execute_operation',
            execute_callback=self._execute, goal_callback=self._goal_cb,
            cancel_callback=self._cancel_cb, callback_group=self.cb_group)

        self._last_report = None
        self._land_reported = False
        self.create_timer(1.0 / p['rate_hz'], self._tick, callback_group=tick_group)

    # ---------------------------------------------------------------- inputs

    def _on_vehicle(self, msg):
        self.vehicle.set(msg)
        if msg.connected and self.link_up_time is None:
            self.link_up_time = time.monotonic()
        elif not msg.connected:
            self.link_up_time = None
            self.origin_sent = 0

    def _on_safety(self, msg):
        # TRANSIENT_LOCAL hands us the last status even if it is old: judge age by its stamp
        age = (self.get_clock().now() - Time.from_msg(msg.header.stamp)).nanoseconds
        if age * 1e-9 < self.cfg.safety_stale_s:
            self.safety.set(msg)

    def _on_statustext(self, msg):
        now = time.monotonic()
        self.statustexts = [(t, s) for t, s in self.statustexts
                            if now - t < STATUSTEXT_KEEP_S] + [(now, msg.text)]

    def _recent_fcu_text(self):
        now = time.monotonic()
        texts = [s for t, s in self.statustexts if now - t < 3.0]
        return ' | '.join(texts[-3:])

    # ---------------------------------------------------------------- EKF origin

    def _origin_configured(self):
        lat, lon = self.p['ekf_origin_lat_deg'], self.p['ekf_origin_lon_deg']
        return (abs(lat) > 1e-6 or abs(lon) > 1e-6) and abs(lat) <= 90 and abs(lon) <= 180

    def _maybe_send_origin(self, now):
        """Three tries after the link comes up, then again whenever ArduPilot says it waits
        for home/origin (at most every 5 s). Harmless if an origin is already set."""
        if self.origin_pub is None or self.link_up_time is None:
            return
        v = self.vehicle.msg
        if v is None or v.armed:
            return
        text = v.last_prearm_text.lower()
        waiting = 'home' in text or 'origin' in text
        due_initial = (self.origin_sent < 3
                       and now - self.link_up_time > 2.0 + 5.0 * self.origin_sent)
        due_waiting = waiting and (self.origin_last is None or now - self.origin_last > 5.0)
        if not (due_initial or due_waiting):
            return
        msg = GeoPointStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.position.latitude = float(self.p['ekf_origin_lat_deg'])
        msg.position.longitude = float(self.p['ekf_origin_lon_deg'])
        msg.position.altitude = float(self.p['ekf_origin_alt_m'])
        self.origin_pub.publish(msg)
        self.origin_sent += 1
        self.origin_last = now
        self.get_logger().info(
            f'EKF origin sent ({msg.position.latitude:.4f}, {msg.position.longitude:.4f})'
            + (': ArduPilot still waits for home/origin' if waiting else ''))

    # ---------------------------------------------------------------- operations

    def _goal_cb(self, goal):
        with self.lock:
            if self.op is not None:
                self.get_logger().warn('operation refused: another one is running')
                return GoalResponse.REJECT
        if not self.p['output_enabled']:
            self.get_logger().warn('operation refused: bench mode (output_enabled=false)')
            return GoalResponse.REJECT
        if goal.op == FlightOperation.Goal.OP_TAKEOFF and not self.p['allow_arming']:
            self.get_logger().warn('TAKEOFF refused: allow_arming=false')
            return GoalResponse.REJECT
        if goal.op not in (FlightOperation.Goal.OP_TAKEOFF, FlightOperation.Goal.OP_LAND):
            return GoalResponse.REJECT
        return GoalResponse.ACCEPT

    def _cancel_cb(self, goal_handle):
        with self.lock:
            if self.op is not None and self.op_goal is goal_handle and self.op.cancel():
                self.get_logger().warn('TAKEOFF cancelled: landing if already armed')
                return CancelResponse.ACCEPT
        return CancelResponse.REJECT

    def _start_op(self, op_kind, altitude, source, goal_handle=None):
        v = self.vehicle.msg
        start_h = v.height_above_ground_m if v is not None and v.height_valid else math.nan
        with self.lock:
            if self.op is not None:
                return False
            self.op = ops.Operation(self.op_cfg, op_kind, time.monotonic(), altitude_m=altitude,
                                    start_height_m=start_h, source=source)
            self.op_goal = goal_handle
            self.op_step = None
        name = 'TAKEOFF' if op_kind == ops.OP_TAKEOFF else 'LAND'
        self.get_logger().warn(f'[AIRCRAFT] {name} started (source {source}'
                               + (f', {altitude:.2f} m' if op_kind == ops.OP_TAKEOFF else '')
                               + ')')
        return True

    def _execute(self, goal_handle):
        g = goal_handle.request
        if not self._start_op(g.op, g.altitude_m, g.source, goal_handle):
            goal_handle.abort()
            return self._result(None, 'another operation is running')
        with self.lock:
            op = self.op
        feedback = FlightOperation.Feedback()
        while rclpy.ok() and not op.done:
            step = self.op_step
            v = self.vehicle.msg
            feedback.stage = op.stage
            feedback.height_m = float(v.height_above_ground_m) if v is not None else math.nan
            feedback.elapsed_in_stage_s = float(time.monotonic() - op.t_stage)
            feedback.detail = step.detail if step is not None else ''
            goal_handle.publish_feedback(feedback)
            time.sleep(0.1)
        result = op.result
        with self.lock:
            if self.op is op:
                self.op = None
                self.op_goal = None
        if result is not None and result.success:
            goal_handle.succeed()
        elif goal_handle.is_cancel_requested:
            goal_handle.canceled()
        else:
            goal_handle.abort()
        return self._result(result, '' if result is not None else 'node shutting down')

    def _result(self, r, message):
        res = FlightOperation.Result()
        if r is None:
            v = self.vehicle.msg
            res.success = False
            res.failed_stage = ops.STAGE_NONE
            res.message = message
            res.armed_at_end = bool(v.armed) if v is not None else False
            res.landed_state_at_end = int(v.landed_state) if v is not None else 0
            res.height_at_end_m = float(v.height_above_ground_m) if v is not None else math.nan
            return res
        res.success = r.success
        res.failed_stage = r.failed_stage
        res.message = r.message
        res.armed_at_end = r.armed_at_end
        res.landed_state_at_end = r.landed_state_at_end
        res.height_at_end_m = r.height_at_end_m
        return res

    def _obs(self, now):
        v = self.vehicle.msg
        fresh = (v is not None and self.vehicle.age(now) <= self.cfg.vehicle_timeout_s
                 and v.connected)
        s = self.safety.msg
        s_age = self.safety.age(now)
        o = ops.Obs(fresh=fresh)
        if v is not None:
            o.armed, o.mode, o.landed_state = v.armed, v.mode, v.landed_state
            o.height_m = v.height_above_ground_m if v.height_valid else math.nan
            if v.velocity_valid:
                o.vz_mps = v.velocity_body_flu.z
                o.vxy_mps = math.hypot(v.velocity_body_flu.x, v.velocity_body_flu.y)
            o.ekf_ok = (v.ekf_attitude_ok and v.ekf_velocity_horiz_ok and v.ekf_pos_horiz_rel_ok
                        and not v.ekf_const_pos_mode)
        f = self.flow.msg
        o.flow_ok = (f is not None and self.flow.age(now) <= self.cfg.vehicle_timeout_s
                     and f.healthy_for_flight)
        if s is not None and s.level == LEVEL_OVERRIDE:
            o.override = True
        if s is None or s_age > self.cfg.safety_stale_s:
            o.safety_abort, o.abort_reason = True, f'safety status stale ({s_age:.1f} s)'
        elif s.level >= LEVEL_ABORT:
            o.safety_abort = True
            o.abort_reason = ', '.join(s.active_faults) or 'ABORT'
        return o

    def _run_op(self, now):
        """Step the running operation. Returns the stream it wants, or None for normal."""
        with self.lock:
            op = self.op
        if op is None or op.done:
            return None
        step = op.step(now, self._obs(now))
        self.op_step = step
        if step.request is not None:
            self._send_request(op, *step.request)
        if step.result is not None:
            r = step.result
            text = (f'{"TAKEOFF" if op.op == ops.OP_TAKEOFF else "LAND"} '
                    f'{"OK" if r.success else "FAILED at " + ops.STAGE_NAMES[r.failed_stage]}'
                    f': {r.message}')
            if r.success:
                self.get_logger().info(text)
            else:
                self.get_logger().error(text)
            with self.lock:
                if self.op_goal is None and self.op is op:
                    self.op = None       # started by this node: nobody waits for the result
            return None
        return step.stream

    def _send_request(self, op, kind, arg):
        self.get_logger().warn(f'[AIRCRAFT] {op.stage_name}: request {kind} {arg}')
        if kind == ops.SET_MODE:
            client, req = self.mode_client, SetMode.Request(custom_mode=str(arg))
        elif kind == ops.ARM:
            client, req = self.arm_client, CommandBool.Request(value=bool(arg))
        else:
            client = self.takeoff_client
            req = CommandTOL.Request(min_pitch=0.0, yaw=0.0, latitude=0.0, longitude=0.0,
                                     altitude=float(arg))
        if not client.service_is_ready():
            op.ack(kind, False, f'MAVROS service {client.srv_name} not available')
            return
        future = client.call_async(req)

        def done(fut):
            try:
                resp = fut.result()
            except Exception as exc:  # noqa: BLE001
                op.ack(kind, False, str(exc))
                return
            if kind == ops.SET_MODE:
                ok = bool(resp.mode_sent)
            else:
                ok = bool(resp.success) and int(resp.result) == 0
            text = '' if ok else (f'result {getattr(resp, "result", "?")} '
                                  f'{self._recent_fcu_text()}').strip()
            if not ok:
                self.get_logger().error(f'{kind} {arg} refused: {text}')
            op.ack(kind, ok, text)
        future.add_done_callback(done)

    # ---------------------------------------------------------------- tick

    def _tick(self):
        now = time.monotonic()
        self._maybe_send_origin(now)
        d = decide(self.cfg, self.vehicle.msg, self.vehicle.age(now), self.safety.msg,
                   self.safety.age(now), self.command.msg, self.command.age(now))

        # safety_supervisor lost while airborne: land by ourselves (nothing else running)
        if d.request_land and self.op is None and self.setpoint_pub is not None:
            self._start_op(ops.OP_LAND, 0.0, 'fcu_command_node (safety_supervisor lost)')

        stream = self._run_op(now)
        op = self.op
        if stream is not None and op is not None:
            if stream == ops.SILENT:
                d = Decision(SILENT, f'operation {op.stage_name}')
            elif d.action != SILENT:
                d = Decision(HOLD, f'operation {op.stage_name}')

        if d.action != SILENT and self.setpoint_pub is not None:
            sp = PositionTarget()
            sp.header.stamp = self.get_clock().now().to_msg()
            sp.coordinate_frame = PositionTarget.FRAME_BODY_NED   # MAVROS: body FLU in
            sp.type_mask = TYPE_MASK
            sp.velocity.x, sp.velocity.y, sp.velocity.z = d.vx, d.vy, d.vz
            sp.yaw_rate = d.yaw_rate
            self.setpoint_pub.publish(sp)

        prefix = '' if self.setpoint_pub is not None or d.action == SILENT else 'WOULD SEND '
        text = f'{prefix}{d.action}: {d.reason}'
        if d.action == COMMAND:
            text += (f' (vx {d.vx:.2f} vy {d.vy:.2f} vz {d.vz:.2f} m/s, '
                     f'yaw_rate {d.yaw_rate:.3f} rad/s FLU)')
        step = self.op_step
        if op is not None and step is not None and step.detail:
            text += f' | {step.detail}'
        if d.request_land:
            if self.setpoint_pub is None:
                text += (' | LAND needed: safety_supervisor lost while airborne (bench mode: '
                         'nothing sent, the pilot must land)')
            if not self._land_reported:
                self.get_logger().error('safety_supervisor lost while airborne: LAND')
                self._land_reported = True
        else:
            self._land_reported = False
        self.state_pub.publish(String(data=text))

        # log when the kind of decision changes (numbers in the reason don't count)
        key = (d.action, d.reason.split('(')[0], d.request_land)
        if key != self._last_report:
            self.get_logger().info(text)
            self._last_report = key


def main(args=None):
    rclpy.init(args=args)
    node = FcuCommandNode()
    executor = MultiThreadedExecutor(num_threads=4)
    executor.add_node(node)
    try:
        executor.spin()
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        # A second Ctrl-C during cleanup (terminal + launch both send SIGINT) must not
        # print a traceback.
        try:
            executor.shutdown()
            node.destroy_node()
            rclpy.try_shutdown()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
