# drone_fcu

FCU layer: aggregates Pixhawk/ArduPilot state from MAVROS and is the only package that sends commands to MAVROS.

See `ARCHITECTURE.md` (§3 nodes, §4 topics, §5 services, §6 actions) for the full contract of this package.

| Executable | Responsibility | Implemented in |
|---|---|---|
| `fcu_state_node` | Aggregates MAVROS telemetry, EKF and optical-flow health into VehicleState and FlowStatus. | Phase 4 (done) |
| `fcu_command_node` | The single output to MAVROS: validated setpoints and verified flight operations. | Phase 6 setpoint path, Phase 8 flight operations (TAKEOFF/LAND) and EKF origin |

`fcu_state_node` publishes `/drone/vehicle_state` and `/drone/flow_status` at 10 Hz and
`/diagnostics` at 1 Hz. It is read-only towards the aircraft, except that it asks the FCU for
telemetry rates (MAV_CMD_SET_MESSAGE_INTERVAL, FCU RAM only) on every (re)connect.
EKF_STATUS_REPORT, OPTICAL_FLOW and DISTANCE_SENSOR are decoded from `/uas1/mavlink_source`, using
only frames from the autopilot itself (`fcu_sysid` / `fcu_compid`).

The logic lives in `drone_fcu/core/` (no ROS imports, unit-tested): `mavlink_decode.py`,
`ekf_flags.py`, `flow_health.py`, `frames.py`, `link_monitor.py`.

`fcu_command_node` decides every tick (10 Hz) between SILENT, HOLD and the validated command
(`core/setpoint.py`) and reports it on `/drone/fcu/output_state`. It publishes to
`/mavros/setpoint_raw/local` only while armed in GUIDED **and** with `output_enabled:=true`;
in bench mode the MAVROS publisher is never created.

Run one node on its own:

```bash
ros2 run drone_fcu fcu_state_node --ros-args --params-file $(ros2 pkg prefix drone_bringup)/share/drone_bringup/config/drone.yaml
```

Test:

```bash
colcon test --packages-select drone_fcu && colcon test-result --verbose
```
