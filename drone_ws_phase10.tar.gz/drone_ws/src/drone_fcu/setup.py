from setuptools import find_packages, setup

package_name = 'drone_fcu'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml', 'README.md']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Moganesan',
    maintainer_email='ht.moganesan@gmail.com',
    description=(
        'FCU layer: aggregates Pixhawk/ArduPilot state from MAVROS and is the only '
        'package that sends commands to MAVROS.'
    ),
    license='MIT',
    extras_require={'test': ['pytest']},
    entry_points={
        'console_scripts': [
            'fcu_state_node = drone_fcu.fcu_state_node:main',
            'fcu_command_node = drone_fcu.fcu_command_node:main',
        ],
    },
)
