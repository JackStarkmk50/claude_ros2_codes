import math

from helpers import CFG, command, flying_vehicle, ground_vehicle
from drone_safety.core.gate import DROP, HOLD, PASS, CommandGate


def run(gate, cmd, now=0.0, age=0.05, level=0, latched=False, vehicle=None, fresh=True, op=False):
    return gate.process(cmd, age, now, level, latched, vehicle or flying_vehicle(), fresh, op)


def test_valid_yaw_command_passes():
    r = run(CommandGate(CFG), command(yaw=0.05))
    assert r.action == PASS and math.isclose(r.yaw_rate, 0.05)


def test_level_and_latch_give_hold():
    assert run(CommandGate(CFG), command(), level=2).action == HOLD
    assert run(CommandGate(CFG), command(), latched=True).action == HOLD
    assert run(CommandGate(CFG), command(), level=1).action == PASS   # DEGRADED still moves


def test_source_seq_age_numbers_mode_are_dropped():
    g = CommandGate(CFG)
    assert run(g, command(source='llm')).action == DROP
    assert run(g, command(seq=5)).action == PASS
    assert run(g, command(seq=5)).action == DROP                     # replay
    assert run(g, command(seq=6), age=0.4).action == DROP             # stale
    assert run(g, command(seq=7, max_age=0.1), age=0.15).action == DROP
    assert run(g, command(seq=8, yaw=math.nan)).action == DROP
    assert run(g, command(seq=9, mode=7)).action == DROP


def test_hold_when_not_flying_in_guided():
    g = CommandGate(CFG)
    assert run(g, command(seq=1), vehicle=ground_vehicle(armed=True, mode='GUIDED')).action \
        == HOLD
    assert run(g, command(seq=2), vehicle=flying_vehicle(mode='LOITER')).action == HOLD
    assert run(g, command(seq=3), fresh=False).action == HOLD
    assert run(g, command(seq=4), op=True).action == HOLD


def test_translation_locked_and_yaw_clamped():
    g = CommandGate(CFG)
    r = None
    for i in range(1, 40):      # ramp up through the accel limit
        r = run(g, command(seq=i, yaw=5.0, vx=1.0), now=i * 0.1)
    assert r.vx == 0.0 and r.clamped
    assert math.isclose(r.yaw_rate, math.radians(30.0))


def test_yaw_acceleration_limit():
    g = CommandGate(CFG)
    r = run(g, command(seq=1, yaw=0.5), now=0.0)
    assert math.isclose(r.yaw_rate, math.radians(60.0) * 0.1)        # one 0.1 s step from 0
    r = run(g, command(seq=2, yaw=0.5), now=0.1)
    assert math.isclose(r.yaw_rate, 2 * math.radians(60.0) * 0.1)


def test_turn_right_sign_is_kept():
    # ROS FLU: turning right = negative yaw rate; the gate must not flip signs
    r = run(CommandGate(CFG), command(yaw=-0.05))
    assert r.yaw_rate < 0


def test_invalid_commands_are_dropped_even_during_hold():
    # a foreign or broken command must never look like a live mission stream
    g = CommandGate(CFG)
    assert run(g, command(source='someone_else'), level=2).action == DROP
    assert run(g, command(yaw=math.nan), level=2).action == DROP


def test_ground_test_switch_only_on_the_ground():
    from drone_safety.core.config import SafetyConfig
    on_ground = ground_vehicle(armed=True, mode='GUIDED')
    assert run(CommandGate(CFG), command(), vehicle=on_ground).action == HOLD
    cfg = SafetyConfig(bench_ground_test=True)
    assert run(CommandGate(cfg), command(), vehicle=on_ground).action == PASS
    taking_off = ground_vehicle(armed=True, mode='GUIDED', landed_state=3)
    assert run(CommandGate(cfg), command(), vehicle=taking_off).action == HOLD


def test_ground_test_never_passes_translation():
    from drone_safety.core.config import SafetyConfig
    cfg = SafetyConfig(bench_ground_test=True, max_horizontal_speed_mps=1.0,
                       max_vertical_speed_mps=1.0)
    c = command()
    c.vx_mps = c.vy_mps = c.vz_mps = 0.5
    r = run(CommandGate(cfg), c, vehicle=ground_vehicle(armed=True, mode='GUIDED'))
    assert r.action == PASS and (r.vx, r.vy, r.vz) == (0.0, 0.0, 0.0)
