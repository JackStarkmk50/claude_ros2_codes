"""Test fixtures: VehicleState / FlowStatus / ControlCommand look-alikes."""

import math
from types import SimpleNamespace as NS

from drone_safety.core.config import SafetyConfig

CFG = SafetyConfig(takeoff_min_voltage=15.6, battery_warn_v=14.4, battery_land_v=14.0)


def ground_vehicle(**kw):
    """Disarmed on the floor, everything healthy: pre-flight should pass (with output on)."""
    base = dict(connected=True, heartbeat_age_s=0.3, armed=False, guided=False,
                mode='STABILIZE', system_status=3, landed_state=1, fcu_prearm_ok=True,
                last_prearm_text='', rc_present=True, battery_voltage_v=16.4,
                battery_current_a=0.5, battery_remaining=math.nan, roll_rad=0.01,
                pitch_rad=-0.01, yaw_rad=0.0, velocity_valid=True, local_position_valid=True,
                height_above_ground_m=0.14, height_valid=True, ekf_flags=0x16f,
                ekf_attitude_ok=True, ekf_velocity_horiz_ok=True, ekf_pos_horiz_rel_ok=True,
                ekf_const_pos_mode=False, ekf_velocity_variance=0.1,
                ekf_pos_horiz_variance=0.1, ekf_age_s=0.3)
    base.update(kw)
    return NS(**base)


def flying_vehicle(**kw):
    base = dict(armed=True, guided=True, mode='GUIDED', system_status=4, landed_state=2,
                height_above_ground_m=1.2, battery_voltage_v=15.5)
    base.update(kw)
    return ground_vehicle(**base)


def flow(healthy_flight=True, healthy_takeoff=True, reason=''):
    return NS(healthy_for_flight=healthy_flight, healthy_for_takeoff=healthy_takeoff,
              reason=reason)


def command(seq=1, yaw=0.2, source='mission_manager', mode=1, vx=0.0, max_age=0.3):
    return NS(source=source, seq=seq, mode=mode, vx_mps=vx, vy_mps=0.0, vz_mps=0.0,
              yaw_rate_rad_s=yaw, max_age_s=max_age)
