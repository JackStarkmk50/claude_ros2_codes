"""Every executable module imports cleanly and exposes main()."""


def test_node_modules_import():
    from drone_safety import safety_supervisor  # noqa: F401
    assert callable(safety_supervisor.main)
