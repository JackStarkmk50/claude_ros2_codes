from drone_safety.core.override import OverrideDetector


def test_pilot_mode_switch_after_engaged():
    d = OverrideDetector()
    assert d.update(True, 'GUIDED', 2) is None
    assert 'LOITER' in d.update(True, 'LOITER', 2)


def test_not_engaged_until_armed_in_guided():
    d = OverrideDetector()
    assert d.update(True, 'LOITER', 2) is None      # the pilot flies; the Pi is not driving
    assert d.update(False, 'GUIDED', 1) is None     # disarmed in GUIDED: not engaged


def test_disarm_in_the_air():
    d = OverrideDetector()
    d.update(True, 'GUIDED', 2)
    assert 'disarmed' in d.update(False, 'GUIDED', 2)


def test_normal_disarm_on_the_ground():
    d = OverrideDetector()
    d.update(True, 'GUIDED', 1)
    assert d.update(False, 'GUIDED', 1) is None


def test_expected_land_is_not_an_override():
    d = OverrideDetector()
    d.update(True, 'GUIDED', 2)
    d.expected_extra.add('LAND')
    assert d.update(True, 'LAND', 4) is None


def test_empty_mode_during_link_glitch_is_ignored():
    d = OverrideDetector()
    d.update(True, 'GUIDED', 2)
    assert d.update(True, '', 2) is None
