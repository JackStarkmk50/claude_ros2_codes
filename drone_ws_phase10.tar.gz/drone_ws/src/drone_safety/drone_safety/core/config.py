"""Safety limits. Read once at startup; they cannot change while the node runs."""

import math
from dataclasses import dataclass, field

LEVEL_OK, LEVEL_DEGRADED, LEVEL_HOLD, LEVEL_ABORT, LEVEL_OVERRIDE = range(5)
LEVEL_NAMES = ['OK', 'DEGRADED', 'HOLD', 'ABORT', 'OVERRIDE']

LANDED_UNDEFINED, LANDED_ON_GROUND, LANDED_IN_AIR, LANDED_TAKEOFF, LANDED_LANDING = range(5)
MAV_STATE_STANDBY = 3


@dataclass(frozen=True)
class SafetyConfig:
    # link and freshness
    telemetry_timeout_s: float = 1.0
    heartbeat_timeout_s: float = 2.0
    ekf_timeout_s: float = 2.0
    # command gate
    max_yaw_rate_deg_s: float = 30.0
    max_yaw_accel_deg_s2: float = 60.0
    max_horizontal_speed_mps: float = 0.0
    max_vertical_speed_mps: float = 0.0
    max_cmd_age_s: float = 0.3
    allowed_sources: tuple = ('mission_manager', 'operator')
    # heights and attitude
    min_height_m: float = 0.5
    max_height_m: float = 2.0
    hard_ceiling_m: float = 2.2
    ceiling_margin_m: float = 0.5
    min_takeoff_alt_m: float = 0.8
    max_takeoff_alt_m: float = 1.5
    ground_height_max_m: float = 0.25
    max_tilt_deg: float = 25.0
    preflight_max_tilt_deg: float = 5.0
    # battery (0 = not configured: pre-flight fails on purpose)
    takeoff_min_voltage: float = 0.0
    takeoff_min_remaining: float = 0.3
    battery_warn_v: float = 0.0
    battery_land_v: float = 0.0
    # timing of in-flight reactions
    flow_bad_timeout_s: float = 1.0
    hold_to_land_s: float = 5.0
    # misc
    require_rc_present: bool = True
    allow_auto_land: bool = True
    cpu_temp_warn_c: float = 75.0
    cpu_temp_fault_c: float = 82.0
    allowed_pretakeoff_modes: tuple = ('STABILIZE', 'ALT_HOLD', 'LOITER', 'GUIDED')
    autonomy_modes: tuple = field(default=('GUIDED',))
    # [AIRCRAFT] Phase 7 props-off test only: let commands through while armed ON THE GROUND
    bench_ground_test: bool = False

    @property
    def max_yaw_rate_rad_s(self):
        return math.radians(self.max_yaw_rate_deg_s)

    @property
    def max_yaw_accel_rad_s2(self):
        return math.radians(self.max_yaw_accel_deg_s2)


def finite(*values):
    return all(isinstance(x, (int, float)) and math.isfinite(x) for x in values)
