"""Pre-flight validation (ARCHITECTURE §11.3). Every failing check is listed, not just the first.

PF11 (request source) and PF12 (altitude limits) belong to a takeoff request:
takeoff_request_failures(), checked when one arrives. PF15 (perception ready) is added with the mission (Phase 12).
"""

import math

from drone_safety.core.config import (LANDED_ON_GROUND, LANDED_UNDEFINED, LEVEL_DEGRADED,
                                      MAV_STATE_STANDBY, finite)


def preflight_failures(cfg, v, v_age, flow, flow_age, level, latched, fcu_output):
    """List of 'PFn NAME: detail' strings; empty means ready to take off.

    v / flow: last VehicleState / FlowStatus (or None); *_age: seconds since received.
    level / latched: current safety verdict. fcu_output: (output_enabled, allow_arming) as
    read from fcu_command_node, or None if it could not be read.
    """
    fails = []
    if v is None or v_age > cfg.telemetry_timeout_s:
        fails.append('PF1 LINK: no fresh vehicle state (is fcu_state_node running?)')
        return fails
    if not v.connected or v.heartbeat_age_s > cfg.heartbeat_timeout_s:
        fails.append(f'PF1 LINK: FCU not connected (heartbeat age {v.heartbeat_age_s:.1f} s)')
        return fails

    if not v.mode or v.system_status != MAV_STATE_STANDBY or not finite(v.roll_rad, v.pitch_rad):
        fails.append(f'PF2 STATE: incomplete or not STANDBY (mode "{v.mode}", '
                     f'system_status {v.system_status})')

    on_ground = v.landed_state == LANDED_ON_GROUND or (
        v.landed_state == LANDED_UNDEFINED and v.height_valid
        and v.height_above_ground_m < cfg.ground_height_max_m)
    if v.armed:
        fails.append('PF3 GROUND: vehicle is armed')
    if not on_ground:
        fails.append(f'PF3 GROUND: not confirmed on the ground (landed_state {v.landed_state})')

    if not v.fcu_prearm_ok:
        fails.append('PF4 FCU_PREARM: ArduPilot pre-arm checks not passing'
                     + (f' ({v.last_prearm_text})' if v.last_prearm_text else ''))
    elif v.last_prearm_text:
        fails.append(f'PF4 FCU_PREARM: {v.last_prearm_text}')

    if cfg.takeoff_min_voltage <= 0.0:
        fails.append('PF5 BATTERY: takeoff_min_voltage not configured')
    elif not finite(v.battery_voltage_v) or v.battery_voltage_v < cfg.takeoff_min_voltage:
        fails.append(f'PF5 BATTERY: {v.battery_voltage_v:.2f} V < {cfg.takeoff_min_voltage:.2f} V')
    if finite(v.battery_remaining) and v.battery_remaining < cfg.takeoff_min_remaining:
        fails.append(f'PF5 BATTERY: {v.battery_remaining:.0%} remaining < '
                     f'{cfg.takeoff_min_remaining:.0%}')

    ekf_bad = [name for name, ok in (('attitude', v.ekf_attitude_ok),
                                     ('velocity', v.ekf_velocity_horiz_ok),
                                     ('position', v.ekf_pos_horiz_rel_ok)) if not ok]
    if v.ekf_const_pos_mode:
        ekf_bad.append('const_pos_mode')
    if not v.ekf_age_s < cfg.ekf_timeout_s:
        ekf_bad.append(f'stale {v.ekf_age_s:.1f} s')
    if ekf_bad:
        fails.append(f'PF6 EKF: {", ".join(ekf_bad)}')

    if flow is None or flow_age > cfg.telemetry_timeout_s:
        fails.append('PF7 FLOW: no fresh flow status')
    elif not flow.healthy_for_takeoff:
        fails.append(f'PF7 FLOW: {flow.reason or "not healthy for takeoff"}')
    if not v.height_valid:
        fails.append('PF7 FLOW: rangefinder invalid')
    elif v.height_above_ground_m >= cfg.ground_height_max_m:
        fails.append(f'PF7 FLOW: height {v.height_above_ground_m:.2f} m >= on-ground limit '
                     f'{cfg.ground_height_max_m:.2f} m')

    max_tilt = math.radians(cfg.preflight_max_tilt_deg)
    if finite(v.roll_rad, v.pitch_rad) and (abs(v.roll_rad) > max_tilt
                                            or abs(v.pitch_rad) > max_tilt):
        fails.append(f'PF8 LEVEL: roll {math.degrees(v.roll_rad):.1f}, pitch '
                     f'{math.degrees(v.pitch_rad):.1f} deg > {cfg.preflight_max_tilt_deg} deg')

    if v.mode not in cfg.allowed_pretakeoff_modes:
        fails.append(f'PF9 MODE: {v.mode} is not an allowed pre-takeoff mode')

    if level > LEVEL_DEGRADED or latched:
        fails.append('PF10 SAFETY: active fault' + (' (latched, needs reset)' if latched else ''))

    if fcu_output is None:
        fails.append('PF13 OUTPUT: fcu_command_node not reachable')
    elif not all(fcu_output):
        fails.append(f'PF13 OUTPUT: bench mode (output_enabled={fcu_output[0]}, '
                     f'allow_arming={fcu_output[1]})')

    if cfg.bench_ground_test:
        fails.append('PF13 OUTPUT: bench_ground_test is on (props-off ground test only)')

    if cfg.require_rc_present and not v.rc_present:
        fails.append('PF14 RC: no RC link (pilot override not available)')
    return fails


def takeoff_request_failures(cfg, altitude_m, source):
    """PF11 / PF12 for one TAKEOFF request."""
    fails = []
    if source not in cfg.allowed_sources:
        fails.append(f'PF11 SOURCE: "{source}" is not an allowed source')
    top = min(cfg.max_takeoff_alt_m, cfg.hard_ceiling_m - cfg.ceiling_margin_m)
    if not finite(altitude_m) or not cfg.min_takeoff_alt_m <= altitude_m <= top:
        fails.append(f'PF12 ALTITUDE: {altitude_m} m outside {cfg.min_takeoff_alt_m:.2f}-'
                     f'{top:.2f} m')
    return fails
