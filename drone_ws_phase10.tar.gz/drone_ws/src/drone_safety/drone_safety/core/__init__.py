"""Pure-Python safety logic (no ROS imports), unit-tested in drone_safety/test.

Inputs are the ROS messages themselves (VehicleState, FlowStatus, ControlCommand) or anything
with the same attribute names, so tests can use simple namespaces.
"""
