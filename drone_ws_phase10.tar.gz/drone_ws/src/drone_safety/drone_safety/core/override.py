"""Pilot / FCU override detection (ARCHITECTURE §11.6).

The Pi is 'engaged' once it has seen the vehicle armed in a mode the Pi drives (GUIDED, or LAND
while the Pi runs a landing). From then on, any other mode, or a disarm in the air, means a
person or an ArduPilot failsafe took authority: OVERRIDE, latched until reset on the ground.
"""

from drone_safety.core.config import LANDED_ON_GROUND


class OverrideDetector:

    def __init__(self, autonomy_modes=('GUIDED',)):
        self.autonomy_modes = set(autonomy_modes)
        self.expected_extra = set()     # e.g. {'LAND'} while the Pi itself runs a landing
        self.engaged = False
        self._last_armed = None
        self._last_landed = None

    def update(self, armed, mode, landed_state):
        """Reason string when an override happens now, else None."""
        allowed = self.autonomy_modes | self.expected_extra
        reason = None
        if armed and mode in allowed:
            self.engaged = True
        elif self.engaged and armed and mode and mode not in allowed:
            reason = f'mode changed to {mode} (not requested by the Pi)'
        elif (self.engaged and self._last_armed and not armed
              and self._last_landed != LANDED_ON_GROUND):
            reason = 'disarmed while not on the ground (pilot kill or FCU disarm)'
        if not armed:
            self.engaged = False
        self._last_armed = armed
        self._last_landed = landed_state
        return reason
