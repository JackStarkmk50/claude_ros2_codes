"""safety_supervisor: the veto between the mission and the flight controller.

  * health checks and safety level (drone_safety/core/supervisor.py), published on
    /drone/safety_status at 20 Hz (TRANSIENT_LOCAL, so late joiners get the current verdict)
  * pre-flight validation PF1-PF14 (core/preflight.py), also on /drone/safety/preflight_check
  * pilot / FCU override detection (core/override.py), latched
  * command gate (core/gate.py): /drone/control/command -> /drone/control/validated_command
  * /drone/safety/reset: clears latched faults, only disarmed on the ground
  * Phase 8: the public flight-operation gate /drone/flight/operation (TAKEOFF, LAND). TAKEOFF
    is re-checked right now (PF1-PF14, plus source and altitude); LAND is never blocked by
    health faults, only refused when disarmed, during an OVERRIDE, or while another operation
    runs. Approved operations go to fcu_command_node (/drone/fcu/execute_operation).
  * Phase 8: ABORT in the air -> this node requests LAND itself (allow_auto_land).
"""

import math
import threading
import time

import rclpy
from rcl_interfaces.srv import GetParameters
from rclpy.action import ActionClient, ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup, ReentrantCallbackGroup
from rclpy.executors import ExternalShutdownException, MultiThreadedExecutor
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from rclpy.time import Time
from std_srvs.srv import Trigger

from drone_interfaces.action import FlightOperation
from drone_interfaces.msg import ControlCommand, FlowStatus, SafetyStatus, VehicleState
from drone_safety.core.config import (LANDED_ON_GROUND, LEVEL_NAMES, LEVEL_OVERRIDE,
                                      SafetyConfig)
from drone_safety.core.gate import DROP, HOLD, PASS, CommandGate
from drone_safety.core.preflight import takeoff_request_failures
from drone_safety.core.supervisor import Inputs, SafetyCore

# Parameter defaults. drone_bringup/config/drone.yaml overrides them. Read once at startup:
# the limits cannot be changed while the node runs.
PARAMETERS = {
    'rate_hz': 20.0,
    'telemetry_timeout_s': 1.0,
    'heartbeat_timeout_s': 2.0,
    'ekf_timeout_s': 2.0,
    'max_yaw_rate_deg_s': 30.0,
    'max_yaw_accel_deg_s2': 60.0,
    'max_horizontal_speed_mps': 0.0,
    'max_vertical_speed_mps': 0.0,
    'max_cmd_age_s': 0.3,
    'min_takeoff_alt_m': 0.8,
    'max_takeoff_alt_m': 1.5,
    'hard_ceiling_m': 2.2,
    'ceiling_margin_m': 0.5,
    'min_height_m': 0.5,
    'max_height_m': 2.0,
    'ground_height_max_m': 0.25,
    'max_tilt_deg': 25.0,
    'preflight_max_tilt_deg': 5.0,
    'takeoff_min_voltage': 0.0,
    'takeoff_min_remaining': 0.3,
    'battery_warn_v': 0.0,
    'battery_land_v': 0.0,
    'flow_bad_timeout_s': 1.0,
    'hold_to_land_s': 5.0,
    'require_rc_present': True,
    'allow_auto_land': True,
    'cpu_temp_warn_c': 75.0,
    'cpu_temp_fault_c': 82.0,
    'allowed_sources': ['mission_manager', 'operator'],
    'allowed_pretakeoff_modes': ['STABILIZE', 'ALT_HOLD', 'LOITER', 'GUIDED'],
    'bench_ground_test': False,       # [AIRCRAFT] launch arg bench_ground_test (Phase 7 only)
}
CONFIG_FIELDS = set(SafetyConfig.__dataclass_fields__)
CPU_TEMP_FILE = '/sys/class/thermal/thermal_zone0/temp'

IN_QOS = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                    durability=DurabilityPolicy.VOLATILE)
CMD_QOS = QoSProfile(depth=10, reliability=ReliabilityPolicy.RELIABLE,
                     durability=DurabilityPolicy.VOLATILE)
STATUS_QOS = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                        durability=DurabilityPolicy.TRANSIENT_LOCAL)

OP_NAMES = {FlightOperation.Goal.OP_TAKEOFF: 'TAKEOFF', FlightOperation.Goal.OP_LAND: 'LAND'}


class SafetySupervisor(Node):

    def __init__(self):
        super().__init__('safety_supervisor')
        for name, default in PARAMETERS.items():
            self.declare_parameter(name, default)
        p = {name: self.get_parameter(name).value for name in PARAMETERS}
        values = {k: (tuple(v) if isinstance(v, list) else v) for k, v in p.items()
                  if k in CONFIG_FIELDS}
        self.cfg = SafetyConfig(**values)
        self.core = SafetyCore(self.cfg)
        self.gate = CommandGate(self.cfg)
        self.lock = threading.RLock()

        self.vehicle = None
        self.vehicle_time = None
        self.flow = None
        self.flow_time = None
        self.last_cmd_time = None
        self.stream_active = False
        self.cpu_temp = math.nan
        self.fcu_output = None
        self.fcu_output_time = None
        self.rejected = 0
        self.clamped = 0
        self.verdict = None
        self._last_level = None
        self._land_logged = False
        self.op_active = None           # 'TAKEOFF' / 'LAND' / 'AUTO_LAND' while one runs
        self._auto_land_last_try = None

        main_group = MutuallyExclusiveCallbackGroup()
        self.op_group = ReentrantCallbackGroup()
        self.create_subscription(VehicleState, '/drone/vehicle_state', self._on_vehicle, IN_QOS,
                                 callback_group=main_group)
        self.create_subscription(FlowStatus, '/drone/flow_status', self._on_flow, IN_QOS,
                                 callback_group=main_group)
        self.create_subscription(ControlCommand, '/drone/control/command', self._on_command,
                                 CMD_QOS, callback_group=main_group)
        self.status_pub = self.create_publisher(SafetyStatus, '/drone/safety_status', STATUS_QOS)
        self.cmd_pub = self.create_publisher(ControlCommand, '/drone/control/validated_command',
                                             IN_QOS)
        self.create_service(Trigger, '/drone/safety/preflight_check', self._srv_preflight,
                            callback_group=main_group)
        self.create_service(Trigger, '/drone/safety/reset', self._srv_reset,
                            callback_group=main_group)
        self.param_client = self.create_client(GetParameters, '/fcu_command_node/get_parameters',
                                               callback_group=self.op_group)
        self.op_server = ActionServer(
            self, FlightOperation, '/drone/flight/operation', execute_callback=self._execute,
            goal_callback=self._goal_cb, cancel_callback=self._cancel_cb,
            callback_group=self.op_group)
        self.fcu_ops = ActionClient(self, FlightOperation, '/drone/fcu/execute_operation',
                                    callback_group=self.op_group)

        self.create_timer(1.0 / p['rate_hz'], self._tick, callback_group=main_group)
        self.create_timer(1.0, self._slow_tick, callback_group=main_group)
        if self.cfg.bench_ground_test:
            self.get_logger().warn(
                '[AIRCRAFT] bench_ground_test=true: yaw commands pass the gate while armed ON '
                'THE GROUND. PROPS OFF. Never use this for flight.')
        self.get_logger().info(
            f'up: yaw limit {self.cfg.max_yaw_rate_deg_s} deg/s, translation limits '
            f'{self.cfg.max_horizontal_speed_mps}/{self.cfg.max_vertical_speed_mps} m/s, '
            f'takeoff {self.cfg.min_takeoff_alt_m}-{self.cfg.max_takeoff_alt_m} m, '
            f'sources {list(self.cfg.allowed_sources)}')

    # ---------------------------------------------------------------- inputs

    def _on_vehicle(self, msg):
        self.vehicle, self.vehicle_time = msg, time.monotonic()

    def _on_flow(self, msg):
        self.flow, self.flow_time = msg, time.monotonic()

    def _inputs(self, now):
        def age(t):
            return now - t if t is not None else math.inf
        fcu_output = self.fcu_output if age(self.fcu_output_time) < 5.0 else None
        # judged only once it has answered at least once (startup order does not matter)
        alive = self.fcu_output_time is None or age(self.fcu_output_time) < 3.5
        return Inputs(vehicle=self.vehicle, vehicle_age=age(self.vehicle_time),
                      flow=self.flow, flow_age=age(self.flow_time),
                      cmd_age=age(self.last_cmd_time), stream_active=self.stream_active,
                      cpu_temp_c=self.cpu_temp, fcu_output=fcu_output,
                      command_node_alive=alive)

    def _slow_tick(self):
        try:
            with open(CPU_TEMP_FILE) as fh:
                self.cpu_temp = int(fh.read().strip()) / 1000.0
        except (OSError, ValueError):
            self.cpu_temp = math.nan
        if self.param_client.service_is_ready():
            req = GetParameters.Request(names=['output_enabled', 'allow_arming'])
            self.param_client.call_async(req).add_done_callback(self._on_fcu_params)

    def _on_fcu_params(self, future):
        try:
            values = future.result().values
            self.fcu_output = (values[0].bool_value, values[1].bool_value)
            self.fcu_output_time = time.monotonic()
        except Exception:  # noqa: BLE001  (node went away: PF13 reports it)
            self.fcu_output = None

    # ---------------------------------------------------------------- verdict

    def _update(self, now):
        with self.lock:
            # while the Pi runs an operation, LAND is a mode the Pi itself asked for
            self.core.override.expected_extra = {'LAND'} if self.op_active else set()
            return self.core.update(now, self._inputs(now))

    def _tick(self):
        now = time.monotonic()
        v = self.vehicle
        if v is None or not v.armed:
            self.stream_active = False
        self.verdict = self._update(now)
        self._publish_status()
        if self.verdict.request_land:
            self._auto_land(now)

    def _publish_status(self):
        vd = self.verdict
        s = SafetyStatus()
        s.header.stamp = self.get_clock().now().to_msg()
        s.level = vd.level
        s.latched = vd.latched
        s.motion_allowed = vd.motion_allowed
        s.preflight_ok = vd.preflight_ok
        s.preflight_failures = vd.preflight_failures
        s.active_faults = vd.active_faults
        s.warnings = vd.warnings
        s.commands_rejected = self.rejected
        s.commands_clamped = self.clamped
        self.status_pub.publish(s)

        if vd.level != self._last_level:
            detail = '; '.join(vd.active_faults + vd.warnings) or 'no faults'
            # (rclpy forbids one log call site with two severities, hence two calls)
            if vd.level <= 1:
                self.get_logger().info(f'safety level {LEVEL_NAMES[vd.level]}: {detail}')
            else:
                self.get_logger().warn(f'safety level {LEVEL_NAMES[vd.level]}: {detail}')
            self._last_level = vd.level

    # ---------------------------------------------------------------- automatic LAND

    def _auto_land(self, now):
        """ABORT while airborne: request LAND (a running TAKEOFF lands by itself)."""
        if self.op_active is not None:
            return
        if not self._land_logged:
            self.get_logger().error('ABORT in the air: requesting LAND ('
                                    + '; '.join(self.verdict.active_faults) + ')')
            self._land_logged = True
        if self._auto_land_last_try is not None and now - self._auto_land_last_try < 1.0:
            return
        self._auto_land_last_try = now
        if not self.fcu_ops.server_is_ready():
            self.get_logger().error('LAND cannot be requested: fcu_command_node not reachable. '
                                    'PILOT: land now', throttle_duration_sec=2.0)
            return
        goal = FlightOperation.Goal(op=FlightOperation.Goal.OP_LAND,
                                    source='safety_supervisor', reason='ABORT')
        with self.lock:
            self.op_active = 'AUTO_LAND'
        future = self.fcu_ops.send_goal_async(goal)
        future.add_done_callback(self._on_auto_land_goal)

    def _on_auto_land_goal(self, future):
        gh = future.result()
        if gh is None or not gh.accepted:
            self.get_logger().error('LAND refused by fcu_command_node (bench mode or another '
                                    'operation running)', throttle_duration_sec=2.0)
            with self.lock:
                self.op_active = None
            return
        gh.get_result_async().add_done_callback(self._on_auto_land_result)

    def _on_auto_land_result(self, future):
        r = future.result().result
        with self.lock:
            self.op_active = None
            self._land_logged = False
        if r.success:
            self.get_logger().warn(f'automatic LAND done: {r.message}')
        else:
            self.get_logger().error(f'automatic LAND failed: {r.message}')

    # ---------------------------------------------------------------- flight operation gate

    def _goal_cb(self, goal):
        name = OP_NAMES.get(goal.op)
        if name is None:
            self.get_logger().warn(f'operation {goal.op} unknown: rejected')
            return GoalResponse.REJECT
        # accepted here so the caller gets the reason in the result; checked in _execute
        return GoalResponse.ACCEPT

    def _cancel_cb(self, goal_handle):
        if goal_handle.request.op == FlightOperation.Goal.OP_LAND:
            self.get_logger().warn('cancel refused: a LAND cannot be cancelled from ROS '
                                   '(the pilot can take over with the mode switch)')
            return CancelResponse.REJECT
        return CancelResponse.ACCEPT

    def _check_request(self, g):
        """List of reasons to refuse this request now; empty = approved."""
        now = time.monotonic()
        verdict = self._update(now)
        v = self.vehicle
        if g.op == FlightOperation.Goal.OP_TAKEOFF:
            return verdict.preflight_failures + takeoff_request_failures(
                self.cfg, g.altitude_m, g.source)
        fails = []
        if g.source not in self.cfg.allowed_sources:
            fails.append(f'source "{g.source}" is not allowed')
        if v is None or now - self.vehicle_time > self.cfg.telemetry_timeout_s:
            fails.append('no fresh vehicle state')
        elif not v.armed:
            fails.append('vehicle is disarmed: nothing to land')
        if verdict.level == LEVEL_OVERRIDE:
            fails.append('OVERRIDE: the pilot has authority, the Pi does not fight them')
        return fails

    def _execute(self, goal_handle):
        g = goal_handle.request
        name = OP_NAMES[g.op]
        result = FlightOperation.Result()
        with self.lock:
            busy = self.op_active
            fails = [f'{busy} already running'] if busy else self._check_request(g)
            if not fails:
                self.op_active = name
        if fails:
            result.success = False
            result.failed_stage = FlightOperation.Result.STAGE_PREFLIGHT
            result.message = f'{name} REFUSED: ' + ' | '.join(fails)
            self.get_logger().warn(result.message)
            goal_handle.abort()
            return result
        self.get_logger().warn(f'[AIRCRAFT] {name} approved (source {g.source}'
                               + (f', {g.altitude_m:.2f} m' if name == 'TAKEOFF' else '')
                               + '): forwarding to fcu_command_node')
        try:
            return self._forward(goal_handle, g, name, result)
        finally:
            with self.lock:
                self.op_active = None

    def _forward(self, goal_handle, g, name, result):
        def fail(message):
            result.success = False
            result.failed_stage = FlightOperation.Result.STAGE_PREFLIGHT
            result.message = f'{name} FAILED: {message}'
            self.get_logger().error(result.message)
            goal_handle.abort()
            return result

        if not self.fcu_ops.wait_for_server(timeout_sec=2.0):
            return fail('fcu_command_node not reachable')
        done = threading.Event()
        box = {}

        def on_feedback(msg):
            goal_handle.publish_feedback(msg.feedback)

        def on_goal(future):
            box['gh'] = future.result()
            if box['gh'] is None or not box['gh'].accepted:
                done.set()
                return
            box['gh'].get_result_async().add_done_callback(on_result)

        def on_result(future):
            box['result'] = future.result().result
            done.set()

        fwd = FlightOperation.Goal(op=g.op, altitude_m=g.altitude_m, source=g.source,
                                   reason=g.reason)
        self.fcu_ops.send_goal_async(fwd, feedback_callback=on_feedback) \
            .add_done_callback(on_goal)
        cancel_sent = False
        while rclpy.ok() and not done.wait(0.1):
            if goal_handle.is_cancel_requested and not cancel_sent and 'gh' in box:
                box['gh'].cancel_goal_async()
                cancel_sent = True
        if 'result' not in box:
            return fail('refused by fcu_command_node (bench mode, allow_arming=false, or '
                        'another operation running)')
        r = box['result']
        if r.success:
            self.get_logger().info(f'{name} OK: {r.message}')
            goal_handle.succeed()
        else:
            self.get_logger().error(f'{name} FAILED: {r.message}')
            if goal_handle.is_cancel_requested:
                goal_handle.canceled()
            else:
                goal_handle.abort()
        return r

    # ---------------------------------------------------------------- command gate

    def _on_command(self, cmd):
        now = time.monotonic()
        if self.verdict is None:
            return
        age = (self.get_clock().now() - Time.from_msg(cmd.header.stamp)).nanoseconds * 1e-9
        vehicle_fresh = (self.vehicle_time is not None
                         and now - self.vehicle_time <= self.cfg.telemetry_timeout_s)
        result = self.gate.process(cmd, age, now, self.verdict.level, self.verdict.latched,
                                   self.vehicle, vehicle_fresh,
                                   op_in_progress=self.op_active is not None)
        if result.action == DROP:
            self.rejected += 1
            self.get_logger().warn(f'command rejected: {result.reason}',
                                   throttle_duration_sec=2.0)
            return
        # a valid command from an allowed source: the mission stream is alive
        self.last_cmd_time = now
        if self.vehicle is not None and self.vehicle.armed \
                and self.vehicle.landed_state != LANDED_ON_GROUND:
            self.stream_active = True

        out = ControlCommand()
        out.header.stamp = self.get_clock().now().to_msg()
        out.source = cmd.source
        out.seq = cmd.seq
        out.max_age_s = self.cfg.max_cmd_age_s
        if result.action == HOLD:
            out.mode = ControlCommand.MODE_HOLD
        else:
            assert result.action == PASS
            out.mode = ControlCommand.MODE_BODY_VELOCITY
            out.vx_mps, out.vy_mps, out.vz_mps = result.vx, result.vy, result.vz
            out.yaw_rate_rad_s = result.yaw_rate
            if result.clamped:
                self.clamped += 1
        self.cmd_pub.publish(out)

    # ---------------------------------------------------------------- services

    def _srv_preflight(self, request, response):
        vd = self._update(time.monotonic())
        response.success = vd.preflight_ok
        response.message = 'PRE-FLIGHT OK' if vd.preflight_ok else \
            'PRE-FLIGHT FAILED: ' + ' | '.join(vd.preflight_failures)
        return response

    def _srv_reset(self, request, response):
        with self.lock:
            ok, message = self.core.reset(time.monotonic(), self._inputs(time.monotonic()))
        response.success = ok
        response.message = message
        if ok:
            self.get_logger().info(f'reset: {message}')
        else:
            self.get_logger().warn(f'reset refused: {message}')
        return response


def main(args=None):
    rclpy.init(args=args)
    node = SafetySupervisor()
    executor = MultiThreadedExecutor(num_threads=4)
    executor.add_node(node)
    try:
        executor.spin()
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        # A second Ctrl-C during cleanup (terminal + launch both send SIGINT) must not
        # print a traceback.
        try:
            executor.shutdown()
            node.destroy_node()
            rclpy.try_shutdown()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
