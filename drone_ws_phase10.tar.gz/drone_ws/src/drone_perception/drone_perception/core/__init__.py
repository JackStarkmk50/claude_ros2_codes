"""Pure-Python perception logic (no ROS imports), unit-tested in test/."""
