"""ONNX Runtime wrapper for a YOLO detect model (CPU). No ROS imports."""

import os
import time

from .yolo_postprocess import decode, letterbox


class YoloModel:
    def __init__(self, path, input_size=320, num_threads=3):
        import onnxruntime as ort
        if not path or not os.path.isfile(path):
            raise FileNotFoundError(f'model file not found: "{path}"')
        opts = ort.SessionOptions()
        opts.intra_op_num_threads = max(1, int(num_threads))
        opts.inter_op_num_threads = 1
        self.session = ort.InferenceSession(path, sess_options=opts,
                                            providers=['CPUExecutionProvider'])
        inp = self.session.get_inputs()[0]
        self.input_name = inp.name
        shape = inp.shape                                   # [1, 3, S, S] or dynamic
        fixed = [d for d in shape[2:] if isinstance(d, int)]
        if fixed and any(d != input_size for d in fixed):
            raise ValueError(f'model expects {shape[2:]} input but input_size is {input_size}: '
                             f'export it with imgsz={input_size} or change input_size')
        self.size = int(input_size)
        out = self.session.get_outputs()[0].shape
        if len(out) != 3 or (isinstance(out[1], int) and out[1] < 5):
            raise ValueError(f'unexpected output shape {out}: expected a YOLOv8/11 detect '
                             f'model [1, 4+classes, N]')

    def detect(self, rgb, conf, iou, allowed_ids=None):
        """(detections, timings dict in ms: pre, infer, post)."""
        t0 = time.perf_counter()
        tensor, lb = letterbox(rgb, self.size)
        t1 = time.perf_counter()
        out = self.session.run(None, {self.input_name: tensor})[0]
        t2 = time.perf_counter()
        dets = decode(out, lb, conf, iou, allowed_ids)
        t3 = time.perf_counter()
        return dets, {'pre': (t1 - t0) * 1e3, 'infer': (t2 - t1) * 1e3, 'post': (t3 - t2) * 1e3}
