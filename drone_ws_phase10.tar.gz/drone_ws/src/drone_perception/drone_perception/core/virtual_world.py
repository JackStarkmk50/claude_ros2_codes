"""Virtual 360 degree room for camera-less tests (tools/fake_camera.py --world)."""

import numpy as np


def wrap_deg(a):
    return (a + 180.0) % 360.0 - 180.0


class World:
    """A textured 360 degree strip plus one person sprite at a bearing."""

    def __init__(self, width, height, hfov_deg, sprite, bearing_deg, seed=7):
        """sprite: HxWx3 RGB already scaled to its on-screen size (or None)."""
        self.w, self.h, self.hfov = width, height, hfov_deg
        self.pano_w = int(round(width * 360.0 / hfov_deg))
        rng = np.random.default_rng(seed)
        blocks = rng.integers(60, 200, size=(height // 40 + 1, self.pano_w // 40 + 1, 3),
                              dtype=np.uint8)
        pano = np.repeat(np.repeat(blocks, 40, axis=0), 40, axis=1)[:height, :self.pano_w]
        self.pano = np.concatenate([pano, pano], axis=1)          # for wrap-around crops
        self.sprite = sprite
        self.bearing = bearing_deg
        self.visible = True

    def render(self, yaw_deg):
        # column of the view centre: bearings grow to the LEFT (CCW), columns to the right
        centre = (-yaw_deg / 360.0 * self.pano_w) % self.pano_w
        x0 = int(round(centre - self.w / 2)) % self.pano_w
        frame = self.pano[:, x0:x0 + self.w].copy()
        if self.sprite is not None and self.visible:
            d = wrap_deg(self.bearing - yaw_deg)                  # + = person to the left
            cx = self.w / 2 - d / self.hfov * self.w
            sh, sw = self.sprite.shape[:2]
            left = int(round(cx - sw / 2))
            top = self.h - sh
            a, b = max(left, 0), min(left + sw, self.w)
            if a < b:
                frame[top:top + sh, a:b] = self.sprite[:, a - left:b - left]
        return frame
