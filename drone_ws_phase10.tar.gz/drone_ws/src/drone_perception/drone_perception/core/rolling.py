"""Rolling-window statistics (rate and mean) on a caller-supplied clock."""

from collections import deque


class Rolling:
    def __init__(self, window_s=5.0):
        self.window = window_s
        self.samples = deque()          # (t, value)

    def add(self, t, value=0.0):
        self.samples.append((t, value))
        self.trim(t)

    def trim(self, now):
        while self.samples and now - self.samples[0][0] > self.window:
            self.samples.popleft()

    def rate(self, now):
        self.trim(now)
        return len(self.samples) / self.window

    def mean(self, now):
        self.trim(now)
        return sum(v for _, v in self.samples) / len(self.samples) if self.samples else float('nan')

    def max(self, now):
        self.trim(now)
        return max((v for _, v in self.samples), default=float('nan'))
