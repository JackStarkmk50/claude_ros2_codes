"""YOLO (v8 / 11 detect, ONNX export) pre- and post-processing. numpy + OpenCV resize only.

Model output: [1, 4 + C, N] with rows cx, cy, w, h (input pixels) then C class scores; no
objectness row, no NMS inside the model (Ultralytics' default ONNX export).
Pre-processing matches Ultralytics: letterbox to a square, grey (114) padding centred, RGB,
0..1, CHW. Boxes are mapped back to ORIGINAL image pixels.
"""

from dataclasses import dataclass

import numpy as np

COCO_CLASSES = (
    'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus', 'train', 'truck', 'boat',
    'traffic light', 'fire hydrant', 'stop sign', 'parking meter', 'bench', 'bird', 'cat', 'dog',
    'horse', 'sheep', 'cow', 'elephant', 'bear', 'zebra', 'giraffe', 'backpack', 'umbrella',
    'handbag', 'tie', 'suitcase', 'frisbee', 'skis', 'snowboard', 'sports ball', 'kite',
    'baseball bat', 'baseball glove', 'skateboard', 'surfboard', 'tennis racket', 'bottle',
    'wine glass', 'cup', 'fork', 'knife', 'spoon', 'bowl', 'banana', 'apple', 'sandwich',
    'orange', 'broccoli', 'carrot', 'hot dog', 'pizza', 'donut', 'cake', 'chair', 'couch',
    'potted plant', 'bed', 'dining table', 'toilet', 'tv', 'laptop', 'mouse', 'remote',
    'keyboard', 'cell phone', 'microwave', 'oven', 'toaster', 'sink', 'refrigerator', 'book',
    'clock', 'vase', 'scissors', 'teddy bear', 'hair drier', 'toothbrush')


@dataclass
class Letterbox:
    scale: float
    pad_x: int
    pad_y: int
    width: int          # original image
    height: int


@dataclass
class Detection:
    x1: float
    y1: float
    x2: float
    y2: float
    score: float
    class_id: int

    @property
    def cx(self):
        return (self.x1 + self.x2) / 2

    @property
    def cy(self):
        return (self.y1 + self.y2) / 2

    @property
    def w(self):
        return self.x2 - self.x1

    @property
    def h(self):
        return self.y2 - self.y1


def class_ids(names):
    """COCO ids for class names; unknown names raise ValueError."""
    ids = []
    for n in names:
        if n not in COCO_CLASSES:
            raise ValueError(f'unknown class "{n}"')
        ids.append(COCO_CLASSES.index(n))
    return ids


def letterbox(rgb, size):
    """HxWx3 uint8 RGB -> (1x3xSxS float32 tensor, Letterbox)."""
    import cv2
    h, w = rgb.shape[:2]
    r = min(size / h, size / w)
    nw, nh = int(round(w * r)), int(round(h * r))
    dw, dh = (size - nw) / 2, (size - nh) / 2
    left, top = int(round(dw - 0.1)), int(round(dh - 0.1))
    canvas = np.full((size, size, 3), 114, np.uint8)
    resized = rgb if (nw, nh) == (w, h) else cv2.resize(rgb, (nw, nh),
                                                        interpolation=cv2.INTER_LINEAR)
    canvas[top:top + nh, left:left + nw] = resized
    tensor = canvas.transpose(2, 0, 1)[None].astype(np.float32) / 255.0
    return np.ascontiguousarray(tensor), Letterbox(r, left, top, w, h)


def nms(boxes, scores, iou_threshold):
    """Indices kept by greedy NMS. boxes: Nx4 x1y1x2y2."""
    order = scores.argsort()[::-1]
    keep = []
    area = (boxes[:, 2] - boxes[:, 0]).clip(0) * (boxes[:, 3] - boxes[:, 1]).clip(0)
    while order.size:
        i = order[0]
        keep.append(int(i))
        rest = order[1:]
        xx1 = np.maximum(boxes[i, 0], boxes[rest, 0])
        yy1 = np.maximum(boxes[i, 1], boxes[rest, 1])
        xx2 = np.minimum(boxes[i, 2], boxes[rest, 2])
        yy2 = np.minimum(boxes[i, 3], boxes[rest, 3])
        inter = (xx2 - xx1).clip(0) * (yy2 - yy1).clip(0)
        iou = inter / (area[i] + area[rest] - inter + 1e-9)
        order = rest[iou <= iou_threshold]
    return keep


def decode(output, lb, conf_threshold, iou_threshold, allowed_ids=None, max_det=50):
    """Model output [1, 4+C, N] (or [4+C, N]) -> list of Detection in original pixels,
    best first."""
    out = np.asarray(output, dtype=np.float32)
    if out.ndim == 3:
        out = out[0]
    if out.ndim != 2 or out.shape[0] < 5:
        raise ValueError(f'unexpected model output shape {np.shape(output)}')
    pred = out.T                                         # N x (4 + C)
    scores_all = pred[:, 4:]
    if allowed_ids is not None:
        mask = np.zeros(scores_all.shape[1], bool)
        mask[[i for i in allowed_ids if i < scores_all.shape[1]]] = True
        scores_all = np.where(mask, scores_all, 0.0)
    cls = scores_all.argmax(axis=1)
    score = scores_all[np.arange(len(cls)), cls]
    sel = score >= conf_threshold
    if not sel.any():
        return []
    p, cls, score = pred[sel], cls[sel], score[sel]
    cx, cy, w, h = p[:, 0], p[:, 1], p[:, 2], p[:, 3]
    boxes = np.stack([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], axis=1)
    boxes[:, [0, 2]] = ((boxes[:, [0, 2]] - lb.pad_x) / lb.scale).clip(0, lb.width)
    boxes[:, [1, 3]] = ((boxes[:, [1, 3]] - lb.pad_y) / lb.scale).clip(0, lb.height)
    offset = cls[:, None].astype(np.float32) * 10000.0   # class-aware NMS in one pass
    keep = nms(boxes + offset, score, iou_threshold)[:max_det]
    return [Detection(*map(float, boxes[i]), float(score[i]), int(cls[i])) for i in keep]
