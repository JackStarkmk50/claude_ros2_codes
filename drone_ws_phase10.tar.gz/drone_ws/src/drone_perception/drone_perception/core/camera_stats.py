"""Frame-stream statistics for the camera check (Phase 9): rate, latency, stamp sanity."""

import math
from dataclasses import dataclass, field


@dataclass
class CameraExpect:
    min_fps: float = 15.0
    max_median_latency_s: float = 0.15    # capture stamp -> received on the Pi
    max_frame_gap_s: float = 0.5
    width: int = 640
    height: int = 480
    encoding: str = 'rgb8'
    frame_id: str = 'camera_optical_frame'


@dataclass
class FrameStats:
    stamps: list = field(default_factory=list)       # header stamp, s
    received: list = field(default_factory=list)     # local receive time, s (same clock)
    sizes: set = field(default_factory=set)
    encodings: set = field(default_factory=set)
    frame_ids: set = field(default_factory=set)

    def add(self, stamp_s, recv_s, width, height, encoding, frame_id):
        self.stamps.append(stamp_s)
        self.received.append(recv_s)
        self.sizes.add((width, height))
        self.encodings.add(encoding)
        self.frame_ids.add(frame_id)

    @property
    def count(self):
        return len(self.stamps)

    def fps(self):
        if self.count < 2:
            return 0.0
        span = self.received[-1] - self.received[0]
        return (self.count - 1) / span if span > 0 else 0.0

    def latencies(self):
        return sorted(r - s for s, r in zip(self.stamps, self.received))

    def median_latency(self):
        lat = self.latencies()
        return lat[len(lat) // 2] if lat else math.nan

    def max_gap(self):
        gaps = [b - a for a, b in zip(self.received, self.received[1:])]
        return max(gaps) if gaps else math.nan

    def non_increasing_stamps(self):
        return sum(1 for a, b in zip(self.stamps, self.stamps[1:]) if b <= a)


def camera_checks(stats, exp, info=None):
    """List of (name, ok, detail). info = (width, height, frame_id, calibrated) or None."""
    checks = []
    n = stats.count
    checks.append(('C1 frames arrive', n >= 2, f'{n} frames'))
    if n < 2:
        return checks
    fps = stats.fps()
    checks.append(('C2 frame rate', fps >= exp.min_fps, f'{fps:.1f} fps (need >= '
                                                        f'{exp.min_fps:.0f})'))
    size_ok = stats.sizes == {(exp.width, exp.height)}
    checks.append(('C3 image size', size_ok, ', '.join(f'{w}x{h}' for w, h in
                                                       sorted(stats.sizes))
                   + ('' if size_ok else f' (expected {exp.width}x{exp.height})')))
    enc_ok = stats.encodings == {exp.encoding}
    checks.append(('C4 encoding', enc_ok, ', '.join(sorted(stats.encodings))
                   + ('' if enc_ok else f' (expected {exp.encoding})')))
    fid_ok = stats.frame_ids == {exp.frame_id}
    checks.append(('C5 frame_id', fid_ok, ', '.join(sorted(stats.frame_ids))
                   + ('' if fid_ok else f' (expected {exp.frame_id})')))
    lat = stats.median_latency()
    lat_min = stats.latencies()[0]
    lat_ok = 0.0 <= lat <= exp.max_median_latency_s and lat_min > -0.01
    checks.append(('C6 stamp = capture time', lat_ok,
                   f'median {lat * 1000:.0f} ms, min {lat_min * 1000:.0f} ms behind now'
                   + ('' if lat_ok else ' (stamp is not the capture time on this clock)')))
    bad = stats.non_increasing_stamps()
    checks.append(('C7 stamps increase', bad == 0, f'{bad} out of order'))
    gap = stats.max_gap()
    checks.append(('C8 no long gaps', gap <= exp.max_frame_gap_s, f'longest gap {gap:.2f} s'))
    if info is None:
        checks.append(('C9 camera_info', False, 'no camera_info received'))
    else:
        w, h, fid, calibrated = info
        ok = (w, h) == (exp.width, exp.height) and fid == exp.frame_id
        checks.append(('C9 camera_info', ok, f'{w}x{h} {fid}, '
                       + ('calibrated' if calibrated else
                          'not calibrated (fine: only pixel offsets are used)')))
    return checks
