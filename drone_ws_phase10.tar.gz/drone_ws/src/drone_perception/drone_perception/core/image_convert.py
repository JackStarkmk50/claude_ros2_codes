"""sensor_msgs/Image <-> numpy without cv_bridge (numpy only).

cv_bridge from apt is built against Ubuntu's numpy; keeping it out of the nodes avoids a whole
class of version problems. Only the encodings this project uses are supported.
"""

import numpy as np

SUPPORTED = ('rgb8', 'bgr8', 'mono8', 'yuv422_yuy2')


def image_to_rgb(encoding, width, height, step, data):
    """Return an HxWx3 uint8 RGB array (a copy), or raise ValueError."""
    if width <= 0 or height <= 0:
        raise ValueError(f'bad image size {width}x{height}')
    buf = np.frombuffer(bytes(data) if not isinstance(data, (bytes, bytearray, memoryview))
                        else data, dtype=np.uint8)
    channels = {'rgb8': 3, 'bgr8': 3, 'mono8': 1, 'yuv422_yuy2': 2}.get(encoding)
    if channels is None:
        raise ValueError(f'unsupported encoding "{encoding}" (supported: {", ".join(SUPPORTED)})')
    if step < width * channels or buf.size < step * height:
        raise ValueError(f'buffer too small for {width}x{height} {encoding} (step {step}, '
                         f'{buf.size} bytes)')
    rows = buf[:step * height].reshape(height, step)[:, :width * channels]
    img = rows.reshape(height, width, channels)
    if encoding == 'rgb8':
        return img.copy()
    if encoding == 'bgr8':
        return img[:, :, ::-1].copy()
    if encoding == 'mono8':
        return np.repeat(img, 3, axis=2)
    return _yuyv_to_rgb(img.reshape(height, width * 2), width, height)


def _yuyv_to_rgb(yuyv, width, height):
    """YUYV (Y0 U Y1 V per 2 pixels), BT.601 limited range."""
    if width % 2:
        raise ValueError('yuv422_yuy2 needs an even width')
    p = yuyv.reshape(height, width // 2, 4).astype(np.float32)
    y = np.empty((height, width), np.float32)
    y[:, 0::2] = p[:, :, 0]
    y[:, 1::2] = p[:, :, 2]
    u = np.repeat(p[:, :, 1], 2, axis=1) - 128.0
    v = np.repeat(p[:, :, 3], 2, axis=1) - 128.0
    c = (y - 16.0) * 1.164
    rgb = np.stack([c + 1.596 * v, c - 0.392 * u - 0.813 * v, c + 2.017 * u], axis=2)
    return np.clip(rgb, 0, 255).astype(np.uint8)


def rgb_to_image_fields(rgb):
    """(encoding, width, height, step, bytes) for publishing an HxWx3 RGB array."""
    h, w = rgb.shape[:2]
    return 'rgb8', w, h, w * 3, np.ascontiguousarray(rgb, dtype=np.uint8).tobytes()
