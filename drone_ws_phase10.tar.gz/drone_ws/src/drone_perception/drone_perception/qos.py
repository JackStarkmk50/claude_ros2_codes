"""QoS shared by everything that publishes or subscribes camera images.

RELIABLE, newest frame only. Best-effort drops most full-size frames on FastDDS (measured: 7 Hz
arrive of 30 published at 640x480 rgb8), and v4l2_camera publishes RELIABLE (depth 10) anyway,
so a RELIABLE depth-1 subscriber is compatible and always gets the latest frame.
"""

from rclpy.qos import QoSProfile, ReliabilityPolicy

IMAGE_QOS = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE)
