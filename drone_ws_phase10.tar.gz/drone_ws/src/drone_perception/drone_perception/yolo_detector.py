"""yolo_detector: YOLO person detection on the newest camera frame (ONNX Runtime, CPU).

  /camera/image_raw  (sensor_msgs/Image)  ->  /drone/perception/detections
                                              (vision_msgs/Detection2DArray)

- Only the NEWEST frame is processed. Frames that arrive while the model runs are dropped, so
  the output is never a growing backlog of old pictures.
- Every processed frame gets a Detection2DArray, empty if nothing was found. The header is the
  image's header (capture stamp), so "now - stamp" is the real age of what the tracker sees.
- Frames older than max_frame_age_s when they would be processed are skipped (counted).
- Boxes are in ORIGINAL image pixels, class_id is the class name ("person").
- Inference runs in its own thread so the ROS callbacks never wait for the model.
- No model or a bad model: logs an ERROR once, publishes nothing, keeps running (so the tracker
  reports "detector silent" instead of the node restarting forever).

This node commands nothing. Its output only reaches the drone through the tracker, the mission
and the safety gate.
"""

import threading
import time

import rclpy
from diagnostic_msgs.msg import DiagnosticStatus
from diagnostic_updater import Updater
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from sensor_msgs.msg import Image
from vision_msgs.msg import Detection2D, Detection2DArray, ObjectHypothesisWithPose

from drone_perception.core.image_convert import image_to_rgb, rgb_to_image_fields
from drone_perception.core.rolling import Rolling
from drone_perception.core.yolo_postprocess import COCO_CLASSES, class_ids
from drone_perception.qos import IMAGE_QOS

PARAMETERS = {
    'model_path': '',                  # absolute path to the .onnx file
    'input_size': 320,
    'confidence_threshold': 0.5,
    'nms_iou_threshold': 0.45,
    'allowed_classes': ['person'],
    'num_threads': 3,                  # ONNX Runtime threads; the Pi 5 has 4 cores
    'max_rate_hz': 0.0,                # 0 = as fast as the CPU allows
    'max_frame_age_s': 0.5,            # skip frames older than this
    'publish_debug_image': False,
    'cpu_temp_path': '/sys/class/thermal/thermal_zone0/temp',
}


def read_cpu_temp(path):
    try:
        with open(path) as f:
            return int(f.read().strip()) / 1000.0
    except (OSError, ValueError):
        return float('nan')


class YoloDetector(Node):

    def __init__(self):
        super().__init__('yolo_detector')
        for name, default in PARAMETERS.items():
            self.declare_parameter(name, default)
        self.p = p = {name: self.get_parameter(name).value for name in PARAMETERS}

        self.allowed = class_ids(p['allowed_classes'])
        self.model = None
        self.model_error = ''
        try:
            from drone_perception.core.yolo_model import YoloModel
            self.model = YoloModel(p['model_path'], p['input_size'], p['num_threads'])
        except Exception as e:     # missing file, onnxruntime missing, wrong model
            self.model_error = str(e)
            self.get_logger().error(f'no detection: {e}. Set yolo_detector.model_path in '
                                    'drone.yaml (see docs/PHASE10_YOLO.md).')

        self.pub = self.create_publisher(Detection2DArray, '/drone/perception/detections', 10)
        self.debug_pub = (self.create_publisher(Image, '/drone/perception/debug_image', IMAGE_QOS)
                          if p['publish_debug_image'] else None)
        self.create_subscription(Image, '/camera/image_raw', self._on_image, IMAGE_QOS)

        self.lock = threading.Lock()
        self.wake = threading.Event()
        self.pending = None
        self.frames_in = Rolling(5.0)
        self.processed = Rolling(5.0)
        self.infer_ms = Rolling(5.0)
        self.latency_ms = Rolling(5.0)
        self.found = Rolling(5.0)
        self.dropped = 0
        self.skipped_old = 0
        self.errors = 0
        self.last_error = ''

        self.diag = Updater(self, period=1.0)
        self.diag.setHardwareID('pi5-cpu')
        self.diag.add('yolo_detector', self._diag)
        self.stats_timer = self.create_timer(10.0, self._log_stats)

        self.running = True
        self.worker = threading.Thread(target=self._loop, daemon=True)
        self.worker.start()
        if self.model is not None:
            self.get_logger().info(
                f'up: {p["model_path"]} at {p["input_size"]} px, classes '
                f'{", ".join(p["allowed_classes"])}, confidence >= '
                f'{p["confidence_threshold"]:.2f}, {p["num_threads"]} threads')

    def _now(self):
        return self.get_clock().now().nanoseconds * 1e-9

    def _on_image(self, msg):
        self.frames_in.add(time.monotonic())
        with self.lock:
            if self.pending is not None:
                self.dropped += 1
            self.pending = msg
        self.wake.set()

    def _loop(self):
        period = 1.0 / self.p['max_rate_hz'] if self.p['max_rate_hz'] > 0 else 0.0
        last = 0.0
        while self.running:
            if not self.wake.wait(timeout=0.2):
                continue
            with self.lock:
                msg, self.pending = self.pending, None
                self.wake.clear()
            if msg is None or self.model is None:
                continue
            if period:
                wait = last + period - time.monotonic()
                if wait > 0:
                    time.sleep(wait)
            last = time.monotonic()
            self._process(msg)

    def _process(self, msg):
        stamp = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        if self._now() - stamp > self.p['max_frame_age_s']:
            self.skipped_old += 1
            return
        try:
            rgb = image_to_rgb(msg.encoding, msg.width, msg.height, msg.step, msg.data)
            dets, t = self.model.detect(rgb, self.p['confidence_threshold'],
                                        self.p['nms_iou_threshold'], self.allowed)
        except Exception as e:
            self.errors += 1
            if str(e) != self.last_error:
                self.last_error = str(e)
                self.get_logger().error(f'frame skipped: {e}')
            return
        out = Detection2DArray()
        out.header = msg.header
        for d in dets:
            det = Detection2D()
            det.header = msg.header
            det.bbox.center.position.x = d.cx
            det.bbox.center.position.y = d.cy
            det.bbox.size_x = d.w
            det.bbox.size_y = d.h
            hyp = ObjectHypothesisWithPose()
            hyp.hypothesis.class_id = COCO_CLASSES[d.class_id]
            hyp.hypothesis.score = d.score
            det.results.append(hyp)
            out.detections.append(det)
        self.pub.publish(out)
        now = time.monotonic()
        self.processed.add(now)
        self.infer_ms.add(now, t['pre'] + t['infer'] + t['post'])
        self.latency_ms.add(now, (self._now() - stamp) * 1e3)
        self.found.add(now, float(len(dets)))
        if self.debug_pub is not None:
            self._publish_debug(msg, rgb, dets)

    def _publish_debug(self, msg, rgb, dets):
        import cv2
        img = rgb.copy()
        for d in dets:
            cv2.rectangle(img, (int(d.x1), int(d.y1)), (int(d.x2), int(d.y2)), (0, 255, 0), 2)
            cv2.putText(img, f'{COCO_CLASSES[d.class_id]} {d.score:.2f}',
                        (int(d.x1), max(12, int(d.y1) - 4)), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                        (0, 255, 0), 1)
        enc, w, h, step, data = rgb_to_image_fields(img)
        dbg = Image(encoding=enc, width=w, height=h, step=step, data=data)
        dbg.header = msg.header
        self.debug_pub.publish(dbg)

    def stats(self):
        now = time.monotonic()
        return {
            'camera_fps': self.frames_in.rate(now),
            'detector_fps': self.processed.rate(now),
            'model_ms': self.infer_ms.mean(now),
            'latency_ms': self.latency_ms.mean(now),
            'latency_max_ms': self.latency_ms.max(now),
            'people_per_frame': self.found.mean(now),
            'cpu_temp_c': read_cpu_temp(self.p['cpu_temp_path']),
        }

    def _diag(self, stat):
        if self.model is None:
            stat.summary(DiagnosticStatus.ERROR, f'no model: {self.model_error}')
            return stat
        s = self.stats()
        if s['detector_fps'] == 0.0:
            stat.summary(DiagnosticStatus.WARN, 'no frames processed (camera silent?)')
        else:
            stat.summary(DiagnosticStatus.OK, f'{s["detector_fps"]:.1f} fps')
        for k, v in s.items():
            stat.add(k, f'{v:.1f}')
        stat.add('dropped_newer_frame_arrived', str(self.dropped))
        stat.add('skipped_too_old', str(self.skipped_old))
        stat.add('errors', str(self.errors))
        return stat

    def _log_stats(self):
        if self.model is None:
            return
        s = self.stats()
        self.get_logger().info(
            f'camera {s["camera_fps"]:.1f} fps, detector {s["detector_fps"]:.1f} fps, model '
            f'{s["model_ms"]:.0f} ms, image age at publish {s["latency_ms"]:.0f} ms (max '
            f'{s["latency_max_ms"]:.0f}), CPU {s["cpu_temp_c"]:.0f} C, skipped old '
            f'{self.skipped_old}')

    def destroy_node(self):
        self.running = False
        self.wake.set()
        self.worker.join(timeout=1.0)
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = YoloDetector()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        # A second Ctrl-C during cleanup (terminal + launch both send SIGINT) must not
        # print a traceback.
        try:
            node.destroy_node()
            rclpy.try_shutdown()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
