import numpy as np
import pytest

from drone_perception.core.yolo_postprocess import (Letterbox, class_ids, decode, letterbox,
                                                    nms)


def raw(boxes, n_classes=80):
    """boxes: list of (cx, cy, w, h, class_id, score) in model-input pixels -> [1, 4+C, N]."""
    out = np.zeros((4 + n_classes, len(boxes)), np.float32)
    for j, (cx, cy, w, h, c, s) in enumerate(boxes):
        out[:4, j] = (cx, cy, w, h)
        out[4 + c, j] = s
    return out[None]


IDENTITY = Letterbox(1.0, 0, 0, 320, 320)


def test_class_ids():
    assert class_ids(['person']) == [0]
    with pytest.raises(ValueError):
        class_ids(['alien'])


def test_letterbox_landscape_pads_top_and_bottom():
    img = np.full((480, 640, 3), 200, np.uint8)
    t, lb = letterbox(img, 320)
    assert t.shape == (1, 3, 320, 320) and t.dtype == np.float32
    assert lb.scale == 0.5 and lb.pad_x == 0 and lb.pad_y == 40
    assert abs(t[0, 0, 0, 0] - 114 / 255) < 1e-6          # padding
    assert abs(t[0, 0, 160, 160] - 200 / 255) < 1e-6      # image


def test_boxes_map_back_to_original_pixels():
    lb = Letterbox(0.5, 0, 40, 640, 480)
    # a box centred in the letterboxed input -> centre of the 640x480 image
    dets = decode(raw([(160, 160, 50, 100, 0, 0.9)]), lb, 0.5, 0.45)
    d = dets[0]
    assert (round(d.cx), round(d.cy), round(d.w), round(d.h)) == (320, 240, 100, 200)


def test_threshold_and_class_filter():
    out = raw([(100, 100, 20, 20, 0, 0.4), (200, 200, 20, 20, 2, 0.9),
               (50, 50, 20, 20, 0, 0.8)])
    dets = decode(out, IDENTITY, 0.5, 0.45, allowed_ids=[0])
    assert len(dets) == 1 and dets[0].class_id == 0 and abs(dets[0].score - 0.8) < 1e-6


def test_nms_removes_duplicates_keeps_separate_people():
    out = raw([(100, 100, 40, 80, 0, 0.9), (102, 101, 40, 80, 0, 0.8),
               (250, 100, 40, 80, 0, 0.7)])
    dets = decode(out, IDENTITY, 0.5, 0.45)
    assert [round(d.cx) for d in dets] == [100, 250]


def test_overlapping_different_classes_both_kept():
    out = raw([(100, 100, 40, 80, 0, 0.9), (100, 100, 40, 80, 56, 0.8)])
    assert len(decode(out, IDENTITY, 0.5, 0.45)) == 2


def test_boxes_clipped_to_image():
    d = decode(raw([(5, 5, 40, 40, 0, 0.9)]), IDENTITY, 0.5, 0.45)[0]
    assert d.x1 == 0.0 and d.y1 == 0.0


def test_nothing_above_threshold_and_bad_shape():
    assert decode(raw([(1, 1, 1, 1, 0, 0.1)]), IDENTITY, 0.5, 0.45) == []
    with pytest.raises(ValueError):
        decode(np.zeros((1, 3, 10)), IDENTITY, 0.5, 0.45)


def test_nms_plain():
    boxes = np.array([[0, 0, 10, 10], [1, 1, 10, 10], [20, 20, 30, 30]], np.float32)
    assert nms(boxes, np.array([0.9, 0.8, 0.7]), 0.5) == [0, 2]
