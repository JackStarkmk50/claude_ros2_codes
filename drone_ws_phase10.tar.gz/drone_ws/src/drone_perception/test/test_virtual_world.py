import numpy as np

from drone_perception.core.virtual_world import World, wrap_deg

W, H = 640, 480


def person_columns(world, yaw):
    frame = world.render(yaw)
    cols = np.where((frame == 255).all(axis=2).any(axis=0))[0]
    return cols


def make(bearing):
    return World(W, H, 60.0, np.full((200, 40, 3), 255, np.uint8), bearing)


def test_wrap():
    assert wrap_deg(190) == -170 and wrap_deg(-190) == 170 and wrap_deg(0) == 0


def test_person_ahead_is_centred():
    cols = person_columns(make(0.0), 0.0)
    assert abs(cols.mean() - W / 2) < 2


def test_person_left_appears_left_and_turning_left_centres_it():
    w = make(20.0)                       # 20 deg to the LEFT
    assert person_columns(w, 0.0).mean() < W / 2 - 150
    assert abs(person_columns(w, 20.0).mean() - W / 2) < 2   # yaw left (CCW) by 20


def test_person_behind_is_not_visible_and_wraps():
    w = make(170.0)
    assert person_columns(w, 0.0).size == 0
    assert person_columns(w, -175.0).size > 0              # 15 deg further round


def test_hidden_person():
    w = make(0.0)
    w.visible = False
    assert person_columns(w, 0.0).size == 0
