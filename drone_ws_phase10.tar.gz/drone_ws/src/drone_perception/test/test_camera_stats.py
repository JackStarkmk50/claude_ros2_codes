from drone_perception.core.camera_stats import CameraExpect, FrameStats, camera_checks


def stream(n=60, fps=30.0, latency=0.03, size=(640, 480), enc='rgb8',
           fid='camera_optical_frame'):
    s = FrameStats()
    for i in range(n):
        t = 100.0 + i / fps
        s.add(t, t + latency, size[0], size[1], enc, fid)
    return s


def results(stats, info=(640, 480, 'camera_optical_frame', False)):
    return {name.split()[0]: ok for name, ok, _ in camera_checks(stats, CameraExpect(), info)}


def test_good_stream_passes_everything():
    assert all(results(stream()).values())


def test_slow_stream_fails_rate():
    r = results(stream(fps=8.0))
    assert not r['C2'] and r['C3']


def test_wrong_size_encoding_frame():
    assert not results(stream(size=(320, 240)))['C3']
    assert not results(stream(enc='yuv422_yuy2'))['C4']
    assert not results(stream(fid='camera'))['C5']


def test_stamp_in_the_future_or_old():
    assert not results(stream(latency=-0.5))['C6']
    assert not results(stream(latency=2.0))['C6']


def test_out_of_order_and_gap():
    s = stream()
    s.add(90.0, s.received[-1] + 1.0, 640, 480, 'rgb8', 'camera_optical_frame')
    r = results(s)
    assert not r['C7'] and not r['C8']


def test_camera_info_missing_or_mismatched():
    assert not results(stream(), info=None)['C9']
    assert not results(stream(), info=(320, 240, 'camera_optical_frame', False))['C9']


def test_no_frames():
    checks = camera_checks(FrameStats(), CameraExpect())
    assert len(checks) == 1 and not checks[0][1]
