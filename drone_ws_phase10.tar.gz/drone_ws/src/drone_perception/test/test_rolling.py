import math

from drone_perception.core.rolling import Rolling


def test_rate_mean_max_and_expiry():
    r = Rolling(window_s=2.0)
    for i in range(20):
        r.add(i * 0.1, float(i))
    assert abs(r.rate(1.9) - 10.0) < 1e-9
    assert r.max(1.9) == 19.0
    assert math.isnan(r.mean(10.0)) and r.rate(10.0) == 0.0
