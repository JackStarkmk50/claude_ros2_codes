"""Every executable module imports cleanly and exposes main()."""


def test_node_modules_import():
    from drone_perception import yolo_detector  # noqa: F401
    from drone_perception import target_tracker  # noqa: F401
    assert callable(yolo_detector.main)
    assert callable(target_tracker.main)
