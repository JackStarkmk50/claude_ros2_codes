import numpy as np
import pytest

from drone_perception.core.image_convert import image_to_rgb, rgb_to_image_fields


def test_rgb_roundtrip_with_padded_step():
    rgb = np.arange(4 * 6 * 3, dtype=np.uint8).reshape(4, 6, 3)
    padded = np.zeros((4, 6 * 3 + 2), np.uint8)
    padded[:, :18] = rgb.reshape(4, 18)
    out = image_to_rgb('rgb8', 6, 4, 20, padded.tobytes())
    assert np.array_equal(out, rgb)


def test_bgr_is_swapped():
    bgr = np.zeros((2, 2, 3), np.uint8)
    bgr[..., 0] = 200   # blue
    out = image_to_rgb('bgr8', 2, 2, 6, bgr.tobytes())
    assert out[0, 0].tolist() == [0, 0, 200]


def test_yuyv_grey_and_colour():
    # Y=126 U=V=128 -> mid grey; Y=81 U=90 V=240 -> red
    grey = np.array([[126, 128, 126, 128]], np.uint8)
    out = image_to_rgb('yuv422_yuy2', 2, 1, 4, grey.tobytes())
    assert np.all(np.abs(out.astype(int) - 128) <= 2)
    red = np.array([[81, 90, 81, 240]], np.uint8)
    r = image_to_rgb('yuv422_yuy2', 2, 1, 4, red.tobytes())[0, 0]
    assert r[0] > 230 and r[1] < 20 and r[2] < 20


def test_unsupported_and_short_buffers_raise():
    with pytest.raises(ValueError):
        image_to_rgb('16UC1', 2, 2, 4, bytes(8))
    with pytest.raises(ValueError):
        image_to_rgb('rgb8', 4, 4, 12, bytes(10))


def test_rgb_to_fields():
    enc, w, h, step, data = rgb_to_image_fields(np.zeros((3, 5, 3), np.uint8))
    assert (enc, w, h, step, len(data)) == ('rgb8', 5, 3, 15, 45)
