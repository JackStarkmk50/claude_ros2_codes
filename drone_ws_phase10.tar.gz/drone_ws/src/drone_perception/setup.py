from setuptools import find_packages, setup

package_name = 'drone_perception'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml', 'README.md']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Moganesan',
    maintainer_email='ht.moganesan@gmail.com',
    description='Perception: YOLO person detection (ONNX Runtime on CPU) and target tracking.',
    license='MIT',
    extras_require={'test': ['pytest']},
    entry_points={
        'console_scripts': [
            'yolo_detector = drone_perception.yolo_detector:main',
            'target_tracker = drone_perception.target_tracker:main',
        ],
    },
)
