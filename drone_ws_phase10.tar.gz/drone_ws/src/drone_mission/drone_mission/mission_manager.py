"""mission_manager: SearchAndTrack action server and deterministic mission state machine.

Phase 2 skeleton. It starts, loads its parameters from drone_bringup/config/drone.yaml,
logs what it loaded, and spins. It publishes and commands nothing. The real
behaviour is added in Phase 12.
"""

import rclpy
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node

from drone_interfaces.action import SearchAndTrack  # noqa: F401  (import check)


BUILTIN_PARAMETERS = ('use_sim_time', 'start_type_description_service')


class MissionManager(Node):

    def __init__(self):
        super().__init__(
            'mission_manager',
            automatically_declare_parameters_from_overrides=True,
        )
        params = self.get_parameters_by_prefix('')
        loaded = sorted(name for name in params if name not in BUILTIN_PARAMETERS)
        self.get_logger().info(
            f'skeleton up (Phase 2), {len(loaded)} parameters loaded: '
            f'{", ".join(loaded) or "none"}'
        )


def main(args=None):
    rclpy.init(args=args)
    node = MissionManager()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        # A second Ctrl-C during cleanup (terminal + launch both send SIGINT) must not
        # print a traceback.
        try:
            node.destroy_node()
            rclpy.try_shutdown()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
