"""Every executable module imports cleanly and exposes main()."""


def test_node_modules_import():
    from drone_mission import mission_manager  # noqa: F401
    assert callable(mission_manager.main)
