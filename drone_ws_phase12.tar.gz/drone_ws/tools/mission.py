#!/usr/bin/env python3
"""Start a SearchAndTrack mission and follow it. [AIRCRAFT]

  python3 mission.py start                         take off, search, track 60 s, return, land
  python3 mission.py start --track 30 --search 45 --alt 1.0
  python3 mission.py start --in-air                start while already hovering in GUIDED
  python3 mission.py start --no-land               hover at the end instead of landing
  python3 mission.py watch                         print /drone/mission/status changes

Ctrl-C during a mission cancels it: the drone LANDS (on_cancel: land). Nothing flies unless the
stack runs with enable_fcu_output:=true allow_arming:=true.
"""

import argparse
import sys
import time

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from rclpy.signals import SignalHandlerOptions

from drone_interfaces.action import SearchAndTrack
from drone_interfaces.msg import MissionStatus

OUTCOMES = ('COMPLETED', 'CANCELLED', 'TARGET_NOT_FOUND', 'TARGET_LOST', 'SAFETY_STOP',
            'MANUAL_OVERRIDE', 'PREFLIGHT_FAILED', 'TAKEOFF_FAILED', 'ERROR')
LATCHED = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                     durability=DurabilityPolicy.TRANSIENT_LOCAL)


def line(s, t0):
    return (f'{time.monotonic() - t0:6.1f} s  {s.state_name:17} target {s.target_track_id or "-":>3}'
            f'  turned {s.search_yaw_accumulated_deg:5.0f} deg  {s.detail}')


def start(node, args):
    client = ActionClient(node, SearchAndTrack, '/drone/mission/search_and_track')
    if not client.wait_for_server(timeout_sec=5.0):
        print('mission_manager not reachable: is the stack running?')
        return 2
    goal = SearchAndTrack.Goal(target_class='person', autonomous_takeoff=not args.in_air,
                               takeoff_altitude_m=args.alt, search_timeout_s=args.search,
                               track_duration_s=args.track, land_on_finish=not args.no_land)
    t0 = time.monotonic()
    last = [None]

    def fb(msg):
        s = msg.feedback.status
        if (s.state, s.detail.split(',')[0]) != last[0]:
            print(line(s, t0), flush=True)
            last[0] = (s.state, s.detail.split(',')[0])

    f = client.send_goal_async(goal, feedback_callback=fb)
    rclpy.spin_until_future_complete(node, f, timeout_sec=5.0)
    gh = f.result()
    if gh is None or not gh.accepted:
        print('goal rejected: a mission is already running')
        return 1
    rf = gh.get_result_async()
    cancel_sent = False
    while not rf.done():
        try:
            rclpy.spin_once(node, timeout_sec=0.1)
        except KeyboardInterrupt:
            if not cancel_sent:
                print('\nCancelling the mission: the drone LANDS if it is flying ...', flush=True)
                gh.cancel_goal_async()
                cancel_sent = True
    r = rf.result().result
    print(f'\nRESULT: {OUTCOMES[r.outcome]}: {r.message}')
    print(f'  after {r.duration_s:.1f} s, landed and disarmed: {r.landed_and_disarmed}')
    return 0 if r.outcome == 0 else 1


def watch(node):
    t0 = time.monotonic()
    last = [None]

    def cb(s):
        if (s.state, s.detail.split(',')[0]) != last[0]:
            print(line(s, t0), flush=True)
            last[0] = (s.state, s.detail.split(',')[0])
    node.create_subscription(MissionStatus, '/drone/mission/status', cb, LATCHED)
    while True:
        rclpy.spin_once(node, timeout_sec=0.1)


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('cmd', choices=['start', 'watch'])
    p.add_argument('--alt', type=float, default=0.0, help='takeoff height, m (0 = default)')
    p.add_argument('--search', type=float, default=0.0, help='search time limit, s')
    p.add_argument('--track', type=float, default=60.0, help='how long to track, s')
    p.add_argument('--in-air', action='store_true', help='start while hovering in GUIDED')
    p.add_argument('--no-land', action='store_true', help='hover at the end')
    args = p.parse_args()
    # no rclpy SIGINT handler: Ctrl-C must reach the cancel below, not shut ROS down
    rclpy.init(signal_handler_options=SignalHandlerOptions.NO)
    node = Node('mission_cli')
    try:
        return start(node, args) if args.cmd == 'start' else watch(node)
    except KeyboardInterrupt:
        return 1
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == '__main__':
    sys.exit(main())
