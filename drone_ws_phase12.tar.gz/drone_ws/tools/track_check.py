#!/usr/bin/env python3
"""Phase 11 walk-through test of the target tracker (sends nothing to the drone).

  python3 track_check.py            guided steps T1..T6, writes ~/drone_ws/phase11_report.txt
  python3 track_check.py --watch    just print the target once per second until Ctrl-C

Needs the camera, yolo_detector and target_tracker running (perception.launch.py). You walk in
front of the camera and press Enter when the tool asks. "The drone's LEFT" is the left side of
the camera picture: when you face the camera, that is YOUR right.
"""

import argparse
import os
import sys
import time

import rclpy
from rclpy.node import Node

from drone_interfaces.msg import TrackedTarget

REPORT = os.path.expanduser('~/drone_ws/phase11_report.txt')
STATES = ('NONE', 'CANDIDATE', 'TRACKING', 'LOST')
SIDE = {-1: 'left', 0: 'centre', 1: 'right'}


class Watch(Node):
    def __init__(self):
        super().__init__('track_check')
        self.last = None
        self.create_subscription(TrackedTarget, '/drone/perception/target', self._cb, 10)

    def _cb(self, msg):
        self.last = msg

    def spin_for(self, seconds, pred=None):
        """Spin; return the first message for which pred is true (or the last one)."""
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            rclpy.spin_once(self, timeout_sec=0.05)
            if pred and self.last is not None and pred(self.last):
                return self.last, True
        return self.last, pred is None


def describe(m):
    if m is None:
        return 'no message from target_tracker'
    s = f'{STATES[m.state]}'
    if m.track_id:
        s += (f' id {m.track_id}, error_x {m.error_x_norm:+.2f}, size {m.bbox_height_norm:.2f},'
              f' seen {m.frames_seen} frames, {m.time_since_seen_s:.1f} s ago')
    return s + f', last side {SIDE.get(m.last_seen_side, "?")}'


STEPS = [
    ('T1', 'Make sure NOBODY is in the picture.', 5.0,
     lambda m: m.state == 0, 'state NONE'),
    ('T2', 'Walk in and stand in the MIDDLE of the picture, 2 to 4 m away.', 6.0,
     lambda m: m.state == 2 and abs(m.error_x_norm) < 0.35, 'TRACKING, |error_x| < 0.35'),
    ('T3', "Step to the drone's LEFT (YOUR right when you face the camera), still in the picture.",
     6.0, lambda m: m.state == 2 and m.error_x_norm < -0.3, 'TRACKING, error_x < -0.3'),
    ('T4', "Step to the drone's RIGHT (YOUR left when you face the camera), still in the picture.",
     6.0, lambda m: m.state == 2 and m.error_x_norm > 0.3, 'TRACKING, error_x > +0.3'),
    ('T5', "Walk OUT of the picture on the drone's RIGHT side and stay out.", 6.0,
     lambda m: m.state == 3 and m.last_seen_side == 1, 'LOST, last side right'),
    ('T6', 'Come back into the middle of the picture.', 8.0,
     lambda m: m.state == 2, 'TRACKING again'),
]


def guided(node):
    lines = []
    ids = {}
    for name, prompt, timeout, pred, want in STEPS:
        input(f'\n{name}: {prompt}\n    press Enter when you are there ... ')
        msg, ok = node.spin_for(timeout, pred)
        ids[name] = msg.track_id if msg is not None else 0
        line = f'{"PASS" if ok else "FAIL"}  {name} ({want}): {describe(msg)}'
        print('   ' + line)
        lines.append(line)
    same = ids['T6'] == ids['T2']
    lines.append(f'INFO  after coming back the target id is {"the same" if same else "new"} '
                 f'({ids["T2"]} -> {ids["T6"]}); both are fine')
    ok = all(line.startswith('PASS') for line in lines if not line.startswith('INFO'))
    lines.append('TRACK CHECK: ' + ('ALL PASSED' if ok else 'FAILURES ABOVE'))
    return lines, ok


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--watch', action='store_true')
    args = p.parse_args()
    rclpy.init()
    node = Watch()
    try:
        if args.watch:
            while True:
                node.spin_for(1.0)
                print(describe(node.last), flush=True)
        msg, _ = node.spin_for(3.0, lambda m: True)
        if msg is None:
            print('no message on /drone/perception/target: is perception.launch.py running?')
            return 2
        lines, ok = guided(node)
    except KeyboardInterrupt:
        return 1
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
    text = '\n'.join(lines)
    print('\n' + text)
    with open(REPORT, 'w') as f:
        f.write(text + '\n')
    print(f'report written: {REPORT}')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
