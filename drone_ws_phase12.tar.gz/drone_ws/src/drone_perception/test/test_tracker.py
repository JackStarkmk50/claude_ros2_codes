from drone_perception.core.tracker import (STATE_CANDIDATE, STATE_LOST, STATE_NONE,
                                           STATE_TRACKING, Box, Tracker, TrackerConfig)

W, H = 640, 480


def run(tr, t0, frames, boxes_fn, dt=0.1):
    """Feed `frames` frames from t0 every dt; boxes_fn(i) -> list of Box."""
    rep = None
    for i in range(frames):
        t = t0 + i * dt
        tr.update(t, W, H, boxes_fn(i))
        rep = tr.report(t)
    return rep, t0 + frames * dt


def person(cx=320, cy=240, h=200, score=0.9):
    return Box(cx, cy, h * 0.4, h, score)


def test_confirm_then_track():
    tr = Tracker(TrackerConfig(confirm_frames=3))
    tr.update(0.0, W, H, [person()])
    assert tr.report(0.0).state == STATE_CANDIDATE
    tr.update(0.1, W, H, [person()])
    assert tr.report(0.1).state == STATE_CANDIDATE
    tr.update(0.2, W, H, [person()])
    r = tr.report(0.2)
    assert r.state == STATE_TRACKING and r.track_id == 1 and r.frames_seen == 3


def test_error_signs():
    tr = Tracker(TrackerConfig(confirm_frames=1))
    tr.update(0.0, W, H, [person(cx=560, cy=120)])
    r = tr.report(0.0)
    assert r.error_x_norm > 0.7 and r.error_y_norm < 0 and r.last_seen_side == 1   # right, up
    tr2 = Tracker(TrackerConfig(confirm_frames=1))
    tr2.update(0.0, W, H, [person(cx=80)])
    r2 = tr2.report(0.0)
    assert r2.error_x_norm < -0.7 and r2.last_seen_side == -1                        # left
    assert abs(r2.bbox_height_norm - 200 / H) < 1e-9


def test_centre_has_no_side():
    tr = Tracker(TrackerConfig(confirm_frames=1))
    tr.update(0.0, W, H, [person(cx=330)])
    assert tr.report(0.0).last_seen_side == 0


def test_loss_after_timeout_keeps_side_then_drops():
    tr = Tracker(TrackerConfig(confirm_frames=1, lost_timeout_s=1.0, track_drop_s=3.0))
    rep, t = run(tr, 0.0, 5, lambda i: [person(cx=500)])
    assert rep.state == STATE_TRACKING
    tr.update(t + 0.5, W, H, [])
    assert tr.report(t + 0.5).state == STATE_TRACKING          # short gap: still tracking
    r = tr.report(t + 1.5)
    assert r.state == STATE_LOST and r.last_seen_side == 1 and r.time_since_seen_s > 1.0
    r = tr.report(t + 5.0)
    assert r.state == STATE_NONE and r.last_seen_side == 1


def test_sticky_selection_ignores_a_bigger_newcomer():
    tr = Tracker(TrackerConfig(confirm_frames=2))
    rep, t = run(tr, 0.0, 3, lambda i: [person(cx=200, h=150)])
    first = rep.track_id
    rep, _ = run(tr, t, 5, lambda i: [person(cx=200 + i, h=150), person(cx=500, h=300)])
    assert rep.track_id == first


def test_largest_bbox_first_then_closest_to_center_on_tie():
    tr = Tracker(TrackerConfig(confirm_frames=1))
    tr.update(0.0, W, H, [person(cx=100, h=150), person(cx=500, h=300)])
    assert abs(tr.report(0.0).box.cx - 500) < 1e-9
    tr2 = Tracker(TrackerConfig(confirm_frames=1))
    tr2.update(0.0, W, H, [person(cx=100, h=200), person(cx=300, h=200)])
    assert abs(tr2.report(0.0).box.cx - 300) < 1e-9
    tr3 = Tracker(TrackerConfig(confirm_frames=1, selection_policy='closest_to_center'))
    tr3.update(0.0, W, H, [person(cx=100, h=300), person(cx=330, h=100)])
    assert abs(tr3.report(0.0).box.cx - 330) < 1e-9


def test_reacquire_same_person_keeps_id():
    tr = Tracker(TrackerConfig(confirm_frames=2, lost_timeout_s=1.0, track_drop_s=3.0))
    rep, t = run(tr, 0.0, 4, lambda i: [person(cx=300)])
    tid = rep.track_id
    tr.update(t + 1.5, W, H, [])
    assert tr.report(t + 1.5).state == STATE_LOST
    tr.update(t + 2.0, W, H, [person(cx=310)])
    r = tr.report(t + 2.0)
    assert r.state == STATE_TRACKING and r.track_id == tid


def test_new_person_after_loss_becomes_target():
    tr = Tracker(TrackerConfig(confirm_frames=2, lost_timeout_s=1.0, track_drop_s=3.0))
    rep, t = run(tr, 0.0, 4, lambda i: [person(cx=100)])
    old = rep.track_id
    rep, _ = run(tr, t + 1.5, 3, lambda i: [person(cx=560)])
    assert rep.state == STATE_TRACKING and rep.track_id != old


def test_fast_turn_still_matches_by_centre_jump():
    # drone yawing: the person moves 100 px between frames (no box overlap at 80 px width)
    tr = Tracker(TrackerConfig(confirm_frames=1))
    rep, _ = run(tr, 0.0, 4, lambda i: [person(cx=150 + 100 * i)])
    assert rep.track_id == 1 and rep.frames_seen == 4


def test_low_confidence_and_old_frames_ignored():
    tr = Tracker(TrackerConfig(confirm_frames=1, min_confidence=0.5))
    tr.update(1.0, W, H, [person(score=0.3)])
    assert tr.report(1.0).state == STATE_NONE
    assert tr.update(0.5, W, H, [person()]) is False            # older than the last frame
    assert tr.report(1.0).state == STATE_NONE


def test_detector_silent_means_lost():
    tr = Tracker(TrackerConfig(confirm_frames=1, lost_timeout_s=1.0))
    tr.update(0.0, W, H, [person()])
    assert tr.report(0.5).state == STATE_TRACKING
    assert tr.report(1.2).state == STATE_LOST                   # no frames at all since
