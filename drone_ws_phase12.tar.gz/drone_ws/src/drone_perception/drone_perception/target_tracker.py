"""target_tracker: turns detections into ONE selected target, with loss detection.

  /drone/perception/detections (vision_msgs/Detection2DArray)
      -> /drone/perception/target (drone_interfaces/TrackedTarget) at publish_rate_hz

- Publishes on a timer, not only when detections arrive: if the detector goes silent, the target
  still turns LOST after lost_timeout_s.
- Header stamp = capture time of the image that last saw the target (now, if there is none).
- Detection messages older than max_detection_age_s, or older than the last one, are ignored.
- error_x_norm > 0 means the person is RIGHT of centre (the mission then turns right).

This node commands nothing.
"""

import time

import rclpy
from builtin_interfaces.msg import Time
from diagnostic_msgs.msg import DiagnosticStatus
from diagnostic_updater import Updater
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from sensor_msgs.msg import CameraInfo
from vision_msgs.msg import Detection2DArray

from drone_interfaces.msg import TrackedTarget
from drone_perception.core.rolling import Rolling
from drone_perception.core.tracker import STATE_NAMES, Box, Tracker, TrackerConfig
from drone_perception.qos import IMAGE_QOS

PARAMETERS = {
    'confirm_frames': 3,
    'lost_timeout_s': 1.0,
    'track_drop_s': 3.0,
    'selection_policy': 'largest_bbox',
    'iou_match_threshold': 0.3,
    'max_center_jump_norm': 0.25,
    'min_confidence': 0.5,
    'side_deadband': 0.1,
    'class_id': 'person',
    'max_detection_age_s': 0.5,
    'publish_rate_hz': 10.0,
    'image_width': 640,                # used until /camera/camera_info arrives
    'image_height': 480,
}


def to_time(t):
    sec = int(t)
    return Time(sec=sec, nanosec=int((t - sec) * 1e9))


class TargetTracker(Node):

    def __init__(self):
        super().__init__('target_tracker')
        for name, default in PARAMETERS.items():
            self.declare_parameter(name, default)
        self.p = p = {name: self.get_parameter(name).value for name in PARAMETERS}
        if p['selection_policy'] not in ('largest_bbox', 'closest_to_center'):
            raise ValueError(f'selection_policy "{p["selection_policy"]}" unknown')
        self.tracker = Tracker(TrackerConfig(
            confirm_frames=int(p['confirm_frames']), lost_timeout_s=p['lost_timeout_s'],
            track_drop_s=p['track_drop_s'], iou_match_threshold=p['iou_match_threshold'],
            max_center_jump_norm=p['max_center_jump_norm'], min_confidence=p['min_confidence'],
            selection_policy=p['selection_policy'], side_deadband=p['side_deadband'],
            class_id=p['class_id']))
        self.tracker.width, self.tracker.height = int(p['image_width']), int(p['image_height'])
        self.pub = self.create_publisher(TrackedTarget, '/drone/perception/target', 10)
        self.create_subscription(Detection2DArray, '/drone/perception/detections',
                                 self._on_detections, 10)
        self.create_subscription(CameraInfo, '/camera/camera_info', self._on_info, IMAGE_QOS)
        self.create_timer(1.0 / p['publish_rate_hz'], self._tick)
        self.frames = Rolling(5.0)
        self.ignored_old = 0
        self.last_state = None
        self.last_id = None
        self.diag = Updater(self, period=1.0)
        self.diag.setHardwareID('perception')
        self.diag.add('target_tracker', self._diag)
        self.get_logger().info(
            f'up: {p["class_id"]}, confirm {p["confirm_frames"]} frames, lost after '
            f'{p["lost_timeout_s"]:.1f} s, selection {p["selection_policy"]}')

    def _now(self):
        return self.get_clock().now().nanoseconds * 1e-9

    def _on_info(self, msg):
        if msg.width > 0 and msg.height > 0:
            self.tracker.width, self.tracker.height = msg.width, msg.height

    def _on_detections(self, msg):
        stamp = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        if self._now() - stamp > self.p['max_detection_age_s']:
            self.ignored_old += 1
            return
        boxes = []
        for d in msg.detections:
            if not d.results:
                continue
            hyp = max(d.results, key=lambda r: r.hypothesis.score)
            if hyp.hypothesis.class_id != self.p['class_id']:
                continue
            boxes.append(Box(d.bbox.center.position.x, d.bbox.center.position.y,
                             d.bbox.size_x, d.bbox.size_y, hyp.hypothesis.score))
        # Detection2DArray carries no image size: it comes from /camera/camera_info.
        if self.tracker.update(stamp, self.tracker.width, self.tracker.height, boxes):
            self.frames.add(time.monotonic())
        else:
            self.ignored_old += 1

    def _tick(self):
        now = self._now()
        r = self.tracker.report(now)
        msg = TrackedTarget()
        msg.header.stamp = to_time(r.stamp) if r.box is not None else to_time(now)
        msg.header.frame_id = 'camera_optical_frame'
        msg.state = r.state
        msg.track_id = r.track_id
        msg.class_id = self.p['class_id']
        if r.box is not None:
            msg.confidence = float(r.box.score)
            msg.bbox.center.position.x = float(r.box.cx)
            msg.bbox.center.position.y = float(r.box.cy)
            msg.bbox.size_x = float(r.box.w)
            msg.bbox.size_y = float(r.box.h)
            msg.time_since_seen_s = float(r.time_since_seen_s)
        else:
            msg.time_since_seen_s = float('inf')
        msg.image_width = self.tracker.width
        msg.image_height = self.tracker.height
        msg.error_x_norm = float(r.error_x_norm)
        msg.error_y_norm = float(r.error_y_norm)
        msg.bbox_height_norm = float(r.bbox_height_norm)
        msg.frames_seen = r.frames_seen
        msg.last_seen_side = r.last_seen_side
        self.pub.publish(msg)
        if (r.state, r.track_id) != (self.last_state, self.last_id):
            self.get_logger().info(f'target {STATE_NAMES[r.state]}'
                                   + (f' id {r.track_id}' if r.track_id else '')
                                   + f': {r.detail}')
            self.last_state, self.last_id = r.state, r.track_id

    def _diag(self, stat):
        rate = self.frames.rate(time.monotonic())
        if rate == 0.0:
            stat.summary(DiagnosticStatus.WARN, 'no detection messages (detector silent?)')
        else:
            stat.summary(DiagnosticStatus.OK, f'{rate:.1f} detection frames/s')
        stat.add('state', STATE_NAMES[self.last_state] if self.last_state is not None else '-')
        stat.add('tracks', str(len(self.tracker.tracks)))
        stat.add('ignored_old', str(self.ignored_old))
        return stat


def main(args=None):
    rclpy.init(args=args)
    node = TargetTracker()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        # A second Ctrl-C during cleanup (terminal + launch both send SIGINT) must not
        # print a traceback.
        try:
            node.destroy_node()
            rclpy.try_shutdown()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
