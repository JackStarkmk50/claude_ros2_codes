"""Multi-person tracking, target selection and loss (Phase 11). Pure Python, no ROS.

Detections (boxes in image pixels, with the capture time of their frame) become tracks; one
track is SELECTED as the target and kept ("sticky") through short gaps. The mission only ever
sees the selected target.

States (TrackedTarget):
  NONE       nothing selected and no confirmed person
  CANDIDATE  a person is being confirmed (seen < confirm_frames frames in a row)
  TRACKING   the target was seen within lost_timeout_s
  LOST       the target has not been seen for lost_timeout_s (kept until track_drop_s, so the
             mission knows where it was last: last_seen_side)
Any new confirmed person while LOST (or NONE) becomes the new target. All times are capture
stamps / the caller's clock in seconds.
"""

import math
from dataclasses import dataclass, field

STATE_NONE, STATE_CANDIDATE, STATE_TRACKING, STATE_LOST = 0, 1, 2, 3
STATE_NAMES = ('NONE', 'CANDIDATE', 'TRACKING', 'LOST')


@dataclass
class TrackerConfig:
    confirm_frames: int = 3
    lost_timeout_s: float = 1.0
    track_drop_s: float = 3.0
    iou_match_threshold: float = 0.3
    max_center_jump_norm: float = 0.25    # fallback match: centre moved < this x image width
    min_confidence: float = 0.5
    selection_policy: str = 'largest_bbox'   # or 'closest_to_center'
    side_deadband: float = 0.1
    class_id: str = 'person'


@dataclass
class Box:
    cx: float
    cy: float
    w: float
    h: float
    score: float = 1.0

    def iou(self, o):
        ax1, ay1, ax2, ay2 = self.cx - self.w / 2, self.cy - self.h / 2, \
            self.cx + self.w / 2, self.cy + self.h / 2
        bx1, by1, bx2, by2 = o.cx - o.w / 2, o.cy - o.h / 2, o.cx + o.w / 2, o.cy + o.h / 2
        iw = max(0.0, min(ax2, bx2) - max(ax1, bx1))
        ih = max(0.0, min(ay2, by2) - max(ay1, by1))
        inter = iw * ih
        union = self.w * self.h + o.w * o.h - inter
        return inter / union if union > 0 else 0.0


@dataclass
class Track:
    track_id: int
    box: Box
    first_seen: float
    last_seen: float
    streak: int = 1               # consecutive processed frames with a match
    frames_seen: int = 1
    confirmed: bool = False


@dataclass
class TargetReport:
    state: int
    track_id: int = 0
    box: Box = None
    stamp: float = math.nan       # capture time of the frame that last saw the target
    time_since_seen_s: float = math.nan
    frames_seen: int = 0
    error_x_norm: float = 0.0
    error_y_norm: float = 0.0
    bbox_height_norm: float = 0.0
    last_seen_side: int = 0
    detail: str = ''

    @property
    def state_name(self):
        return STATE_NAMES[self.state]


@dataclass
class Tracker:
    cfg: TrackerConfig = field(default_factory=TrackerConfig)
    width: int = 0
    height: int = 0
    tracks: dict = field(default_factory=dict)
    selected: int = 0
    next_id: int = 1
    last_frame_stamp: float = -math.inf
    last_side: int = 0

    # ------------------------------------------------------------------ input

    def update(self, stamp, width, height, boxes):
        """One processed frame: capture stamp, image size, list of Box (already the right
        class). Frames older than the last one are ignored (returns False)."""
        if stamp <= self.last_frame_stamp:
            return False
        self.last_frame_stamp = stamp
        self.width, self.height = width, height
        boxes = [b for b in boxes if b.score >= self.cfg.min_confidence and b.w > 0 and b.h > 0]
        matched_tracks, matched_boxes = self._associate(boxes)
        for tid, bi in zip(matched_tracks, matched_boxes):
            t = self.tracks[tid]
            t.box, t.last_seen = boxes[bi], stamp
            t.streak += 1
            t.frames_seen += 1
            if t.streak >= self.cfg.confirm_frames:
                t.confirmed = True
        for tid, t in self.tracks.items():
            if tid not in matched_tracks:
                t.streak = 0
        for bi, b in enumerate(boxes):
            if bi not in matched_boxes:
                tid = self.next_id
                self.next_id += 1
                self.tracks[tid] = Track(tid, b, stamp, stamp,
                                         confirmed=self.cfg.confirm_frames <= 1)
        return True

    def _associate(self, boxes):
        pairs = []
        for tid, t in self.tracks.items():
            for bi, b in enumerate(boxes):
                iou = t.box.iou(b)
                if iou >= self.cfg.iou_match_threshold:
                    pairs.append((1.0 + iou, tid, bi))           # IoU matches first
                elif self.width > 0:
                    jump = math.hypot(t.box.cx - b.cx, t.box.cy - b.cy) / self.width
                    ratio = b.h / t.box.h if t.box.h > 0 else 0.0
                    if jump < self.cfg.max_center_jump_norm and 0.5 <= ratio <= 2.0:
                        pairs.append((1.0 - jump, tid, bi))
        pairs.sort(reverse=True)
        used_t, used_b = [], []
        for _, tid, bi in pairs:
            if tid not in used_t and bi not in used_b:
                used_t.append(tid)
                used_b.append(bi)
        return used_t, used_b

    # ------------------------------------------------------------------ output

    def report(self, now):
        """Drop old tracks, keep/choose the target, return a TargetReport for `now`."""
        for tid in [tid for tid, t in self.tracks.items()
                    if now - t.last_seen > self.cfg.track_drop_s]:
            del self.tracks[tid]
        sel = self.tracks.get(self.selected)
        if sel is None or now - sel.last_seen > self.cfg.lost_timeout_s:
            better = self._choose(now)
            if better is not None:
                self.selected = better.track_id
                sel = better
        if sel is None:
            self.selected = 0
            pending = [t for t in self.tracks.values() if not t.confirmed
                       and now - t.last_seen <= self.cfg.lost_timeout_s]
            if pending:
                best = max(pending, key=lambda t: t.streak)
                return TargetReport(STATE_CANDIDATE, best.track_id, best.box, best.last_seen,
                                    now - best.last_seen, best.frames_seen,
                                    detail=f'confirming ({best.streak}/'
                                           f'{self.cfg.confirm_frames} frames)',
                                    last_seen_side=self.last_side,
                                    **self._errors(best.box))
            return TargetReport(STATE_NONE, last_seen_side=self.last_side,
                                detail='no person')
        age = now - sel.last_seen
        state = STATE_TRACKING if age <= self.cfg.lost_timeout_s else STATE_LOST
        err = self._errors(sel.box)
        if state == STATE_TRACKING:
            ex = err['error_x_norm']
            self.last_side = 0 if abs(ex) < self.cfg.side_deadband else (1 if ex > 0 else -1)
        return TargetReport(state, sel.track_id, sel.box, sel.last_seen, age, sel.frames_seen,
                            last_seen_side=self.last_side,
                            detail=('tracking' if state == STATE_TRACKING
                                    else f'not seen for {age:.1f} s'), **err)

    def _choose(self, now):
        fresh = [t for t in self.tracks.values()
                 if t.confirmed and now - t.last_seen <= self.cfg.lost_timeout_s]
        if not fresh:
            return None
        cx = self.width / 2

        def centre_dist(t):
            return abs(t.box.cx - cx)
        if self.cfg.selection_policy == 'closest_to_center':
            return min(fresh, key=lambda t: (centre_dist(t), -t.box.h))
        return max(fresh, key=lambda t: (round(t.box.w * t.box.h), -centre_dist(t)))

    def _errors(self, box):
        if self.width <= 0 or self.height <= 0:
            return {'error_x_norm': 0.0, 'error_y_norm': 0.0, 'bbox_height_norm': 0.0}
        return {
            'error_x_norm': max(-1.0, min(1.0, (box.cx - self.width / 2) / (self.width / 2))),
            'error_y_norm': max(-1.0, min(1.0, (box.cy - self.height / 2) / (self.height / 2))),
            'bbox_height_norm': max(0.0, min(1.0, box.h / self.height)),
        }
