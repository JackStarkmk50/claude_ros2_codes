# drone_perception

Perception: YOLO person detection (ONNX Runtime on CPU) and target tracking.

See `ARCHITECTURE.md` (§3 nodes, §4 topics, §5 services, §6 actions) for the full contract of this package.

| Executable | Responsibility | Implemented in |
|---|---|---|
| `yolo_detector` | Runs YOLO on the newest camera frame and publishes vision_msgs/Detection2DArray. | Phase 10 (done) |
| `target_tracker` | Associates detections into tracks, selects the target, and reports loss. | Phase 11 (done) |

Current state: **Phase 11.** Camera driver (`v4l2_camera`, started by `drone_bringup/perception.launch.py`), `yolo_detector` (newest frame only, ONNX Runtime on the CPU, capture stamps kept) and `target_tracker` (one sticky target, CANDIDATE / TRACKING / LOST, last seen side) are real. Pure helpers in `core/`: image conversion, frame statistics, YOLO pre/post-processing, tracker, virtual room for tests.

Run one node on its own:

```bash
ros2 run drone_perception yolo_detector --ros-args --params-file $(ros2 pkg prefix drone_bringup)/share/drone_bringup/config/drone.yaml
```

Test:

```bash
colcon test --packages-select drone_perception && colcon test-result --verbose
```
