# drone_mission

Mission layer: SearchAndTrack action server and the deterministic mission state machine.

See `ARCHITECTURE.md` (§3 nodes, §4 topics, §5 services, §6 actions) for the full contract of this package.

| Executable | Responsibility | Implemented in |
|---|---|---|
| `mission_manager` | SearchAndTrack action server and deterministic mission state machine. | Phase 12 |

Current state: **Phase 12, real.** The state machine lives in `drone_mission/core/mission.py`
(no ROS, unit-tested with a simulated drone and person). `mission_manager` wraps it: action
`/drone/mission/search_and_track`, status `/drone/mission/status`, yaw-only commands to the safety
gate on `/drone/control/command`. Operator tool: `tools/mission.py`. Steps: `docs/PHASE12_MISSION.md`.

Run one node on its own:

```bash
ros2 run drone_mission mission_manager --ros-args --params-file $(ros2 pkg prefix drone_bringup)/share/drone_bringup/config/drone.yaml
```

Test:

```bash
colcon test --packages-select drone_mission && colcon test-result --verbose
```
