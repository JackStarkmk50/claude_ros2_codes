"""Pure-Python mission logic (no ROS imports), unit-tested in test/."""
