"""mission_manager: the SearchAndTrack action server and mission state machine (Phase 12).

  action  /drone/mission/search_and_track  (SearchAndTrack)       <- operator tool, intent_bridge
  topic   /drone/mission/status            (MissionStatus, 5 Hz + on change, TRANSIENT_LOCAL)
  topic   /drone/control/command           (ControlCommand, 10 Hz while airborne) -> safety gate
  uses    /drone/safety/preflight_check, /drone/flight/operation (TAKEOFF / LAND, via safety)
  reads   /drone/vehicle_state, /drone/safety_status, /drone/perception/target

The logic is in drone_mission/core/mission.py. This node only feeds it and carries out what it
asks. It never talks to MAVROS: yaw commands go through the safety gate, takeoff and landing are
FlightOperations that safety_supervisor re-checks.

While the drone flies in GUIDED and no mission runs (mission finished with land_on_finish false,
or a takeoff from tools/flight_op.py), the node streams HOLD so the hover is held on purpose.
If this node dies in the air, the stream stops and safety_supervisor goes HOLD, then LANDs.
If the mission logic ever raises, the node stops streaming for good (same result) and reports
ERROR.
"""

import threading
import time
import traceback

import rclpy
from rclpy.action import ActionClient, ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup, ReentrantCallbackGroup
from rclpy.executors import ExternalShutdownException, MultiThreadedExecutor
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from std_srvs.srv import Trigger

from drone_interfaces.action import FlightOperation, SearchAndTrack
from drone_interfaces.msg import ControlCommand, MissionStatus, SafetyStatus, TrackedTarget
from drone_interfaces.msg import VehicleState
from drone_mission.core import mission as core
from drone_mission.core.mission import Goal, Mission, MissionConfig, Obs, validate_goal

# Parameter defaults (drone.yaml overrides them). The mission ones mirror MissionConfig; a
# test checks they stay the same.
PARAMETERS = {
    'default_takeoff_altitude_m': 1.2,
    'min_takeoff_alt_m': 0.8,
    'max_takeoff_alt_m': 1.5,
    'search_yaw_rate_deg_s': 15.0,
    'search_direction': 1,
    'search_max_total_yaw_deg': 360.0,
    'search_timeout_s': 60.0,
    'max_search_timeout_s': 120.0,
    'track_kp': 0.5,
    'track_deadband': 0.05,
    'max_track_yaw_rate_deg_s': 20.0,
    'lost_hold_s': 1.0,
    'reacquire_timeout_s': 5.0,
    'reacquire_max_yaw_deg': 45.0,
    'reacquire_yaw_rate_deg_s': 10.0,
    'max_reacquire_attempts': 2,
    'max_track_duration_s': 300.0,
    'return_mode': 'yaw_to_start_then_land',
    'return_yaw_tol_deg': 5.0,
    'return_yaw_rate_deg_s': 15.0,
    'return_timeout_s': 30.0,
    'on_cancel': 'land',
    'perception_timeout_s': 2.0,
    'preflight_timeout_s': 5.0,
    'takeoff_timeout_s': 45.0,
    'land_timeout_s': 60.0,
    'enable_approach': False,
    # node only
    'rate_hz': 10.0,
    'status_rate_hz': 5.0,
    'vehicle_timeout_s': 1.0,
    'safety_timeout_s': 0.5,
    'target_timeout_s': 0.5,
    'cmd_max_age_s': 0.3,
    'hold_when_idle_airborne': True,
}
CONFIG_KEYS = tuple(MissionConfig.__dataclass_fields__)

IN_QOS = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                    durability=DurabilityPolicy.VOLATILE)
LATCHED = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                     durability=DurabilityPolicy.TRANSIENT_LOCAL)


class MissionManager(Node):

    def __init__(self):
        super().__init__('mission_manager')
        for name, default in PARAMETERS.items():
            self.declare_parameter(name, default)
        self.p = p = {name: self.get_parameter(name).value for name in PARAMETERS}
        self.cfg = MissionConfig(**{k: p[k] for k in CONFIG_KEYS})
        if self.cfg.return_mode not in ('yaw_to_start_then_land', 'land_in_place'):
            raise ValueError(f'return_mode "{self.cfg.return_mode}" unknown')
        if self.cfg.on_cancel not in ('land', 'hover'):
            raise ValueError(f'on_cancel "{self.cfg.on_cancel}" unknown')

        self.lock = threading.RLock()
        self.vehicle = self.vehicle_t = None
        self.safety = self.safety_t = None
        self.target = self.target_t = None
        self.mission = None
        self.goal_active = False
        self.broken = False              # mission logic raised: never stream again
        self.seq = 0
        self.op_handle = None            # running FlightOperation goal
        self.op_cancel_sent = False
        self.last_status = None
        self.last_status_t = 0.0
        self.last_idle_log = None

        tick_group = MutuallyExclusiveCallbackGroup()
        self.cb = ReentrantCallbackGroup()
        self.create_subscription(VehicleState, '/drone/vehicle_state', self._on_vehicle, IN_QOS,
                                 callback_group=tick_group)
        self.create_subscription(SafetyStatus, '/drone/safety_status', self._on_safety, LATCHED,
                                 callback_group=tick_group)
        self.create_subscription(TrackedTarget, '/drone/perception/target', self._on_target,
                                 IN_QOS, callback_group=tick_group)
        self.cmd_pub = self.create_publisher(ControlCommand, '/drone/control/command', IN_QOS)
        self.status_pub = self.create_publisher(MissionStatus, '/drone/mission/status', LATCHED)
        self.preflight = self.create_client(Trigger, '/drone/safety/preflight_check',
                                            callback_group=self.cb)
        self.ops = ActionClient(self, FlightOperation, '/drone/flight/operation',
                                callback_group=self.cb)
        self.server = ActionServer(
            self, SearchAndTrack, '/drone/mission/search_and_track',
            execute_callback=self._execute, goal_callback=self._on_goal,
            cancel_callback=lambda _: CancelResponse.ACCEPT, callback_group=self.cb)
        self.create_timer(1.0 / p['rate_hz'], self._tick, callback_group=tick_group)
        self._publish_status(force=True)
        self.get_logger().info(
            f'up: search {self.cfg.search_yaw_rate_deg_s:.0f} deg/s up to '
            f'{self.cfg.search_max_total_yaw_deg:.0f} deg / {self.cfg.search_timeout_s:.0f} s, '
            f'track kp {self.cfg.track_kp}, max {self.cfg.max_track_yaw_rate_deg_s:.0f} deg/s, '
            f'return {self.cfg.return_mode}, on cancel {self.cfg.on_cancel}')

    # ---------------------------------------------------------------- inputs

    def _on_vehicle(self, msg):
        self.vehicle, self.vehicle_t = msg, time.monotonic()

    def _on_safety(self, msg):
        self.safety, self.safety_t = msg, time.monotonic()

    def _on_target(self, msg):
        self.target, self.target_t = msg, time.monotonic()

    def _obs(self):
        now = time.monotonic()
        o = Obs()
        v, s, t = self.vehicle, self.safety, self.target
        o.vehicle_fresh = v is not None and now - self.vehicle_t <= self.p['vehicle_timeout_s']
        if v is not None:
            o.armed, o.mode, o.landed_state = v.armed, v.mode, v.landed_state
            o.yaw_rad, o.height_m = v.yaw_rad, v.height_above_ground_m
        o.safety_fresh = s is not None and now - self.safety_t <= self.p['safety_timeout_s']
        if s is not None:
            o.safety_level, o.safety_latched = s.level, s.latched
            o.safety_faults = tuple(s.active_faults)
        o.target_fresh = t is not None and now - self.target_t <= self.p['target_timeout_s']
        if t is not None:
            o.target_state, o.target_id = t.state, t.track_id
            o.error_x_norm, o.last_seen_side = t.error_x_norm, t.last_seen_side
        return o

    # ---------------------------------------------------------------- tick

    def _tick(self):
        now = time.monotonic()
        o = self._obs()
        with self.lock:
            m = self.mission
            if m is not None and not m.done:
                try:
                    step = m.step(now, o)
                except Exception:
                    self.broken = True
                    self.get_logger().error('mission logic failed, streaming stops (safety '
                                            'will HOLD, then LAND):\n' + traceback.format_exc())
                    m.result = core.Result(core.OUTCOME_ERROR, o.landed_and_disarmed,
                                           'internal error in the mission logic',
                                           now - m.t_start)
                    m.state = core.ERROR
                    step = None
                if step is not None:
                    if step.command is not None:
                        self._send(*step.command)
                    if step.request is not None:
                        self._run_request(m, *step.request)
                    if m.cancel_requested and m.state == core.TAKING_OFF:
                        self._cancel_op()
            else:
                self._idle_stream(o)
        self._publish_status()

    def _idle_stream(self, o):
        """HOLD while flying in GUIDED with no mission, unless the pilot has control."""
        if (self.broken or not self.p['hold_when_idle_airborne'] or not o.vehicle_fresh
                or not o.airborne or o.mode != 'GUIDED'
                or (o.safety_fresh and o.safety_level == core.LEVEL_OVERRIDE)):
            return
        self._send(*core.HOLD_CMD)

    def _send(self, mode, yaw_rate):
        if self.broken:
            return
        self.seq = max(self.seq + 1, int(time.monotonic() * 20))   # increases across restarts
        cmd = ControlCommand()
        cmd.header.stamp = self.get_clock().now().to_msg()
        cmd.mode = mode
        cmd.source = 'mission_manager'
        cmd.seq = self.seq % (2 ** 32)
        cmd.yaw_rate_rad_s = float(yaw_rate) if mode == core.MODE_BODY_VELOCITY else 0.0
        cmd.max_age_s = float(self.p['cmd_max_age_s'])
        self.cmd_pub.publish(cmd)

    # ---------------------------------------------------------------- requests

    def _run_request(self, m, kind, arg):
        self.get_logger().info(f'mission {m.state_name}: {kind}'
                               + (f' {arg:.2f} m' if kind == core.TAKEOFF_REQ else ''))
        if kind == core.PREFLIGHT_REQ:
            if not self.preflight.service_is_ready():
                m.ack(kind, False, 'safety_supervisor not reachable')
                return
            fut = self.preflight.call_async(Trigger.Request())
            fut.add_done_callback(lambda f: self._ack(m, kind, *(
                (f.result().success, f.result().message) if f.result() else
                (False, 'no answer'))))
            return
        if not self.ops.server_is_ready():
            m.ack(kind, False, 'flight operation server (safety_supervisor) not reachable')
            return
        goal = FlightOperation.Goal()
        goal.op = (FlightOperation.Goal.OP_TAKEOFF if kind == core.TAKEOFF_REQ
                   else FlightOperation.Goal.OP_LAND)
        goal.altitude_m = float(arg or 0.0)
        goal.source = 'mission_manager'
        goal.reason = f'SearchAndTrack {m.state_name}'
        self.op_cancel_sent = False
        fut = self.ops.send_goal_async(goal)

        def on_goal(f):
            gh = f.result()
            if gh is None or not gh.accepted:
                self._ack(m, kind, False, 'flight operation not accepted')
                return
            with self.lock:
                self.op_handle = gh

            def on_result(rf):
                r = rf.result().result if rf.result() else None
                with self.lock:
                    self.op_handle = None
                if r is None:
                    self._ack(m, kind, False, 'no result')
                else:
                    self._ack(m, kind, r.success, r.message)
            gh.get_result_async().add_done_callback(on_result)
        fut.add_done_callback(on_goal)

    def _ack(self, m, kind, ok, message):
        with self.lock:
            m.ack(kind, ok, message)
        # rclpy forbids one log call site from using two severities, so two calls.
        if ok:
            self.get_logger().info(f'{kind} OK: {message}')
        else:
            self.get_logger().warn(f'{kind} FAILED: {message}')

    def _cancel_op(self):
        if self.op_handle is not None and not self.op_cancel_sent:
            self.op_cancel_sent = True
            self.get_logger().warn('mission cancelled during TAKEOFF: cancelling it (lands)')
            self.op_handle.cancel_goal_async()

    # ---------------------------------------------------------------- action server

    def _on_goal(self, goal_request):
        with self.lock:
            if self.goal_active:
                self.get_logger().warn('SearchAndTrack rejected: a mission is already running')
                return GoalResponse.REJECT
            self.goal_active = True
        return GoalResponse.ACCEPT

    def _execute(self, goal_handle):
        g = goal_handle.request
        goal = Goal(target_class=g.target_class, autonomous_takeoff=g.autonomous_takeoff,
                    takeoff_altitude_m=g.takeoff_altitude_m, search_timeout_s=g.search_timeout_s,
                    track_duration_s=g.track_duration_s, land_on_finish=g.land_on_finish)
        result = SearchAndTrack.Result()
        try:
            with self.lock:
                fails = ['mission logic failed earlier: restart mission_manager'] \
                    if self.broken else validate_goal(self.cfg, goal, self._obs())
                if fails:
                    result.outcome = SearchAndTrack.Result.OUTCOME_ERROR
                    result.message = 'REJECTED: ' + ' | '.join(fails)
                    result.landed_and_disarmed = self._obs().landed_and_disarmed
                    self.get_logger().warn(result.message)
                    goal_handle.abort()
                    return result
                self.mission = m = Mission(self.cfg, goal, time.monotonic())
            self.get_logger().warn(
                f'[AIRCRAFT] SearchAndTrack started: {goal.target_class}, '
                + (f'autonomous takeoff to {m.altitude_m:.2f} m, ' if goal.autonomous_takeoff
                   else 'starting in the air, ')
                + f'search {m.search_timeout_s:.0f} s, track {m.track_duration_s:.0f} s, '
                + ('land at the end' if goal.land_on_finish else 'hover at the end'))
            last_fb = 0.0
            while rclpy.ok() and not m.done:
                if goal_handle.is_cancel_requested and not m.cancel_requested:
                    self.get_logger().warn('SearchAndTrack cancel requested')
                    with self.lock:
                        m.cancel()
                if time.monotonic() - last_fb >= 0.2:
                    goal_handle.publish_feedback(SearchAndTrack.Feedback(
                        status=self._status_msg()))
                    last_fb = time.monotonic()
                time.sleep(0.05)
            r = m.result
            if r is None:                      # rclpy is shutting down mid-mission
                result.outcome = SearchAndTrack.Result.OUTCOME_ERROR
                result.message = 'mission_manager shutting down'
                goal_handle.abort()
                return result
            result.outcome = r.outcome
            result.landed_and_disarmed = bool(r.landed_and_disarmed)
            result.message = r.message
            result.duration_s = float(r.duration_s)
            self.get_logger().warn(f'SearchAndTrack {core.OUTCOME_NAMES[r.outcome]} '
                                   f'({m.state_name}): {r.message}')
            if r.outcome == core.OUTCOME_COMPLETED:
                goal_handle.succeed()
            elif r.outcome == core.OUTCOME_CANCELLED and goal_handle.is_cancel_requested:
                goal_handle.canceled()
            else:
                goal_handle.abort()
            return result
        finally:
            with self.lock:
                self.goal_active = False
            try:
                self._publish_status(force=True)
            except Exception:                  # node already destroyed at shutdown
                pass

    # ---------------------------------------------------------------- status

    def _status_msg(self):
        msg = MissionStatus()
        msg.header.stamp = self.get_clock().now().to_msg()
        m = self.mission
        if m is None:
            msg.state, msg.state_name, msg.detail = core.IDLE, 'IDLE', 'no mission yet'
            return msg
        msg.state = m.state
        msg.state_name = m.state_name
        msg.target_class = m.goal.target_class
        msg.target_track_id = int(m.target_id)
        msg.elapsed_s = float((m.result.duration_s if m.result else
                               time.monotonic() - m.t_start))
        msg.search_yaw_accumulated_deg = float(m.search_yaw_deg)
        msg.reacquire_attempts = int(m.reacquire_attempts)
        msg.detail = m.detail + (f' [{core.OUTCOME_NAMES[m.result.outcome]}]' if m.result
                                 else '')
        return msg

    def _publish_status(self, force=False):
        msg = self._status_msg()
        key = (msg.state, msg.detail)
        now = time.monotonic()
        if force or key != self.last_status or now - self.last_status_t >= \
                1.0 / self.p['status_rate_hz']:
            if self.last_status is None or msg.state != self.last_status[0]:
                if self.mission is not None:
                    self.get_logger().info(f'mission {msg.state_name}: {msg.detail}')
            self.status_pub.publish(msg)
            self.last_status, self.last_status_t = key, now


def main(args=None):
    rclpy.init(args=args)
    node = MissionManager()
    executor = MultiThreadedExecutor(num_threads=4)
    executor.add_node(node)
    try:
        executor.spin()
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        # A second Ctrl-C during cleanup (terminal + launch both send SIGINT) must not
        # print a traceback.
        try:
            node.destroy_node()
            rclpy.try_shutdown()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
