import ast
import pathlib

from drone_mission.core.mission import MissionConfig


def test_node_defaults_mirror_mission_config():
    src = pathlib.Path(__file__).resolve().parents[1] / 'drone_mission' / 'mission_manager.py'
    params = None
    for node in ast.parse(src.read_text()).body:
        if isinstance(node, ast.Assign) and getattr(node.targets[0], 'id', '') == 'PARAMETERS':
            params = ast.literal_eval(node.value)
    assert params is not None
    for name, f in MissionConfig.__dataclass_fields__.items():
        assert name in params, name
        assert params[name] == f.default and type(params[name]) is type(f.default), name
