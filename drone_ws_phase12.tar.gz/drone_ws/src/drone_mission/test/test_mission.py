import math

import pytest

from drone_mission.core import mission as m
from drone_mission.core.mission import (Goal, Mission, MissionConfig, Obs, track_yaw_rate,
                                        validate_goal)

HFOV = 60.0


class Sim:
    """Drone that turns at the commanded yaw rate + a person at a bearing (deg, CCW+)."""

    def __init__(self, person_bearing=None, airborne=False):
        self.t = 0.0
        self.yaw = 0.0                    # rad, ENU
        self.armed = airborne
        self.landed = m.LANDED_IN_AIR if airborne else m.LANDED_ON_GROUND
        self.mode = 'GUIDED' if airborne else 'STABILIZE'
        self.person = person_bearing
        self.level = m.LEVEL_OK
        self.faults = ()
        self.tracker_alive = True
        self.last_side = 0
        self.lost_for = 99.0
        self.commands = []
        self.requests = []

    def obs(self):
        o = Obs(armed=self.armed, mode=self.mode, landed_state=self.landed, yaw_rad=self.yaw,
                height_m=1.2 if self.armed else 0.14, safety_level=self.level,
                safety_faults=self.faults, target_fresh=self.tracker_alive)
        if self.person is not None:
            d = (self.person - math.degrees(self.yaw) + 180) % 360 - 180
            if abs(d) < HFOV / 2:
                o.target_state, o.target_id = m.TGT_TRACKING, 1
                o.error_x_norm = -d / (HFOV / 2)
                self.last_side = 0 if abs(o.error_x_norm) < 0.1 else (
                    1 if o.error_x_norm > 0 else -1)
                self.lost_for = 0.0
            elif self.lost_for < 3.0:
                o.target_state, o.target_id = m.TGT_LOST, 1
        o.last_seen_side = self.last_side
        return o

    def run(self, mission, seconds, handler=None, dt=0.1):
        end = self.t + seconds
        step = None
        while self.t < end and not mission.done:
            step = mission.step(self.t, self.obs())
            if step.command is not None:
                self.commands.append((self.t, step.state, step.command))
                if step.command[0] == m.MODE_BODY_VELOCITY and self.level <= m.LEVEL_DEGRADED:
                    self.yaw = m.wrap_rad(self.yaw + step.command[1] * dt)
            if step.request is not None:
                self.requests.append(step.request[0])
                (handler or self.default)(mission, step.request)
            self.t += dt
            self.lost_for += dt
        return step

    def default(self, mission, req):
        kind = req[0]
        if kind == m.PREFLIGHT_REQ:
            mission.ack(kind, True)
        elif kind == m.TAKEOFF_REQ:
            self.armed, self.landed, self.mode = True, m.LANDED_IN_AIR, 'GUIDED'
            mission.ack(kind, True, 'hovering')
        elif kind == m.LAND_REQ:
            self.armed, self.landed, self.mode = False, m.LANDED_ON_GROUND, 'LAND'
            mission.ack(kind, True, 'landed and disarmed')


CFG = MissionConfig()


def states(sim):
    out = []
    for _, s, _ in sim.commands:
        if not out or out[-1] != s:
            out.append(s)
    return out


def test_yaw_sign_person_right_turn_right():
    assert track_yaw_rate(0.5, 0.5, 0.05, 1.0) < 0
    assert track_yaw_rate(-0.5, 0.5, 0.05, 1.0) > 0
    assert track_yaw_rate(0.03, 0.5, 0.05, 1.0) == 0.0
    assert track_yaw_rate(5.0, 0.5, 0.05, 0.3) == -0.3


def test_goal_validation():
    ground = Sim().obs()
    assert validate_goal(CFG, Goal(), ground) == []
    assert validate_goal(CFG, Goal(target_class='dog'), ground)
    assert validate_goal(CFG, Goal(autonomous_takeoff=False), ground)
    air = Sim(airborne=True).obs()
    assert validate_goal(CFG, Goal(autonomous_takeoff=False), air) == []
    assert validate_goal(CFG, Goal(), air)                      # takeoff while flying
    latched = Sim().obs()
    latched.safety_latched = True
    assert validate_goal(CFG, Goal(), latched)
    stale = Sim().obs()
    stale.safety_fresh = False
    assert validate_goal(CFG, Goal(), stale)


def test_full_mission_search_find_track_return_land():
    sim = Sim(person_bearing=90.0)                               # 90 deg to the LEFT
    mis = Mission(CFG, Goal(track_duration_s=5.0), 0.0)
    sim.run(mis, 120)
    assert mis.done and mis.result.outcome == m.OUTCOME_COMPLETED
    assert mis.state == m.MISSION_COMPLETE and mis.result.landed_and_disarmed
    assert sim.requests == ['PREFLIGHT', 'TAKEOFF', 'LAND']
    seq = states(sim)
    for a, b in [(m.SEARCHING, m.PERSON_DETECTED), (m.PERSON_DETECTED, m.TARGET_SELECTED),
                 (m.TARGET_SELECTED, m.TRACKING), (m.TRACKING, m.RETURNING)]:
        assert seq.index(a) < seq.index(b)
    # after tracking, it turned back to the start heading before landing
    assert abs(math.degrees(sim.yaw)) < CFG.return_yaw_tol_deg + 1
    # searched CCW (positive yaw rate) and never commanded translation
    search_rates = [c[2][1] for c in sim.commands if c[1] == m.SEARCHING
                    and c[2][0] == m.MODE_BODY_VELOCITY]
    assert search_rates and all(r > 0 for r in search_rates)


def test_tracking_centres_the_person():
    sim = Sim(person_bearing=20.0, airborne=True)
    mis = Mission(CFG, Goal(autonomous_takeoff=False, track_duration_s=8.0,
                            land_on_finish=False), 0.0)
    sim.run(mis, 7.0)
    assert mis.state == m.TRACKING
    assert abs(20.0 - math.degrees(sim.yaw)) < 3.0


def test_returns_to_start_heading_then_lands():
    sim = Sim(person_bearing=60.0, airborne=True)
    mis = Mission(CFG, Goal(autonomous_takeoff=False, track_duration_s=3.0), 0.0)
    sim.run(mis, 60)
    assert mis.result.outcome == m.OUTCOME_COMPLETED
    assert abs(math.degrees(sim.yaw)) <= CFG.return_yaw_tol_deg + 0.5
    assert sim.requests[-1] == 'LAND'


def test_nobody_found_by_yaw_limit():
    sim = Sim(person_bearing=None, airborne=True)
    mis = Mission(CFG, Goal(autonomous_takeoff=False), 0.0)
    sim.run(mis, 120)
    assert mis.result.outcome == m.OUTCOME_TARGET_NOT_FOUND
    assert 'deg of turning' in mis.result.message and mis.result.landed_and_disarmed


def test_nobody_found_by_timeout():
    sim = Sim(person_bearing=None, airborne=True)
    mis = Mission(CFG, Goal(autonomous_takeoff=False, search_timeout_s=5.0), 0.0)
    sim.run(mis, 60)
    assert mis.result.outcome == m.OUTCOME_TARGET_NOT_FOUND
    assert 'in 5 s' in mis.result.message


def test_search_timeout_is_clamped():
    mis = Mission(CFG, Goal(search_timeout_s=10000.0, takeoff_altitude_m=9.0), 0.0)
    assert mis.search_timeout_s == CFG.max_search_timeout_s
    assert mis.altitude_m == CFG.max_takeoff_alt_m


def test_lost_then_reacquired_by_turning_towards_last_side():
    sim = Sim(person_bearing=0.0, airborne=True)
    mis = Mission(CFG, Goal(autonomous_takeoff=False, track_duration_s=60.0), 0.0)
    sim.run(mis, 3.0)
    assert mis.state == m.TRACKING
    sim.person = -45.0                  # jumps out of view to the RIGHT
    sim.last_side = 1
    sim.run(mis, 0.5)
    sim.run(mis, 8.0)
    seq = states(sim)
    assert m.TARGET_LOST in seq and m.REACQUIRING in seq
    reacq = [c[2][1] for c in sim.commands if c[1] == m.REACQUIRING
             and c[2][0] == m.MODE_BODY_VELOCITY]
    assert reacq and all(r < 0 for r in reacq)            # turned RIGHT
    assert mis.state == m.TRACKING


def test_lost_for_good_ends_target_lost():
    sim = Sim(person_bearing=0.0, airborne=True)
    mis = Mission(CFG, Goal(autonomous_takeoff=False, track_duration_s=60.0), 0.0)
    sim.run(mis, 3.0)
    sim.person = None
    sim.run(mis, 120)
    assert mis.result.outcome == m.OUTCOME_TARGET_LOST
    assert mis.reacquire_attempts == 1 and 'target lost; nobody found' in mis.result.message


def test_repeated_losses_use_up_reacquire_attempts():
    sim = Sim(person_bearing=0.0, airborne=True)
    mis = Mission(CFG, Goal(autonomous_takeoff=False, track_duration_s=120.0), 0.0)
    for _ in range(CFG.max_reacquire_attempts + 1):
        sim.run(mis, 3.0)                       # tracking
        assert mis.state == m.TRACKING
        sim.person = None
        sim.run(mis, 0.5 + CFG.lost_hold_s + 0.5)
        sim.person = math.degrees(sim.yaw)      # back in front of the drone
    sim.person = None
    sim.run(mis, 60)
    assert mis.result.outcome == m.OUTCOME_TARGET_LOST
    assert mis.reacquire_attempts == CFG.max_reacquire_attempts


def test_preflight_fails_stays_on_ground():
    sim = Sim(person_bearing=0.0)
    mis = Mission(CFG, Goal(), 0.0)

    def refuse(mission, req):
        mission.ack(req[0], False, 'PF5 BATTERY: 12.0 V')
    sim.run(mis, 5, refuse)
    assert mis.result.outcome == m.OUTCOME_PREFLIGHT_FAILED and 'PF5' in mis.result.message
    assert sim.requests == ['PREFLIGHT'] and not sim.armed


def test_takeoff_fails_waits_for_disarm():
    sim = Sim(person_bearing=0.0)
    mis = Mission(CFG, Goal(), 0.0)

    def handler(mission, req):
        if req[0] == m.PREFLIGHT_REQ:
            mission.ack(req[0], True)
        else:
            sim.armed, sim.landed = True, m.LANDED_ON_GROUND      # armed, still disarming
            mission.ack(req[0], False, 'no climb within 5 s; landed and disarmed')
    sim.run(mis, 1.0, handler)
    assert not mis.done and mis.state == m.TAKING_OFF
    sim.armed = False
    sim.run(mis, 1.0, handler)
    assert mis.result.outcome == m.OUTCOME_TAKEOFF_FAILED and mis.state == m.IDLE


def test_cancel_in_air_lands():
    sim = Sim(person_bearing=None, airborne=True)
    mis = Mission(CFG, Goal(autonomous_takeoff=False), 0.0)
    sim.run(mis, 2.0)
    mis.cancel()
    sim.run(mis, 5.0)
    assert mis.result.outcome == m.OUTCOME_CANCELLED and mis.state == m.MISSION_CANCELLED
    assert sim.requests == ['LAND'] and mis.result.landed_and_disarmed


def test_cancel_hover_option():
    cfg = MissionConfig(on_cancel='hover')
    sim = Sim(person_bearing=None, airborne=True)
    mis = Mission(cfg, Goal(autonomous_takeoff=False), 0.0)
    sim.run(mis, 1.0)
    mis.cancel()
    sim.run(mis, 1.0)
    assert mis.result.outcome == m.OUTCOME_CANCELLED and sim.armed and sim.requests == []


def test_cancel_before_takeoff():
    sim = Sim()
    mis = Mission(CFG, Goal(), 0.0)
    mis.cancel()
    sim.run(mis, 1.0)
    assert mis.state == m.MISSION_CANCELLED and not sim.armed


def test_override_is_terminal_and_silent():
    sim = Sim(person_bearing=0.0, airborne=True)
    mis = Mission(CFG, Goal(autonomous_takeoff=False), 0.0)
    sim.run(mis, 2.0)
    sim.level = m.LEVEL_OVERRIDE
    n = len(sim.commands)
    sim.run(mis, 2.0)
    assert mis.state == m.MANUAL_OVERRIDE and mis.result.outcome == m.OUTCOME_MANUAL_OVERRIDE
    assert len(sim.commands) == n and sim.requests == []


def test_safety_abort_waits_for_safety_landing():
    sim = Sim(person_bearing=None, airborne=True)
    mis = Mission(CFG, Goal(autonomous_takeoff=False), 0.0)
    sim.run(mis, 2.0)
    sim.level, sim.faults = m.LEVEL_ABORT, ('BATTERY_LAND: 13.9 V',)
    sim.run(mis, 2.0)
    assert mis.state == m.SAFETY_STOP and not mis.done and sim.requests == []
    assert all(c[2] == m.HOLD_CMD for c in sim.commands if c[1] == m.SAFETY_STOP)
    sim.armed, sim.landed = False, m.LANDED_ON_GROUND
    sim.run(mis, 1.0)
    assert mis.result.outcome == m.OUTCOME_SAFETY_STOP and 'BATTERY' in mis.result.message


def test_safety_hold_pauses_motion():
    sim = Sim(person_bearing=None, airborne=True)
    mis = Mission(CFG, Goal(autonomous_takeoff=False), 0.0)
    sim.run(mis, 1.0)
    sim.level = m.LEVEL_HOLD
    yaw = sim.yaw
    sim.run(mis, 2.0)
    assert sim.yaw == yaw and mis.state == m.SEARCHING
    assert sim.commands[-1][2] == m.HOLD_CMD


def test_perception_silent_ends_mission():
    sim = Sim(person_bearing=None, airborne=True)
    mis = Mission(CFG, Goal(autonomous_takeoff=False), 0.0)
    sim.run(mis, 1.0)
    sim.tracker_alive = False
    sim.run(mis, 60.0)
    assert mis.result.outcome == m.OUTCOME_ERROR and 'perception' in mis.result.message
    assert mis.state == m.ERROR and mis.result.landed_and_disarmed


def test_land_refused_is_an_error():
    sim = Sim(person_bearing=None, airborne=True)
    mis = Mission(CFG, Goal(autonomous_takeoff=False, search_timeout_s=2.0), 0.0)

    def refuse_land(mission, req):
        mission.ack(req[0], False, 'LAND NOT ACCEPTED: take manual control')
    sim.run(mis, 60.0, refuse_land)
    assert mis.state == m.ERROR and 'manual' in mis.result.message


def test_streams_every_tick_while_airborne():
    sim = Sim(person_bearing=30.0, airborne=True)
    mis = Mission(CFG, Goal(autonomous_takeoff=False, track_duration_s=4.0), 0.0)
    ticks = 0
    while not mis.done and sim.t < 60:
        before = len(sim.commands)
        sim.run(mis, 0.1)
        ticks += 1
        if sim.armed and not mis.done and mis.state != m.LANDING:
            assert len(sim.commands) == before + 1
    assert mis.done


@pytest.mark.parametrize('rm', ['land_in_place', 'yaw_to_start_then_land'])
def test_return_modes(rm):
    sim = Sim(person_bearing=60.0, airborne=True)
    mis = Mission(MissionConfig(return_mode=rm), Goal(autonomous_takeoff=False,
                                                       track_duration_s=3.0), 0.0)
    sim.run(mis, 60)
    assert mis.result.outcome == m.OUTCOME_COMPLETED
    if rm == 'land_in_place':
        assert abs(math.degrees(sim.yaw) - 60) < 5
    else:
        assert abs(math.degrees(sim.yaw)) < 6


def test_no_landing_when_land_on_finish_false():
    sim = Sim(person_bearing=None, airborne=True)
    mis = Mission(CFG, Goal(autonomous_takeoff=False, search_timeout_s=3.0,
                            land_on_finish=False), 0.0)
    sim.run(mis, 60)
    assert mis.result.outcome == m.OUTCOME_TARGET_NOT_FOUND and sim.armed
    assert 'LAND' not in sim.requests
