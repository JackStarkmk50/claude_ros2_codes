# Phase 12: the SearchAndTrack mission

**Goal:** one command runs the whole autonomous mission:

`pre-flight → take off → turn to search → person found → turn to keep them centred for N seconds
→ turn back to the start heading → land → disarm confirmed`

The drone only **turns on the spot**. It never flies towards anyone. ArduPilot holds position on
the optical flow sensor, and the safety gate forces all forward/sideways/up/down speeds to zero.
Takeoff and landing are the Phase 8 operations, re-checked by the safety layer every time.

**Safety [AIRCRAFT]:** this phase contains **no real flight**. Steps 1 to 4 are bench and
props-off. The first real mission is described at the end as a separate step, after conditions
you have to meet first.

---

## What is new

| File | What it does |
|---|---|
| `mission_manager` (real now) | action `/drone/mission/search_and_track`, status on `/drone/mission/status`, yaw commands on `/drone/control/command` (→ safety gate) |
| `drone_mission/core/mission.py` | the mission state machine, 25 unit tests with a simulated drone and person |
| `tools/mission.py` | `start` (options `--track`, `--search`, `--alt`, `--in-air`, `--no-land`), `watch`. Ctrl-C cancels, and the drone lands |
| `drone.yaml` → `mission_manager` | search 15 deg/s, up to 360 deg or 60 s; track gain 0.5, max 20 deg/s; lost → wait 1 s → look towards the last side (up to 45 deg or 5 s), 2 attempts; return to the start heading, then land |

**What the mission does in each situation**

| Situation | What happens | Result |
|---|---|---|
| person found | PERSON_DETECTED → TARGET_SELECTED → TRACKING (turns to keep them centred) | after `--track` s: turn back, land, COMPLETED |
| nobody after 360 deg or the search time | turn back to the start heading, land | TARGET_NOT_FOUND |
| person hides / leaves the picture | TARGET_LOST (hold 1 s) → REACQUIRING (turn towards the side they left) → TRACKING, or search again | COMPLETED, or TARGET_LOST |
| you press Ctrl-C (cancel) | lands at once | CANCELLED |
| you move the RC mode switch | the Pi stops sending anything, at once and for good | MANUAL_OVERRIDE (you fly) |
| safety ABORT (battery, flow, tilt, ...) | safety_supervisor lands. The mission only holds and waits | SAFETY_STOP |
| safety HOLD (e.g. height out of band) | the mission pauses (HOLD). After 5 s safety turns it into a landing | SAFETY_STOP if it lasts |
| tracker/camera silent for 2 s | turn back, land | ERROR |
| pre-flight fails | nothing moves, stays disarmed | PREFLIGHT_FAILED |
| takeoff fails (e.g. props off: no climb) | Phase 8 lands and disarms | TAKEOFF_FAILED |
| `mission_manager` dies in the air | its command stream stops. Safety: COMMAND_STALE → HOLD → after 5 s LAND | drone lands |

**One behaviour change to know:** while the drone hovers in GUIDED and no mission runs (for
example after `flight_op.py takeoff`), `mission_manager` now streams HOLD. That is the "Pi is
alive" signal. If `mission_manager` dies during such a hover, safety lands the drone after about
5 s instead of hovering forever.

**Tested in the simulator** (real ArduCopter 4.6.3 SITL, indoor setup, the whole stack including
YOLO and the tracker). The camera was the virtual room from `fake_camera.py`, with a real photo of
a person placed at a bearing. The view follows the simulated drone's heading, so the loop is
closed: the drone turns, the picture changes, YOLO sees the person move, the drone turns.

| Test | Result |
|---|---|
| M1 person 120 deg to the left | found after 89 deg of searching; tracked 15 s with the person centred (error median 0.04, max 0.05); turned back; landed and disarmed: **COMPLETED** |
| M2 person walking round the drone at 8 deg/s | followed for 20 s, person kept in view (steady error 0.28, the price of a gentle gain) → COMPLETED |
| M3 person hidden for 3 s | TARGET_LOST → REACQUIRING → TRACKING → COMPLETED |
| M4 nobody there | 360 deg search → turned back → landed: TARGET_NOT_FOUND |
| M5 cancel while tracking | landed and disarmed: CANCELLED |
| M6 pilot to LOITER while tracking | MANUAL_OVERRIDE; mode stayed LOITER, Pi silent; pilot landed |
| M7 battery 13.5 V while tracking | safety landed: SAFETY_STOP (BATTERY_LAND) |
| M8 tracker killed while tracking | lost → reacquire → perception silent → turned back → landed: ERROR |
| M9 mission_manager killed while searching | COMMAND_STALE → HOLD_TIMEOUT → LAND 5.4 s later, disarmed |
| M10 cancel right after arming, during takeoff | takeoff cancelled, disarmed on the ground within 2 s: **CANCELLED** |
| Phase 8 S1 again (operator takeoff/land, mission idle) | unchanged |

**Honest limits**
- A simulator and a pasted photo are not your room. Real YOLO on the Pi runs at maybe 8 to 15
  fps, not 30. The tracking gain may need tuning (`track_kp`) at the first real flight.
- "Return" only turns back to the start heading. It does not fly back to the start point: with
  flow only, position drifts, and flying "back" near walls would look precise without being so.
- The drone never approaches the person (`enable_approach: false`), by design in this scope.

---

## Step 1: update and check

```bash
cp ~/drone_ws/src/drone_bringup/config/drone.yaml ~/drone.yaml.mine
tar -xzf drone_ws_phase12.tar.gz -C ~/drone_ws --strip-components=1
python3 ~/drone_ws/tools/carry_settings.py ~/drone.yaml.mine
bash ~/drone_ws/tools/verify_workspace.sh
```

**EXPECTED** `Summary: 190 tests, 0 errors, 0 failures, 0 skipped` and `WORKSPACE CHECK: ALL PASSED`.

## Step 2: bench run, output OFF (the mission must refuse to fly)

**WHAT** the whole stack with camera and YOLO, but `fcu_command_node` in bench mode.

Terminal A (Pixhawk connected, USB or battery, props off):

```bash
source ~/drone_ws/env.sh
ros2 launch drone_bringup bringup.launch.py
```

Terminal B:

```bash
source ~/drone_ws/env.sh
python3 ~/drone_ws/tools/mission.py start --track 15 | tee ~/drone_ws/phase12_report.txt
```

**EXPECTED**

```
   0.0 s  PREFLIGHT ...
RESULT: PREFLIGHT_FAILED: pre-flight failed: PRE-FLIGHT FAILED: ... PF13 OUTPUT: bench mode ...
  after 0.x s, landed and disarmed: True
```

Nothing arms, nothing moves.

**IF NOT** anything other than PREFLIGHT_FAILED: stop and send me terminal A and B.

## Step 3: watch the mission see you (still output OFF)

**WHAT** with the drone on the table, check that the mission's eyes work: tracker and status.

```bash
python3 ~/drone_ws/tools/track_check.py --watch
```

Walk in front of the camera: `TRACKING id N, error_x ...`. Ctrl-C to stop.

## Step 4: props-off mission [AIRCRAFT]

**WHAT** the real sequence on the real Pixhawk. **PROPS OFF**, 4S battery, RC on in STABILIZE,
estop in reach, EKF origin set (Phase 8). The Pi arms and commands a takeoff. Without props it
cannot climb, so Phase 8 lands and disarms. The mission must report TAKEOFF_FAILED.

Terminal A:

```bash
ros2 launch drone_bringup bringup.launch.py enable_fcu_output:=true allow_arming:=true
```

Terminal B:

```bash
python3 ~/drone_ws/tools/flight_op.py preflight
python3 ~/drone_ws/tools/mission.py start --track 15 | tee -a ~/drone_ws/phase12_report.txt
```

**EXPECTED**
- `PRE-FLIGHT OK`
- `PREFLIGHT`, `TAKING_OFF`. Motors spin up (loud) for up to 5 s, then LAND and disarm.
- `RESULT: TAKEOFF_FAILED: takeoff failed: no climb within 5 s of the takeoff command; landed and disarmed`

Then flip the mode switch to STABILIZE (Phase 8 step 8).

**Cancel check:** run `mission.py start` again (after `preflight` says OK). Press Ctrl-C during
`TAKING_OFF`. Expected: `Cancelling the mission ...`, then
`RESULT: CANCELLED: cancelled during takeoff: cancelled; ...` ending in `landed and disarmed` or
`disarmed on the ground` (or TAKEOFF_FAILED if the no-climb came first. All of these end disarmed).

**IF NOT** motors keep spinning more than 20 s: estop, then send me terminals A and B.

## Step 5: send the report

Upload `~/drone_ws/phase12_report.txt`.

---

## The first real mission (NOT part of this phase)

Only after **all** of these are done and reported:
1. The deferred Phase 5 flow test on battery, cable-free, and `flow_min_quality` tuned.
2. The FCU parameters from the end of Phase 8 set (your decision).
3. A first real Phase 8 takeoff/hover/land, tethered, you on the RC, with the physical yaw
   direction checked (a small yaw at the hover).

Then I will send a short flight card for the first mission: tethered, 1.0 m, `--track 15`,
`--search 30`, one person standing 3 m away in good light, you on the RC with a hand on the mode
switch. Every step on that card says what to watch and when to take over.
