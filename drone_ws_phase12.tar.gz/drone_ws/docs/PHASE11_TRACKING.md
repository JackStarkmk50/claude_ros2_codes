# Phase 11: target tracking

**Goal:** `target_tracker` turns YOLO's boxes into **one** selected person, the target, and says
at every moment where that person is in the picture, or that they are lost and on which side they
were last seen. The mission (Phase 12) steers only by this.

**Safety:** nothing here talks to the Pixhawk.

---

## What is new

| File | What it does |
|---|---|
| `target_tracker` (real now) | Publishes `/drone/perception/target` (`TrackedTarget`) 10 times a second, also when the detector is silent |
| `drone_perception/core/tracker.py` | matching boxes frame to frame, confirmation, selection, loss. 11 unit tests |
| `tools/track_check.py` | guided walk-through T1 to T6, writes `~/drone_ws/phase11_report.txt`. `--watch` prints the target once a second |
| `drone.yaml` → `target_tracker` | confirm 3 frames, lost after 1.0 s **[TUNE]**, forget after 3 s, selection `largest_bbox` |

**How the tracker behaves**

| State | Meaning |
|---|---|
| NONE | nobody selected, nobody being confirmed |
| CANDIDATE | a person is seen but not yet 3 frames in a row (filters out single false detections) |
| TRACKING | the target was seen within the last 1.0 s |
| LOST | the target has not been seen for 1.0 s. Kept up to 3 s with the side it was last seen on, so the drone knows which way to look |

- **Sticky:** once a person is selected, a bigger person walking in does not steal the target.
- **Selection:** the biggest box (usually the nearest person). On a tie, the one closest to the
  centre.
- **Coming back:** the same person returning to about the same place keeps their id. Anyone else,
  or someone returning later, becomes a new target (new id). Both are fine for the mission.
- **Fast turns:** at a few frames per second, a person can jump across the picture while the drone
  turns. Boxes are also matched when they don't overlap, if the centre moved less than a quarter of
  the image width and the size is similar.
- **Signs:** `error_x_norm` goes from −1 (left edge) to +1 (right edge). A person on the right
  gives a positive value, and the mission turns right.
- **Time:** the target carries the capture time of the picture that last saw it. Detections older
  than 0.5 s are ignored.

**Tested here:** 11 unit tests, plus the full chain `fake_camera → yolo_detector →
target_tracker`, with a virtual person walking from the drone's left to its right and out of the
picture. The error went smoothly from −0.21 to +0.84, the side from left to centre to right. The
target turned LOST 1.1 s after the person left on the right (last side right), and NONE after 3 s.

---

## Step 1: update and check

**COMMAND**

```bash
cp ~/drone_ws/src/drone_bringup/config/drone.yaml ~/drone.yaml.mine
tar -xzf drone_ws_phase11.tar.gz -C ~/drone_ws --strip-components=1
python3 ~/drone_ws/tools/carry_settings.py ~/drone.yaml.mine
bash ~/drone_ws/tools/verify_workspace.sh
```

**EXPECTED** `Summary: 163 tests, 0 errors, 0 failures, 0 skipped` and `WORKSPACE CHECK: ALL PASSED`.

## Step 2: start camera, detector and tracker (terminal A)

**COMMAND**

```bash
source ~/drone_ws/env.sh
ros2 launch drone_bringup perception.launch.py
```

**EXPECTED** `target_tracker ... up: person, confirm 3 frames, lost after 1.0 s, selection
largest_bbox`, then `target NONE: no person`. When someone walks in:
`target CANDIDATE id 1 ...`, then `target TRACKING id 1: tracking`.

**IF NOT** no `yolo_detector ... up:` line: go back to Phase 10 step 2 (model path).

## Step 3: the walk-through (terminal B)

**WHAT** you walk to places the tool asks for. It checks what the tracker says. Put the drone (or
just the camera) where it can see 3 to 4 m of open floor.

**"The drone's LEFT" is the left side of the camera picture. Facing the camera, that is YOUR
right.** This is the part that matters most: it decides which way the drone will turn.

**COMMAND**

```bash
source ~/drone_ws/env.sh
python3 ~/drone_ws/tools/track_check.py
```

| Step | You | Expected |
|---|---|---|
| T1 | nobody in the picture | NONE |
| T2 | stand in the middle, 2 to 4 m away | TRACKING, error_x near 0 |
| T3 | step to the drone's LEFT | TRACKING, error_x below −0.3 |
| T4 | step to the drone's RIGHT | TRACKING, error_x above +0.3 |
| T5 | walk out on the drone's RIGHT | LOST, last side right |
| T6 | come back to the middle | TRACKING again |

**EXPECTED** `TRACK CHECK: ALL PASSED`.

**IF NOT**
- T3 and T4 swapped (error_x has the opposite sign): the picture is mirrored. Check the Phase 9
  snapshot and tell me. **Do not continue to Phase 12** before this is right.
- T2 fails with CANDIDATE: YOLO finds you only now and then. Check the light, and the Phase 10
  numbers.
- T5 shows LOST but last side "centre": you left the picture too fast for the camera. Walk out
  more slowly and repeat.

## Step 4 (optional): two people

With a second person: both in the picture, the tracker keeps the one it selected first, even if
the other comes closer. Use `python3 ~/drone_ws/tools/track_check.py --watch` and check that the
id does not change while both are visible.

## Step 5: send the report

Upload `~/drone_ws/phase11_report.txt`.
