#!/usr/bin/env bash
# Ask ArduPilot to send the MAVLink messages this stack needs, at modest rates.
# Uses MAV_CMD_SET_MESSAGE_INTERVAL through MAVROS. This changes NO parameters: the rates live in
# FCU RAM and reset when the Pixhawk reboots (fcu_state_node will request them itself from Phase 4).
# It does not arm, move, or change modes. MAVROS must be running.
set -u

req() {  # req <msg_id> <hz> <name>
  local out
  out=$(ros2 service call /mavros/set_message_interval mavros_msgs/srv/MessageInterval \
        "{message_id: $1, message_rate: $2}" 2>&1)
  if echo "$out" | grep -q "success=True"; then
    printf 'PASS  %-20s %5s Hz\n' "$3" "$2"
  else
    printf 'FAIL  %-20s %5s Hz  (%s)\n' "$3" "$2" "$(echo "$out" | tail -1)"
  fi
}

req 30  10.0 ATTITUDE
req 32  10.0 LOCAL_POSITION_NED
req 100 10.0 OPTICAL_FLOW
req 173 10.0 RANGEFINDER
req 132 10.0 DISTANCE_SENSOR
req 193  2.0 EKF_STATUS_REPORT
req 1    2.0 SYS_STATUS
req 245  2.0 EXTENDED_SYS_STATE
req 147  1.0 BATTERY_STATUS
req 65   2.0 RC_CHANNELS
