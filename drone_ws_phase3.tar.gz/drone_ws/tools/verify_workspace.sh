#!/usr/bin/env bash
# Phase 2 check: clean build from scratch, then verify packages, interfaces, executables and tests.
# Touches nothing outside this workspace. Does not start MAVROS or talk to the Pixhawk.
set -eo pipefail

WS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$WS_DIR"

echo "== 1. clean build (removes build/ install/ log/)"
rm -rf build install log
source /opt/ros/jazzy/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash

fail=0
check() {  # check <description> <expected count> <actual count>
  if [ "$2" = "$3" ]; then echo "PASS  $1 ($3)"; else echo "FAIL  $1: expected $2, got $3"; fail=1; fi
}

echo "== 2. packages"
check "drone packages" 7 "$(ros2 pkg list | grep -c '^drone_')"

echo "== 3. interfaces"
check "drone_interfaces types" 9 "$(ros2 interface list | grep -c 'drone_interfaces/')"
ros2 interface show drone_interfaces/action/FlightOperation > /dev/null && echo "PASS  interface show FlightOperation"
python3 -c "from drone_interfaces.action import FlightOperation, SearchAndTrack" && echo "PASS  python import"

echo "== 4. executables"
check "drone executables" 7 "$(ros2 pkg executables | grep -c '^drone_')"

echo "== 5. tests"
colcon test --event-handlers console_direct- > /dev/null
colcon test-result --all | tail -1
colcon test-result > /dev/null || fail=1

if [ $fail = 0 ]; then echo "PHASE 2 CHECK: ALL PASSED"; else echo "PHASE 2 CHECK: FAILURES ABOVE"; exit 1; fi
