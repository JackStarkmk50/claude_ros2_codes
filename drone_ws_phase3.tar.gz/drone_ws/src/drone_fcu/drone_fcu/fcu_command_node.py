"""fcu_command_node:

The single output to MAVROS: validated setpoints and verified flight operations.

Phase 2 skeleton. It starts, loads its parameters from drone_bringup/config/drone.yaml,
logs what it loaded, and spins. It publishes and commands nothing. The real
behaviour is added in Phase 6.
"""

import rclpy
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node

from drone_interfaces.action import FlightOperation  # noqa: F401  (import check)
from drone_interfaces.msg import ControlCommand  # noqa: F401  (import check)


BUILTIN_PARAMETERS = ('use_sim_time', 'start_type_description_service')


class FcuCommandNode(Node):

    def __init__(self):
        super().__init__(
            'fcu_command_node',
            automatically_declare_parameters_from_overrides=True,
        )
        params = self.get_parameters_by_prefix('')
        loaded = sorted(name for name in params if name not in BUILTIN_PARAMETERS)
        self.get_logger().info(
            f'skeleton up (Phase 2), {len(loaded)} parameters loaded: '
            f'{", ".join(loaded) or "none"}'
        )
        output_enabled = self.get_parameter_or(
            'output_enabled', rclpy.Parameter('output_enabled', value=False)).value
        allow_arming = self.get_parameter_or(
            'allow_arming', rclpy.Parameter('allow_arming', value=False)).value
        self.get_logger().warn(
            f'BENCH SKELETON: output_enabled={output_enabled} allow_arming={allow_arming}. '
            'This Phase 2 node sends nothing to MAVROS regardless of these values.'
        )


def main(args=None):
    rclpy.init(args=args)
    node = FcuCommandNode()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        # A second Ctrl-C during cleanup (terminal + launch both send SIGINT) must not
        # print a traceback.
        try:
            node.destroy_node()
            rclpy.try_shutdown()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
