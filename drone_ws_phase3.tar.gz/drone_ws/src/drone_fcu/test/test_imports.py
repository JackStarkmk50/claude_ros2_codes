"""Every executable module imports cleanly and exposes main()."""


def test_node_modules_import():
    from drone_fcu import fcu_state_node  # noqa: F401
    from drone_fcu import fcu_command_node  # noqa: F401
    assert callable(fcu_state_node.main)
    assert callable(fcu_command_node.main)
