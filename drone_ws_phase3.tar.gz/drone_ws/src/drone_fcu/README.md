# drone_fcu

FCU layer: aggregates Pixhawk/ArduPilot state from MAVROS and is the only package that sends commands to MAVROS.

See `ARCHITECTURE.md` (§3 nodes, §4 topics, §5 services, §6 actions) for the full contract of this package.

| Executable | Responsibility | Implemented in |
|---|---|---|
| `fcu_state_node` | Aggregates MAVROS telemetry, EKF and optical-flow health into VehicleState and FlowStatus. | Phase 4 |
| `fcu_command_node` | The single output to MAVROS: validated setpoints and verified flight operations. | Phase 6 |

Current state: **Phase 2 skeleton.** Each node starts, loads its parameters from
`drone_bringup/config/drone.yaml`, logs them, and spins. It publishes and commands nothing.

Run one node on its own:

```bash
ros2 run drone_fcu fcu_state_node --ros-args --params-file $(ros2 pkg prefix drone_bringup)/share/drone_bringup/config/drone.yaml
```

Test:

```bash
colcon test --packages-select drone_fcu && colcon test-result --verbose
```
