# drone_safety

Safety supervisor: health checks, pre-flight validation, command gate, flight-operation gate and override handling.

See `ARCHITECTURE.md` (§3 nodes, §4 topics, §5 services, §6 actions) for the full contract of this package.

| Executable | Responsibility | Implemented in |
|---|---|---|
| `safety_supervisor` | Health checks, pre-flight validation, command gate, flight-operation gate, override handling. | Phase 6 |

Current state: **Phase 2 skeleton.** Each node starts, loads its parameters from
`drone_bringup/config/drone.yaml`, logs them, and spins. It publishes and commands nothing.

Run one node on its own:

```bash
ros2 run drone_safety safety_supervisor --ros-args --params-file $(ros2 pkg prefix drone_bringup)/share/drone_bringup/config/drone.yaml
```

Test:

```bash
colcon test --packages-select drone_safety && colcon test-result --verbose
```
