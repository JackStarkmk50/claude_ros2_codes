"""drone.yaml is valid, has a section for every node, and keeps the bench-mode defaults."""

import pathlib

import yaml

CONFIG = pathlib.Path(__file__).resolve().parents[1] / 'config' / 'drone.yaml'
NODES = [
    'fcu_state_node', 'fcu_command_node', 'safety_supervisor', 'yolo_detector',
    'target_tracker', 'mission_manager', 'intent_bridge',
]


def load():
    with open(CONFIG) as f:
        return yaml.safe_load(f)


def test_every_node_has_parameters():
    cfg = load()
    for node in NODES:
        assert 'ros__parameters' in cfg[node], node


def test_bench_mode_defaults():
    p = load()['fcu_command_node']['ros__parameters']
    assert p['output_enabled'] is False
    assert p['allow_arming'] is False


def test_translation_locked_in_current_scope():
    p = load()['safety_supervisor']['ros__parameters']
    assert p['max_horizontal_speed_mps'] == 0.0
    assert p['max_vertical_speed_mps'] == 0.0


def test_takeoff_altitudes_are_consistent():
    s = load()['safety_supervisor']['ros__parameters']
    m = load()['mission_manager']['ros__parameters']
    assert s['min_takeoff_alt_m'] <= m['default_takeoff_altitude_m'] <= s['max_takeoff_alt_m']
    assert s['max_takeoff_alt_m'] <= s['hard_ceiling_m'] - s['ceiling_margin_m']


def test_llm_off_until_phase_13():
    assert load()['intent_bridge']['ros__parameters']['llm_enabled'] is False
