"""Top-level launch: starts the stack in stages, each switchable by an argument.

Examples:
  ros2 launch drone_bringup bringup.launch.py                       # everything, bench mode
  ros2 launch drone_bringup bringup.launch.py use_perception:=false  # FCU + autonomy only

Bench mode is the default: enable_fcu_output and allow_arming are both false.
Setting either to true can affect the real aircraft.
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, LogInfo
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    launch_dir = os.path.join(get_package_share_directory('drone_bringup'), 'launch')
    default_config = os.path.join(
        get_package_share_directory('drone_bringup'), 'config', 'drone.yaml')

    args = [
        DeclareLaunchArgument('config', default_value=default_config,
                              description='Parameter file for all drone nodes'),
        DeclareLaunchArgument('use_fcu', default_value='true',
                              description='Start the FCU layer (state + command nodes)'),
        DeclareLaunchArgument('use_perception', default_value='true',
                              description='Start camera, YOLO and tracker'),
        DeclareLaunchArgument('use_autonomy', default_value='true',
                              description='Start safety supervisor and mission manager'),
        DeclareLaunchArgument('use_llm', default_value='true',
                              description='Start the intent bridge'),
        DeclareLaunchArgument('use_mavros', default_value='true',
                              description='Start MAVROS (the link to the Pixhawk)'),
        DeclareLaunchArgument('fcu_device', default_value='/dev/ttyAMA0',
                              description='Serial device wired to Pixhawk TELEM1'),
        DeclareLaunchArgument('fcu_baud', default_value='115200',
                              description='Must match SERIAL1_BAUD on the Pixhawk'),
        DeclareLaunchArgument('gcs_url', default_value='',
                              description='Optional GCS forward (adds serial link load)'),
        DeclareLaunchArgument('enable_fcu_output', default_value='false',
                              description='[AIRCRAFT] allow setpoints to be sent'),
        DeclareLaunchArgument('allow_arming', default_value='false',
                              description='[AIRCRAFT] allow arm and takeoff'),
    ]

    def include(name, condition, extra=None):
        launch_args = {'config': LaunchConfiguration('config')}
        launch_args.update(extra or {})
        return IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(launch_dir, name)),
            launch_arguments=launch_args.items(),
            condition=IfCondition(LaunchConfiguration(condition)),
        )

    return LaunchDescription(args + [
        LogInfo(msg=['drone bringup: enable_fcu_output=', LaunchConfiguration('enable_fcu_output'),
                     ' allow_arming=', LaunchConfiguration('allow_arming')]),
        include('fcu.launch.py', 'use_fcu', {
            'use_mavros': LaunchConfiguration('use_mavros'),
            'fcu_device': LaunchConfiguration('fcu_device'),
            'fcu_baud': LaunchConfiguration('fcu_baud'),
            'gcs_url': LaunchConfiguration('gcs_url'),
            'enable_fcu_output': LaunchConfiguration('enable_fcu_output'),
            'allow_arming': LaunchConfiguration('allow_arming'),
        }),
        include('autonomy.launch.py', 'use_autonomy', {
            'use_llm': LaunchConfiguration('use_llm'),
        }),
        include('perception.launch.py', 'use_perception'),
    ])
