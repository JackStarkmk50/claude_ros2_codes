"""Autonomy layer: safety_supervisor, mission_manager and (optionally) intent_bridge."""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    default_config = os.path.join(
        get_package_share_directory('drone_bringup'), 'config', 'drone.yaml')
    config = LaunchConfiguration('config')

    return LaunchDescription([
        DeclareLaunchArgument('config', default_value=default_config),
        DeclareLaunchArgument('use_llm', default_value='true'),
        Node(
            package='drone_safety', executable='safety_supervisor', name='safety_supervisor',
            parameters=[config], output='screen',
        ),
        Node(
            package='drone_mission', executable='mission_manager', name='mission_manager',
            parameters=[config], output='screen',
        ),
        Node(
            package='drone_llm', executable='intent_bridge', name='intent_bridge',
            parameters=[config], output='screen',
            condition=IfCondition(LaunchConfiguration('use_llm')),
        ),
    ])
