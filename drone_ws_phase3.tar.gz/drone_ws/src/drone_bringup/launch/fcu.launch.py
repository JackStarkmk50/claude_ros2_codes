"""FCU layer: MAVROS, fcu_state_node and fcu_command_node.

MAVROS connects to the Pixhawk on TELEM1 (SERIAL1). By default: /dev/ttyAMA0 at 115200.
MAVROS on its own only reads telemetry and sends a companion heartbeat; it commands nothing.
Commands only ever come from fcu_command_node, which is in bench mode by default.
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    share = get_package_share_directory('drone_bringup')
    default_config = os.path.join(share, 'config', 'drone.yaml')
    mavros_pluginlists = os.path.join(share, 'config', 'mavros_pluginlists.yaml')
    config = LaunchConfiguration('config')

    return LaunchDescription([
        DeclareLaunchArgument('config', default_value=default_config),
        DeclareLaunchArgument('use_mavros', default_value='true',
                              description='Start MAVROS (the link to the Pixhawk)'),
        DeclareLaunchArgument('fcu_device', default_value='/dev/ttyAMA0',
                              description='Serial device wired to Pixhawk TELEM1'),
        DeclareLaunchArgument('fcu_baud', default_value='115200',
                              description='Must match SERIAL1_BAUD on the Pixhawk'),
        DeclareLaunchArgument('fcu_url',
                              default_value=['serial://', LaunchConfiguration('fcu_device'),
                                             ':', LaunchConfiguration('fcu_baud')],
                              description='Full MAVROS FCU URL (overrides device + baud)'),
        DeclareLaunchArgument('gcs_url', default_value='',
                              description='Optional GCS forward, e.g. udp://@192.168.1.10:14550 '
                                          '(adds load on the serial link)'),
        DeclareLaunchArgument('enable_fcu_output', default_value='false',
                              description='[AIRCRAFT] allow setpoints to be sent'),
        DeclareLaunchArgument('allow_arming', default_value='false',
                              description='[AIRCRAFT] allow arm and takeoff'),

        # No namespace and no name override: MAVROS 2 then publishes /mavros/state etc.
        # (a namespace of 'mavros' produces /mavros/mavros/state). No respawn (ARCHITECTURE P16).
        Node(
            package='mavros', executable='mavros_node', output='screen',
            parameters=[
                {
                    'fcu_url': LaunchConfiguration('fcu_url'),
                    'gcs_url': LaunchConfiguration('gcs_url'),
                    'tgt_system': 1,
                    'tgt_component': 1,
                    'fcu_protocol': 'v2.0',
                },
                mavros_pluginlists,
            ],
            condition=IfCondition(LaunchConfiguration('use_mavros')),
        ),
        Node(
            package='drone_fcu', executable='fcu_state_node', name='fcu_state_node',
            parameters=[config], output='screen',
        ),
        Node(
            package='drone_fcu', executable='fcu_command_node', name='fcu_command_node',
            parameters=[config, {
                'output_enabled': ParameterValue(
                    LaunchConfiguration('enable_fcu_output'), value_type=bool),
                'allow_arming': ParameterValue(
                    LaunchConfiguration('allow_arming'), value_type=bool),
            }],
            output='screen',
        ),
    ])
