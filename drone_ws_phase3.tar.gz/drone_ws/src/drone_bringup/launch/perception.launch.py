"""Perception layer: yolo_detector and target_tracker.

The USB camera driver (v4l2_camera) and the static camera transform are added here in Phase 9.
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    default_config = os.path.join(
        get_package_share_directory('drone_bringup'), 'config', 'drone.yaml')
    config = LaunchConfiguration('config')

    return LaunchDescription([
        DeclareLaunchArgument('config', default_value=default_config),
        Node(
            package='drone_perception', executable='yolo_detector', name='yolo_detector',
            parameters=[config], output='screen', respawn=True, respawn_delay=2.0,
        ),
        Node(
            package='drone_perception', executable='target_tracker', name='target_tracker',
            parameters=[config], output='screen',
        ),
    ])
