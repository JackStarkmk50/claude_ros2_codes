# drone_perception

Perception: YOLO person detection (ONNX Runtime on CPU) and target tracking.

See `ARCHITECTURE.md` (§3 nodes, §4 topics, §5 services, §6 actions) for the full contract of this package.

| Executable | Responsibility | Implemented in |
|---|---|---|
| `yolo_detector` | Runs YOLO on the newest camera frame and publishes vision_msgs/Detection2DArray. | Phase 10 |
| `target_tracker` | Associates detections into tracks, selects the target, and reports loss. | Phase 11 |

Current state: **Phase 9.** The camera driver (`v4l2_camera`, started by `drone_bringup/perception.launch.py`) and the pure helpers in `core/` (image conversion, frame statistics, virtual room for tests) are in place. `yolo_detector` and `target_tracker` are still skeletons.

Run one node on its own:

```bash
ros2 run drone_perception yolo_detector --ros-args --params-file $(ros2 pkg prefix drone_bringup)/share/drone_bringup/config/drone.yaml
```

Test:

```bash
colcon test --packages-select drone_perception && colcon test-result --verbose
```
