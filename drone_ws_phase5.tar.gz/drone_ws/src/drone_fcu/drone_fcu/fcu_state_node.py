"""fcu_state_node: the Pi's single view of the flight controller.

Reads MAVROS telemetry and a few raw MAVLink messages, and publishes at 10 Hz:
  /drone/vehicle_state  (drone_interfaces/VehicleState)
  /drone/flow_status    (drone_interfaces/FlowStatus)
plus /diagnostics once per second (link load, stream rates, forwarded sensor traffic).

Read-only towards the aircraft. The only request it makes is MAV_CMD_SET_MESSAGE_INTERVAL
(through /mavros/set_message_interval), which sets telemetry rates in FCU RAM: no parameter
is written, nothing moves, and the rates reset when the Pixhawk reboots.

Raw MAVLink (from /uas1/mavlink_source) is used for what MAVROS has no plugin for here:
HEARTBEAT age, EKF_STATUS_REPORT, OPTICAL_FLOW and DISTANCE_SENSOR. Only frames from the
autopilot itself (fcu_sysid / fcu_compid) are used; frames the FCU forwards from other devices
(for example the MTF-01's own messages) are counted for diagnostics only.

Every value has an age. Anything older than its timeout is reported as invalid / NaN, never
as its last value.
"""

import math
import time

import rclpy
from diagnostic_msgs.msg import DiagnosticStatus
from diagnostic_updater import Updater
from geometry_msgs.msg import PoseStamped, TwistStamped
from mavros_msgs.msg import ExtendedState, Mavlink, RCIn, State, StatusText, SysStatus
from mavros_msgs.srv import MessageInterval
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, HistoryPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import BatteryState, Imu

from drone_fcu.core import ekf_flags
from drone_fcu.core import fcu_status
from drone_fcu.core import mavlink_decode as mav
from drone_fcu.core.flow_health import FlowConfig, FlowHealth
from drone_fcu.core.frames import enu_yaw_to_compass_deg, quaternion_to_euler
from drone_fcu.core.link_monitor import LinkMonitor, StreamRequester
from drone_interfaces.msg import FlowStatus, VehicleState

# Parameter defaults. drone_bringup/config/drone.yaml overrides them.
PARAMETERS = {
    'publish_rate_hz': 10.0,
    'telemetry_timeout_s': 1.0,       # 10 Hz streams: attitude, velocity, rangefinder
    'slow_stream_timeout_s': 1.5,     # 2 Hz streams: sys_status, extended_state, rc, battery
    'heartbeat_timeout_s': 2.0,
    'ekf_timeout_s': 2.0,
    'prearm_text_hold_s': 5.0,
    'flow_timeout_s': 0.5,
    'flow_min_quality': 100,
    'flow_quality_samples': 5,
    'flow_min_height_m': 0.3,
    'flow_max_height_m': 3.0,
    'fcu_sysid': 1,
    'fcu_compid': 1,
    'link_baud': 115200,
    'request_streams': True,
    'rate_attitude_hz': 10.0,
    'rate_local_position_hz': 10.0,
    'rate_optical_flow_hz': 10.0,
    'rate_distance_sensor_hz': 10.0,
    'rate_ekf_status_hz': 2.0,
    'rate_sys_status_hz': 2.0,
    'rate_extended_sys_state_hz': 2.0,
    'rate_rc_channels_hz': 2.0,
}

STREAM_PARAMETERS = {
    mav.ATTITUDE: 'rate_attitude_hz',
    mav.LOCAL_POSITION_NED: 'rate_local_position_hz',
    mav.OPTICAL_FLOW: 'rate_optical_flow_hz',
    mav.DISTANCE_SENSOR: 'rate_distance_sensor_hz',
    mav.EKF_STATUS_REPORT: 'rate_ekf_status_hz',
    mav.SYS_STATUS: 'rate_sys_status_hz',
    mav.EXTENDED_SYS_STATE: 'rate_extended_sys_state_hz',
    mav.RC_CHANNELS: 'rate_rc_channels_hz',
}

FRAMING_OK = 1
LINK_LOAD_WARN = 0.7

# MAVROS topics: BEST_EFFORT matches both reliable and best-effort publishers. VOLATILE means
# we never receive an old latched /mavros/state from before we started.
MAVROS_QOS = QoSProfile(depth=10, reliability=ReliabilityPolicy.BEST_EFFORT,
                        durability=DurabilityPolicy.VOLATILE, history=HistoryPolicy.KEEP_LAST)
RAW_QOS = QoSProfile(depth=100, reliability=ReliabilityPolicy.BEST_EFFORT,
                     durability=DurabilityPolicy.VOLATILE, history=HistoryPolicy.KEEP_LAST)
OUT_QOS = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                     durability=DurabilityPolicy.VOLATILE, history=HistoryPolicy.KEEP_LAST)


class Latest:
    """Last message of one kind and the steady-clock time it arrived."""

    def __init__(self):
        self.msg = None
        self.time = None

    def set(self, msg, now):
        self.msg = msg
        self.time = now

    def age(self, now):
        return now - self.time if self.time is not None else math.inf

    def fresh(self, now, timeout):
        return self.age(now) < timeout


class FcuStateNode(Node):

    def __init__(self):
        super().__init__('fcu_state_node')
        for name, default in PARAMETERS.items():
            self.declare_parameter(name, default)
        p = {name: self.get_parameter(name).value for name in PARAMETERS}
        self.p = p

        self.flow = FlowHealth(FlowConfig(
            timeout_s=p['flow_timeout_s'], min_quality=p['flow_min_quality'],
            quality_samples=p['flow_quality_samples'], min_height_m=p['flow_min_height_m'],
            max_height_m=p['flow_max_height_m']))
        self.link = LinkMonitor(window_s=5.0)
        self.streams = StreamRequester(
            {mid: float(p[name]) for mid, name in STREAM_PARAMETERS.items()})

        self.state = Latest()
        self.extended = Latest()
        self.sys_status = Latest()
        self.battery = Latest()
        self.imu = Latest()
        self.pose = Latest()
        self.velocity = Latest()
        self.rc = Latest()
        self.heartbeat = Latest()
        self.ekf = Latest()
        self.distance = Latest()
        self.prearm_text = Latest()

        self._connected = False
        self._last_mode = None
        self._last_armed = None
        self._last_vehicle = None
        self._last_flow = None
        self._request_queue = []
        self._request_in_flight = False
        self._reported_sources = set()
        self._reported_given_up = set()

        sub = self.create_subscription
        sub(State, '/mavros/state', self._on_state, MAVROS_QOS)
        sub(ExtendedState, '/mavros/extended_state', self._store(self.extended), MAVROS_QOS)
        sub(SysStatus, '/mavros/sys_status', self._store(self.sys_status), MAVROS_QOS)
        sub(BatteryState, '/mavros/battery', self._store(self.battery), MAVROS_QOS)
        sub(Imu, '/mavros/imu/data', self._store(self.imu), MAVROS_QOS)
        sub(PoseStamped, '/mavros/local_position/pose', self._store(self.pose), MAVROS_QOS)
        sub(TwistStamped, '/mavros/local_position/velocity_body', self._store(self.velocity),
            MAVROS_QOS)
        sub(RCIn, '/mavros/rc/in', self._store(self.rc), MAVROS_QOS)
        sub(StatusText, '/mavros/statustext/recv', self._on_statustext, MAVROS_QOS)
        sub(Mavlink, '/uas1/mavlink_source', self._on_raw, RAW_QOS)

        self.vehicle_pub = self.create_publisher(VehicleState, '/drone/vehicle_state', OUT_QOS)
        self.flow_pub = self.create_publisher(FlowStatus, '/drone/flow_status', OUT_QOS)
        self.interval_client = self.create_client(MessageInterval, '/mavros/set_message_interval')

        self.create_timer(1.0 / p['publish_rate_hz'], self._publish)
        self.create_timer(1.0, self._manage_streams)

        self.diag = Updater(self, period=1.0)
        self.diag.setHardwareID('pixhawk')
        self.diag.add('fcu_state: link', self._diag_link)
        self.diag.add('fcu_state: estimator and flow', self._diag_estimator)

        self.get_logger().info(
            f'up: publishing /drone/vehicle_state and /drone/flow_status at '
            f'{p["publish_rate_hz"]:.0f} Hz; FCU = sysid {p["fcu_sysid"]} compid '
            f'{p["fcu_compid"]}; stream requests {"on" if p["request_streams"] else "off"}')

    # ---------------------------------------------------------------- inputs

    def _store(self, latest):
        def callback(msg):
            latest.set(msg, time.monotonic())
        return callback

    def _on_state(self, msg):
        self.state.set(msg, time.monotonic())
        if msg.mode and msg.mode != self._last_mode:
            self.get_logger().info(f'FCU mode: {self._last_mode or "-"} -> {msg.mode}')
            self._last_mode = msg.mode
        if msg.armed != self._last_armed:
            self.get_logger().info(f'FCU {"ARMED" if msg.armed else "disarmed"}')
            self._last_armed = msg.armed

    def _on_statustext(self, msg):
        if msg.text.startswith('PreArm'):
            if self.prearm_text.msg != msg.text:
                self.get_logger().warn(f'FCU says: {msg.text}')
            self.prearm_text.set(msg.text, time.monotonic())

    def _on_raw(self, msg):
        now = time.monotonic()
        self.link.record(msg.sysid, msg.compid, msg.msgid, msg.len, now)
        if msg.framing_status != FRAMING_OK:
            return
        if msg.sysid != self.p['fcu_sysid'] or msg.compid != self.p['fcu_compid']:
            return
        if msg.msgid == mav.HEARTBEAT:
            self.heartbeat.set(True, now)
            return
        decoded = mav.decode(msg.msgid, msg.payload64, msg.len)
        if decoded is None:
            return
        if msg.msgid == mav.EKF_STATUS_REPORT:
            self.ekf.set(decoded, now)
        elif msg.msgid == mav.DISTANCE_SENSOR:
            if decoded.orientation == mav.ORIENTATION_DOWN:
                self.distance.set(decoded, now)
        elif msg.msgid == mav.OPTICAL_FLOW:
            self.flow.add_sample(decoded.quality, decoded.flow_rate_x, decoded.flow_rate_y,
                                 decoded.ground_distance, now)

    # ---------------------------------------------------------------- derived values

    def _height(self, now):
        """(height_m, valid) from the FCU's downward DISTANCE_SENSOR (cm)."""
        d = self.distance.msg
        if d is None or not self.distance.fresh(now, self.p['telemetry_timeout_s']):
            return math.nan, False
        if d.current_distance <= 0 or not d.min_distance <= d.current_distance <= d.max_distance:
            return math.nan, False
        return d.current_distance / 100.0, True

    def _is_connected(self, now):
        s = self.state.msg
        return (s is not None and s.connected
                and self.state.fresh(now, self.p['heartbeat_timeout_s'])
                and self.heartbeat.fresh(now, self.p['heartbeat_timeout_s']))

    # ---------------------------------------------------------------- outputs

    def _publish(self):
        now = time.monotonic()
        p = self.p
        stamp = self.get_clock().now().to_msg()
        v = VehicleState()
        v.header.stamp = stamp
        v.header.frame_id = 'base_link'

        connected = self._is_connected(now)
        if connected != self._connected:
            if connected:
                self.get_logger().info('FCU link up')
                self.streams.reset(now)
            else:
                self.get_logger().warn('FCU link LOST (no heartbeat)')
            self._connected = connected
        v.connected = connected
        v.heartbeat_age_s = float(self.heartbeat.age(now))

        s = self.state.msg
        if s is not None:
            v.armed = s.armed
            v.guided = s.mode == 'GUIDED'
            v.mode = s.mode
            v.system_status = s.system_status

        slow = p['slow_stream_timeout_s']
        fast = p['telemetry_timeout_s']
        if self.extended.fresh(now, slow):
            v.landed_state = self.extended.msg.landed_state
        else:
            v.landed_state = VehicleState.LANDED_UNDEFINED

        sys_bits = None
        if self.sys_status.fresh(now, slow):
            ss = self.sys_status.msg
            sys_bits = (ss.sensors_present, ss.sensors_health)
            v.fcu_prearm_ok = fcu_status.prearm_ok(*sys_bits)
        if self.prearm_text.fresh(now, p['prearm_text_hold_s']):
            v.last_prearm_text = self.prearm_text.msg

        if self.rc.fresh(now, slow):
            v.rc_present = fcu_status.rc_present(self.rc.msg.channels, sys_bits)

        v.battery_voltage_v = v.battery_current_a = v.battery_remaining = math.nan
        if self.battery.fresh(now, slow):
            b = self.battery.msg
            v.battery_voltage_v = float(b.voltage)
            v.battery_current_a = float(b.current) if b.current >= 0.0 else math.nan
            v.battery_remaining = float(b.percentage) if b.percentage >= 0.0 else math.nan

        v.roll_rad = v.pitch_rad = v.yaw_rad = math.nan
        if self.imu.fresh(now, fast):
            q = self.imu.msg.orientation
            v.roll_rad, v.pitch_rad, v.yaw_rad = quaternion_to_euler(q.x, q.y, q.z, q.w)

        v.velocity_valid = self.velocity.fresh(now, fast)
        if v.velocity_valid:
            v.velocity_body_flu = self.velocity.msg.twist.linear
        v.local_position_valid = self.pose.fresh(now, fast)
        if v.local_position_valid:
            v.local_position_enu = self.pose.msg.pose.position

        height, height_valid = self._height(now)
        v.height_above_ground_m = height
        v.height_valid = height_valid

        on_ground = not v.armed or v.landed_state == VehicleState.LANDED_ON_GROUND
        v.ekf_age_s = float(self.ekf.age(now))
        v.ekf_velocity_variance = v.ekf_pos_horiz_variance = math.nan
        if self.ekf.msg is not None:
            v.ekf_flags = self.ekf.msg.flags
        if self.ekf.fresh(now, p['ekf_timeout_s']):
            ekf = ekf_flags.evaluate(self.ekf.msg.flags, on_ground)
            v.ekf_attitude_ok = ekf.attitude_ok
            v.ekf_velocity_horiz_ok = ekf.velocity_horiz_ok
            v.ekf_pos_horiz_rel_ok = ekf.pos_horiz_rel_ok
            v.ekf_const_pos_mode = ekf.const_pos_mode
            v.ekf_velocity_variance = float(self.ekf.msg.velocity_variance)
            v.ekf_pos_horiz_variance = float(self.ekf.msg.pos_horiz_variance)

        verdict = self.flow.evaluate(now, height, height_valid,
                                     ekf_attitude_ok=v.ekf_attitude_ok,
                                     ekf_velocity_ok=v.ekf_velocity_horiz_ok)
        f = FlowStatus()
        f.header.stamp = stamp
        f.header.frame_id = 'base_link'
        f.source_seen = verdict.source_seen
        f.age_s = float(verdict.age_s)
        f.fresh = verdict.fresh
        f.quality = max(0, min(255, verdict.quality))
        f.quality_ok = verdict.quality_ok
        f.quality_applies = verdict.quality_applies
        f.flow_rate_x_rad_s = verdict.flow_rate_x_rad_s
        f.flow_rate_y_rad_s = verdict.flow_rate_y_rad_s
        f.ground_distance_m = verdict.ground_distance_m
        f.in_valid_height_band = verdict.in_valid_height_band
        f.healthy_for_flight = verdict.healthy_for_flight
        f.healthy_for_takeoff = verdict.healthy_for_takeoff
        f.reason = verdict.reason

        self.vehicle_pub.publish(v)
        self.flow_pub.publish(f)
        self._last_vehicle = v
        self._last_flow = f

    # ---------------------------------------------------------------- stream rates

    def _fcu_last_seen(self, msgid):
        return self.link.last_seen(self.p['fcu_sysid'], self.p['fcu_compid'], msgid)

    def _manage_streams(self):
        if not self.p['request_streams'] or not self._connected:
            return
        now = time.monotonic()
        self._request_queue.extend(self.streams.due(now, self._fcu_last_seen))
        self._send_next_request()
        for mid in self.streams.given_up(now, self._fcu_last_seen):
            if mid not in self._reported_given_up:
                self._reported_given_up.add(mid)
                self.get_logger().warn(
                    f'FCU does not send {mav.MESSAGE_NAMES.get(mid, mid)} after '
                    f'{self.streams.max_attempts} requests')

    def _send_next_request(self):
        # One request at a time: every request is the same COMMAND_LONG id, and MAVROS
        # matches acks to requests by command id.
        if self._request_in_flight or not self._request_queue:
            return
        if not self.interval_client.service_is_ready():
            return
        msgid, hz = self._request_queue.pop(0)
        self._request_in_flight = True
        future = self.interval_client.call_async(
            MessageInterval.Request(message_id=msgid, message_rate=float(hz)))
        future.add_done_callback(lambda fut, m=msgid, r=hz: self._on_request_done(fut, m, r))

    def _on_request_done(self, future, msgid, hz):
        self._request_in_flight = False
        name = mav.MESSAGE_NAMES.get(msgid, str(msgid))
        try:
            ok = future.result().success
        except Exception as exc:  # noqa: BLE001  (service went away; report and move on)
            ok = False
            self.get_logger().warn(f'stream request {name}: {exc}')
        if ok:
            self.get_logger().info(f'stream requested: {name} at {hz:g} Hz')
        else:
            self.get_logger().warn(f'stream request refused by FCU: {name} at {hz:g} Hz')
        self._send_next_request()

    # ---------------------------------------------------------------- diagnostics

    def _diag_link(self, stat):
        now = time.monotonic()
        rates = self.link.rates(now)
        fcu = (self.p['fcu_sysid'], self.p['fcu_compid'])
        total_bytes = sum(bps for _, bps in rates.values())
        capacity = self.p['link_baud'] / 10.0
        load = total_bytes / capacity if capacity > 0 else 0.0

        if not self._connected:
            stat.summary(DiagnosticStatus.ERROR, 'FCU not connected')
        elif load > LINK_LOAD_WARN:
            stat.summary(DiagnosticStatus.WARN, f'link load {load:.0%} of {self.p["link_baud"]}')
        else:
            stat.summary(DiagnosticStatus.OK, f'connected, link load {load:.0%}')
        stat.add('heartbeat_age_s', f'{self.heartbeat.age(now):.2f}')
        stat.add('link_load', f'{load:.0%} ({total_bytes:.0f} B/s of {capacity:.0f})')
        for mid in sorted(STREAM_PARAMETERS):
            hz = rates.get(fcu + (mid,), (0.0, 0.0))[0]
            wanted = self.p[STREAM_PARAMETERS[mid]]
            stat.add(f'fcu {mav.MESSAGE_NAMES[mid]}', f'{hz:.1f} Hz (want {wanted:g})')
        given_up = self.streams.given_up(now, self._fcu_last_seen)
        if given_up and self._connected:
            names = ', '.join(mav.MESSAGE_NAMES.get(m, str(m)) for m in given_up)
            stat.mergeSummary(DiagnosticStatus.WARN, f'FCU does not send: {names}')

        for (sysid, compid, mid), (hz, bps) in sorted(rates.items()):
            if (sysid, compid) == fcu:
                continue
            name = mav.MESSAGE_NAMES.get(mid, str(mid))
            stat.add(f'forwarded {sysid}/{compid} {name}', f'{hz:.1f} Hz, {bps:.0f} B/s')
            if (sysid, compid, mid) not in self._reported_sources:
                self._reported_sources.add((sysid, compid, mid))
                self.get_logger().info(
                    f'FCU forwards {name} from another device (sysid {sysid} compid {compid}); '
                    f'not used, counted as link load (rate in /diagnostics)')
        return stat

    def _diag_estimator(self, stat):
        now = time.monotonic()
        v = self._last_vehicle
        f = self._last_flow
        if v is None or f is None:
            stat.summary(DiagnosticStatus.STALE, 'nothing published yet')
            return stat
        if not self.ekf.fresh(now, self.p['ekf_timeout_s']):
            stat.summary(DiagnosticStatus.ERROR, 'no EKF_STATUS_REPORT')
        elif not f.healthy_for_flight:
            stat.summary(DiagnosticStatus.WARN, f'flow not flight-ready: {f.reason}')
        else:
            stat.summary(DiagnosticStatus.OK, 'EKF and flow healthy')
        stat.add('ekf_flags', f'{v.ekf_flags} ({ekf_flags.describe(v.ekf_flags)})')
        stat.add('ekf_age_s', f'{v.ekf_age_s:.2f}')
        stat.add('flow_quality', str(f.quality))
        stat.add('height_m', f'{v.height_above_ground_m:.2f}' if v.height_valid else 'invalid')
        if not math.isnan(v.yaw_rad):
            stat.add('heading_deg', f'{enu_yaw_to_compass_deg(v.yaw_rad):.0f}')
        stat.add('healthy_for_takeoff', str(f.healthy_for_takeoff))
        stat.add('healthy_for_flight', str(f.healthy_for_flight))
        return stat


def main(args=None):
    rclpy.init(args=args)
    node = FcuStateNode()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        # A second Ctrl-C during cleanup (terminal + launch both send SIGINT) must not
        # print a traceback.
        try:
            node.destroy_node()
            rclpy.try_shutdown()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
