"""Decode the few MAVLink messages fcu_state_node reads from MAVROS's raw stream.

MAVROS publishes every frame it receives from the FCU link on /uas1/mavlink_source as
mavros_msgs/Mavlink, with the payload packed into little-endian uint64 words. MAVLink 2 drops
trailing zero bytes from a payload, so the payload is padded back to full length before
unpacking. Field order is MAVLink wire order (largest types first); test_mavlink_decode.py
checks every layout against pymavlink.
"""

import struct
from collections import namedtuple

HEARTBEAT = 0
SYS_STATUS = 1
ATTITUDE = 30
LOCAL_POSITION_NED = 32
RC_CHANNELS = 65
OPTICAL_FLOW = 100
DISTANCE_SENSOR = 132
EKF_STATUS_REPORT = 193
EXTENDED_SYS_STATE = 245

MESSAGE_NAMES = {
    HEARTBEAT: 'HEARTBEAT', SYS_STATUS: 'SYS_STATUS', ATTITUDE: 'ATTITUDE',
    LOCAL_POSITION_NED: 'LOCAL_POSITION_NED', RC_CHANNELS: 'RC_CHANNELS',
    OPTICAL_FLOW: 'OPTICAL_FLOW', DISTANCE_SENSOR: 'DISTANCE_SENSOR',
    EKF_STATUS_REPORT: 'EKF_STATUS_REPORT', EXTENDED_SYS_STATE: 'EXTENDED_SYS_STATE',
}

# MAV_SENSOR_ORIENTATION for a sensor pointing down (ArduPilot RNGFNDx_ORIENT default).
ORIENTATION_DOWN = 25

EkfStatusReport = namedtuple('EkfStatusReport', [
    'velocity_variance', 'pos_horiz_variance', 'pos_vert_variance', 'compass_variance',
    'terrain_alt_variance', 'flags'])

DistanceSensor = namedtuple('DistanceSensor', [
    'time_boot_ms', 'min_distance', 'max_distance', 'current_distance', 'type', 'id',
    'orientation', 'covariance'])

OpticalFlow = namedtuple('OpticalFlow', [
    'time_usec', 'flow_comp_m_x', 'flow_comp_m_y', 'ground_distance', 'flow_x', 'flow_y',
    'sensor_id', 'quality', 'flow_rate_x', 'flow_rate_y'])

_LAYOUTS = {
    EKF_STATUS_REPORT: (struct.Struct('<5fH'), EkfStatusReport),
    DISTANCE_SENSOR: (struct.Struct('<I3H4B'), DistanceSensor),
    # includes the MAVLink 2 extension fields flow_rate_x / flow_rate_y (0 if not sent)
    OPTICAL_FLOW: (struct.Struct('<Q3f2h2B2f'), OpticalFlow),
}


def payload_bytes(payload64, length):
    """The payload bytes of a mavros_msgs/Mavlink message (payload64 words, len)."""
    words = list(payload64)
    return struct.pack(f'<{len(words)}Q', *words)[:length]


def decode(msgid, payload64, length):
    """Decoded namedtuple for a supported message id, or None."""
    layout = _LAYOUTS.get(msgid)
    if layout is None:
        return None
    fmt, kind = layout
    raw = payload_bytes(payload64, length).ljust(fmt.size, b'\0')[:fmt.size]
    return kind._make(fmt.unpack(raw))
